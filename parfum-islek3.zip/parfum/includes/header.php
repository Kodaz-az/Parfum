<?php
/**
 * Header Template - Enhanced Mobile Navigation
 * Kodaz-az - 2025-07-21 15:00:39 (UTC)
 * Login: Kodaz-az
 */

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
$currentPage = $_GET['page'] ?? 'dashboard';
$userRole = $_SESSION['role'] ?? 'guest';
$userName = $_SESSION['full_name'] ?? 'İstifadəçi';
$userAvatar = $_SESSION['avatar'] ?? '';

// Page title fallback
if (!isset($pageTitle)) {
    $pageTitle = PWA_NAME;
}

// Navigation menu items
$navigationItems = [
    'dashboard' => ['icon' => 'fas fa-home', 'title' => 'Ana Səhifə', 'roles' => ['admin', 'manager', 'seller']],
    'sales' => ['icon' => 'fas fa-shopping-cart', 'title' => 'Satışlar', 'roles' => ['admin', 'manager', 'seller']],
    'products' => ['icon' => 'fas fa-box', 'title' => 'Məhsullar', 'roles' => ['admin', 'manager', 'seller']],
    'reports' => ['icon' => 'fas fa-chart-bar', 'title' => 'Hesabatlar', 'roles' => ['admin', 'manager']],
    'users' => ['icon' => 'fas fa-users', 'title' => 'İstifadəçilər', 'roles' => ['admin', 'manager']],
    'salary' => ['icon' => 'fas fa-money-bill-wave', 'title' => 'Maaş', 'roles' => ['admin', 'manager', 'seller']],
    'chat' => ['icon' => 'fas fa-comments', 'title' => 'Chat', 'roles' => ['admin', 'manager', 'seller']],
    'calls' => ['icon' => 'fas fa-phone', 'title' => 'Zənglər', 'roles' => ['admin', 'manager', 'seller']],
    'support' => ['icon' => 'fas fa-headset', 'title' => 'Support', 'roles' => ['admin', 'manager']],
    'settings' => ['icon' => 'fas fa-cog', 'title' => 'Tənzimləmələr', 'roles' => ['admin']],
];

// Filter navigation based on user role
$filteredNavigation = array_filter($navigationItems, function($item) use ($userRole) {
    return in_array($userRole, $item['roles']);
});
?>
<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="theme-color" content="#667eea">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="<?= PWA_NAME ?>">
    
    <title><?= htmlspecialchars($pageTitle) ?></title>
    
    <!-- PWA Manifest -->
    <link rel="manifest" href="manifest.json">
    
    <!-- Favicons -->
    <link rel="icon" type="image/png" sizes="32x32" href="assets/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/icons/favicon-16x16.png">
    <link rel="apple-touch-icon" href="assets/icons/icon-192x192.png">
    
    <!-- CSS Dependencies -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Main Stylesheet -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <!-- Custom Header Styles -->
    <style>
        /* Header Styles */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 70px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            z-index: 1000;
            box-shadow: 0 2px 20px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            padding: 0 20px;
            transition: all 0.3s ease;
        }
        
        .header.scrolled {
            background: rgba(102, 126, 234, 0.95);
            backdrop-filter: blur(10px);
            height: 60px;
        }
        
        .header-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.4rem;
            font-weight: bold;
            text-decoration: none;
            color: white;
            margin-right: auto;
        }
        
        .header-brand:hover {
            color: rgba(255,255,255,0.9);
            text-decoration: none;
        }
        
        .brand-logo {
            width: 40px;
            height: 40px;
            background: rgba(255,255,255,0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }
        
        /* Desktop Navigation */
        .desktop-nav {
            display: flex;
            align-items: center;
            gap: 30px;
        }
        
        .nav-link {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 8px 16px;
            border-radius: 25px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.9rem;
        }
        
        .nav-link:hover {
            background: rgba(255,255,255,0.2);
            color: white;
            text-decoration: none;
            transform: translateY(-2px);
        }
        
        .nav-link.active {
            background: rgba(255,255,255,0.3);
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        
        .user-menu {
            position: relative;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-avatar {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: rgba(255,255,255,0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 2px solid rgba(255,255,255,0.3);
        }
        
        .user-avatar:hover {
            background: rgba(255,255,255,0.3);
            transform: scale(1.05);
        }
        
        .user-dropdown {
            position: absolute;
            top: 55px;
            right: 0;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            min-width: 250px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            overflow: hidden;
        }
        
        .user-dropdown.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .dropdown-header {
            padding: 20px;
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            border-bottom: 1px solid #e9ecef;
        }
        
        .dropdown-user-name {
            font-weight: bold;
            color: var(--dark-color);
            margin-bottom: 3px;
        }
        
        .dropdown-user-role {
            color: var(--primary-color);
            font-size: 0.8rem;
            text-transform: uppercase;
            font-weight: 600;
        }
        
        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: var(--dark-color);
            text-decoration: none;
            transition: all 0.3s ease;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .dropdown-item:hover {
            background: #f8f9fa;
            color: var(--primary-color);
            text-decoration: none;
        }
        
        .dropdown-item:last-child {
            border-bottom: none;
        }
        
        .dropdown-icon {
            width: 16px;
            text-align: center;
        }
        
        .logout-item {
            color: var(--danger-color) !important;
            border-top: 1px solid #e9ecef;
        }
        
        .logout-item:hover {
            background: #ffeaea !important;
        }
        
        /* Mobile Hamburger Menu */
        .mobile-menu-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            padding: 8px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .mobile-menu-toggle:hover {
            background: rgba(255,255,255,0.2);
        }
        
        .mobile-menu-toggle.active .hamburger-line:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }
        
        .mobile-menu-toggle.active .hamburger-line:nth-child(2) {
            opacity: 0;
        }
        
        .mobile-menu-toggle.active .hamburger-line:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -6px);
        }
        
        .hamburger-icon {
            width: 24px;
            height: 18px;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        
        .hamburger-line {
            width: 100%;
            height: 2px;
            background: white;
            border-radius: 2px;
            transition: all 0.3s ease;
        }
        
        /* Mobile Navigation Overlay */
        .mobile-nav-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100vh;
            background: rgba(0,0,0,0.5);
            z-index: 999;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            backdrop-filter: blur(5px);
        }
        
        .mobile-nav-overlay.show {
            opacity: 1;
            visibility: visible;
        }
        
        .mobile-nav {
            position: fixed;
            top: 0;
            right: -100%;
            width: 300px;
            height: 100vh;
            background: white;
            z-index: 1001;
            transition: all 0.3s ease;
            box-shadow: -5px 0 20px rgba(0,0,0,0.1);
            overflow-y: auto;
        }
        
        .mobile-nav.show {
            right: 0;
        }
        
        .mobile-nav-header {
            padding: 25px 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }
        
        .mobile-nav-close {
            position: absolute;
            top: 20px;
            right: 20px;
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }
        
        .mobile-nav-close:hover {
            background: rgba(255,255,255,0.2);
        }
        
        .mobile-nav-user {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-top: 10px;
        }
        
        .mobile-nav-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: rgba(255,255,255,0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        .mobile-nav-list {
            padding: 20px 0;
        }
        
        .mobile-nav-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 25px;
            color: var(--dark-color);
            text-decoration: none;
            transition: all 0.3s ease;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .mobile-nav-item:hover {
            background: #f8f9fa;
            color: var(--primary-color);
            text-decoration: none;
            transform: translateX(5px);
        }
        
        .mobile-nav-item.active {
            background: linear-gradient(90deg, rgba(102, 126, 234, 0.1), transparent);
            color: var(--primary-color);
            border-left: 4px solid var(--primary-color);
        }
        
        .mobile-nav-icon {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }
        
        .notifications-btn {
            position: relative;
            background: rgba(255,255,255,0.2);
            border: none;
            color: white;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .notifications-btn:hover {
            background: rgba(255,255,255,0.3);
            transform: scale(1.05);
        }
        
        .notification-badge {
            position: absolute;
            top: -2px;
            right: -2px;
            background: #ff4757;
            color: white;
            font-size: 0.7rem;
            font-weight: bold;
            padding: 2px 6px;
            border-radius: 10px;
            min-width: 18px;
            height: 18px;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        /* Content Spacing */
        .content-wrapper {
            margin-top: 70px;
            min-height: calc(100vh - 70px);
            padding: 20px;
        }
        
        /* Quick Actions Floating Button */
        .quick-actions-fab {
            position: fixed;
            bottom: 90px;
            right: 20px;
            z-index: 999;
            display: none;
        }
        
        .fab-main {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 20px rgba(102, 126, 234, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            transition: all 0.3s ease;
        }
        
        .fab-main:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 25px rgba(102, 126, 234, 0.6);
        }
        
        .fab-actions {
            position: absolute;
            bottom: 70px;
            right: 0;
            display: flex;
            flex-direction: column;
            gap: 10px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(20px);
            transition: all 0.3s ease;
        }
        
        .fab-actions.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        
        .fab-action {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: white;
            border: none;
            cursor: pointer;
            box-shadow: 0 2px 15px rgba(0,0,0,0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-color);
            transition: all 0.3s ease;
        }
        
        .fab-action:hover {
            background: var(--primary-color);
            color: white;
            transform: scale(1.1);
        }
        
        /* Responsive Design */
        @media (max-width: 1024px) {
            .desktop-nav {
                display: none;
            }
            
            .mobile-menu-toggle {
                display: block;
            }
            
            .quick-actions-fab {
                display: block;
            }
        }
        
        @media (max-width: 768px) {
            .header {
                padding: 0 15px;
            }
            
            .header-brand {
                font-size: 1.2rem;
            }
            
            .brand-logo {
                width: 35px;
                height: 35px;
                font-size: 1rem;
            }
            
            .mobile-nav {
                width: 280px;
            }
            
            .content-wrapper {
                padding: 15px;
            }
        }
        
        @media (max-width: 480px) {
            .mobile-nav {
                width: 100%;
            }
            
            .content-wrapper {
                padding: 10px;
            }
        }
        
        /* Loading states */
        .loading {
            opacity: 0.7;
            pointer-events: none;
        }
        
        .loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 20px;
            height: 20px;
            margin: -10px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header" id="mainHeader">
        <!-- Brand Logo -->
        <a href="?page=dashboard" class="header-brand">
            <div class="brand-logo">
                🧴
            </div>
            <span><?= PWA_NAME ?></span>
        </a>
        
        <!-- Desktop Navigation -->
        <?php if ($isLoggedIn): ?>
        <nav class="desktop-nav">
            <?php foreach ($filteredNavigation as $page => $item): ?>
                <a href="?page=<?= $page ?>" class="nav-link <?= $currentPage === $page ? 'active' : '' ?>">
                    <i class="<?= $item['icon'] ?>"></i>
                    <span><?= $item['title'] ?></span>
                </a>
            <?php endforeach; ?>
        </nav>
        
        <!-- User Menu -->
        <div class="user-menu">
            <!-- Notifications -->
            <button class="notifications-btn" onclick="toggleNotifications()" title="Bildirişlər">
                <i class="fas fa-bell"></i>
                <span class="notification-badge" id="notificationBadge" style="display: none;">0</span>
            </button>
            
            <!-- User Avatar -->
            <div class="user-avatar" onclick="toggleUserDropdown()">
                <?php if ($userAvatar): ?>
                    <img src="uploads/avatars/<?= htmlspecialchars($userAvatar) ?>" alt="Avatar" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
                <?php else: ?>
                    <?= strtoupper(substr($userName, 0, 2)) ?>
                <?php endif; ?>
            </div>
            
            <!-- User Dropdown -->
            <div class="user-dropdown" id="userDropdown">
                <div class="dropdown-header">
                    <div class="dropdown-user-name"><?= htmlspecialchars($userName) ?></div>
                    <div class="dropdown-user-role"><?= htmlspecialchars($userRole) ?></div>
                </div>
                
                <a href="?page=profile" class="dropdown-item">
                    <i class="dropdown-icon fas fa-user"></i>
                    <span>Profil</span>
                </a>
                
                <a href="?page=settings" class="dropdown-item">
                    <i class="dropdown-icon fas fa-cog"></i>
                    <span>Tənzimləmələr</span>
                </a>
                
                <a href="?page=help" class="dropdown-item">
                    <i class="dropdown-icon fas fa-question-circle"></i>
                    <span>Kömək</span>
                </a>
                
                <a href="logout.php" class="dropdown-item logout-item" onclick="return confirm('Çıxış etmək istədiyinizə əminsiniz?')">
                    <i class="dropdown-icon fas fa-sign-out-alt"></i>
                    <span>Çıxış</span>
                </a>
            </div>
        </div>
        
        <!-- Mobile Menu Toggle -->
        <button class="mobile-menu-toggle" onclick="toggleMobileNav()" id="mobileMenuToggle">
            <div class="hamburger-icon">
                <span class="hamburger-line"></span>
                <span class="hamburger-line"></span>
                <span class="hamburger-line"></span>
            </div>
        </button>
        <?php endif; ?>
    </header>
    
    <!-- Mobile Navigation Overlay -->
    <?php if ($isLoggedIn): ?>
    <div class="mobile-nav-overlay" id="mobileNavOverlay" onclick="closeMobileNav()"></div>
    
    <!-- Mobile Navigation -->
    <nav class="mobile-nav" id="mobileNav">
        <div class="mobile-nav-header">
            <button class="mobile-nav-close" onclick="closeMobileNav()">
                <i class="fas fa-times"></i>
            </button>
            
            <div class="mobile-nav-user">
                <div class="mobile-nav-avatar">
                    <?php if ($userAvatar): ?>
                        <img src="uploads/avatars/<?= htmlspecialchars($userAvatar) ?>" alt="Avatar" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">
                    <?php else: ?>
                        <?= strtoupper(substr($userName, 0, 2)) ?>
                    <?php endif; ?>
                </div>
                <div>
                    <div style="font-weight: bold; margin-bottom: 3px;"><?= htmlspecialchars($userName) ?></div>
                    <div style="font-size: 0.8rem; opacity: 0.9; text-transform: uppercase;"><?= htmlspecialchars($userRole) ?></div>
                </div>
            </div>
        </div>
        
        <div class="mobile-nav-list">
            <?php foreach ($filteredNavigation as $page => $item): ?>
                <a href="?page=<?= $page ?>" class="mobile-nav-item <?= $currentPage === $page ? 'active' : '' ?>" onclick="closeMobileNav()">
                    <i class="mobile-nav-icon <?= $item['icon'] ?>"></i>
                    <span><?= $item['title'] ?></span>
                </a>
            <?php endforeach; ?>
            
            <hr style="margin: 10px 0; border: none; border-top: 1px solid #e9ecef;">
            
            <a href="?page=profile" class="mobile-nav-item" onclick="closeMobileNav()">
                <i class="mobile-nav-icon fas fa-user"></i>
                <span>Profil</span>
            </a>
            
            <a href="?page=help" class="mobile-nav-item" onclick="closeMobileNav()">
                <i class="mobile-nav-icon fas fa-question-circle"></i>
                <span>Kömək</span>
            </a>
            
            <a href="logout.php" class="mobile-nav-item" onclick="return confirm('Çıxış etmək istədiyinizə əminsiniz?')">
                <i class="mobile-nav-icon fas fa-sign-out-alt"></i>
                <span>Çıxış</span>
            </a>
        </div>
    </nav>
    
    <!-- Quick Actions FAB (Mobile) -->
    <div class="quick-actions-fab" id="quickActionsFab">
        <div class="fab-actions" id="fabActions">
            <button class="fab-action" onclick="window.location.href='?page=sales&action=new'" title="Yeni Satış">
                <i class="fas fa-plus"></i>
            </button>
            <button class="fab-action" onclick="window.location.href='?page=products&action=add'" title="Məhsul Əlavə Et">
                <i class="fas fa-box"></i>
            </button>
            <button class="fab-action" onclick="window.location.href='?page=chat'" title="Chat">
                <i class="fas fa-comments"></i>
            </button>
        </div>
        
        <button class="fab-main" onclick="toggleFabActions()">
            <i class="fas fa-plus" id="fabIcon"></i>
        </button>
    </div>
    <?php endif; ?>
    
    <!-- Main Content Wrapper -->
    <main class="content-wrapper">
        <!-- Success/Error Messages -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle"></i>
                <?= $_SESSION['success_message'] ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle"></i>
                <?= $_SESSION['error_message'] ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['warning_message'])): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle"></i>
                <?= $_SESSION['warning_message'] ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php unset($_SESSION['warning_message']); ?>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['info_message'])): ?>
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="fas fa-info-circle"></i>
                <?= $_SESSION['info_message'] ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php unset($_SESSION['info_message']); ?>
        <?php endif; ?>

<script>
// Navigation Functions
function toggleMobileNav() {
    const overlay = document.getElementById('mobileNavOverlay');
    const nav = document.getElementById('mobileNav');
    const toggle = document.getElementById('mobileMenuToggle');
    
    overlay.classList.add('show');
    nav.classList.add('show');
    toggle.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeMobileNav() {
    const overlay = document.getElementById('mobileNavOverlay');
    const nav = document.getElementById('mobileNav');
    const toggle = document.getElementById('mobileMenuToggle');
    
    overlay.classList.remove('show');
    nav.classList.remove('show');
    toggle.classList.remove('active');
    document.body.style.overflow = '';
}

function toggleUserDropdown() {
    const dropdown = document.getElementById('userDropdown');
    dropdown.classList.toggle('show');
}

function toggleNotifications() {
    // Implement notifications panel
    console.log('Notifications toggle');
}

function toggleFabActions() {
    const actions = document.getElementById('fabActions');
    const icon = document.getElementById('fabIcon');
    
    actions.classList.toggle('show');
    icon.style.transform = actions.classList.contains('show') ? 'rotate(45deg)' : 'rotate(0deg)';
}

// Header Scroll Effect
let lastScrollTop = 0;
window.addEventListener('scroll', function() {
    const header = document.getElementById('mainHeader');
    const currentScroll = window.pageYOffset || document.documentElement.scrollTop;
    
    if (currentScroll > 50) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
    
    lastScrollTop = currentScroll <= 0 ? 0 : currentScroll;
});

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    const userDropdown = document.getElementById('userDropdown');
    const userAvatar = document.querySelector('.user-avatar');
    
    if (!userAvatar?.contains(event.target)) {
        userDropdown?.classList.remove('show');
    }
});

// Auto-hide alerts
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-20px)';
            setTimeout(() => {
                alert.remove();
            }, 300);
        }, 5000);
    });
});

// Close alert buttons
document.querySelectorAll('.alert .close').forEach(button => {
    button.addEventListener('click', function() {
        const alert = this.closest('.alert');
        alert.style.opacity = '0';
        alert.style.transform = 'translateY(-20px)';
        setTimeout(() => {
            alert.remove();
        }, 300);
    });
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // ESC key - close mobile nav and dropdowns
    if (e.key === 'Escape') {
        closeMobileNav();
        document.getElementById('userDropdown')?.classList.remove('show');
    }
    
    // Ctrl/Cmd + K - Focus search (if exists)
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }
});

// PWA Install Prompt Integration
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    // Handle PWA install prompt (handled by PWA Manager)
});

console.log('Header navigation initialized');
</script>