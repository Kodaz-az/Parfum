<?php
/**
 * Parfüm POS Sistemi - Helper Functions
 * Yaradıldığı tarix: 2025-07-21 16:53:37 (Baku Time)
 * Müəllif: Kodaz-az
 * Login: Kodaz-az
 */

// Prevent direct access
if (!defined('ROOT_PATH')) {
    die('Direct access not allowed');
}

/**
 * Redirect function (with conflict prevention)
 */
if (!function_exists('redirect')) {
    function redirect($page, $params = []) {
        $url = BASE_URL;
        
        if ($page !== 'dashboard') {
            $url .= "?page={$page}";
            
            if (!empty($params)) {
                $url .= "&" . http_build_query($params);
            }
        }
        
        header("Location: {$url}");
        exit;
    }
}

/**
 * Sanitize input data
 */
function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate email address
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Validate phone number (Azerbaijan format)
 */
function validatePhone($phone) {
    $phone = preg_replace('/[^0-9+]/', '', $phone);
    
    // Azerbaijan phone formats: +994xxxxxxxxx, 994xxxxxxxxx, 0xxxxxxxxx
    $patterns = [
        '/^\+994[0-9]{9}$/',  // +994xxxxxxxxx
        '/^994[0-9]{9}$/',    // 994xxxxxxxxx
        '/^0[0-9]{9}$/'       // 0xxxxxxxxx
    ];
    
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $phone)) {
            return true;
        }
    }
    
    return false;
}

/**
 * Format price with currency
 */
function formatPrice($price, $currency = 'AZN') {
    $symbols = [
        'AZN' => '₼',
        'USD' => '$',
        'EUR' => '€',
        'TRY' => '₺'
    ];
    
    $symbol = $symbols[$currency] ?? $currency;
    return $symbol . number_format($price, 2);
}

/**
 * Generate unique sale number
 */
function generateSaleNumber() {
    $prefix = 'S';
    $date = date('Ymd');
    $random = str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
    
    return $prefix . $date . '-' . $random;
}

/**
 * Generate unique product barcode
 */
function generateBarcode($prefix = '2') {
    // EAN-13 format for internal products
    $code = $prefix . date('ymd') . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
    
    // Calculate check digit
    $checkDigit = calculateEAN13CheckDigit($code);
    
    return $code . $checkDigit;
}

/**
 * Calculate EAN-13 check digit
 */
function calculateEAN13CheckDigit($code) {
    $sum = 0;
    for ($i = 0; $i < 12; $i++) {
        $digit = intval($code[$i]);
        $sum += ($i % 2 === 0) ? $digit : $digit * 3;
    }
    
    $checkDigit = (10 - ($sum % 10)) % 10;
    return $checkDigit;
}

/**
 * Format file size
 */
function formatFileSize($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    
    return round($bytes, 2) . ' ' . $units[$i];
}

/**
 * Generate secure password
 */
function generatePassword($length = 12) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    $password = '';
    
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, strlen($characters) - 1)];
    }
    
    return $password;
}

/**
 * Check password strength
 */
function checkPasswordStrength($password) {
    $score = 0;
    $feedback = [];
    
    // Length check
    if (strlen($password) >= 8) {
        $score += 2;
    } else {
        $feedback[] = 'Ən azı 8 simvol olmalıdır';
    }
    
    // Uppercase check
    if (preg_match('/[A-Z]/', $password)) {
        $score += 1;
    } else {
        $feedback[] = 'Böyük hərf olmalıdır';
    }
    
    // Lowercase check
    if (preg_match('/[a-z]/', $password)) {
        $score += 1;
    } else {
        $feedback[] = 'Kiçik hərf olmalıdır';
    }
    
    // Number check
    if (preg_match('/[0-9]/', $password)) {
        $score += 1;
    } else {
        $feedback[] = 'Rəqəm olmalıdır';
    }
    
    // Special character check
    if (preg_match('/[^A-Za-z0-9]/', $password)) {
        $score += 1;
    } else {
        $feedback[] = 'Xüsusi simvol olmalıdır';
    }
    
    // Determine strength
    if ($score >= 5) {
        $strength = 'güçlü';
    } elseif ($score >= 3) {
        $strength = 'orta';
    } else {
        $strength = 'zəif';
    }
    
    return [
        'score' => $score,
        'strength' => $strength,
        'feedback' => $feedback
    ];
}

/**
 * Generate CSRF token
 */
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Log user activity
 */
function logActivity($userId, $action, $description = '', $metadata = []) {
    try {
        $db = Database::getInstance();
        
        $sql = "INSERT INTO user_activity_log (user_id, action, description, metadata, ip_address, user_agent, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW())";
        
        $params = [
            $userId,
            $action,
            $description,
            json_encode($metadata),
            $_SERVER['REMOTE_ADDR'] ?? '',
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        ];
        
        return $db->insert($sql, $params);
        
    } catch (Exception $e) {
        error_log("Activity log error: " . $e->getMessage());
        return false;
    }
}

/**
 * Send notification
 */
function sendNotification($userId, $type, $title, $message, $data = [], $priority = 'normal') {
    try {
        $db = Database::getInstance();
        
        $sql = "INSERT INTO notifications (user_id, type, title, message, data, priority, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, NOW())";
        
        $params = [
            $userId,
            $type,
            $title,
            $message,
            json_encode($data),
            $priority
        ];
        
        return $db->insert($sql, $params);
        
    } catch (Exception $e) {
        error_log("Notification error: " . $e->getMessage());
        return false;
    }
}

/**
 * Upload file securely
 */
function uploadFile($file, $targetDir, $allowedTypes = [], $maxSize = null) {
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Fayl yüklənmədi və ya xəta baş verdi');
    }
    
    $maxSize = $maxSize ?? MAX_UPLOAD_SIZE;
    
    // Check file size
    if ($file['size'] > $maxSize) {
        throw new Exception('Fayl ölçüsü çox böyükdür: ' . formatFileSize($maxSize));
    }
    
    // Get file info
    $fileName = $file['name'];
    $fileTmpName = $file['tmp_name'];
    $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    
    // Check allowed types
    if (!empty($allowedTypes) && !in_array($fileExtension, $allowedTypes)) {
        throw new Exception('Bu fayl növü dəstəklənmir: ' . $fileExtension);
    }
    
    // Generate unique filename
    $newFileName = uniqid() . '_' . time() . '.' . $fileExtension;
    $targetPath = $targetDir . '/' . $newFileName;
    
    // Create directory if not exists
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }
    
    // Move uploaded file
    if (!move_uploaded_file($fileTmpName, $targetPath)) {
        throw new Exception('Fayl yüklənə bilmədi');
    }
    
    // Return file info
    return [
        'original_name' => $fileName,
        'filename' => $newFileName,
        'path' => $targetPath,
        'size' => $file['size'],
        'extension' => $fileExtension,
        'mime_type' => $file['type']
    ];
}

/**
 * Resize image
 */
function resizeImage($sourcePath, $targetPath, $maxWidth, $maxHeight, $quality = 85) {
    $imageInfo = getimagesize($sourcePath);
    if (!$imageInfo) {
        throw new Exception('Şəkil faylı deyil');
    }
    
    list($originalWidth, $originalHeight, $imageType) = $imageInfo;
    
    // Calculate new dimensions
    $ratio = min($maxWidth / $originalWidth, $maxHeight / $originalHeight);
    $newWidth = intval($originalWidth * $ratio);
    $newHeight = intval($originalHeight * $ratio);
    
    // Create image resource
    switch ($imageType) {
        case IMAGETYPE_JPEG:
            $sourceImage = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $sourceImage = imagecreatefrompng($sourcePath);
            break;
        case IMAGETYPE_GIF:
            $sourceImage = imagecreatefromgif($sourcePath);
            break;
        default:
            throw new Exception('Dəstəklənməyən şəkil formatı');
    }
    
    // Create new image
    $newImage = imagecreatetruecolor($newWidth, $newHeight);
    
    // Preserve transparency for PNG and GIF
    if ($imageType == IMAGETYPE_PNG || $imageType == IMAGETYPE_GIF) {
        imagealphablending($newImage, false);
        imagesavealpha($newImage, true);
        $transparent = imagecolorallocatealpha($newImage, 255, 255, 255, 127);
        imagefilledrectangle($newImage, 0, 0, $newWidth, $newHeight, $transparent);
    }
    
    // Resize image
    imagecopyresampled($newImage, $sourceImage, 0, 0, 0, 0, $newWidth, $newHeight, $originalWidth, $originalHeight);
    
    // Save image
    switch ($imageType) {
        case IMAGETYPE_JPEG:
            imagejpeg($newImage, $targetPath, $quality);
            break;
        case IMAGETYPE_PNG:
            imagepng($newImage, $targetPath, intval(9 - ($quality / 10)));
            break;
        case IMAGETYPE_GIF:
            imagegif($newImage, $targetPath);
            break;
    }
    
    // Clean up memory
    imagedestroy($sourceImage);
    imagedestroy($newImage);
    
    return [
        'width' => $newWidth,
        'height' => $newHeight,
        'path' => $targetPath
    ];
}

/**
 * Generate thumbnail
 */
function generateThumbnail($imagePath, $thumbnailPath, $size = 150) {
    return resizeImage($imagePath, $thumbnailPath, $size, $size);
}

/**
 * Format date in Azerbaijani
 */
function formatDateAZ($date, $format = 'd.m.Y H:i') {
    if (is_string($date)) {
        $date = new DateTime($date);
    }
    
    $months = [
        1 => 'Yanvar', 2 => 'Fevral', 3 => 'Mart', 4 => 'Aprel',
        5 => 'May', 6 => 'İyun', 7 => 'İyul', 8 => 'Avqust',
        9 => 'Sentyabr', 10 => 'Oktyabr', 11 => 'Noyabr', 12 => 'Dekabr'
    ];
    
    $days = [
        1 => 'Bazar ertəsi', 2 => 'Çərşənbə axşamı', 3 => 'Çərşənbə',
        4 => 'Cümə axşamı', 5 => 'Cümə', 6 => 'Şənbə', 0 => 'Bazar'
    ];
    
    $formatted = $date->format($format);
    
    // Replace month names
    foreach ($months as $num => $name) {
        $formatted = str_replace($date->format('n') == $num ? $date->format('F') : '', $name, $formatted);
    }
    
    return $formatted;
}

/**
 * Time ago function in Azerbaijani
 */
function timeAgoAZ($datetime) {
    if (is_string($datetime)) {
        $datetime = new DateTime($datetime);
    }
    
    $now = new DateTime();
    $diff = $now->getTimestamp() - $datetime->getTimestamp();
    
    if ($diff < 60) {
        return 'İndi';
    } elseif ($diff < 3600) {
        $minutes = floor($diff / 60);
        return $minutes . ' dəqiqə əvvəl';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' saat əvvəl';
    } elseif ($diff < 2592000) {
        $days = floor($diff / 86400);
        return $days . ' gün əvvəl';
    } elseif ($diff < 31536000) {
        $months = floor($diff / 2592000);
        return $months . ' ay əvvəl';
    } else {
        $years = floor($diff / 31536000);
        return $years . ' il əvvəl';
    }
}

/**
 * Get system settings
 */
function getSystemSetting($key, $default = null) {
    static $settings = [];
    
    if (empty($settings)) {
        try {
            $db = Database::getInstance();
            $results = $db->selectAll("SELECT setting_key, setting_value FROM system_settings");
            
            foreach ($results as $row) {
                $settings[$row['setting_key']] = $row['setting_value'];
            }
        } catch (Exception $e) {
            error_log("System settings error: " . $e->getMessage());
        }
    }
    
    return $settings[$key] ?? $default;
}

/**
 * Update system setting
 */
function updateSystemSetting($key, $value) {
    try {
        $db = Database::getInstance();
        
        $sql = "INSERT INTO system_settings (setting_key, setting_value, created_at) 
                VALUES (?, ?, NOW()) 
                ON DUPLICATE KEY UPDATE setting_value = ?, updated_at = NOW()";
        
        return $db->update($sql, [$key, $value, $value]);
        
    } catch (Exception $e) {
        error_log("Update setting error: " . $e->getMessage());
        return false;
    }
}

/**
 * Check if user has permission
 */
function hasPermission($userId, $permission) {
    try {
        $db = Database::getInstance();
        $user = $db->selectOne("SELECT role FROM users WHERE id = ?", [$userId]);
        
        if (!$user) {
            return false;
        }
        
        $permissions = [
            'admin' => ['*'], // Admin has all permissions
            'manager' => [
                'view_dashboard', 'view_sales', 'create_sale', 'view_products', 
                'create_product', 'edit_product', 'view_reports', 'view_users',
                'view_salary', 'manage_inventory'
            ],
            'seller' => [
                'view_dashboard', 'view_sales', 'create_sale', 'view_products',
                'view_own_salary'
            ]
        ];
        
        $userPermissions = $permissions[$user['role']] ?? [];
        
        return in_array('*', $userPermissions) || in_array($permission, $userPermissions);
        
    } catch (Exception $e) {
        error_log("Permission check error: " . $e->getMessage());
        return false;
    }
}

/**
 * Generate QR Code (simple implementation)
 */
function generateQRCode($text, $size = 200) {
    // Using Google Charts API for simplicity
    $url = "https://chart.googleapis.com/chart?chs={$size}x{$size}&cht=qr&chl=" . urlencode($text);
    return $url;
}

/**
 * Send email (basic implementation)
 */
function sendEmail($to, $subject, $body, $isHTML = true) {
    $headers = [
        'From: ' . SYSTEM_EMAIL,
        'Reply-To: ' . SYSTEM_EMAIL,
        'X-Mailer: ' . SYSTEM_NAME
    ];
    
    if ($isHTML) {
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
    }
    
    return mail($to, $subject, $body, implode("\r\n", $headers));
}

/**
 * Generate backup filename
 */
function generateBackupFilename($type = 'full') {
    $timestamp = date('Y-m-d_H-i-s');
    return "backup_{$type}_{$timestamp}.sql";
}

/**
 * Export data to CSV
 */
function exportToCSV($data, $filename, $headers = []) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    $output = fopen('php://output', 'w');
    
    // Add BOM for UTF-8
    fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));
    
    // Add headers
    if (!empty($headers)) {
        fputcsv($output, $headers);
    }
    
    // Add data
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

/**
 * Mobile device detection
 */
function isMobile() {
    return preg_match('/(android|iphone|ipad|mobile|phone)/i', $_SERVER['HTTP_USER_AGENT'] ?? '');
}

/**
 * Debug function (only in development)
 */
function debug($data, $die = false) {
    if (ENVIRONMENT === 'development') {
        echo '<pre style="background: #f8f9fa; padding: 15px; border: 1px solid #dee2e6; border-radius: 5px; margin: 10px 0;">';
        print_r($data);
        echo '</pre>';
        
        if ($die) {
            die();
        }
    }
}

/**
 * Clean up old files
 */
function cleanupOldFiles($directory, $maxAge = 2592000) { // 30 days default
    $files = glob($directory . '/*');
    $now = time();
    $deletedCount = 0;
    
    foreach ($files as $file) {
        if (is_file($file) && ($now - filemtime($file) >= $maxAge)) {
            if (unlink($file)) {
                $deletedCount++;
            }
        }
    }
    
    return $deletedCount;
}

/**
 * Get user IP address
 */
function getUserIP() {
    $ipKeys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
    
    foreach ($ipKeys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            $ip = trim($_SERVER[$key]);
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
            // If multiple IPs, get the first one
            if (strpos($ip, ',') !== false) {
                $ip = trim(explode(',', $ip)[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
    }
    
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/**
 * Rate limiting function
 */
function checkRateLimit($identifier, $maxAttempts = 5, $timeWindow = 300) {
    $cacheKey = 'rate_limit_' . md5($identifier);
    
    if (!isset($_SESSION[$cacheKey])) {
        $_SESSION[$cacheKey] = ['count' => 0, 'time' => time()];
    }
    
    $data = $_SESSION[$cacheKey];
    
    // Reset if time window has passed
    if ((time() - $data['time']) > $timeWindow) {
        $_SESSION[$cacheKey] = ['count' => 1, 'time' => time()];
        return true;
    }
    
    // Check if limit exceeded
    if ($data['count'] >= $maxAttempts) {
        return false;
    }
    
    // Increment counter
    $_SESSION[$cacheKey]['count']++;
    return true;
}

// Helper function to load additional functions if needed
function loadHelperFunctions() {
    $helperFiles = [
        ROOT_PATH . '/includes/currency_functions.php',
        ROOT_PATH . '/includes/notification_functions.php',
        ROOT_PATH . '/includes/report_functions.php'
    ];
    
    foreach ($helperFiles as $file) {
        if (file_exists($file)) {
            require_once $file;
        }
    }
}

// Initialize additional functions
loadHelperFunctions();

?>