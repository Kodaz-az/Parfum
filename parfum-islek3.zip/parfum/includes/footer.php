        </main>
</div>

<!-- Mobile Bottom Navigation -->
<?php if (isset($_SESSION['username'])): ?>
<nav class="mobile-bottom-nav d-md-none">
    <div class="container-fluid">
        <div class="row text-center">
            <div class="col">
                <a href="<?= BASE_URL ?>" class="nav-link">
                    <i class="fas fa-home"></i>
                    <span>Ana Səhifə</span>
                </a>
            </div>
            <?php if (($_SESSION['role'] ?? '') !== 'admin'): ?>
            <div class="col">
                <a href="<?= BASE_URL ?>?page=sales&action=new" class="nav-link">
                    <i class="fas fa-plus-circle"></i>
                    <span>Yeni Satış</span>
                </a>
            </div>
            <div class="col">
                <a href="<?= BASE_URL ?>?page=sales" class="nav-link">
                    <i class="fas fa-shopping-cart"></i>
                    <span>Satışlar</span>
                </a>
            </div>
            <?php else: ?>
            <div class="col">
                <a href="<?= BASE_URL ?>?page=sales" class="nav-link">
                    <i class="fas fa-chart-line"></i>
                    <span>Satışlar</span>
                </a>
            </div>
            <div class="col">
                <a href="<?= BASE_URL ?>?page=products" class="nav-link">
                    <i class="fas fa-box"></i>
                    <span>Məhsullar</span>
                </a>
            </div>
            <?php endif; ?>
            <div class="col">
                <a href="<?= BASE_URL ?>?page=chat" class="nav-link position-relative">
                    <i class="fas fa-comments"></i>
                    <span>Chat</span>
                    <span class="chat-notification" id="chatNotification" style="display: none;"></span>
                </a>
            </div>
            <div class="col">
                <a href="<?= BASE_URL ?>?page=profile" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profil</span>
                </a>
            </div>
        </div>
    </div>
</nav>
<?php endif; ?>

<!-- Support Widget -->
<div class="support-widget">
    <button class="support-btn" onclick="toggleSupport()" title="Dəstək">
        <i class="fas fa-headset"></i>
    </button>
    
    <div class="support-panel" id="supportPanel">
        <div style="background: linear-gradient(135deg, var(--success-color), #20c997); color: white; padding: 20px; text-align: center;">
            <h4><i class="fas fa-headset"></i> Dəstək Xidməti</h4>
            <p style="opacity: 0.9; margin: 0; font-size: 0.9rem;">Kodaz.az 24/7 Dəstək</p>
        </div>
        
        <div style="padding: 20px;">
            <div style="margin-bottom: 15px;">
                <a href="tel:+994123456789" class="btn btn-success" style="width: 100%; justify-content: center;">
                    <i class="fas fa-phone"></i> Zəng Et
                </a>
            </div>
            
            <div style="margin-bottom: 15px;">
                <a href="https://wa.me/994123456789" target="_blank" class="btn btn-success" style="width: 100%; justify-content: center; background: linear-gradient(135deg, #25d366, #128C7E);">
                    <i class="fab fa-whatsapp"></i> WhatsApp
                </a>
            </div>
            
            <div style="margin-bottom: 15px;">
                <a href="mailto:support@kodaz.az" class="btn btn-info" style="width: 100%; justify-content: center; background: linear-gradient(135deg, var(--info-color), #138496);">
                    <i class="fas fa-envelope"></i> Email
                </a>
            </div>
            
            <div style="margin-bottom: 15px;">
                <button onclick="openSupportChat()" class="btn btn-primary" style="width: 100%; justify-content: center; background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));">
                    <i class="fas fa-comments"></i> Canlı Chat
                </button>
            </div>
            
            <hr style="margin: 15px 0;">
            
            <div style="text-align: center; font-size: 0.8rem; color: #6c757d;">
                <p><strong>İş Saatları:</strong><br>
                Bazar ertəsi - Şənbə: 09:00-18:00</p>
                <p style="margin-top: 10px;"><strong>Təcili hallar:</strong><br>
                24/7 WhatsApp və Email</p>
            </div>
        </div>
    </div>
</div>

<!-- Modals -->
<div class="modal" id="notificationModal">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title"><i class="fas fa-bell"></i> Bildirişlər</h5>
            <button class="modal-close" onclick="closeModal('notificationModal')">×</button>
        </div>
        <div id="notificationList">
            <div style="text-align: center; padding: 20px; color: #6c757d;">
                <i class="fas fa-bell-slash" style="font-size: 2rem; margin-bottom: 10px;"></i>
                <p>Yeni bildiriş yoxdur</p>
            </div>
        </div>
    </div>
</div>

<div class="modal" id="quickActionsModal">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title"><i class="fas fa-plus"></i> Tez Əməliyyatlar</h5>
            <button class="modal-close" onclick="closeModal('quickActionsModal')">×</button>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
            <a href="<?= BASE_URL ?>?page=sales&action=new" class="btn btn-primary">
                <i class="fas fa-shopping-cart"></i> Yeni Satış
            </a>
            <a href="<?= BASE_URL ?>?page=products&action=add" class="btn btn-success">
                <i class="fas fa-plus"></i> Məhsul Əlavə Et
            </a>
            <a href="<?= BASE_URL ?>?page=users&action=add" class="btn btn-info">
                <i class="fas fa-user-plus"></i> İstifadəçi Əlavə Et
            </a>
            <a href="<?= BASE_URL ?>?page=reports" class="btn btn-warning">
                <i class="fas fa-chart-bar"></i> Hesabat Al
            </a>
        </div>
    </div>
</div>

<div class="modal" id="userMenuModal">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title"><i class="fas fa-user"></i> İstifadəçi Menyusu</h5>
            <button class="modal-close" onclick="closeModal('userMenuModal')">×</button>
        </div>
        <div style="display: flex; flex-direction: column; gap: 10px;">
            <a href="<?= BASE_URL ?>?page=profile" class="btn btn-secondary">
                <i class="fas fa-user-circle"></i> Profilim
            </a>
            <a href="<?= BASE_URL ?>?page=salary" class="btn btn-secondary">
                <i class="fas fa-money-bill-wave"></i> Maaş Məlumatı
            </a>
            <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
            <a href="<?= BASE_URL ?>?page=settings" class="btn btn-secondary">
                <i class="fas fa-cog"></i> Sistem Tənzimləmələri
            </a>
            <?php endif; ?>
            <hr style="margin: 5px 0;">
            <a href="<?= BASE_URL ?>?page=logout" class="btn btn-danger">
                <i class="fas fa-sign-out-alt"></i> Çıxış
            </a>
        </div>
    </div>
</div>

<!-- Chat Modal for Support -->
<div class="modal" id="supportChatModal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white;">
            <h5 class="modal-title"><i class="fas fa-headset"></i> Kodaz.az Dəstək</h5>
            <button class="modal-close" onclick="closeModal('supportChatModal')" style="color: white;">×</button>
        </div>
        <div class="chat-container" style="height: 400px;">
            <div class="chat-messages" id="supportChatMessages">
                <div class="chat-message">
                    <div class="message-bubble">
                        <div>Salam! Kodaz.az dəstək komandası sizə necə kömək edə bilər?</div>
                        <div class="message-time"><?= date('H:i') ?></div>
                    </div>
                </div>
            </div>
            <div class="chat-input">
                <input type="text" id="supportChatInput" placeholder="Mesajınızı yazın..." onkeypress="if(event.key==='Enter') sendSupportMessage()">
                <button onclick="sendSupportMessage()" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script>
// Global variables
let notifications = [];
let unreadCount = 0;

// Real-time clock
function updateClock() {
    const now = new Date();
    const timeElements = document.querySelectorAll('.live-time');
    timeElements.forEach(el => {
        el.textContent = now.toLocaleTimeString('az-AZ');
    });
}
setInterval(updateClock, 1000);

// Modal functions
function toggleNotifications() {
    const modal = document.getElementById('notificationModal');
    modal.classList.toggle('show');
    loadNotifications();
}

function toggleQuickActions() {
    const modal = document.getElementById('quickActionsModal');
    modal.classList.toggle('show');
}

function toggleUserMenu() {
    const modal = document.getElementById('userMenuModal');
    modal.classList.toggle('show');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
}

// Support functions
function toggleSupport() {
    const panel = document.getElementById('supportPanel');
    panel.classList.toggle('show');
}

function openSupportChat() {
    toggleSupport();
    const modal = document.getElementById('supportChatModal');
    modal.classList.add('show');
}

function sendSupportMessage() {
    const input = document.getElementById('supportChatInput');
    const message = input.value.trim();
    
    if (message) {
        const messagesContainer = document.getElementById('supportChatMessages');
        
        // Add user message
        messagesContainer.innerHTML += `
            <div class="chat-message own">
                <div class="message-bubble" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white;">
                    <div>${message}</div>
                    <div class="message-time">${new Date().toLocaleTimeString('az-AZ')}</div>
                </div>
            </div>
        `;
        
        input.value = '';
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Simulate support response
        setTimeout(() => {
            messagesContainer.innerHTML += `
                <div class="chat-message">
                    <div class="message-bubble">
                        <div>Mesajınız qəbul edildi. Tezliklə sizə cavab veriləcək.</div>
                        <div class="message-time">${new Date().toLocaleTimeString('az-AZ')}</div>
                    </div>
                </div>
            `;
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }, 1000);
    }
}

// Notification functions
function loadNotifications() {
    fetch('<?= BASE_URL ?>api/notifications.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateNotificationsList(data.notifications);
                updateUnreadCount(data.unread_count);
            }
        })
        .catch(error => console.error('Notification error:', error));
}

function updateNotificationsList(notifications) {
    const list = document.getElementById('notificationList');
    
    if (notifications.length === 0) {
        list.innerHTML = `
            <div style="text-align: center; padding: 20px; color: #6c757d;">
                <i class="fas fa-bell-slash" style="font-size: 2rem; margin-bottom: 10px;"></i>
                <p>Yeni bildiriş yoxdur</p>
            </div>
        `;
        return;
    }
    
    list.innerHTML = notifications.map(notification => `
        <div class="notification-item" style="padding: 15px; border-bottom: 1px solid #e9ecef;">
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-${notification.icon} text-${notification.type}"></i>
                <div style="flex: 1;">
                    <div style="font-weight: bold;">${notification.title}</div>
                    <div style="font-size: 0.9rem; color: #6c757d;">${notification.message}</div>
                    <div style="font-size: 0.8rem; color: #adb5bd; margin-top: 5px;">
                        <i class="fas fa-clock"></i> ${notification.time_ago}
                    </div>
                </div>
                ${!notification.is_read ? '<span class="badge badge-primary">Yeni</span>' : ''}
            </div>
        </div>
    `).join('');
}

function updateUnreadCount(count) {
    unreadCount = count;
    const badge = document.getElementById('unread-count');
    const notificationBadge = document.getElementById('notification-count');
    
    if (count > 0) {
        badge.textContent = count;
        badge.style.display = 'inline';
        notificationBadge.textContent = count;
        notificationBadge.style.display = 'inline';
    } else {
        badge.style.display = 'none';
        notificationBadge.style.display = 'none';
    }
}

// Close modals when clicking outside
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('show');
    }
    
    // Close support panel when clicking outside
    const supportWidget = document.querySelector('.support-widget');
    const supportPanel = document.getElementById('supportPanel');
    if (supportWidget && supportPanel && !supportWidget.contains(e.target)) {
        supportPanel.classList.remove('show');
    }
});

// Auto-hide alerts
setTimeout(() => {
    document.querySelectorAll('.alert').forEach(alert => {
        alert.style.opacity = '0';
        alert.style.transition = 'opacity 0.5s ease';
        setTimeout(() => alert.remove(), 500);
    });
}, 5000);

// PWA Service Worker
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('<?= BASE_URL ?>sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}

// WebSocket connection for real-time updates
let ws;
function connectWebSocket() {
    try {
        ws = new WebSocket(`ws://${window.location.hostname}:8080`);
        
        ws.onopen = function() {
            console.log('WebSocket connected');
        };
        
        ws.onmessage = function(event) {
            const data = JSON.parse(event.data);
            handleWebSocketMessage(data);
        };
        
        ws.onclose = function() {
            console.log('WebSocket disconnected, reconnecting...');
            setTimeout(connectWebSocket, 5000);
        };
        
        ws.onerror = function(error) {
            console.error('WebSocket error:', error);
        };
    } catch (error) {
        console.error('WebSocket connection failed:', error);
    }
}

function handleWebSocketMessage(data) {
    switch(data.type) {
        case 'notification':
            addNotification(data.notification);
            break;
        case 'chat_message':
            updateChatBadge();
            break;
        case 'system_update':
            showSystemUpdate();
            break;
    }
}

function addNotification(notification) {
    notifications.unshift(notification);
    updateUnreadCount(unreadCount + 1);
    
    // Show toast notification
    showToast(notification.title, notification.message, notification.type);
}

function showToast(title, message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type}`;
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 2000;
        min-width: 300px;
        animation: slideIn 0.3s ease;
    `;
    toast.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <div>
                <div style="font-weight: bold;">${title}</div>
                <div style="font-size: 0.9rem;">${message}</div>
            </div>
            <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; font-size: 1.2rem; cursor: pointer;">×</button>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    updateClock();
    loadNotifications();
    try {
        connectWebSocket();
    } catch (e) {
        console.log('WebSocket not supported or server unavailable');
    }
    
    // Mobile navigation active state
    const currentPath = window.location.pathname;
    const currentPage = new URLSearchParams(window.location.search).get('page') || 'home';
    const navLinks = document.querySelectorAll('.mobile-bottom-nav .nav-link');
    
    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href');
        if (linkHref === currentPath || 
            (linkHref.includes('page=') && linkHref.includes(currentPage))) {
            link.classList.add('active');
        }
    });
});

// Debug info
console.log('Kodaz.az Parfüm POS System v<?= defined('APP_VERSION') ? APP_VERSION : '1.0' ?>');
console.log('Current user:', '<?= $_SESSION['username'] ?? 'Anonymous' ?>');
console.log('User role:', '<?= $_SESSION['role'] ?? 'guest' ?>');
console.log('Session ID:', '<?= session_id() ?>');
</script>

<!-- CSS for Mobile Navigation and Support Widget -->
<style>
/* Mobile Bottom Navigation */
.mobile-bottom-nav {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    background: var(--white);
    box-shadow: var(--box-shadow);
    padding: 8px 0;
    border-top: 1px solid #e9ecef;
}

.mobile-bottom-nav .row {
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-around;
    width: 100%;
    margin: 0;
}

.mobile-bottom-nav .col {
    padding: 0;
    flex: 1;
    max-width: 20%; /* Ensure items are distributed evenly */
}

.mobile-bottom-nav .nav-link {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #6c757d;
    font-size: 0.7rem;
    padding: 5px 0;
    text-decoration: none;
    height: 100%;
    transition: var(--transition);
    border-radius: var(--border-radius);
}

.mobile-bottom-nav .nav-link i {
    font-size: 1.1rem;
    margin-bottom: 3px;
    color: #6c757d;
    transition: var(--transition);
}

.mobile-bottom-nav .nav-link.active {
    color: var(--white);
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
}

.mobile-bottom-nav .nav-link.active i {
    color: var(--white);
}

.mobile-bottom-nav .nav-link:hover {
    transform: translateY(-2px);
    color: var(--primary-color);
}

.mobile-bottom-nav .nav-link:hover i {
    color: var(--primary-color);
}

.mobile-bottom-nav .nav-link.active:hover {
    color: var(--white);
    transform: translateY(-2px);
}

.mobile-bottom-nav .nav-link.active:hover i {
    color: var(--white);
}

.mb-mobile-nav {
    margin-bottom: 60px; /* Reduced for smaller horizontal nav */
}

/* Chat Notification */
.chat-notification {
    position: absolute;
    top: 0;
    right: 2px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: var(--danger-color);
}

/* Support Widget */
.support-widget {
    position: fixed;
    bottom: 70px; /* Adjusted to be above mobile nav */
    right: 20px;
    z-index: 1500;
}

.support-btn {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--success-color), #20c997);
    color: var(--white);
    border: none;
    box-shadow: 0 4px 20px rgba(40, 167, 69, 0.4);
    font-size: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: var(--transition);
}

.support-btn:hover {
    transform: scale(1.1);
    box-shadow: 0 6px 25px rgba(40, 167, 69, 0.5);
}

.support-panel {
    position: absolute;
    bottom: 70px;
    right: 0;
    width: 350px;
    background: var(--white);
    border-radius: 15px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.2);
    display: none;
    overflow: hidden;
    transform-origin: bottom right;
    transition: var(--transition);
}

.support-panel.show {
    display: block;
    animation: slideIn 0.3s ease;
}

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Modal Styles */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    z-index: 2000;
    backdrop-filter: blur(5px);
}

.modal.show {
    display: flex;
    align-items: center;
    justify-content: center;
    animation: fadeIn 0.3s ease;
}

.modal-content {
    background: var(--white);
    border-radius: 15px;
    padding: 30px;
    max-width: 500px;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
    transform: scale(0.9);
    transition: var(--transition);
}

.modal.show .modal-content {
    transform: scale(1);
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid #e9ecef;
}

.modal-title {
    font-size: 1.3rem;
    font-weight: bold;
    color: var(--dark-color);
}

.modal-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: #6c757d;
    padding: 5px;
    border-radius: 50%;
    transition: var(--transition);
}

.modal-close:hover {
    background: #f8f9fa;
    color: var(--danger-color);
}

/* Chat Styles */
.chat-container {
    display: flex;
    flex-direction: column;
    background: var(--white);
    border-radius: 15px;
    overflow: hidden;
    box-shadow: var(--box-shadow);
}

.chat-messages {
    flex: 1;
    padding: 20px;
    overflow-y: auto;
    background: #f8f9fa;
}

.chat-message {
    display: flex;
    margin-bottom: 15px;
    animation: slideIn 0.3s ease;
}

.chat-message.own {
    justify-content: flex-end;
}

.message-bubble {
    max-width: 70%;
    padding: 12px 16px;
    border-radius: 20px;
    background: var(--white);
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    position: relative;
}

.chat-message.own .message-bubble {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--white);
}

.message-time {
    font-size: 0.7rem;
    opacity: 0.7;
    margin-top: 5px;
    text-align: right;
}

.chat-input {
    padding: 20px;
    background: var(--white);
    border-top: 1px solid #e9ecef;
    display: flex;
    gap: 10px;
}

.chat-input input {
    flex: 1;
    padding: 12px 16px;
    border: 1px solid #e9ecef;
    border-radius: 25px;
    outline: none;
}

.chat-input button {
    width: 45px;
    height: 45px;
    border: none;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--white);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--transition);
}

.chat-input button:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
}

/* Animations */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Responsive Adjustments */
@media (max-width: 767px) {
    .support-widget {
        bottom: 70px;
    }
    
    .modal-content {
        width: 95%;
        margin: 10px auto;
    }
    
    footer {
        margin-bottom: 60px;
    }
}

/* For very small screens */
@media (max-width: 359px) {
    .mobile-bottom-nav .nav-link {
        font-size: 0.6rem;
    }
    
    .mobile-bottom-nav .nav-link i {
        font-size: 1rem;
        margin-bottom: 2px;
    }
    
    .support-panel {
        width: 300px;
    }
}
</style>

<?php if (isset($additionalJS)): ?>
    <?php foreach ($additionalJS as $js): ?>
        <script src="<?= BASE_URL ?>assets/js/<?= $js ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>

</body>
</html>