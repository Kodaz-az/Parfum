<?php
/**
 * Parfüm POS Sistemi - Sidebar Include
 * Yaradıldığı tarix: 2025-07-21
 */

$currentPage = basename($_SERVER['PHP_SELF'], '.php');

// Chat unread count
$chat = new Chat();
$chatUnreadCount = $chat->getUnreadCount($currentUser['id']);
?>

<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <i class="fas fa-spray-can"></i>
            <span class="logo-text"><?= PWA_SHORT_NAME ?></span>
        </div>
        <button class="sidebar-close" onclick="toggleSidebar()">
            <i class="fas fa-times"></i>
        </button>
    </div>
    
    <div class="sidebar-content">
        <nav class="sidebar-nav">
            <ul class="nav-list">
                <!-- Dashboard -->
                <li class="nav-item">
                    <a href="<?= BASE_URL ?>dashboard" 
                       class="nav-link <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
                        <i class="fas fa-home"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <!-- Sales -->
                <li class="nav-item">
                    <a href="<?= BASE_URL ?>sales" 
                       class="nav-link <?= $currentPage === 'sales' ? 'active' : '' ?>">
                        <i class="fas fa-shopping-cart"></i>
                        <span>Satışlar</span>
                        <span class="nav-badge">Yeni</span>
                    </a>
                </li>
                
                <!-- Products -->
                <li class="nav-item">
                    <a href="<?= BASE_URL ?>products" 
                       class="nav-link <?= $currentPage === 'products' ? 'active' : '' ?>">
                        <i class="fas fa-box"></i>
                        <span>Məhsullar</span>
                    </a>
                </li>
                
                <!-- Chat -->
                <li class="nav-item">
                    <a href="<?= BASE_URL ?>chat" 
                       class="nav-link <?= $currentPage === 'chat' ? 'active' : '' ?>">
                        <i class="fas fa-comments"></i>
                        <span>Chat</span>
                        <?php if ($chatUnreadCount > 0): ?>
                            <span class="nav-badge unread"><?= $chatUnreadCount ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                
                <!-- Calls -->
                <li class="nav-item">
                    <a href="<?= BASE_URL ?>calls" 
                       class="nav-link <?= $currentPage === 'calls' ? 'active' : '' ?>">
                        <i class="fas fa-phone"></i>
                        <span>Zənglər</span>
                    </a>
                </li>
                
                <!-- Separator -->
                <li class="nav-separator">
                    <span>İdarəetmə</span>
                </li>
                
                <!-- Users (Admin/Manager only) -->
                <?php if ($user->hasPermission('view_users')): ?>
                    <li class="nav-item">
                        <a href="<?= BASE_URL ?>users" 
                           class="nav-link <?= $currentPage === 'users' ? 'active' : '' ?>">
                            <i class="fas fa-users"></i>
                            <span>İstifadəçilər</span>
                        </a>
                    </li>
                <?php endif; ?>
                
                <!-- Salary -->
                <li class="nav-item">
                    <a href="<?= BASE_URL ?>salary" 
                       class="nav-link <?= $currentPage === 'salary' ? 'active' : '' ?>">
                        <i class="fas fa-money-bill"></i>
                        <span>Maaş</span>
                    </a>
                </li>
                
                <!-- Reports -->
                <?php if ($user->hasPermission('view_reports')): ?>
                    <li class="nav-item has-submenu">
                        <a href="#" class="nav-link submenu-toggle" onclick="toggleSubmenu(this)">
                            <i class="fas fa-chart-bar"></i>
                            <span>Hesabatlar</span>
                            <i class="fas fa-chevron-right submenu-arrow"></i>
                        </a>
                        <ul class="submenu">
                            <li><a href="<?= BASE_URL ?>reports?type=sales">Satış Hesabatı</a></li>
                            <li><a href="<?= BASE_URL ?>reports?type=products">Məhsul Hesabatı</a></li>
                            <li><a href="<?= BASE_URL ?>reports?type=financial">Maliyyə Hesabatı</a></li>
                            <li><a href="<?= BASE_URL ?>reports?type=inventory">Inventar Hesabatı</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
                
                <!-- Separator -->
                <li class="nav-separator">
                    <span>Şəxsi</span>
                </li>
                
                <!-- Profile -->
                <li class="nav-item">
                    <a href="<?= BASE_URL ?>profile" 
                       class="nav-link <?= $currentPage === 'profile' ? 'active' : '' ?>">
                        <i class="fas fa-user"></i>
                        <span>Profil</span>
                    </a>
                </li>
                
                <!-- Settings -->
                <li class="nav-item">
                    <a href="<?= BASE_URL ?>settings" 
                       class="nav-link <?= $currentPage === 'settings' ? 'active' : '' ?>">
                        <i class="fas fa-cog"></i>
                        <span>Tənzimləmələr</span>
                    </a>
                </li>
            </ul>
        </nav>
        
        <!-- User Quick Info -->
        <div class="sidebar-user">
            <div class="user-avatar-small">
                <img src="<?= UPLOAD_URL ?>avatars/<?= $currentUser['avatar'] ?>" 
                     alt="<?= escape($currentUser['full_name']) ?>"
                     onerror="this.src='<?= BASE_URL ?>assets/images/default-avatar.png'">
                <span class="user-status-indicator online"></span>
            </div>
            <div class="user-info-small">
                <h4><?= escape($currentUser['full_name']) ?></h4>
                <p><?= ucfirst($currentUser['role']) ?></p>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="sidebar-quick-actions">
            <button onclick="openNewSaleModal()" class="quick-action-btn primary" title="Yeni Satış">
                <i class="fas fa-plus"></i>
            </button>
            <button onclick="openQuickChatModal()" class="quick-action-btn secondary" title="Tez Chat">
                <i class="fas fa-comment"></i>
            </button>
            <button onclick="toggleFullscreen()" class="quick-action-btn" title="Tam Ekran">
                <i class="fas fa-expand"></i>
            </button>
        </div>
    </div>
    
    <!-- Sidebar Footer -->
    <div class="sidebar-footer">
        <div class="connection-status connected" id="connectionStatus">
            <i class="fas fa-wifi"></i>
            <span>Bağlandı</span>
        </div>
        <div class="app-version">
            v<?= APP_VERSION ?? '1.0.0' ?>
        </div>
    </div>
</aside>

<!-- Sidebar Overlay for Mobile -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>