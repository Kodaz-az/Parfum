/**
 * PWA Manager - Install Prompt & Notifications
 * Kodaz-az - 2025-07-21 14:45:31 (UTC)
 * Login: Kodaz-az
 */

class PWAManager {
    constructor() {
        this.deferredPrompt = null;
        this.isInstalled = false;
        this.lastPromptDate = localStorage.getItem('lastPWAPrompt');
        this.installRejected = localStorage.getItem('pwaInstallRejected') === 'true';
        
        this.init();
    }
    
    init() {
        this.checkInstallStatus();
        this.setupInstallPrompt();
        this.requestNotificationPermission();
        this.scheduleNotifications();
        
        console.log('PWA Manager initialized');
    }
    
    checkInstallStatus() {
        // Check if app is installed
        if (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) {
            this.isInstalled = true;
            localStorage.setItem('pwaInstalled', 'true');
            console.log('PWA is installed');
        } else if (window.navigator.standalone === true) {
            // iOS Safari
            this.isInstalled = true;
            localStorage.setItem('pwaInstalled', 'true');
            console.log('PWA is installed (iOS)');
        } else {
            this.isInstalled = localStorage.getItem('pwaInstalled') === 'true';
        }
    }
    
    setupInstallPrompt() {
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            this.deferredPrompt = e;
            
            if (!this.isInstalled && !this.installRejected) {
                this.showInstallPrompt();
            }
        });
        
        // Listen for app installation
        window.addEventListener('appinstalled', () => {
            this.isInstalled = true;
            localStorage.setItem('pwaInstalled', 'true');
            localStorage.removeItem('lastPWAPrompt');
            localStorage.removeItem('pwaInstallRejected');
            
            this.showInstallSuccessNotification();
            console.log('PWA installed successfully');
        });
    }
    
    showInstallPrompt() {
        const today = new Date().toDateString();
        
        // Show prompt only once per day
        if (this.lastPromptDate === today) {
            return;
        }
        
        // Create install banner
        const installBanner = document.createElement('div');
        installBanner.id = 'pwa-install-banner';
        installBanner.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 15px 20px;
            z-index: 2000;
            display: flex;
            align-items: center;
            gap: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            animation: slideDown 0.5s ease;
        `;
        
        installBanner.innerHTML = `
            <div style="flex: 1; display: flex; align-items: center; gap: 15px;">
                <div style="font-size: 1.5rem;">📱</div>
                <div>
                    <div style="font-weight: bold; margin-bottom: 3px;">Tətbiqi Quraşdır</div>
                    <div style="font-size: 0.85rem; opacity: 0.9;">Daha sürətli giriş və offline istifadə üçün</div>
                </div>
            </div>
            
            <div style="display: flex; gap: 10px;">
                <button id="install-btn" style="
                    background: rgba(255,255,255,0.2);
                    border: 1px solid rgba(255,255,255,0.3);
                    color: white;
                    padding: 8px 16px;
                    border-radius: 20px;
                    cursor: pointer;
                    font-weight: bold;
                    transition: all 0.3s ease;
                ">
                    <i class="fas fa-download"></i> Quraşdır
                </button>
                
                <button id="dismiss-btn" style="
                    background: none;
                    border: none;
                    color: white;
                    cursor: pointer;
                    padding: 8px 12px;
                    border-radius: 20px;
                    opacity: 0.8;
                    transition: all 0.3s ease;
                ">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        document.body.appendChild(installBanner);
        
        // Button event listeners
        installBanner.querySelector('#install-btn').addEventListener('click', () => {
            this.installApp();
        });
        
        installBanner.querySelector('#dismiss-btn').addEventListener('click', () => {
            this.dismissInstallPrompt();
        });
        
        // Auto dismiss after 10 seconds
        setTimeout(() => {
            if (installBanner.parentElement) {
                this.dismissInstallPrompt();
            }
        }, 10000);
        
        // Mark as shown today
        localStorage.setItem('lastPWAPrompt', today);
        
        // Play notification sound
        this.playNotificationSound();
    }
    
    async installApp() {
        if (this.deferredPrompt) {
            this.deferredPrompt.prompt();
            
            const result = await this.deferredPrompt.userChoice;
            
            if (result.outcome === 'accepted') {
                console.log('User accepted PWA install');
                this.playSuccessSound();
            } else {
                console.log('User dismissed PWA install');
                localStorage.setItem('pwaInstallRejected', 'true');
                this.playErrorSound();
            }
            
            this.deferredPrompt = null;
        }
        
        this.removeInstallBanner();
    }
    
    dismissInstallPrompt() {
        localStorage.setItem('pwaInstallRejected', 'true');
        this.removeInstallBanner();
        this.playErrorSound();
    }
    
    removeInstallBanner() {
        const banner = document.getElementById('pwa-install-banner');
        if (banner) {
            banner.style.animation = 'slideUp 0.5s ease';
            setTimeout(() => {
                if (banner.parentElement) {
                    banner.remove();
                }
            }, 500);
        }
    }
    
    showInstallSuccessNotification() {
        this.showNotification({
            title: '🎉 Tətbiq Quraşdırıldı!',
            body: 'Parfüm POS artıq cihazınızda mövcuddur',
            icon: '/assets/icons/icon-192x192.png',
            badge: '/assets/icons/badge-72x72.png',
            vibrate: [200, 100, 200],
            tag: 'pwa-installed',
            requireInteraction: true
        });
        
        this.playSuccessSound();
    }
    
    async requestNotificationPermission() {
        if (!('Notification' in window)) {
            console.log('Browser does not support notifications');
            return false;
        }
        
        if (Notification.permission === 'granted') {
            return true;
        }
        
        if (Notification.permission !== 'denied') {
            const permission = await Notification.requestPermission();
            return permission === 'granted';
        }
        
        return false;
    }
    
    scheduleNotifications() {
        // Schedule daily reminder for non-installed users
        if (!this.isInstalled) {
            setInterval(() => {
                this.checkDailyReminder();
            }, 60000); // Check every minute
        }
    }
    
    checkDailyReminder() {
        const now = new Date();
        const hours = now.getHours();
        const minutes = now.getMinutes();
        
        // Show reminder at 10:00 AM daily
        if (hours === 10 && minutes === 0) {
            const today = now.toDateString();
            const lastReminder = localStorage.getItem('lastDailyReminder');
            
            if (lastReminder !== today && !this.installRejected) {
                this.showDailyReminder();
                localStorage.setItem('lastDailyReminder', today);
            }
        }
    }
    
    showDailyReminder() {
        this.showNotification({
            title: '📱 Parfüm POS Tətbiqi',
            body: 'Daha sürətli istifadə üçün tətbiqi quraşdırın!',
            icon: '/assets/icons/icon-192x192.png',
            badge: '/assets/icons/badge-72x72.png',
            vibrate: [100, 50, 100],
            tag: 'daily-reminder',
            actions: [
                {
                    action: 'install',
                    title: 'Quraşdır',
                    icon: '/assets/icons/install.png'
                },
                {
                    action: 'dismiss',
                    title: 'Daha sonra',
                    icon: '/assets/icons/dismiss.png'
                }
            ]
        });
        
        this.playNotificationSound();
    }
    
    async showNotification(options) {
        const hasPermission = await this.requestNotificationPermission();
        
        if (hasPermission) {
            if ('serviceWorker' in navigator && 'showNotification' in ServiceWorkerRegistration.prototype) {
                // Use service worker for better notification management
                const registration = await navigator.serviceWorker.ready;
                registration.showNotification(options.title, options);
            } else {
                // Fallback to basic notification
                new Notification(options.title, options);
            }
        }
    }
    
    playNotificationSound() {
        this.playSound('/assets/sounds/notification.mp3', 0.5);
    }
    
    playSuccessSound() {
        this.playSound('/assets/sounds/success.mp3', 0.7);
    }
    
    playErrorSound() {
        this.playSound('/assets/sounds/error.mp3', 0.3);
    }
    
    playSound(src, volume = 0.5) {
        try {
            const audio = new Audio(src);
            audio.volume = volume;
            audio.play().catch(e => {
                // Silent fail - user might not have interacted with page yet
                console.log('Sound play failed:', e.message);
            });
        } catch (error) {
            console.log('Sound creation failed:', error.message);
        }
    }
}

// Notification sound generation (Web Audio API)
class SoundGenerator {
    constructor() {
        this.audioContext = null;
        this.init();
    }
    
    init() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        } catch (error) {
            console.log('Web Audio API not supported');
        }
    }
    
    playNotificationBeep() {
        if (!this.audioContext) return;
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(800, this.audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(400, this.audioContext.currentTime + 0.2);
        
        gainNode.gain.setValueAtTime(0.3, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.2);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.2);
    }
    
    playSuccessSound() {
        if (!this.audioContext) return;
        
        // Play ascending notes
        const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
        
        notes.forEach((freq, index) => {
            setTimeout(() => {
                const oscillator = this.audioContext.createOscillator();
                const gainNode = this.audioContext.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(this.audioContext.destination);
                
                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(freq, this.audioContext.currentTime);
                
                gainNode.gain.setValueAtTime(0.2, this.audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.3);
                
                oscillator.start(this.audioContext.currentTime);
                oscillator.stop(this.audioContext.currentTime + 0.3);
            }, index * 150);
        });
    }
    
    playErrorSound() {
        if (!this.audioContext) return;
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.type = 'sawtooth';
        oscillator.frequency.setValueAtTime(200, this.audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(100, this.audioContext.currentTime + 0.5);
        
        gainNode.gain.setValueAtTime(0.2, this.audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 0.5);
        
        oscillator.start(this.audioContext.currentTime);
        oscillator.stop(this.audioContext.currentTime + 0.5);
    }
}

// CSS Animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideDown {
        from {
            transform: translateY(-100%);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
    
    @keyframes slideUp {
        from {
            transform: translateY(0);
            opacity: 1;
        }
        to {
            transform: translateY(-100%);
            opacity: 0;
        }
    }
    
    #install-btn:hover {
        background: rgba(255,255,255,0.3) !important;
        transform: scale(1.05);
    }
    
    #dismiss-btn:hover {
        background: rgba(255,255,255,0.1) !important;
        opacity: 1 !important;
    }
`;
document.head.appendChild(style);

// Initialize PWA Manager
const pwaManager = new PWAManager();
const soundGenerator = new SoundGenerator();

// Handle notification clicks
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', event => {
        if (event.data && event.data.type === 'notification-click') {
            const action = event.data.action;
            
            switch (action) {
                case 'install':
                    pwaManager.showInstallPrompt();
                    break;
                case 'dismiss':
                    localStorage.setItem('pwaInstallRejected', 'true');
                    break;
            }
        }
    });
}

// Export for global access
window.PWAManager = pwaManager;
window.SoundGenerator = soundGenerator;

console.log('PWA Manager and Sound Generator initialized');