/**
 * Parfüm POS Sistemi - Dashboard JavaScript
 * Yaradıldığı tarix: 2025-07-21
 */

// Dashboard Module
const DashboardModule = {
    config: {
        refreshInterval: 30000, // 30 seconds
        chartColors: {
            primary: '#667eea',
            secondary: '#764ba2',
            success: '#4ade80',
            warning: '#fbbf24',
            error: '#ef4444',
            info: '#3b82f6'
        }
    },
    
    state: {
        charts: {},
        timers: {},
        lastUpdate: null,
        isVisible: true
    },
    
    init(app) {
        this.app = app;
        this.bindEvents();
        this.initCharts();
        this.startAutoRefresh();
        this.initRealTimeUpdates();
        
        console.log('📊 Dashboard module initialized');
    },
    
    bindEvents() {
        // Quick action handlers
        document.addEventListener('click', this.handleQuickActions.bind(this));
        
        // Visibility change handling
        document.addEventListener('visibilitychange', () => {
            this.state.isVisible = !document.hidden;
            if (this.state.isVisible) {
                this.refreshData();
            }
        });
        
        // Window resize handling for charts
        window.addEventListener('resize', this.debounce(this.resizeCharts.bind(this), 300));
    },
    
    handleQuickActions(event) {
        const target = event.target.closest('[data-action]');
        if (!target) return;
        
        const action = target.getAttribute('data-action');
        
        switch (action) {
            case 'new-sale':
                this.openNewSale();
                break;
            case 'quick-chat':
                this.openQuickChat();
                break;
            case 'view-reports':
                this.openReports();
                break;
            case 'manage-products':
                this.openProducts();
                break;
        }
    },
    
    async refreshData() {
        try {
            const response = await this.app.api('/api/dashboard/stats');
            if (response.success) {
                this.updateStats(response.stats);
                this.updateCharts(response.charts || {});
                this.state.lastUpdate = new Date();
            }
        } catch (error) {
            console.error('Failed to refresh dashboard data:', error);
            this.app.showToast('Məlumatlar yenilənmədi', 'error');
        }
    },
    
    updateStats(stats) {
        // Update today's stats
        this.updateStatCard('today-sales', stats.today?.sales_count || 0);
        this.updateStatCard('today-revenue', this.app.formatMoney(stats.today?.total_revenue || 0));
        
        // Update weekly stats
        this.updateStatCard('week-sales', stats.week?.sales_count || 0);
        this.updateStatCard('week-revenue', this.app.formatMoney(stats.week?.total_revenue || 0));
        
        // Update monthly stats
        this.updateStatCard('month-sales', stats.month?.sales_count || 0);
        this.updateStatCard('month-revenue', this.app.formatMoney(stats.month?.total_revenue || 0));
        
        // Update product stats
        this.updateStatCard('total-products', stats.products?.total_products || 0);
        this.updateLowStockWarning(stats.products?.low_stock_count || 0);
        
        // Animate updated values
        this.animateStatCards();
    },
    
    updateStatCard(cardId, value) {
        const element = document.querySelector(`[data-stat="${cardId}"]`);
        if (element) {
            const currentValue = element.textContent.trim();
            if (currentValue !== value.toString()) {
                element.textContent = value;
                element.classList.add('stat-updated');
                setTimeout(() => {
                    element.classList.remove('stat-updated');
                }, 1000);
            }
        }
    },
    
    updateLowStockWarning(count) {
        const warningElement = document.querySelector('.stat-warning');
        if (warningElement) {
            if (count > 0) {
                warningElement.style.display = 'flex';
                warningElement.querySelector('span').textContent = `${count} az qalıb`;
            } else {
                warningElement.style.display = 'none';
            }
        }
    },
    
    animateStatCards() {
        const cards = document.querySelectorAll('.stat-card');
        cards.forEach((card, index) => {
            setTimeout(() => {
                card.style.animation = 'pulse 0.5s ease';
                setTimeout(() => {
                    card.style.animation = '';
                }, 500);
            }, index * 100);
        });
    },
    
    initCharts() {
        this.initSalesChart();
        this.initRevenueChart();
        this.initTopProductsChart();
        this.initPaymentMethodsChart();
    },
    
    initSalesChart() {
        const canvas = document.getElementById('salesChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        this.state.charts.sales = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Satışlar',
                    data: [],
                    borderColor: this.config.chartColors.primary,
                    backgroundColor: this.config.chartColors.primary + '20',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: '#e5e7eb'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    },
    
    initRevenueChart() {
        const canvas = document.getElementById('revenueChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        this.state.charts.revenue = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Gəlir',
                    data: [],
                    backgroundColor: this.config.chartColors.success,
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return new Intl.NumberFormat('az-AZ', {
                                    style: 'currency',
                                    currency: 'AZN',
                                    minimumFractionDigits: 0
                                }).format(value);
                            }
                        }
                    }
                }
            }
        });
    },
    
    initTopProductsChart() {
        const canvas = document.getElementById('topProductsChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        this.state.charts.topProducts = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        this.config.chartColors.primary,
                        this.config.chartColors.secondary,
                        this.config.chartColors.success,
                        this.config.chartColors.warning,
                        this.config.chartColors.error,
                        this.config.chartColors.info
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    }
                }
            }
        });
    },
    
    initPaymentMethodsChart() {
        const canvas = document.getElementById('paymentMethodsChart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        this.state.charts.paymentMethods = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        this.config.chartColors.success,
                        this.config.chartColors.primary,
                        this.config.chartColors.warning,
                        this.config.chartColors.info
                    ],
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            usePointStyle: true,
                            padding: 15
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((context.parsed / total) * 100).toFixed(1);
                                return `${context.label}: ${percentage}%`;
                            }
                        }
                    }
                }
            }
        });
    },
    
    updateCharts(chartData) {
        // Update sales chart
        if (this.state.charts.sales && chartData.sales) {
            this.updateLineChart(this.state.charts.sales, chartData.sales);
        }
        
        // Update revenue chart
        if (this.state.charts.revenue && chartData.revenue) {
            this.updateBarChart(this.state.charts.revenue, chartData.revenue);
        }
        
        // Update top products chart
        if (this.state.charts.topProducts && chartData.topProducts) {
            this.updateDoughnutChart(this.state.charts.topProducts, chartData.topProducts);
        }
        
        // Update payment methods chart
        if (this.state.charts.paymentMethods && chartData.paymentMethods) {
            this.updatePieChart(this.state.charts.paymentMethods, chartData.paymentMethods);
        }
    },
    
    updateLineChart(chart, data) {
        chart.data.labels = data.labels || [];
        chart.data.datasets[0].data = data.values || [];
        chart.update('active');
    },
    
    updateBarChart(chart, data) {
        chart.data.labels = data.labels || [];
        chart.data.datasets[0].data = data.values || [];
        chart.update('active');
    },
    
    updateDoughnutChart(chart, data) {
        chart.data.labels = data.labels || [];
        chart.data.datasets[0].data = data.values || [];
        chart.update('active');
    },
    
    updatePieChart(chart, data) {
        chart.data.labels = data.labels || [];
        chart.data.datasets[0].data = data.values || [];
        chart.update('active');
    },
    
    resizeCharts() {
        Object.values(this.state.charts).forEach(chart => {
            if (chart && chart.resize) {
                chart.resize();
            }
        });
    },
    
    startAutoRefresh() {
        this.state.timers.refresh = setInterval(() => {
            if (this.state.isVisible) {
                this.refreshData();
            }
        }, this.config.refreshInterval);
    },
    
    stopAutoRefresh() {
        if (this.state.timers.refresh) {
            clearInterval(this.state.timers.refresh);
            delete this.state.timers.refresh;
        }
    },
    
    initRealTimeUpdates() {
        // Listen for real-time updates via WebSocket
        if (window.WebSocket) {
            this.connectWebSocket();
        }
        
        // Listen for custom events
        document.addEventListener('app:new-sale', this.handleNewSale.bind(this));
        document.addEventListener('app:low-stock', this.handleLowStock.bind(this));
    },
    
    connectWebSocket() {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${wsProtocol}//${window.location.hostname}:8080`;
        
        try {
            this.ws = new WebSocket(wsUrl);
            
            this.ws.onopen = () => {
                console.log('📡 Dashboard WebSocket connected');
                this.ws.send(JSON.stringify({
                    type: 'subscribe',
                    channel: 'dashboard',
                    user_id: this.app.config.currentUser?.id
                }));
            };
            
            this.ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    this.handleWebSocketMessage(data);
                } catch (error) {
                    console.error('WebSocket message parse error:', error);
                }
            };
            
            this.ws.onclose = () => {
                console.log('📡 Dashboard WebSocket disconnected');
                // Attempt to reconnect after 5 seconds
                setTimeout(() => this.connectWebSocket(), 5000);
            };
            
            this.ws.onerror = (error) => {
                console.error('📡 Dashboard WebSocket error:', error);
            };
        } catch (error) {
            console.error('Failed to connect WebSocket:', error);
        }
    },
    
    handleWebSocketMessage(data) {
        switch (data.type) {
            case 'stats_update':
                this.updateStats(data.stats);
                break;
            case 'new_sale':
                this.handleNewSaleUpdate(data.sale);
                break;
            case 'low_stock_alert':
                this.handleLowStockAlert(data.product);
                break;
            case 'user_activity':
                this.updateUserActivity(data.activity);
                break;
        }
    },
    
    handleNewSale(event) {
        const { sale } = event.detail;
        this.handleNewSaleUpdate(sale);
    },
    
    handleNewSaleUpdate(sale) {
        // Show notification
        this.app.showToast(
            `Yeni satış: ${this.app.formatMoney(sale.final_amount)}`,
            'success'
        );
        
        // Update recent sales list
        this.addToRecentSales(sale);
        
        // Refresh stats after a short delay
        setTimeout(() => this.refreshData(), 2000);
        
        // Play notification sound
        this.playNotificationSound();
    },
    
    handleLowStock(event) {
        const { product } = event.detail;
        this.handleLowStockAlert(product);
    },
    
    handleLowStockAlert(product) {
        this.app.showToast(
            `Az stok: ${product.name} - ${product.stock_quantity} ədəd qalıb`,
            'warning',
            10000
        );
        
        // Update low stock count
        this.refreshData();
    },
    
    addToRecentSales(sale) {
        const salesList = document.querySelector('.sales-list');
        if (!salesList) return;
        
        const saleElement = this.createSaleElement(sale);
        salesList.insertBefore(saleElement, salesList.firstChild);
        
        // Remove last item if more than 10
        const items = salesList.querySelectorAll('.sale-item');
        if (items.length > 10) {
            items[items.length - 1].remove();
        }
        
        // Animate new item
        saleElement.style.animation = 'slideInLeft 0.5s ease';
    },
    
    createSaleElement(sale) {
        const div = document.createElement('div');
        div.className = 'sale-item';
        div.innerHTML = `
            <div class="sale-info">
                <div class="sale-number">#${sale.sale_number}</div>
                <div class="sale-details">
                    <span class="seller-name">${sale.seller_name}</span>
                    <span class="sale-time">${this.app.timeAgo(sale.created_at)}</span>
                </div>
            </div>
            <div class="sale-amount">
                ${this.app.formatMoney(sale.final_amount)}
            </div>
        `;
        return div;
    },
    
    updateUserActivity(activity) {
        const onlineUsers = document.querySelector('.users-list');
        if (!onlineUsers) return;
        
        // Update online user status
        activity.forEach(user => {
            const userElement = onlineUsers.querySelector(`[data-user-id="${user.id}"]`);
            if (userElement) {
                const indicator = userElement.querySelector('.online-indicator');
                if (indicator) {
                    indicator.className = `online-indicator ${user.status}`;
                }
            }
        });
    },
    
    playNotificationSound() {
        try {
            const audio = new Audio('/assets/sounds/notification.mp3');
            audio.volume = 0.3;
            audio.play().catch(() => {
                // Ignore audio play errors
            });
        } catch (error) {
            // Ignore audio errors
        }
    },
    
    // Quick Action Handlers
    openNewSale() {
        window.location.href = this.app.config.baseUrl + 'sales';
    },
    
    openQuickChat() {
        window.location.href = this.app.config.baseUrl + 'chat';
    },
    
    openReports() {
        window.location.href = this.app.config.baseUrl + 'reports';
    },
    
    openProducts() {
        window.location.href = this.app.config.baseUrl + 'products';
    },
    
    // Utility functions
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },
    
    onThemeChange(theme) {
        // Update chart colors for dark/light theme
        const isDark = theme === 'dark';
        
        Object.values(this.state.charts).forEach(chart => {
            if (chart && chart.options) {
                // Update grid colors
                if (chart.options.scales) {
                    Object.values(chart.options.scales).forEach(scale => {
                        if (scale.grid) {
                            scale.grid.color = isDark ? '#374151' : '#e5e7eb';
                        }
                        if (scale.ticks) {
                            scale.ticks.color = isDark ? '#d1d5db' : '#374151';
                        }
                    });
                }
                
                // Update legend colors
                if (chart.options.plugins && chart.options.plugins.legend) {
                    chart.options.plugins.legend.labels.color = isDark ? '#d1d5db' : '#374151';
                }
                
                chart.update();
            }
        });
    },
    
    destroy() {
        // Clean up timers
        Object.values(this.state.timers).forEach(timer => {
            clearInterval(timer);
        });
        
        // Destroy charts
        Object.values(this.state.charts).forEach(chart => {
            if (chart && chart.destroy) {
                chart.destroy();
            }
        });
        
        // Close WebSocket
        if (this.ws) {
            this.ws.close();
        }
        
        console.log('📊 Dashboard module destroyed');
    }
};

// Register module
if (window.App) {
    window.App.registerModule('dashboard', DashboardModule);
}

// Global functions for backward compatibility
function startChat(userId) {
    window.location.href = `${window.App.config.baseUrl}chat?user=${userId}`;
}

function startCall(userId) {
    if (confirm('Zəng etmək istədiyinizə əminsiniz?')) {
        window.location.href = `${window.App.config.baseUrl}calls?action=call&user=${userId}`;
    }
}

function updateDashboard() {
    if (window.App && window.App.modules.dashboard) {
        window.App.modules.dashboard.refreshData();
    }
}

// Auto-refresh dashboard when page becomes visible
document.addEventListener('visibilitychange', () => {
    if (!document.hidden && window.App && window.App.modules.dashboard) {
        window.App.modules.dashboard.refreshData();
    }
});