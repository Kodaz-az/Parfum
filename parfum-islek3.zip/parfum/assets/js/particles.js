/**
 * Parfüm POS Sistemi - Particles Animation
 * Yaradıldığı tarix: 2025-07-21
 */

function initParticles() {
    const container = document.getElementById('particles');
    if (!container) return;
    
    const particleCount = 50;
    const particles = [];
    
    function createParticle() {
        const particle = document.createElement('div');
        particle.className = 'particle';
        
        const size = Math.random() * 4 + 2;
        const x = Math.random() * window.innerWidth;
        const y = Math.random() * window.innerHeight;
        const duration = Math.random() * 3 + 3;
        const delay = Math.random() * 2;
        
        particle.style.width = size + 'px';
        particle.style.height = size + 'px';
        particle.style.left = x + 'px';
        particle.style.top = y + 'px';
        particle.style.animationDuration = duration + 's';
        particle.style.animationDelay = delay + 's';
        
        container.appendChild(particle);
        particles.push({
            element: particle,
            x: x,
            y: y,
            vx: (Math.random() - 0.5) * 0.5,
            vy: (Math.random() - 0.5) * 0.5,
            size: size
        });
    }
    
    function animateParticles() {
        particles.forEach(particle => {
            particle.x += particle.vx;
            particle.y += particle.vy;
            
            if (particle.x < 0 || particle.x > window.innerWidth) {
                particle.vx = -particle.vx;
            }
            if (particle.y < 0 || particle.y > window.innerHeight) {
                particle.vy = -particle.vy;
            }
            
            particle.element.style.left = particle.x + 'px';
            particle.element.style.top = particle.y + 'px';
        });
        
        requestAnimationFrame(animateParticles);
    }
    
    // Create particles
    for (let i = 0; i < particleCount; i++) {
        createParticle();
    }
    
    // Start animation
    animateParticles();
    
    // Handle resize
    window.addEventListener('resize', () => {
        particles.forEach(particle => {
            if (particle.x > window.innerWidth) {
                particle.x = window.innerWidth - particle.size;
            }
            if (particle.y > window.innerHeight) {
                particle.y = window.innerHeight - particle.size;
            }
        });
    });
}