/**
 * Parfüm POS Sistemi - WebRTC JavaScript
 * Yaradıldığı tarix: 2025-07-21
 */

// WebRTC Module
const WebRTCModule = {
    config: {
        iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
            { urls: 'stun:stun2.l.google.com:19302' }
        ],
        constraints: {
            audio: {
                echoCancellation: true,
                noiseSuppression: true,
                autoGainControl: true,
                sampleRate: 44100
            },
            video: {
                width: { ideal: 1280 },
                height: { ideal: 720 },
                frameRate: { ideal: 30 }
            }
        }
    },
    
    state: {
        localStream: null,
        remoteStream: null,
        peerConnection: null,
        isCallActive: false,
        isVideoEnabled: false,
        isAudioEnabled: false,
        callType: null,
        callId: null,
        ws: null
    },
    
    init(app) {
        this.app = app;
        this.bindEvents();
        this.checkMediaDevices();
        
        console.log('📞 WebRTC module initialized');
    },
    
    bindEvents() {
        // Call control buttons
        document.addEventListener('click', this.handleCallControls.bind(this));
        
        // Window beforeunload
        window.addEventListener('beforeunload', this.handleBeforeUnload.bind(this));
        
        // Custom events
        document.addEventListener('app:incoming-call', this.handleIncomingCall.bind(this));
        document.addEventListener('app:call-ended', this.handleCallEnded.bind(this));
    },
    
    async checkMediaDevices() {
        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            const audioInputs = devices.filter(device => device.kind === 'audioinput');
            const videoInputs = devices.filter(device => device.kind === 'videoinput');
            
            console.log(`📞 Found ${audioInputs.length} audio inputs, ${videoInputs.length} video inputs`);
            
            // Check permissions
            await this.checkPermissions();
        } catch (error) {
            console.error('Failed to enumerate devices:', error);
        }
    },
    
    async checkPermissions() {
        try {
            // Request minimal permissions to check availability
            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: true, 
                video: false 
            });
            stream.getTracks().forEach(track => track.stop());
            
            console.log('📞 Media permissions granted');
        } catch (error) {
            console.warn('Media permissions not granted:', error);
        }
    },
    
    handleCallControls(event) {
        const target = event.target.closest('[data-call-action]');
        if (!target) return;
        
        const action = target.getAttribute('data-call-action');
        const userId = target.getAttribute('data-user-id');
        const callId = target.getAttribute('data-call-id');
        
        switch (action) {
            case 'audio-call':
                this.initiateCall(userId, 'audio');
                break;
            case 'video-call':
                this.initiateCall(userId, 'video');
                break;
            case 'answer-call':
                this.answerCall(callId);
                break;
            case 'reject-call':
                this.rejectCall(callId);
                break;
            case 'end-call':
                this.endCall();
                break;
            case 'toggle-audio':
                this.toggleAudio();
                break;
            case 'toggle-video':
                this.toggleVideo();
                break;
            case 'toggle-screen':
                this.toggleScreenShare();
                break;
        }
    },
    
    async initiateCall(userId, callType) {
        try {
            // Create call on server
            const response = await this.app.api('/api/calls/initiate', {
                method: 'POST',
                body: {
                    user_id: userId,
                    call_type: callType
                }
            });
            
            if (!response.success) {
                throw new Error(response.message);
            }
            
            this.state.callId = response.call_id;
            this.state.callType = callType;
            
            // Setup WebRTC
            await this.setupPeerConnection();
            await this.getLocalStream(callType === 'video');
            
            // Create offer
            const offer = await this.state.peerConnection.createOffer();
            await this.state.peerConnection.setLocalDescription(offer);
            
            // Send offer to server
            await this.sendSignalingMessage('offer', {
                offer: offer,
                call_id: this.state.callId
            });
            
            this.showCallUI();
            this.app.showToast('Zəng edilir...', 'info');
            
        } catch (error) {
            console.error('Failed to initiate call:', error);
            this.app.showToast('Zəng başladıla bilmədi: ' + error.message, 'error');
        }
    },
    
    async answerCall(callId) {
        try {
            this.state.callId = callId;
            
            // Answer call on server
            const response = await this.app.api('/api/calls/answer', {
                method: 'POST',
                body: { call_id: callId }
            });
            
            if (!response.success) {
                throw new Error(response.message);
            }
            
            // Setup WebRTC
            await this.setupPeerConnection();
            await this.getLocalStream(this.state.callType === 'video');
            
            this.showCallUI();
            this.app.showToast('Zəng qəbul edildi', 'success');
            
        } catch (error) {
            console.error('Failed to answer call:', error);
            this.app.showToast('Zəng qəbul edilmədi: ' + error.message, 'error');
        }
    },
    
    async rejectCall(callId) {
        try {
            const response = await this.app.api('/api/calls/reject', {
                method: 'POST',
                body: { call_id: callId }
            });
            
            if (response.success) {
                this.app.showToast('Zəng rədd edildi', 'info');
                this.hideCallUI();
            }
        } catch (error) {
            console.error('Failed to reject call:', error);
        }
    },
    
    async endCall() {
        try {
            if (this.state.callId) {
                await this.app.api('/api/calls/end', {
                    method: 'POST',
                    body: { call_id: this.state.callId }
                });
            }
            
            this.cleanup();
            this.hideCallUI();
            this.app.showToast('Zəng bitirildi', 'info');
            
        } catch (error) {
            console.error('Failed to end call:', error);
            this.cleanup();
            this.hideCallUI();
        }
    },
    
    async setupPeerConnection() {
        this.state.peerConnection = new RTCPeerConnection({
            iceServers: this.config.iceServers
        });
        
        // Handle ICE candidates
        this.state.peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                this.sendSignalingMessage('ice-candidate', {
                    candidate: event.candidate,
                    call_id: this.state.callId
                });
            }
        };
        
        // Handle remote stream
        this.state.peerConnection.ontrack = (event) => {
            console.log('📞 Received remote stream');
            this.state.remoteStream = event.streams[0];
            this.displayRemoteStream();
        };
        
        // Handle connection state changes
        this.state.peerConnection.onconnectionstatechange = () => {
            const state = this.state.peerConnection.connectionState;
            console.log('📞 Connection state:', state);
            
            switch (state) {
                case 'connected':
                    this.state.isCallActive = true;
                    this.app.showToast('Zəng bağlandı', 'success');
                    break;
                case 'disconnected':
                case 'failed':
                case 'closed':
                    this.endCall();
                    break;
            }
        };
    },
    
    async getLocalStream(includeVideo = false) {
        try {
            const constraints = {
                audio: this.config.constraints.audio,
                video: includeVideo ? this.config.constraints.video : false
            };
            
            this.state.localStream = await navigator.mediaDevices.getUserMedia(constraints);
            this.state.isAudioEnabled = true;
            this.state.isVideoEnabled = includeVideo;
            
            // Add tracks to peer connection
            this.state.localStream.getTracks().forEach(track => {
                this.state.peerConnection.addTrack(track, this.state.localStream);
            });
            
            this.displayLocalStream();
            
        } catch (error) {
            console.error('Failed to get local stream:', error);
            throw new Error('Kamera və ya mikrofona giriş icazəsi lazımdır');
        }
    },
    
    displayLocalStream() {
        const localVideo = document.getElementById('localVideo');
        if (localVideo && this.state.localStream) {
            localVideo.srcObject = this.state.localStream;
            localVideo.muted = true; // Prevent echo
        }
    },
    
    displayRemoteStream() {
        const remoteVideo = document.getElementById('remoteVideo');
        if (remoteVideo && this.state.remoteStream) {
            remoteVideo.srcObject = this.state.remoteStream;
        }
    },
    
    async toggleAudio() {
        if (!this.state.localStream) return;
        
        const audioTrack = this.state.localStream.getAudioTracks()[0];
        if (audioTrack) {
            audioTrack.enabled = !audioTrack.enabled;
            this.state.isAudioEnabled = audioTrack.enabled;
            
            const button = document.querySelector('[data-call-action="toggle-audio"]');
            if (button) {
                button.classList.toggle('muted', !this.state.isAudioEnabled);
                button.querySelector('i').className = this.state.isAudioEnabled ? 
                    'fas fa-microphone' : 'fas fa-microphone-slash';
            }
            
            this.app.showToast(
                this.state.isAudioEnabled ? 'Mikrofon açıldı' : 'Mikrofon bağlandı', 
                'info'
            );
        }
    },
    
    async toggleVideo() {
        if (!this.state.localStream) return;
        
        const videoTrack = this.state.localStream.getVideoTracks()[0];
        if (videoTrack) {
            videoTrack.enabled = !videoTrack.enabled;
            this.state.isVideoEnabled = videoTrack.enabled;
            
            const button = document.querySelector('[data-call-action="toggle-video"]');
            if (button) {
                button.classList.toggle('disabled', !this.state.isVideoEnabled);
                button.querySelector('i').className = this.state.isVideoEnabled ? 
                    'fas fa-video' : 'fas fa-video-slash';
            }
            
            this.app.showToast(
                this.state.isVideoEnabled ? 'Kamera açıldı' : 'Kamera bağlandı', 
                'info'
            );
        }
    },
    
    async toggleScreenShare() {
        try {
            if (!this.state.isScreenSharing) {
                // Start screen sharing
                const screenStream = await navigator.mediaDevices.getDisplayMedia({
                    video: true,
                    audio: true
                });
                
                // Replace video track
                const videoTrack = screenStream.getVideoTracks()[0];
                const sender = this.state.peerConnection.getSenders().find(s => 
                    s.track && s.track.kind === 'video'
                );
                
                if (sender) {
                    await sender.replaceTrack(videoTrack);
                }
                
                this.state.isScreenSharing = true;
                
                // Handle screen share end
                videoTrack.onended = () => {
                    this.stopScreenShare();
                };
                
                this.app.showToast('Ekran paylaşımı başladı', 'success');
                
            } else {
                this.stopScreenShare();
            }
        } catch (error) {
            console.error('Screen share failed:', error);
            this.app.showToast('Ekran paylaşımı başladıla bilmədi', 'error');
        }
    },
    
    async stopScreenShare() {
        try {
            // Get camera stream back
            const cameraStream = await navigator.mediaDevices.getUserMedia({
                video: this.config.constraints.video
            });
            
            // Replace screen track with camera track
            const videoTrack = cameraStream.getVideoTracks()[0];
            const sender = this.state.peerConnection.getSenders().find(s => 
                s.track && s.track.kind === 'video'
            );
            
            if (sender) {
                await sender.replaceTrack(videoTrack);
            }
            
            this.state.isScreenSharing = false;
            this.app.showToast('Ekran paylaşımı dayandırıldı', 'info');
            
        } catch (error) {
            console.error('Failed to stop screen share:', error);
        }
    },
    
    async sendSignalingMessage(type, data) {
        try {
            await this.app.api('/api/calls/signaling', {
                method: 'POST',
                body: {
                    type: type,
                    data: data
                }
            });
        } catch (error) {
            console.error('Failed to send signaling message:', error);
        }
    },
    
    async handleSignalingMessage(message) {
        const { type, data } = message;
        
        try {
            switch (type) {
                case 'offer':
                    await this.handleOffer(data.offer);
                    break;
                case 'answer':
                    await this.handleAnswer(data.answer);
                    break;
                case 'ice-candidate':
                    await this.handleIceCandidate(data.candidate);
                    break;
            }
        } catch (error) {
            console.error('Failed to handle signaling message:', error);
        }
    },
    
    async handleOffer(offer) {
        await this.state.peerConnection.setRemoteDescription(offer);
        
        const answer = await this.state.peerConnection.createAnswer();
        await this.state.peerConnection.setLocalDescription(answer);
        
        await this.sendSignalingMessage('answer', {
            answer: answer,
            call_id: this.state.callId
        });
    },
    
    async handleAnswer(answer) {
        await this.state.peerConnection.setRemoteDescription(answer);
    },
    
    async handleIceCandidate(candidate) {
        await this.state.peerConnection.addIceCandidate(candidate);
    },
    
    handleIncomingCall(event) {
        const { call } = event.detail;
        this.state.callType = call.call_type;
        this.showIncomingCallUI(call);
    },
    
    handleCallEnded(event) {
        this.cleanup();
        this.hideCallUI();
    },
    
    showIncomingCallUI(call) {
        const modal = this.createIncomingCallModal(call);
        document.body.appendChild(modal);
        
        // Play ringtone
        this.playRingtone();
    },
    
    createIncomingCallModal(call) {
        const modal = document.createElement('div');
        modal.className = 'modal incoming-call-modal';
        modal.innerHTML = `
            <div class="modal-content call-modal">
                <div class="incoming-call-header">
                    <img src="/uploads/avatars/${call.caller_avatar}" alt="${call.caller_name}">
                    <h3>${call.caller_name}</h3>
                    <p>Gələn ${call.call_type === 'video' ? 'video' : 'audio'} zəng</p>
                </div>
                <div class="call-actions">
                    <button class="call-btn reject" data-call-action="reject-call" data-call-id="${call.id}">
                        <i class="fas fa-phone-slash"></i>
                    </button>
                    <button class="call-btn answer" data-call-action="answer-call" data-call-id="${call.id}">
                        <i class="fas fa-phone"></i>
                    </button>
                </div>
            </div>
        `;
        return modal;
    },
    
    showCallUI() {
        const callUI = this.createCallUI();
        document.body.appendChild(callUI);
    },
    
    createCallUI() {
        const callUI = document.createElement('div');
        callUI.className = 'call-interface';
        callUI.id = 'callInterface';
        
        callUI.innerHTML = `
            <div class="call-videos">
                <video id="remoteVideo" autoplay playsinline></video>
                <video id="localVideo" autoplay playsinline muted class="local-video"></video>
            </div>
            <div class="call-controls">
                <button class="call-control-btn" data-call-action="toggle-audio" title="Mikrofon">
                    <i class="fas fa-microphone"></i>
                </button>
                <button class="call-control-btn" data-call-action="toggle-video" title="Kamera">
                    <i class="fas fa-video"></i>
                </button>
                <button class="call-control-btn" data-call-action="toggle-screen" title="Ekran paylaşımı">
                    <i class="fas fa-desktop"></i>
                </button>
                <button class="call-control-btn end-call" data-call-action="end-call" title="Zəngi bitir">
                    <i class="fas fa-phone-slash"></i>
                </button>
            </div>
            <div class="call-info">
                <div class="call-timer" id="callTimer">00:00</div>
                <div class="call-status" id="callStatus">Bağlanır...</div>
            </div>
        `;
        
        return callUI;
    },
    
    hideCallUI() {
        const callUI = document.getElementById('callInterface');
        if (callUI) {
            callUI.remove();
        }
        
        const incomingModal = document.querySelector('.incoming-call-modal');
        if (incomingModal) {
            incomingModal.remove();
        }
        
        this.stopRingtone();
    },
    
    playRingtone() {
        try {
            this.ringtone = new Audio('/assets/sounds/ringtone.mp3');
            this.ringtone.loop = true;
            this.ringtone.volume = 0.5;
            this.ringtone.play();
        } catch (error) {
            console.error('Failed to play ringtone:', error);
        }
    },
    
    stopRingtone() {
        if (this.ringtone) {
            this.ringtone.pause();
            this.ringtone.currentTime = 0;
            this.ringtone = null;
        }
    },
    
    startCallTimer() {
        this.callStartTime = Date.now();
        this.callTimer = setInterval(() => {
            const elapsed = Date.now() - this.callStartTime;
            const minutes = Math.floor(elapsed / 60000);
            const seconds = Math.floor((elapsed % 60000) / 1000);
            
            const timerElement = document.getElementById('callTimer');
            if (timerElement) {
                timerElement.textContent = 
                    `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
        }, 1000);
    },
    
    stopCallTimer() {
        if (this.callTimer) {
            clearInterval(this.callTimer);
            this.callTimer = null;
        }
    },
    
    handleBeforeUnload(event) {
        if (this.state.isCallActive) {
            event.preventDefault();
            event.returnValue = 'Aktiv zənginiz var. Səhifəni bağlamaq istədiyinizə əminsiniz?';
            return event.returnValue;
        }
    },
    
    cleanup() {
        // Stop call timer
        this.stopCallTimer();
        
        // Close peer connection
        if (this.state.peerConnection) {
            this.state.peerConnection.close();
            this.state.peerConnection = null;
        }
        
        // Stop local stream
        if (this.state.localStream) {
            this.state.localStream.getTracks().forEach(track => track.stop());
            this.state.localStream = null;
        }
        
        // Reset state
        this.state.isCallActive = false;
        this.state.isVideoEnabled = false;
        this.state.isAudioEnabled = false;
        this.state.isScreenSharing = false;
        this.state.callType = null;
        this.state.callId = null;
        this.state.remoteStream = null;
    },
    
    destroy() {
        this.cleanup();
        this.hideCallUI();
        
        console.log('📞 WebRTC module destroyed');
    }
};

// Register module
if (window.App) {
    window.App.registerModule('webrtc', WebRTCModule);
}

// CSS for call interface
const callInterfaceCSS = `
.call-interface {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: #000;
    z-index: 2000;
    display: flex;
    flex-direction: column;
}

.call-videos {
    flex: 1;
    position: relative;
    overflow: hidden;
}

#remoteVideo {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.local-video {
    position: absolute;
    top: 20px;
    right: 20px;
    width: 200px;
    height: 150px;
    border-radius: 10px;
    border: 2px solid #fff;
    object-fit: cover;
    z-index: 10;
}

.call-controls {
    display: flex;
    justify-content: center;
    gap: 20px;
    padding: 30px;
    background: rgba(0, 0, 0, 0.8);
}

.call-control-btn {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    border: none;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    font-size: 24px;
    cursor: pointer;
    transition: all 0.3s ease;
    backdrop-filter: blur(10px);
}

.call-control-btn:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.1);
}

.call-control-btn.muted,
.call-control-btn.disabled {
    background: rgba(239, 68, 68, 0.8);
}

.call-control-btn.end-call {
    background: rgba(239, 68, 68, 0.8);
}

.call-control-btn.end-call:hover {
    background: rgba(220, 38, 38, 0.9);
}

.call-info {
    position: absolute;
    top: 30px;
    left: 30px;
    color: white;
    text-align: center;
}

.call-timer {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 5px;
}

.call-status {
    font-size: 14px;
    opacity: 0.8;
}

.incoming-call-modal .modal-content {
    max-width: 400px;
    text-align: center;
    padding: 40px;
}

.incoming-call-header img {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    margin-bottom: 20px;
    border: 4px solid #667eea;
}

.incoming-call-header h3 {
    margin-bottom: 10px;
    font-size: 24px;
}

.incoming-call-header p {
    color: #666;
    margin-bottom: 30px;
}

.call-actions {
    display: flex;
    justify-content: center;
    gap: 40px;
}

.call-btn {
    width: 70px;
    height: 70px;
    border-radius: 50%;
    border: none;
    font-size: 28px;
    color: white;
    cursor: pointer;
    transition: all 0.3s ease;
}

.call-btn.reject {
    background: #ef4444;
}

.call-btn.answer {
    background: #22c55e;
}

.call-btn:hover {
    transform: scale(1.1);
}

@media (max-width: 768px) {
    .local-video {
        width: 120px;
        height: 90px;
        top: 10px;
        right: 10px;
    }
    
    .call-controls {
        padding: 20px;
        gap: 15px;
    }
    
    .call-control-btn {
        width: 50px;
        height: 50px;
        font-size: 20px;
    }
    
    .call-info {
        top: 15px;
        left: 15px;
    }
    
    .call-timer {
        font-size: 18px;
    }
}
`;

// Add CSS to document
const style = document.createElement('style');
style.textContent = callInterfaceCSS;
document.head.appendChild(style);