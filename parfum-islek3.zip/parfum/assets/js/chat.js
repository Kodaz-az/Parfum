/**
 * Parfüm POS Sistemi - Chat JavaScript
 * Yaradıldığı tarix: 2025-07-21
 */

// Chat Application Class
class ChatApp {
    constructor() {
        this.ws = null;
        this.currentRoomId = null;
        this.currentUserId = null;
        this.isTyping = false;
        this.typingTimeout = null;
        this.mediaRecorder = null;
        this.recordedChunks = [];
        this.replyToMessageId = null;
        this.isLoadingMessages = false;
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.initializeWebSocket();
        this.setupEmojiPicker();
        this.setupFileUpload();
        this.setupVoiceRecording();
        this.loadMessages();
    }
    
    bindEvents() {
        // Message input events
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            messageInput.addEventListener('keydown', (e) => this.handleMessageInput(e));
            messageInput.addEventListener('input', () => this.handleTyping());
            messageInput.addEventListener('paste', (e) => this.handlePaste(e));
        }
        
        // Send button
        const sendBtn = document.getElementById('sendBtn');
        if (sendBtn) {
            sendBtn.addEventListener('click', () => this.sendMessage());
        }
        
        // Scroll to load more messages
        const messagesArea = document.getElementById('messagesArea');
        if (messagesArea) {
            messagesArea.addEventListener('scroll', () => this.handleScroll());
        }
        
        // Context menu for messages
        document.addEventListener('contextmenu', (e) => this.handleContextMenu(e));
        
        // Global keyboard shortcuts
        document.addEventListener('keydown', (e) => this.handleGlobalKeyboard(e));
        
        // Window focus/blur
        window.addEventListener('focus', () => this.handleWindowFocus());
        window.addEventListener('blur', () => this.handleWindowBlur());
        
        // Visibility change
        document.addEventListener('visibilitychange', () => this.handleVisibilityChange());
    }
    
    initializeWebSocket() {
        const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${wsProtocol}//${window.location.hostname}:8080`;
        
        this.ws = new WebSocket(wsUrl);
        
        this.ws.onopen = () => {
            console.log('WebSocket connected');
            this.sendIdentification();
            this.updateConnectionStatus(true);
        };
        
        this.ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleWebSocketMessage(data);
        };
        
        this.ws.onclose = () => {
            console.log('WebSocket disconnected');
            this.updateConnectionStatus(false);
            this.reconnectWebSocket();
        };
        
        this.ws.onerror = (error) => {
            console.error('WebSocket error:', error);
            this.updateConnectionStatus(false);
        };
    }
    
    reconnectWebSocket() {
        setTimeout(() => {
            console.log('Attempting to reconnect WebSocket...');
            this.initializeWebSocket();
        }, 3000);
    }
    
    sendIdentification() {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'identify',
                user_id: this.currentUserId,
                room_id: this.currentRoomId
            }));
        }
    }
    
    updateConnectionStatus(connected) {
        const statusIndicator = document.querySelector('.connection-status');
        if (statusIndicator) {
            statusIndicator.className = `connection-status ${connected ? 'connected' : 'disconnected'}`;
            statusIndicator.textContent = connected ? 'Bağlandı' : 'Bağlantı kəsildi';
        }
    }
    
    handleWebSocketMessage(data) {
        switch (data.type) {
            case 'new_message':
                this.handleNewMessage(data);
                break;
            case 'message_edited':
                this.handleMessageEdited(data);
                break;
            case 'message_deleted':
                this.handleMessageDeleted(data);
                break;
            case 'typing':
                this.handleTypingIndicator(data);
                break;
            case 'stop_typing':
                this.hideTypingIndicator();
                break;
            case 'user_online':
                this.handleUserOnline(data);
                break;
            case 'user_offline':
                this.handleUserOffline(data);
                break;
            case 'message_reaction':
                this.handleMessageReaction(data);
                break;
            case 'call_incoming':
                this.handleIncomingCall(data);
                break;
            case 'call_answered':
                this.handleCallAnswered(data);
                break;
            case 'call_ended':
                this.handleCallEnded(data);
                break;
        }
    }
    
    handleNewMessage(data) {
        if (data.room_id == this.currentRoomId) {
            this.appendMessage(data.message);
            this.scrollToBottom();
            
            // Mark as read if sender is not current user
            if (data.message.sender_id != this.currentUserId) {
                this.markMessageAsRead(data.message.id);
                this.showDesktopNotification(data.message);
                this.playNotificationSound();
            }
        }
        
        this.updateRoomUnreadCount(data.room_id);
        this.updateRoomLastMessage(data.room_id, data.message);
    }
    
    handleMessageEdited(data) {
        const messageElement = document.querySelector(`[data-message-id="${data.message_id}"]`);
        if (messageElement) {
            const contentElement = messageElement.querySelector('.message-text');
            if (contentElement) {
                contentElement.textContent = data.new_content;
                
                // Add edited indicator
                let editedIndicator = messageElement.querySelector('.message-edited');
                if (!editedIndicator) {
                    editedIndicator = document.createElement('span');
                    editedIndicator.className = 'message-edited';
                    editedIndicator.textContent = 'düzəliş edilib';
                    messageElement.querySelector('.message-meta').appendChild(editedIndicator);
                }
            }
        }
    }
    
    handleMessageDeleted(data) {
        const messageElement = document.querySelector(`[data-message-id="${data.message_id}"]`);
        if (messageElement) {
            messageElement.classList.add('deleted');
            const contentElement = messageElement.querySelector('.message-text');
            if (contentElement) {
                contentElement.innerHTML = '<i class="fas fa-trash"></i> Bu mesaj silindi';
                contentElement.classList.add('deleted-content');
            }
        }
    }
    
    handleTypingIndicator(data) {
        if (data.room_id == this.currentRoomId && data.user_id != this.currentUserId) {
            this.showTypingIndicator(data.user_name);
        }
    }
    
    showTypingIndicator(userName) {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.querySelector('.typing-text').textContent = `${userName} yazır...`;
            indicator.style.display = 'flex';
            this.scrollToBottom();
            
            // Auto hide after 3 seconds
            setTimeout(() => {
                this.hideTypingIndicator();
            }, 3000);
        }
    }
    
    hideTypingIndicator() {
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.style.display = 'none';
        }
    }
    
    sendMessage() {
        const input = document.getElementById('messageInput');
        const message = input.value.trim();
        
        if (!message || !this.currentRoomId) return;
        
        // Show sending state
        this.showSendingState();
        
        const data = {
            room_id: this.currentRoomId,
            content: message,
            type: 'text',
            reply_to: this.replyToMessageId
        };
        
        fetch('/api/chat/send-message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
            this.hideSendingState();
            
            if (data.success) {
                input.value = '';
                this.cancelReply();
                this.resizeTextarea();
                
                // Add optimistic message
                this.addOptimisticMessage(message);
            } else {
                this.showError(data.message || 'Mesaj göndərilmədi');
            }
        })
        .catch(error => {
            this.hideSendingState();
            console.error('Error:', error);
            this.showError('Xəta baş verdi');
        });
    }
    
    addOptimisticMessage(content) {
        const message = {
            id: 'temp_' + Date.now(),
            content: content,
            sender_id: this.currentUserId,
            sender_name: this.getCurrentUserName(),
            sender_avatar: this.getCurrentUserAvatar(),
            message_type: 'text',
            created_at: new Date().toISOString(),
            is_optimistic: true
        };
        
        this.appendMessage(message);
        this.scrollToBottom();
    }
    
    appendMessage(message) {
        const container = document.getElementById('messagesContainer');
        if (!container) return;
        
        // Check if message already exists (prevent duplicates)
        if (document.querySelector(`[data-message-id="${message.id}"]`)) {
            return;
        }
        
        const messageElement = this.createMessageElement(message);
        container.appendChild(messageElement);
        
        // Animate new message
        messageElement.style.opacity = '0';
        messageElement.style.transform = 'translateY(20px)';
        
        requestAnimationFrame(() => {
            messageElement.style.transition = 'all 0.3s ease';
            messageElement.style.opacity = '1';
            messageElement.style.transform = 'translateY(0)';
        });
        
        // Auto-scroll if user is at bottom
        if (this.isScrolledToBottom()) {
            this.scrollToBottom();
        }
    }
    
    createMessageElement(message) {
        const div = document.createElement('div');
        div.className = `message ${message.sender_id == this.currentUserId ? 'own' : 'other'}`;
        div.setAttribute('data-message-id', message.id);
        
        if (message.is_optimistic) {
            div.classList.add('optimistic');
        }
        
        let avatarHtml = '';
        if (message.sender_id != this.currentUserId) {
            avatarHtml = `
                <div class="message-avatar">
                    <img src="/uploads/avatars/${message.sender_avatar}" 
                         alt="${this.escapeHtml(message.sender_name)}"
                         onerror="this.src='/assets/images/default-avatar.png'">
                </div>
            `;
        }
        
        let contentHtml = this.createMessageContent(message);
        
        let reactionsHtml = '';
        if (message.reactions && message.reactions.length > 0) {
            reactionsHtml = this.createReactionsHtml(message.reactions);
        }
        
        div.innerHTML = `
            ${avatarHtml}
            <div class="message-content">
                ${message.reply_to ? this.createReplyHtml(message) : ''}
                <div class="message-bubble">
                    ${contentHtml}
                    ${reactionsHtml}
                </div>
                <div class="message-meta">
                    <span class="message-time">${this.formatTime(message.created_at)}</span>
                    ${message.is_edited ? '<span class="message-edited">düzəliş edilib</span>' : ''}
                    ${message.sender_id == this.currentUserId ? '<span class="message-status"><i class="fas fa-check"></i></span>' : ''}
                </div>
            </div>
            <div class="message-menu">
                <button onclick="chatApp.replyToMessage(${message.id})" title="Cavab ver">
                    <i class="fas fa-reply"></i>
                </button>
                <button onclick="chatApp.showReactionPicker(${message.id})" title="Reaksiya">
                    <i class="fas fa-smile"></i>
                </button>
                ${message.sender_id == this.currentUserId ? `
                    <button onclick="chatApp.editMessage(${message.id})" title="Düzəliş">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button onclick="chatApp.deleteMessage(${message.id})" title="Sil">
                        <i class="fas fa-trash"></i>
                    </button>
                ` : ''}
            </div>
        `;
        
        return div;
    }
    
    createMessageContent(message) {
        switch (message.message_type) {
            case 'text':
                return `<div class="message-text">${this.formatMessageText(message.content)}</div>`;
            
            case 'image':
                const metadata = JSON.parse(message.metadata || '{}');
                return `
                    <div class="message-image">
                        <img src="/uploads/chat/images/${message.file_name}" 
                             alt="Image" 
                             onclick="chatApp.showImageModal(this.src)"
                             loading="lazy">
                        ${message.content ? `<div class="image-caption">${this.escapeHtml(message.content)}</div>` : ''}
                    </div>
                `;
            
            case 'audio':
                return `
                    <div class="message-audio">
                        <audio controls preload="metadata">
                            <source src="/uploads/chat/audios/${message.file_name}" type="audio/mpeg">
                            <source src="/uploads/chat/audios/${message.file_name}" type="audio/wav">
                            Brauzeriniz audio faylını dəstəkləmir.
                        </audio>
                        <div class="audio-info">
                            <i class="fas fa-microphone"></i>
                            <span>Səs mesajı</span>
                        </div>
                    </div>
                `;
            
            case 'video':
                return `
                    <div class="message-video">
                        <video controls width="300" preload="metadata">
                            <source src="/uploads/chat/videos/${message.file_name}" type="video/mp4">
                            <source src="/uploads/chat/videos/${message.file_name}" type="video/webm">
                            Brauzeriniz video faylını dəstəkləmir.
                        </video>
                    </div>
                `;
            
            case 'document':
                return `
                    <div class="message-document">
                        <div class="document-icon">
                            <i class="fas fa-file-${this.getFileIcon(message.file_name)}"></i>
                        </div>
                        <div class="document-info">
                            <a href="/uploads/chat/documents/${message.file_name}" 
                               download="${this.escapeHtml(message.content)}"
                               class="document-name">
                                ${this.escapeHtml(message.content)}
                            </a>
                            <div class="document-size">${this.formatFileSize(message.file_size)}</div>
                        </div>
                        <button onclick="chatApp.downloadFile('/uploads/chat/documents/${message.file_name}', '${message.content}')" 
                                class="download-btn" title="Yüklə">
                            <i class="fas fa-download"></i>
                        </button>
                    </div>
                `;
            
            case 'location':
                const location = JSON.parse(message.metadata || '{}');
                return `
                    <div class="message-location">
                        <div class="location-preview">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Məkan paylaşıldı</span>
                        </div>
                        <a href="https://www.google.com/maps?q=${location.latitude},${location.longitude}" 
                           target="_blank" class="location-link">
                            <i class="fas fa-external-link-alt"></i>
                            Xəritədə aç
                        </a>
                    </div>
                `;
            
            case 'system':
                return `
                    <div class="system-message">
                        <i class="fas fa-info-circle"></i>
                        ${this.escapeHtml(message.content)}
                    </div>
                `;
            
            default:
                return `<div class="message-text">${this.escapeHtml(message.content)}</div>`;
        }
    }
    
    formatMessageText(text) {
        // Convert URLs to links
        text = text.replace(
            /(https?:\/\/[^\s]+)/g,
            '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
        );
        
        // Convert newlines to <br>
        text = text.replace(/\n/g, '<br>');
        
        // Convert @mentions to links
        text = text.replace(
            /@(\w+)/g,
            '<span class="mention">@$1</span>'
        );
        
        // Convert #hashtags to links
        text = text.replace(
            /#(\w+)/g,
            '<span class="hashtag">#$1</span>'
        );
        
        return text;
    }
    
    handleMessageInput(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            this.sendMessage();
        } else if (event.key === 'Escape') {
            this.cancelReply();
        }
        
        this.resizeTextarea();
    }
    
    handleTyping() {
        if (!this.isTyping && this.currentRoomId) {
            this.isTyping = true;
            this.sendTypingIndicator();
        }
        
        clearTimeout(this.typingTimeout);
        this.typingTimeout = setTimeout(() => {
            this.isTyping = false;
            this.sendStopTypingIndicator();
        }, 2000);
    }
    
    sendTypingIndicator() {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'typing',
                room_id: this.currentRoomId,
                user_id: this.currentUserId
            }));
        }
    }
    
    sendStopTypingIndicator() {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'stop_typing',
                room_id: this.currentRoomId,
                user_id: this.currentUserId
            }));
        }
    }
    
    resizeTextarea() {
        const textarea = document.getElementById('messageInput');
        if (textarea) {
            textarea.style.height = 'auto';
            textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
        }
    }
    
    scrollToBottom() {
        const messagesArea = document.getElementById('messagesArea');
        if (messagesArea) {
            messagesArea.scrollTop = messagesArea.scrollHeight;
        }
    }
    
    isScrolledToBottom() {
        const messagesArea = document.getElementById('messagesArea');
        if (!messagesArea) return false;
        
        const threshold = 100;
        return messagesArea.scrollHeight - messagesArea.clientHeight <= messagesArea.scrollTop + threshold;
    }
    
    handleScroll() {
        const messagesArea = document.getElementById('messagesArea');
        if (!messagesArea || this.isLoadingMessages) return;
        
        // Load more messages when scrolled to top
        if (messagesArea.scrollTop === 0) {
            this.loadMoreMessages();
        }
        
        // Show/hide scroll to bottom button
        const scrollBtn = document.querySelector('.scroll-to-bottom');
        if (scrollBtn) {
            if (this.isScrolledToBottom()) {
                scrollBtn.style.display = 'none';
            } else {
                scrollBtn.style.display = 'block';
            }
        }
    }
    
    loadMoreMessages() {
        if (this.isLoadingMessages || !this.currentRoomId) return;
        
        this.isLoadingMessages = true;
        this.showLoadingIndicator();
        
        const firstMessage = document.querySelector('.message');
        const beforeMessageId = firstMessage ? firstMessage.getAttribute('data-message-id') : null;
        
        fetch(`/api/chat/messages?room_id=${this.currentRoomId}&before=${beforeMessageId}`)
        .then(response => response.json())
        .then(data => {
            this.hideLoadingIndicator();
            this.isLoadingMessages = false;
            
            if (data.success && data.messages.length > 0) {
                const container = document.getElementById('messagesContainer');
                const oldScrollHeight = container.scrollHeight;
                
                // Prepend messages
                data.messages.reverse().forEach(message => {
                    const messageElement = this.createMessageElement(message);
                    container.insertBefore(messageElement, container.firstChild);
                });
                
                // Maintain scroll position
                const newScrollHeight = container.scrollHeight;
                container.scrollTop = newScrollHeight - oldScrollHeight;
            }
        })
        .catch(error => {
            this.hideLoadingIndicator();
            this.isLoadingMessages = false;
            console.error('Error loading messages:', error);
        });
    }
    
    // Emoji picker functionality
    setupEmojiPicker() {
        const emojiPicker = document.getElementById('emojiPicker');
        if (!emojiPicker) return;
        
        // Popular emojis
        const popularEmojis = [
            '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
            '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚',
            '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩',
            '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣',
            '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬',
            '👍', '👎', '👌', '✌️', '🤞', '🤟', '🤘', '🤙', '👈', '👉',
            '👆', '👇', '☝️', '👏', '🙌', '👐', '🤲', '🤝', '🙏', '❤️',
            '🧡', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💔', '❣️',
            '💕', '💞', '💓', '💗', '💖', '💘', '💝', '💟', '✨', '💫',
            '⭐', '🌟', '💥', '💦', '💨', '🔥'
        ];
        
        // Create emoji grid
        const emojiGrid = emojiPicker.querySelector('.emoji-grid');
        if (emojiGrid) {
            emojiGrid.innerHTML = popularEmojis.map(emoji => 
                `<span class="emoji-item" onclick="chatApp.insertEmoji('${emoji}')">${emoji}</span>`
            ).join('');
        }
    }
    
    insertEmoji(emoji) {
        const input = document.getElementById('messageInput');
        if (!input) return;
        
        const start = input.selectionStart;
        const end = input.selectionEnd;
        const text = input.value;
        
        input.value = text.slice(0, start) + emoji + text.slice(end);
        input.setSelectionRange(start + emoji.length, start + emoji.length);
        input.focus();
        
        this.hideEmojiPicker();
        this.resizeTextarea();
    }
    
    showEmojiPicker() {
        const picker = document.getElementById('emojiPicker');
        if (picker) {
            picker.style.display = 'block';
        }
    }
    
    hideEmojiPicker() {
        const picker = document.getElementById('emojiPicker');
        if (picker) {
            picker.style.display = 'none';
        }
    }
    
    // File upload functionality
    setupFileUpload() {
        // Drag and drop
        const messagesArea = document.getElementById('messagesArea');
        if (messagesArea) {
            messagesArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                messagesArea.classList.add('drag-over');
            });
            
            messagesArea.addEventListener('dragleave', (e) => {
                e.preventDefault();
                messagesArea.classList.remove('drag-over');
            });
            
            messagesArea.addEventListener('drop', (e) => {
                e.preventDefault();
                messagesArea.classList.remove('drag-over');
                
                const files = Array.from(e.dataTransfer.files);
                files.forEach(file => this.uploadFile(file));
            });
        }
    }
    
    uploadFile(file, type = null) {
        if (!file || !this.currentRoomId) return;
        
        // Determine file type
        if (!type) {
            if (file.type.startsWith('image/')) type = 'image';
            else if (file.type.startsWith('audio/')) type = 'audio';
            else if (file.type.startsWith('video/')) type = 'video';
            else type = 'document';
        }
        
        // Validate file size (10MB limit)
        if (file.size > 10 * 1024 * 1024) {
            this.showError('Fayl ölçüsü 10MB-dan böyük ola bilməz');
            return;
        }
        
        const formData = new FormData();
        formData.append('file', file);
        formData.append('room_id', this.currentRoomId);
        formData.append('type', type);
        
        // Show upload progress
        const progressId = this.showUploadProgress(file.name);
        
        fetch('/api/chat/upload-file', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            this.hideUploadProgress(progressId);
            
            if (data.success) {
                // File uploaded successfully, message will be added via WebSocket
                console.log('File uploaded successfully');
            } else {
                this.showError(data.message || 'Fayl yüklənmədi');
            }
        })
        .catch(error => {
            this.hideUploadProgress(progressId);
            console.error('Error:', error);
            this.showError('Fayl yükləmə xətası');
        });
    }
    
    showUploadProgress(fileName) {
        const progressId = 'upload_' + Date.now();
        const progressElement = document.createElement('div');
        progressElement.id = progressId;
        progressElement.className = 'upload-progress';
        progressElement.innerHTML = `
            <div class="upload-info">
                <i class="fas fa-upload"></i>
                <span>${this.escapeHtml(fileName)}</span>
            </div>
            <div class="progress-bar">
                <div class="progress-fill"></div>
            </div>
        `;
        
        const container = document.getElementById('messagesContainer');
        if (container) {
            container.appendChild(progressElement);
            this.scrollToBottom();
        }
        
        return progressId;
    }
    
    hideUploadProgress(progressId) {
        const element = document.getElementById(progressId);
        if (element) {
            element.remove();
        }
    }
    
    // Voice recording
    setupVoiceRecording() {
        this.checkMicrophonePermission();
    }
    
    async checkMicrophonePermission() {
        try {
            if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                stream.getTracks().forEach(track => track.stop());
                console.log('Microphone permission granted');
            }
        } catch (error) {
            console.log('Microphone permission denied or not available');
        }
    }
    
    async startVoiceRecording() {
        if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
            this.stopVoiceRecording();
            return;
        }
        
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    sampleRate: 44100
                }
            });
            
            this.mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'audio/webm;codecs=opus'
            });
            
            this.recordedChunks = [];
            
            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.recordedChunks.push(event.data);
                }
            };
            
            this.mediaRecorder.onstop = () => {
                const blob = new Blob(this.recordedChunks, { type: 'audio/webm' });
                this.uploadVoiceMessage(blob);
                
                // Stop all tracks
                stream.getTracks().forEach(track => track.stop());
            };
            
            this.mediaRecorder.start();
            this.showRecordingUI();
            
        } catch (error) {
            console.error('Error accessing microphone:', error);
            this.showError('Mikrofona giriş icazəsi lazımdır');
        }
    }
    
    stopVoiceRecording() {
        if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
            this.mediaRecorder.stop();
            this.hideRecordingUI();
        }
    }
    
    showRecordingUI() {
        const btn = document.querySelector('.voice-record');
        if (btn) {
            btn.classList.add('recording');
            btn.innerHTML = '<i class="fas fa-stop"></i>';
            btn.title = 'Yazmağı dayandır';
        }
        
        // Show recording indicator
        const indicator = document.createElement('div');
        indicator.id = 'recordingIndicator';
        indicator.className = 'recording-indicator';
        indicator.innerHTML = `
            <div class="recording-animation">
                <div class="recording-dot"></div>
                <span>Səs yazılır...</span>
            </div>
        `;
        
        const inputArea = document.querySelector('.message-input-area');
        if (inputArea) {
            inputArea.appendChild(indicator);
        }
    }
    
    hideRecordingUI() {
        const btn = document.querySelector('.voice-record');
        if (btn) {
            btn.classList.remove('recording');
            btn.innerHTML = '<i class="fas fa-microphone"></i>';
            btn.title = 'Səs yazısı';
        }
        
        const indicator = document.getElementById('recordingIndicator');
        if (indicator) {
            indicator.remove();
        }
    }
    
    uploadVoiceMessage(blob) {
        const formData = new FormData();
        formData.append('file', blob, 'voice-message.webm');
        formData.append('room_id', this.currentRoomId);
        formData.append('type', 'audio');
        
        fetch('/api/chat/upload-file', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Voice message sent successfully');
            } else {
                this.showError(data.message || 'Səs mesajı göndərilmədi');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            this.showError('Səs mesajı göndərmə xətası');
        });
    }
    
    // Utility functions
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    formatTime(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;
        
        // If today, show time
        if (diff < 24 * 60 * 60 * 1000 && date.getDate() === now.getDate()) {
            return date.toLocaleTimeString('az-AZ', { 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: false 
            });
        }
        
        // If this week, show day and time
        if (diff < 7 * 24 * 60 * 60 * 1000) {
            return date.toLocaleDateString('az-AZ', { 
                weekday: 'short',
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            });
        }
        
        // Otherwise show date
        return date.toLocaleDateString('az-AZ', { 
            day: '2-digit',
            month: '2-digit',
            year: '2-digit'
        });
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    getFileIcon(fileName) {
        const extension = fileName.split('.').pop().toLowerCase();
        
        const iconMap = {
            'pdf': 'pdf',
            'doc': 'word',
            'docx': 'word',
            'xls': 'excel',
            'xlsx': 'excel',
            'ppt': 'powerpoint',
            'pptx': 'powerpoint',
            'txt': 'alt',
            'zip': 'archive',
            'rar': 'archive',
            '7z': 'archive'
        };
        
        return iconMap[extension] || 'file';
    }
    
    showError(message) {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = 'toast toast-error';
        toast.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <span>${this.escapeHtml(message)}</span>
            <button onclick="this.parentElement.remove()" class="toast-close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        const container = document.querySelector('.toast-container') || document.body;
        container.appendChild(toast);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 5000);
    }
    
    showSuccess(message) {
        const toast = document.createElement('div');
        toast.className = 'toast toast-success';
        toast.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>${this.escapeHtml(message)}</span>
            <button onclick="this.parentElement.remove()" class="toast-close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        const container = document.querySelector('.toast-container') || document.body;
        container.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 3000);
    }
    
    // Desktop notifications
    showDesktopNotification(message) {
        if ('Notification' in window && Notification.permission === 'granted') {
            const notification = new Notification(message.sender_name, {
                body: message.content,
                icon: `/uploads/avatars/${message.sender_avatar}`,
                badge: '/assets/icons/badge-72x72.png',
                tag: `chat-${message.room_id}`,
                requireInteraction: false
            });
            
            notification.onclick = () => {
                window.focus();
                notification.close();
            };
            
            // Auto close after 5 seconds
            setTimeout(() => {
                notification.close();
            }, 5000);
        }
    }
    
    playNotificationSound() {
        if (this.isWindowVisible && !this.isMuted) {
            const audio = new Audio('/assets/sounds/notification.mp3');
            audio.volume = 0.5;
            audio.play().catch(error => {
                console.log('Could not play notification sound:', error);
            });
        }
    }
    
    // Window focus/blur handling
    handleWindowFocus() {
        this.isWindowVisible = true;
        
        // Mark messages as read
        if (this.currentRoomId) {
            this.markRoomAsRead();
        }
    }
    
    handleWindowBlur() {
        this.isWindowVisible = false;
    }
    
    handleVisibilityChange() {
        if (document.visibilityState === 'visible') {
            this.handleWindowFocus();
        } else {
            this.handleWindowBlur();
        }
    }
    
    markRoomAsRead() {
        if (!this.currentRoomId) return;
        
        fetch('/api/chat/mark-room-as-read', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                room_id: this.currentRoomId
            })
        })
        .catch(error => {
            console.error('Error marking room as read:', error);
        });
    }
    
    markMessageAsRead(messageId) {
        fetch('/api/chat/mark-message-as-read', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            },
            body: JSON.stringify({
                message_id: messageId
            })
        })
        .catch(error => {
            console.error('Error marking message as read:', error);
        });
    }
}

// Initialize chat app when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.chatApp = new ChatApp();
});