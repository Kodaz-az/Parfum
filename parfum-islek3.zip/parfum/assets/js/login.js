/**
 * Parfüm POS Sistemi - Login JavaScript
 * Yaradıldığı tarix: 2025-07-21
 */

// Form validation
function validateLoginForm() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    
    if (!username) {
        showError('İstifadəçi adı tələb olunur');
        return false;
    }
    
    if (username.length < 3) {
        showError('İstifadəçi adı ən azı 3 simvol olmalıdır');
        return false;
    }
    
    if (!password) {
        showError('Şifrə tələb olunur');
        return false;
    }
    
    if (password.length < 6) {
        showError('Şifrə ən azı 6 simvol olmalıdır');
        return false;
    }
    
    return true;
}

function showError(message) {
    // Remove existing alerts
    const existingAlert = document.querySelector('.alert');
    if (existingAlert) {
        existingAlert.remove();
    }
    
    // Create new alert
    const alert = document.createElement('div');
    alert.className = 'alert alert-error';
    alert.innerHTML = `<i class="fas fa-exclamation-circle"></i>${message}`;
    
    // Insert before form
    const form = document.querySelector('.login-form');
    form.parentNode.insertBefore(alert, form);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (alert.parentNode) {
            alert.remove();
        }
    }, 5000);
}

// Enhanced form submission with loading state
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const loginBtn = document.getElementById('loginBtn');
    const btnText = loginBtn.querySelector('.btn-text');
    const btnSpinner = loginBtn.querySelector('.btn-spinner');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            if (!validateLoginForm()) {
                e.preventDefault();
                return false;
            }
            
            // Show loading state
            btnText.style.display = 'none';
            btnSpinner.style.display = 'inline-block';
            loginBtn.disabled = true;
            
            // Reset button state after 10 seconds (in case of network issues)
            setTimeout(() => {
                btnText.style.display = 'inline';
                btnSpinner.style.display = 'none';
                loginBtn.disabled = false;
            }, 10000);
        });
    }
    
    // Auto-focus first input
    const usernameInput = document.getElementById('username');
    if (usernameInput) {
        usernameInput.focus();
    }
    
    // Enter key navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            const focusedElement = document.activeElement;
            
            if (focusedElement.id === 'username') {
                document.getElementById('password').focus();
                e.preventDefault();
            } else if (focusedElement.id === 'password') {
                if (validateLoginForm()) {
                    loginForm.submit();
                }
                e.preventDefault();
            }
        }
    });
    
    // Password strength indicator
    const passwordInput = document.getElementById('password');
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            const strength = calculatePasswordStrength(password);
            showPasswordStrength(strength);
        });
    }
});

function calculatePasswordStrength(password) {
    let score = 0;
    
    if (password.length >= 6) score += 1;
    if (password.length >= 8) score += 1;
    if (/[a-z]/.test(password)) score += 1;
    if (/[A-Z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;
    
    if (score < 3) return 'weak';
    if (score < 5) return 'medium';
    return 'strong';
}

function showPasswordStrength(strength) {
    let existingIndicator = document.querySelector('.password-strength');
    
    if (!existingIndicator) {
        existingIndicator = document.createElement('div');
        existingIndicator.className = 'password-strength';
        existingIndicator.style.cssText = `
            margin-top: 0.5rem;
            font-size: 0.75rem;
            font-weight: 500;
        `;
        
        const passwordGroup = document.querySelector('.password-input').parentNode;
        passwordGroup.appendChild(existingIndicator);
    }
    
    const strengthConfig = {
        weak: { text: 'Zəif şifrə', color: '#ef4444' },
        medium: { text: 'Orta şifrə', color: '#f59e0b' },
        strong: { text: 'Güclü şifrə', color: '#22c55e' }
    };
    
    const config = strengthConfig[strength];
    if (config) {
        existingIndicator.textContent = config.text;
        existingIndicator.style.color = config.color;
    }
}

// Caps Lock detection
document.addEventListener('keydown', function(e) {
    const capsLockOn = e.getModifierState && e.getModifierState('CapsLock');
    const passwordInput = document.getElementById('password');
    
    if (passwordInput && document.activeElement === passwordInput) {
        showCapsLockWarning(capsLockOn);
    }
});

function showCapsLockWarning(isOn) {
    let warning = document.querySelector('.caps-lock-warning');
    
    if (isOn && !warning) {
        warning = document.createElement('div');
        warning.className = 'caps-lock-warning';
        warning.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Caps Lock aktivdir';
        warning.style.cssText = `
            margin-top: 0.5rem;
            font-size: 0.75rem;
            color: #f59e0b;
            display: flex;
            align-items: center;
            gap: 0.25rem;
        `;
        
        const passwordGroup = document.querySelector('.password-input').parentNode;
        passwordGroup.appendChild(warning);
    } else if (!isOn && warning) {
        warning.remove();
    }
}

// Remember me functionality
function handleRememberMe() {
    const rememberCheckbox = document.getElementById('remember');
    const usernameInput = document.getElementById('username');
    
    // Load saved username
    const savedUsername = localStorage.getItem('rememberedUsername');
    if (savedUsername && usernameInput) {
        usernameInput.value = savedUsername;
        rememberCheckbox.checked = true;
    }
    
    // Save username when form is submitted
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function() {
            if (rememberCheckbox.checked) {
                localStorage.setItem('rememberedUsername', usernameInput.value);
            } else {
                localStorage.removeItem('rememberedUsername');
            }
        });
    }
}

// Initialize remember me functionality
document.addEventListener('DOMContentLoaded', handleRememberMe);

// Theme detection and handling
function detectAndApplyTheme() {
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    const theme = savedTheme || (prefersDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
    
    // Listen for theme changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
        if (!localStorage.getItem('theme')) {
            document.documentElement.setAttribute('data-theme', e.matches ? 'dark' : 'light');
        }
    });
}

// Initialize theme
document.addEventListener('DOMContentLoaded', detectAndApplyTheme);

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + Enter to submit form
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        const loginForm = document.getElementById('loginForm');
        if (loginForm && validateLoginForm()) {
            loginForm.submit();
        }
        e.preventDefault();
    }
    
    // ESC to clear form
    if (e.key === 'Escape') {
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        
        if (usernameInput) usernameInput.value = '';
        if (passwordInput) passwordInput.value = '';
        
        // Remove any alerts
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => alert.remove());
    }
});

// Form auto-completion enhancement
function enhanceFormAutoComplete() {
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    
    if (usernameInput) {
        usernameInput.addEventListener('input', function() {
            // Remove any previous error styling
            this.classList.remove('error');
            
            // Real-time validation feedback
            if (this.value.length > 0 && this.value.length < 3) {
                this.style.borderColor = '#f59e0b';
            } else if (this.value.length >= 3) {
                this.style.borderColor = '#22c55e';
            } else {
                this.style.borderColor = '';
            }
        });
    }
    
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            this.classList.remove('error');
            
            if (this.value.length > 0 && this.value.length < 6) {
                this.style.borderColor = '#f59e0b';
            } else if (this.value.length >= 6) {
                this.style.borderColor = '#22c55e';
            } else {
                this.style.borderColor = '';
            }
        });
    }
}

// Initialize form enhancements
document.addEventListener('DOMContentLoaded', enhanceFormAutoComplete);

// Performance monitoring
function trackPerformance() {
    if ('performance' in window) {
        window.addEventListener('load', function() {
            setTimeout(function() {
                const perfData = performance.getEntriesByType('navigation')[0];
                const loadTime = perfData.loadEventEnd - perfData.loadEventStart;
                
                console.log(`Login page loaded in ${loadTime}ms`);
                
                // Send performance data to analytics if needed
                if (loadTime > 3000) {
                    console.warn('Login page load time is slow:', loadTime + 'ms');
                }
            }, 0);
        });
    }
}

// Initialize performance tracking
trackPerformance();

// Accessibility enhancements
function enhanceAccessibility() {
    // Add ARIA labels
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    
    if (usernameInput) {
        usernameInput.setAttribute('aria-describedby', 'username-help');
        usernameInput.setAttribute('aria-required', 'true');
    }
    
    if (passwordInput) {
        passwordInput.setAttribute('aria-describedby', 'password-help');
        passwordInput.setAttribute('aria-required', 'true');
    }
    
    // Add screen reader announcements for dynamic content
    const srAnnouncer = document.createElement('div');
    srAnnouncer.className = 'sr-only';
    srAnnouncer.setAttribute('aria-live', 'polite');
    srAnnouncer.setAttribute('aria-atomic', 'true');
    document.body.appendChild(srAnnouncer);
    
    window.announceToScreenReader = function(message) {
        srAnnouncer.textContent = message;
        setTimeout(() => {
            srAnnouncer.textContent = '';
        }, 1000);
    };
}

// Initialize accessibility
document.addEventListener('DOMContentLoaded', enhanceAccessibility);

// Error handling for network issues
function handleNetworkErrors() {
    window.addEventListener('offline', function() {
        showError('İnternet bağlantısı kəsildi. Zəhmət olmasa bağlantınızı yoxlayın.');
    });
    
    window.addEventListener('online', function() {
        const alerts = document.querySelectorAll('.alert-error');
        alerts.forEach(alert => {
            if (alert.textContent.includes('İnternet bağlantısı')) {
                alert.remove();
            }
        });
        
        announceToScreenReader('İnternet bağlantısı bərpa edildi');
    });
}

// Initialize network error handling
handleNetworkErrors();