/**
 * Parfüm POS Sistemi - App JavaScript
 * Yaradıldığı tarix: 2025-07-21
 */

// Global App Object
window.ParfumApp = {
    config: {
        baseUrl: window.BASE_URL || '/',
        csrfToken: window.CSRF_TOKEN || '',
        currentUser: window.CURRENT_USER || null,
        theme: localStorage.getItem('theme') || 'light',
        language: localStorage.getItem('language') || 'az'
    },
    
    state: {
        sidebarCollapsed: localStorage.getItem('sidebar_collapsed') === 'true',
        notifications: [],
        isOnline: navigator.onLine,
        lastActivity: Date.now()
    },
    
    modules: {},
    
    init() {
        this.bindEvents();
        this.initTheme();
        this.initSidebar();
        this.initNotifications();
        this.initToasts();
        this.startActivityTracking();
        this.checkConnection();
        
        console.log('🚀 Parfüm POS App initialized');
    },
    
    bindEvents() {
        // Global event listeners
        document.addEventListener('click', this.handleGlobalClick.bind(this));
        document.addEventListener('keydown', this.handleGlobalKeydown.bind(this));
        window.addEventListener('online', this.handleOnline.bind(this));
        window.addEventListener('offline', this.handleOffline.bind(this));
        window.addEventListener('beforeunload', this.handleBeforeUnload.bind(this));
        
        // Custom events
        document.addEventListener('app:notification', this.handleNotification.bind(this));
        document.addEventListener('app:toast', this.handleToast.bind(this));
        document.addEventListener('app:theme-change', this.handleThemeChange.bind(this));
    },
    
    handleGlobalClick(event) {
        // Close dropdowns when clicking outside
        const dropdowns = document.querySelectorAll('.dropdown.show, .user-menu.show, .notifications-panel.show');
        dropdowns.forEach(dropdown => {
            if (!dropdown.contains(event.target)) {
                dropdown.classList.remove('show');
            }
        });
        
        // Handle external links
        if (event.target.matches('a[href^="http"]')) {
            event.target.setAttribute('target', '_blank');
            event.target.setAttribute('rel', 'noopener noreferrer');
        }
    },
    
    handleGlobalKeydown(event) {
        // Global keyboard shortcuts
        if (event.ctrlKey || event.metaKey) {
            switch (event.key) {
                case '/':
                    event.preventDefault();
                    this.focusGlobalSearch();
                    break;
                case 'k':
                    event.preventDefault();
                    this.openCommandPalette();
                    break;
                case 'b':
                    event.preventDefault();
                    this.toggleSidebar();
                    break;
                case 'n':
                    if (event.shiftKey) {
                        event.preventDefault();
                        this.openNewSaleModal();
                    }
                    break;
            }
        }
        
        // ESC key handling
        if (event.key === 'Escape') {
            this.closeModals();
            this.clearSearch();
        }
    },
    
    handleOnline() {
        this.state.isOnline = true;
        this.showToast('İnternet bağlantısı bərpa edildi', 'success');
        this.updateConnectionStatus(true);
        this.syncOfflineData();
    },
    
    handleOffline() {
        this.state.isOnline = false;
        this.showToast('İnternet bağlantısı kəsildi', 'warning');
        this.updateConnectionStatus(false);
    },
    
    handleBeforeUnload(event) {
        // Save user state before page unload
        this.saveUserState();
        
        // Show confirmation for unsaved changes
        if (this.hasUnsavedChanges()) {
            event.preventDefault();
            event.returnValue = 'Yadda saxlanmamış dəyişiklikləriniz var. Çıxmaq istədiyinizə əminsiniz?';
            return event.returnValue;
        }
    },
    
    // Theme Management
    initTheme() {
        const theme = this.config.theme;
        document.documentElement.setAttribute('data-theme', theme);
        
        const themeIcon = document.getElementById('themeIcon');
        if (themeIcon) {
            themeIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    },
    
    toggleTheme() {
        const currentTheme = this.config.theme;
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        this.config.theme = newTheme;
        localStorage.setItem('theme', newTheme);
        
        document.documentElement.setAttribute('data-theme', newTheme);
        
        const themeIcon = document.getElementById('themeIcon');
        if (themeIcon) {
            themeIcon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
        
        this.dispatchEvent('app:theme-change', { theme: newTheme });
        this.showToast(`${newTheme === 'dark' ? 'Qaranlıq' : 'İşıqlı'} tema aktivləşdirildi`, 'info');
    },
    
    handleThemeChange(event) {
        // Handle theme change in modules
        Object.values(this.modules).forEach(module => {
            if (module.onThemeChange) {
                module.onThemeChange(event.detail.theme);
            }
        });
    },
    
    // Sidebar Management
    initSidebar() {
        if (this.state.sidebarCollapsed) {
            document.body.classList.add('sidebar-collapsed');
        }
    },
    
    toggleSidebar() {
        const body = document.body;
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        
        if (window.innerWidth <= 768) {
            // Mobile: Show/hide sidebar
            sidebar.classList.toggle('mobile-open');
            overlay.classList.toggle('show');
        } else {
            // Desktop: Collapse/expand sidebar
            body.classList.toggle('sidebar-collapsed');
            this.state.sidebarCollapsed = body.classList.contains('sidebar-collapsed');
            localStorage.setItem('sidebar_collapsed', this.state.sidebarCollapsed);
        }
    },
    
    // Notification System
    initNotifications() {
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission();
        }
        
        this.loadNotifications();
    },
    
    async loadNotifications() {
        try {
            const response = await this.api('/api/notifications');
            if (response.success) {
                this.state.notifications = response.notifications;
                this.updateNotificationUI();
            }
        } catch (error) {
            console.error('Failed to load notifications:', error);
        }
    },
    
    handleNotification(event) {
        const { notification } = event.detail;
        this.state.notifications.unshift(notification);
        this.updateNotificationUI();
        this.showDesktopNotification(notification);
    },
    
    updateNotificationUI() {
        const badge = document.querySelector('.notification-badge');
        const unreadCount = this.state.notifications.filter(n => !n.is_read).length;
        
        if (badge) {
            badge.textContent = unreadCount;
            badge.style.display = unreadCount > 0 ? 'inline' : 'none';
        }
        
        this.updateNotificationPanel();
    },
    
    updateNotificationPanel() {
        const panel = document.querySelector('.notifications-list');
        if (!panel) return;
        
        const unreadNotifications = this.state.notifications.filter(n => !n.is_read).slice(0, 5);
        
        if (unreadNotifications.length === 0) {
            panel.innerHTML = `
                <div class="no-notifications">
                    <i class="fas fa-bell-slash"></i>
                    <p>Yeni bildiriş yoxdur</p>
                </div>
            `;
            return;
        }
        
        panel.innerHTML = unreadNotifications.map(notification => `
            <div class="notification-item ${notification.is_read ? 'read' : 'unread'}" 
                 onclick="ParfumApp.markNotificationRead(${notification.id})">
                <div class="notification-icon">
                    <i class="fas ${this.getNotificationIcon(notification.type)}"></i>
                </div>
                <div class="notification-content">
                    <h5>${this.escapeHtml(notification.title)}</h5>
                    <p>${this.escapeHtml(notification.message)}</p>
                    <span class="notification-time">${this.timeAgo(notification.created_at)}</span>
                </div>
            </div>
        `).join('');
    },
    
    getNotificationIcon(type) {
        const icons = {
            'new_sale': 'fa-shopping-cart',
            'low_stock': 'fa-exclamation-triangle',
            'new_message': 'fa-comment',
            'incoming_call': 'fa-phone',
            'salary_request': 'fa-money-bill',
            'system': 'fa-cog'
        };
        return icons[type] || 'fa-info-circle';
    },
    
    showDesktopNotification(notification) {
        if ('Notification' in window && Notification.permission === 'granted') {
            const desktopNotification = new Notification(notification.title, {
                body: notification.message,
                icon: '/assets/icons/icon-192x192.png',
                badge: '/assets/icons/badge-72x72.png',
                tag: `notification-${notification.id}`,
                requireInteraction: false
            });
            
            desktopNotification.onclick = () => {
                window.focus();
                this.markNotificationRead(notification.id);
                desktopNotification.close();
            };
            
            setTimeout(() => desktopNotification.close(), 5000);
        }
    },
    
    async markNotificationRead(id) {
        try {
            const response = await this.api(`/api/notifications/${id}/read`, { method: 'POST' });
            if (response.success) {
                const notification = this.state.notifications.find(n => n.id === id);
                if (notification) {
                    notification.is_read = true;
                    this.updateNotificationUI();
                }
            }
        } catch (error) {
            console.error('Failed to mark notification as read:', error);
        }
    },
    
    async markAllNotificationsRead() {
        try {
            const response = await this.api('/api/notifications/mark-all-read', { method: 'POST' });
            if (response.success) {
                this.state.notifications.forEach(n => n.is_read = true);
                this.updateNotificationUI();
                this.showToast('Bütün bildirişlər oxunmuş kimi qeyd edildi', 'success');
            }
        } catch (error) {
            console.error('Failed to mark all notifications as read:', error);
        }
    },
    
    // Toast System
    initToasts() {
        this.toastContainer = document.getElementById('toastContainer');
        if (!this.toastContainer) {
            this.toastContainer = document.createElement('div');
            this.toastContainer.id = 'toastContainer';
            this.toastContainer.className = 'toast-container';
            document.body.appendChild(this.toastContainer);
        }
    },
    
    showToast(message, type = 'info', duration = 5000, actions = []) {
        const toastId = 'toast-' + Date.now();
        const toast = document.createElement('div');
        toast.id = toastId;
        toast.className = `toast toast-${type}`;
        
        const icon = this.getToastIcon(type);
        
        toast.innerHTML = `
            <i class="fas ${icon}"></i>
            <span>${this.escapeHtml(message)}</span>
            ${actions.map((action, index) => 
                `<button class="btn btn-sm btn-ghost" onclick="ParfumApp.handleToastAction('${toastId}', ${index})">${action.text}</button>`
            ).join('')}
            <button class="toast-close" onclick="ParfumApp.closeToast('${toastId}')">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        // Store actions for later use
        toast._actions = actions;
        
        this.toastContainer.appendChild(toast);
        
        // Auto remove after duration
        if (duration > 0) {
            setTimeout(() => this.closeToast(toastId), duration);
        }
        
        return toastId;
    },
    
    getToastIcon(type) {
        const icons = {
            'success': 'fa-check-circle',
            'error': 'fa-exclamation-circle',
            'warning': 'fa-exclamation-triangle',
            'info': 'fa-info-circle'
        };
        return icons[type] || 'fa-info-circle';
    },
    
    handleToast(event) {
        const { message, type, duration, actions } = event.detail;
        this.showToast(message, type, duration, actions);
    },
    
    handleToastAction(toastId, actionIndex) {
        const toast = document.getElementById(toastId);
        if (toast && toast._actions && toast._actions[actionIndex]) {
            const action = toast._actions[actionIndex];
            if (action.action) {
                action.action();
            }
            this.closeToast(toastId);
        }
    },
    
    closeToast(toastId) {
        const toast = document.getElementById(toastId);
        if (toast) {
            toast.style.animation = 'toastSlideOut 0.3s ease';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }
    },
    
    // API Helper
    async api(url, options = {}) {
        const defaultOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': this.config.csrfToken,
                'X-Requested-With': 'XMLHttpRequest'
            }
        };
        
        const finalOptions = { ...defaultOptions, ...options };
        
        if (finalOptions.body && typeof finalOptions.body === 'object') {
            finalOptions.body = JSON.stringify(finalOptions.body);
        }
        
        try {
            const response = await fetch(this.config.baseUrl + url.replace(/^\//, ''), finalOptions);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            return data;
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    },
    
    // Utility Functions
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },
    
    timeAgo(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;
        
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);
        
        if (minutes < 1) return 'indi';
        if (minutes < 60) return `${minutes} dəqiqə əvvəl`;
        if (hours < 24) return `${hours} saat əvvəl`;
        if (days < 30) return `${days} gün əvvəl`;
        
        return date.toLocaleDateString('az-AZ');
    },
    
    formatMoney(amount, currency = 'AZN') {
        return new Intl.NumberFormat('az-AZ', {
            style: 'currency',
            currency: currency,
            minimumFractionDigits: 2
        }).format(amount || 0);
    },
    
    formatDate(date, options = {}) {
        const defaultOptions = {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        };
        
        return new Intl.DateTimeFormat('az-AZ', { ...defaultOptions, ...options })
            .format(new Date(date));
    },
    
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },
    
    throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },
    
    // Event System
    dispatchEvent(eventName, detail = {}) {
        const event = new CustomEvent(eventName, { detail });
        document.dispatchEvent(event);
    },
    
    // Activity Tracking
    startActivityTracking() {
        const updateActivity = this.throttle(() => {
            this.state.lastActivity = Date.now();
            this.sendActivityUpdate();
        }, 30000); // 30 seconds
        
        ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'].forEach(event => {
            document.addEventListener(event, updateActivity, true);
        });
    },
    
    async sendActivityUpdate() {
        if (!this.state.isOnline) return;
        
        try {
            await this.api('/api/users/activity', {
                method: 'POST',
                body: { timestamp: this.state.lastActivity }
            });
        } catch (error) {
            console.error('Failed to update activity:', error);
        }
    },
    
    // Connection Status
    checkConnection() {
        setInterval(() => {
            this.updateConnectionStatus(navigator.onLine);
        }, 5000);
    },
    
    updateConnectionStatus(isOnline) {
        const status = document.getElementById('connectionStatus');
        if (status) {
            status.className = `connection-status ${isOnline ? 'connected' : 'disconnected'}`;
            status.innerHTML = `
                <i class="fas ${isOnline ? 'fa-wifi' : 'fa-wifi-slash'}"></i>
                <span>${isOnline ? 'Bağlandı' : 'Bağlantı yoxdur'}</span>
            `;
        }
        this.state.isOnline = isOnline;
    },
    
    // Modal Management
    closeModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
        
        document.querySelectorAll('.dropdown.show').forEach(dropdown => {
            dropdown.classList.remove('show');
        });
    },
    
    // Search
    focusGlobalSearch() {
        const searchInput = document.getElementById('globalSearch');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    },
    
    clearSearch() {
        const searchInput = document.getElementById('globalSearch');
        if (searchInput) {
            searchInput.value = '';
            searchInput.blur();
        }
    },
    
    // User State
    saveUserState() {
        const state = {
            sidebarCollapsed: this.state.sidebarCollapsed,
            theme: this.config.theme,
            lastActivity: this.state.lastActivity
        };
        
        localStorage.setItem('user_state', JSON.stringify(state));
    },
    
    loadUserState() {
        const state = localStorage.getItem('user_state');
        if (state) {
            try {
                const parsed = JSON.parse(state);
                Object.assign(this.state, parsed);
            } catch (error) {
                console.error('Failed to load user state:', error);
            }
        }
    },
    
    hasUnsavedChanges() {
        // Check if any forms have unsaved changes
        const forms = document.querySelectorAll('form[data-unsaved="true"]');
        return forms.length > 0;
    },
    
    // Offline Data Sync
    async syncOfflineData() {
        const offlineData = localStorage.getItem('offline_data');
        if (!offlineData) return;
        
        try {
            const data = JSON.parse(offlineData);
            for (const item of data) {
                await this.api(item.url, item.options);
            }
            localStorage.removeItem('offline_data');
            this.showToast('Offline məlumatlar sinxronlaşdırıldı', 'success');
        } catch (error) {
            console.error('Failed to sync offline data:', error);
        }
    },
    
    // Module Registration
    registerModule(name, module) {
        this.modules[name] = module;
        if (module.init) {
            module.init(this);
        }
    }
};

// Global Functions (backwards compatibility)
function initializeApp() {
    ParfumApp.init();
}

function toggleSidebar() {
    ParfumApp.toggleSidebar();
}

function toggleTheme() {
    ParfumApp.toggleTheme();
}

function toggleNotifications() {
    const panel = document.getElementById('notificationsPanel');
    if (panel) {
        panel.classList.toggle('show');
    }
}

function toggleUserMenu() {
    const menu = document.getElementById('userMenu');
    if (menu) {
        menu.classList.toggle('show');
    }
}

function markAllNotificationsRead() {
    ParfumApp.markAllNotificationsRead();
}

function markNotificationRead(id) {
    ParfumApp.markNotificationRead(id);
}

function logout() {
    if (confirm('Çıxış etmək istədiyinizə əminsiniz?')) {
        window.location.href = ParfumApp.config.baseUrl + 'logout';
    }
}

function showToast(message, type = 'info', duration = 5000) {
    return ParfumApp.showToast(message, type, duration);
}

function toggleSubmenu(element) {
    const parent = element.closest('.has-submenu');
    if (parent) {
        parent.classList.toggle('open');
    }
}

function toggleFullscreen() {
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => {
            console.error('Fullscreen error:', err);
        });
    } else {
        document.exitFullscreen();
    }
}

// Quick Actions
function openNewSaleModal() {
    const modal = document.getElementById('newSaleModal');
    if (modal) {
        modal.style.display = 'block';
        loadQuickSaleForm();
    }
}

function closeNewSaleModal() {
    const modal = document.getElementById('newSaleModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function openQuickChatModal() {
    const modal = document.getElementById('quickChatModal');
    if (modal) {
        modal.style.display = 'block';
        loadChatUsers();
    }
}

function closeQuickChatModal() {
    const modal = document.getElementById('quickChatModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

async function loadQuickSaleForm() {
    // Implementation for quick sale form
    const productSearch = document.getElementById('productSearch');
    if (productSearch) {
        productSearch.addEventListener('input', debounce(searchProducts, 300));
    }
}

async function loadChatUsers() {
    try {
        const response = await ParfumApp.api('/api/users/online');
        if (response.success) {
            const select = document.getElementById('quickChatUser');
            if (select) {
                select.innerHTML = '<option value="">İstifadəçi seçin...</option>' +
                    response.users.map(user => 
                        `<option value="${user.id}">${user.full_name}</option>`
                    ).join('');
            }
        }
    } catch (error) {
        console.error('Failed to load users:', error);
    }
}

function debounce(func, wait) {
    return ParfumApp.debounce(func, wait);
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

// Error handling for unhandled promise rejections
window.addEventListener('unhandledrejection', event => {
    console.error('Unhandled promise rejection:', event.reason);
    ParfumApp.showToast('Sistem xətası baş verdi', 'error');
    event.preventDefault();
});

// Export for modules
window.App = ParfumApp;