/**
 * Sound Assets - Base64 Encoded Sounds
 * Kodaz-az - 2025-07-21 14:50:56 (UTC)
 * Login: Kodaz-az
 */

class SoundAssets {
    constructor() {
        this.sounds = {
            notification: this.generateNotificationSound(),
            success: this.generateSuccessSound(),
            error: this.generateErrorSound(),
            bell: this.generateBellSound(),
            click: this.generateClickSound()
        };
    }
    
    generateNotificationSound() {
        // Create a pleasant notification beep
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const buffer = audioContext.createBuffer(1, audioContext.sampleRate * 0.3, audioContext.sampleRate);
        const data = buffer.getChannelData(0);
        
        for (let i = 0; i < data.length; i++) {
            const t = i / audioContext.sampleRate;
            data[i] = 0.3 * Math.sin(2 * Math.PI * 800 * t) * Math.exp(-t * 5);
        }
        
        return this.bufferToBase64(buffer);
    }
    
    generateSuccessSound() {
        // Create a success sound (ascending notes)
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const buffer = audioContext.createBuffer(1, audioContext.sampleRate * 0.6, audioContext.sampleRate);
        const data = buffer.getChannelData(0);
        
        const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
        
        for (let i = 0; i < data.length; i++) {
            const t = i / audioContext.sampleRate;
            let sample = 0;
            
            notes.forEach((freq, index) => {
                const noteStart = index * 0.2;
                const noteEnd = noteStart + 0.3;
                
                if (t >= noteStart && t <= noteEnd) {
                    const noteT = t - noteStart;
                    sample += 0.2 * Math.sin(2 * Math.PI * freq * noteT) * Math.exp(-noteT * 3);
                }
            });
            
            data[i] = sample;
        }
        
        return this.bufferToBase64(buffer);
    }
    
    generateErrorSound() {
        // Create an error sound (descending note)
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const buffer = audioContext.createBuffer(1, audioContext.sampleRate * 0.5, audioContext.sampleRate);
        const data = buffer.getChannelData(0);
        
        for (let i = 0; i < data.length; i++) {
            const t = i / audioContext.sampleRate;
            const freq = 400 - (t * 200); // Descending from 400Hz to 200Hz
            data[i] = 0.3 * Math.sin(2 * Math.PI * freq * t) * Math.exp(-t * 2);
        }
        
        return this.bufferToBase64(buffer);
    }
    
    generateBellSound() {
        // Create a bell-like sound
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const buffer = audioContext.createBuffer(1, audioContext.sampleRate * 1, audioContext.sampleRate);
        const data = buffer.getChannelData(0);
        
        for (let i = 0; i < data.length; i++) {
            const t = i / audioContext.sampleRate;
            // Bell harmonics
            let sample = 0;
            sample += 0.3 * Math.sin(2 * Math.PI * 1000 * t) * Math.exp(-t * 2);
            sample += 0.2 * Math.sin(2 * Math.PI * 2000 * t) * Math.exp(-t * 3);
            sample += 0.1 * Math.sin(2 * Math.PI * 3000 * t) * Math.exp(-t * 4);
            
            data[i] = sample;
        }
        
        return this.bufferToBase64(buffer);
    }
    
    generateClickSound() {
        // Create a click sound
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const buffer = audioContext.createBuffer(1, audioContext.sampleRate * 0.1, audioContext.sampleRate);
        const data = buffer.getChannelData(0);
        
        for (let i = 0; i < data.length; i++) {
            const t = i / audioContext.sampleRate;
            data[i] = 0.5 * Math.random() * Math.exp(-t * 30);
        }
        
        return this.bufferToBase64(buffer);
    }
    
    bufferToBase64(buffer) {
        // Convert AudioBuffer to base64 (simplified)
        const data = buffer.getChannelData(0);
        const samples = new Int16Array(data.length);
        
        for (let i = 0; i < data.length; i++) {
            samples[i] = Math.max(-32768, Math.min(32767, data[i] * 32767));
        }
        
        return 'data:audio/wav;base64,' + btoa(String.fromCharCode.apply(null, new Uint8Array(samples.buffer)));
    }
    
    play(soundName, volume = 0.5) {
        if (!this.sounds[soundName]) {
            console.warn(`Sound '${soundName}' not found`);
            return;
        }
        
        try {
            const audio = new Audio(this.sounds[soundName]);
            audio.volume = Math.max(0, Math.min(1, volume));
            audio.play().catch(e => {
                console.log('Sound play failed:', e.message);
            });
        } catch (error) {
            console.log('Sound creation failed:', error.message);
        }
    }
}

// Global sound manager
window.SoundAssets = new SoundAssets();

// Convenience functions
window.playNotificationSound = (volume = 0.5) => window.SoundAssets.play('notification', volume);
window.playSuccessSound = (volume = 0.7) => window.SoundAssets.play('success', volume);
window.playErrorSound = (volume = 0.3) => window.SoundAssets.play('error', volume);
window.playBellSound = (volume = 0.6) => window.SoundAssets.play('bell', volume);
window.playClickSound = (volume = 0.2) => window.SoundAssets.play('click', volume);

console.log('Sound Assets initialized');