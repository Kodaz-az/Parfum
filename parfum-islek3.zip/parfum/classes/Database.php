<?php
/**
 * Parfüm POS Sistemi - Database Sinfi
 * Yaradıldığı tarix: 2025-07-21
 */

class Database {
    private static $instance = null;
    private $connection;
    private $host;
    private $dbname;
    private $username;
    private $password;
    private $charset;
    
    private function __construct() {
        $config = Config::database();
        $this->host = $config['host'];
        $this->dbname = $config['dbname'];
        $this->username = $config['username'];
        $this->password = $config['password'];
        $this->charset = $config['charset'];
        
        $this->connect();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function connect() {
        try {
            $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset={$this->charset}";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ];
            
            $this->connection = new PDO($dsn, $this->username, $this->password, $options);
        } catch (PDOException $e) {
            throw new Exception("Database connection failed: " . $e->getMessage());
        }
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    public function query($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            throw new Exception("Query failed: " . $e->getMessage());
        }
    }
    
    public function select($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    public function selectOne($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }
    
    public function insert($table, $data) {
        $fields = array_keys($data);
        $values = array_values($data);
        $placeholders = ':' . implode(', :', $fields);
        
        $sql = "INSERT INTO {$table} (" . implode(', ', $fields) . ") VALUES ({$placeholders})";
        
        $params = array_combine(
            array_map(function($field) { return ':' . $field; }, $fields),
            $values
        );
        
        $this->query($sql, $params);
        return $this->connection->lastInsertId();
    }
    
    public function update($table, $data, $where, $whereParams = []) {
        $setParts = [];
        foreach (array_keys($data) as $field) {
            $setParts[] = "{$field} = :{$field}";
        }
        
        $sql = "UPDATE {$table} SET " . implode(', ', $setParts) . " WHERE {$where}";
        
        $params = array_combine(
            array_map(function($field) { return ':' . $field; }, array_keys($data)),
            array_values($data)
        );
        
        $params = array_merge($params, $whereParams);
        
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }
    
    public function delete($table, $where, $whereParams = []) {
        $sql = "DELETE FROM {$table} WHERE {$where}";
        $stmt = $this->query($sql, $whereParams);
        return $stmt->rowCount();
    }
    
    public function exists($table, $where, $whereParams = []) {
        $sql = "SELECT 1 FROM {$table} WHERE {$where} LIMIT 1";
        $result = $this->selectOne($sql, $whereParams);
        return !empty($result);
    }
    
    public function count($table, $where = '1=1', $whereParams = []) {
        $sql = "SELECT COUNT(*) as count FROM {$table} WHERE {$where}";
        $result = $this->selectOne($sql, $whereParams);
        return $result['count'];
    }
    
    public function beginTransaction() {
        return $this->connection->beginTransaction();
    }
    
    public function commit() {
        return $this->connection->commit();
    }
    
    public function rollback() {
        return $this->connection->rollback();
    }
    
    public function lastInsertId() {
        return $this->connection->lastInsertId();
    }
    
    // Pagination helper
    public function paginate($sql, $params = [], $page = 1, $perPage = 10) {
        // Ümumi sayı hesabla
        $countSql = "SELECT COUNT(*) as total FROM ({$sql}) as count_table";
        $totalResult = $this->selectOne($countSql, $params);
        $total = $totalResult['total'];
        
        // Pagination hesablamaları
        $totalPages = ceil($total / $perPage);
        $offset = ($page - 1) * $perPage;
        
        // Məlumatları əldə et
        $dataSql = $sql . " LIMIT {$offset}, {$perPage}";
        $data = $this->select($dataSql, $params);
        
        return [
            'data' => $data,
            'pagination' => [
                'current_page' => $page,
                'per_page' => $perPage,
                'total' => $total,
                'total_pages' => $totalPages,
                'has_next' => $page < $totalPages,
                'has_prev' => $page > 1
            ]
        ];
    }
    
    // Search helper
    public function search($table, $fields, $term, $conditions = '1=1', $params = []) {
        $searchConditions = [];
        $searchParams = [];
        
        foreach ($fields as $field) {
            $searchConditions[] = "{$field} LIKE :search_{$field}";
            $searchParams[":search_{$field}"] = "%{$term}%";
        }
        
        $searchWhere = '(' . implode(' OR ', $searchConditions) . ')';
        $fullWhere = "({$conditions}) AND ({$searchWhere})";
        
        $sql = "SELECT * FROM {$table} WHERE {$fullWhere}";
        $allParams = array_merge($params, $searchParams);
        
        return $this->select($sql, $allParams);
    }
    
    // Cache methods
    private $cache = [];
    
    public function cacheQuery($key, $sql, $params = [], $ttl = 3600) {
        if (isset($this->cache[$key]) && 
            $this->cache[$key]['expires'] > time()) {
            return $this->cache[$key]['data'];
        }
        
        $data = $this->select($sql, $params);
        $this->cache[$key] = [
            'data' => $data,
            'expires' => time() + $ttl
        ];
        
        return $data;
    }
    
    public function clearCache($key = null) {
        if ($key) {
            unset($this->cache[$key]);
        } else {
            $this->cache = [];
        }
    }
    
    // Bulk operations
    public function bulkInsert($table, $data) {
        if (empty($data)) return 0;
        
        $fields = array_keys($data[0]);
        $placeholders = '(' . implode(',', array_fill(0, count($fields), '?')) . ')';
        $allPlaceholders = implode(',', array_fill(0, count($data), $placeholders));
        
        $sql = "INSERT INTO {$table} (" . implode(',', $fields) . ") VALUES {$allPlaceholders}";
        
        $params = [];
        foreach ($data as $row) {
            foreach ($fields as $field) {
                $params[] = $row[$field];
            }
        }
        
        $stmt = $this->query($sql, $params);
        return $stmt->rowCount();
    }
    
    // Database backup
    public function backup($file = null) {
        if (!$file) {
            $file = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
        }
        
        $backupPath = __DIR__ . '/../backups/' . $file;
        
        if (!is_dir(dirname($backupPath))) {
            mkdir(dirname($backupPath), 0755, true);
        }
        
        $command = sprintf(
            'mysqldump --host=%s --user=%s --password=%s %s > %s',
            escapeshellarg($this->host),
            escapeshellarg($this->username),
            escapeshellarg($this->password),
            escapeshellarg($this->dbname),
            escapeshellarg($backupPath)
        );
        
        exec($command, $output, $return);
        
        if ($return === 0) {
            return $backupPath;
        } else {
            throw new Exception('Backup failed');
        }
    }
    
    // Connection test
    public function testConnection() {
        try {
            $this->connection->query('SELECT 1');
            return true;
        } catch (Exception $e) {
            return false;
        }
    }
    
    public function __destruct() {
        $this->connection = null;
    }
    
    /**
 * Begin a database transaction
 * 
 * @return bool
 */
 public function beginTransaction() {
    return $this->pdo->beginTransaction();
}

/**
 * Commit a database transaction
 * 
 * @return bool
 */
public function commit() {
    return $this->pdo->commit();
}

/**
 * Roll back a database transaction
 * 
 * @return bool
 */
public function rollBack() {
    return $this->pdo->rollBack();
  }
}





?>