<?php
/**
 * Parfüm POS Sistemi - Call Class
 * Yaradıldığı tarix: 2025-07-21 10:52:27
 * Müəllif: Kodaz-az
 */

class Call {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Zəng başlatmaq
     */
    public function initiateCall($callData) {
        try {
            $sql = "INSERT INTO calls (caller_id, recipient_id, call_type, status, started_at) 
                    VALUES (?, ?, ?, 'calling', NOW())";
            
            $params = [
                $callData['caller_id'],
                $callData['recipient_id'],
                $callData['call_type']
            ];
            
            return $this->db->insert($sql, $params);
            
        } catch (Exception $e) {
            error_log("Call initiate error: " . $e->getMessage());
            throw new Exception("Zəng başladıla bilmədi");
        }
    }
    
    /**
     * Zəngə cavab vermək
     */
    public function answerCall($callId) {
        try {
            $sql = "UPDATE calls SET status = 'active', answered_at = NOW() WHERE id = ? AND status = 'calling'";
            
            $result = $this->db->update($sql, [$callId]);
            
            if ($result) {
                // Call participant əlavə etmək
                $this->addCallParticipant($callId);
                return true;
            }
            
            return false;
            
        } catch (Exception $e) {
            error_log("Call answer error: " . $e->getMessage());
            throw new Exception("Zəng qəbul edilmədi");
        }
    }
    
    /**
     * Zəngi rədd etmək
     */
    public function rejectCall($callId, $reason = '') {
        try {
            $sql = "UPDATE calls SET status = 'rejected', ended_at = NOW(), end_reason = ? 
                    WHERE id = ? AND status = 'calling'";
            
            return $this->db->update($sql, [$reason, $callId]);
            
        } catch (Exception $e) {
            error_log("Call reject error: " . $e->getMessage());
            throw new Exception("Zəng rədd edilmədi");
        }
    }
    
    /**
     * Zəngi bitirmək
     */
    public function endCall($callId) {
        try {
            // Zəng müddətini hesablamaq
            $call = $this->getCallById($callId);
            if (!$call) {
                throw new Exception("Zəng tapılmadı");
            }
            
            $duration = 0;
            if ($call['answered_at']) {
                $start = new DateTime($call['answered_at']);
                $end = new DateTime();
                $duration = $end->getTimestamp() - $start->getTimestamp();
            }
            
            $sql = "UPDATE calls SET status = 'completed', ended_at = NOW(), duration = ? 
                    WHERE id = ? AND status IN ('calling', 'active')";
            
            return $this->db->update($sql, [$duration, $callId]);
            
        } catch (Exception $e) {
            error_log("Call end error: " . $e->getMessage());
            throw new Exception("Zəng bitirilmədi");
        }
    }
    
    /**
     * Zəng məlumatlarını əldə etmək
     */
    public function getCallById($callId) {
        try {
            $sql = "SELECT c.*, 
                           u1.full_name as caller_name, u1.avatar as caller_avatar,
                           u2.full_name as recipient_name, u2.avatar as recipient_avatar
                    FROM calls c
                    LEFT JOIN users u1 ON c.caller_id = u1.id
                    LEFT JOIN users u2 ON c.recipient_id = u2.id
                    WHERE c.id = ?";
            
            $call = $this->db->selectOne($sql, [$callId]);
            
            if ($call) {
                // Participant məlumatlarını əlavə etmək
                $call['participants'] = $this->getCallParticipants($callId);
            }
            
            return $call;
            
        } catch (Exception $e) {
            error_log("Get call error: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * İstifadəçinin zəng tarixini əldə etmək
     */
    public function getCallHistory($userId, $limit = 20) {
        try {
            $sql = "SELECT c.*, 
                           u1.full_name as caller_name, u1.avatar as caller_avatar,
                           u2.full_name as recipient_name, u2.avatar as recipient_avatar
                    FROM calls c
                    LEFT JOIN users u1 ON c.caller_id = u1.id
                    LEFT JOIN users u2 ON c.recipient_id = u2.id
                    WHERE c.caller_id = ? OR c.recipient_id = ?
                    ORDER BY c.started_at DESC
                    LIMIT ?";
            
            return $this->db->selectAll($sql, [$userId, $userId, $limit]);
            
        } catch (Exception $e) {
            error_log("Get call history error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Buraxılan zəngləri əldə etmək
     */
    public function getMissedCalls($userId) {
        try {
            $sql = "SELECT c.*, 
                           u1.full_name as caller_name, u1.avatar as caller_avatar
                    FROM calls c
                    LEFT JOIN users u1 ON c.caller_id = u1.id
                    WHERE c.recipient_id = ? AND c.status = 'rejected'
                    ORDER BY c.started_at DESC
                    LIMIT 10";
            
            return $this->db->selectAll($sql, [$userId]);
            
        } catch (Exception $e) {
            error_log("Get missed calls error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Zəng statistikalarını əldə etmək
     */
    public function getCallStatistics($userId) {
        try {
            $stats = [];
            
            // Ümumi zənglər
            $sql = "SELECT COUNT(*) as total_calls FROM calls 
                    WHERE caller_id = ? OR recipient_id = ?";
            $result = $this->db->selectOne($sql, [$userId, $userId]);
            $stats['total_calls'] = $result['total_calls'] ?? 0;
            
            // Uğurlu zənglər
            $sql = "SELECT COUNT(*) as successful_calls FROM calls 
                    WHERE (caller_id = ? OR recipient_id = ?) AND status = 'completed'";
            $result = $this->db->selectOne($sql, [$userId, $userId]);
            $stats['successful_calls'] = $result['successful_calls'] ?? 0;
            
            // Buraxılan zənglər
            $sql = "SELECT COUNT(*) as missed_calls FROM calls 
                    WHERE recipient_id = ? AND status = 'rejected'";
            $result = $this->db->selectOne($sql, [$userId]);
            $stats['missed_calls'] = $result['missed_calls'] ?? 0;
            
            // Ortalama müddət
            $sql = "SELECT AVG(duration) as avg_duration FROM calls 
                    WHERE (caller_id = ? OR recipient_id = ?) AND status = 'completed' AND duration > 0";
            $result = $this->db->selectOne($sql, [$userId, $userId]);
            $stats['avg_duration'] = round($result['avg_duration'] ?? 0);
            
            return $stats;
            
        } catch (Exception $e) {
            error_log("Get call statistics error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Aktiv zəng olub-olmadığını yoxlamaq
     */
    public function hasActiveCall($userId1, $userId2) {
        try {
            $sql = "SELECT COUNT(*) as count FROM calls 
                    WHERE ((caller_id = ? AND recipient_id = ?) OR (caller_id = ? AND recipient_id = ?))
                    AND status IN ('calling', 'active')";
            
            $result = $this->db->selectOne($sql, [$userId1, $userId2, $userId2, $userId1]);
            return ($result['count'] ?? 0) > 0;
            
        } catch (Exception $e) {
            error_log("Check active call error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * WebRTC signaling məlumatlarını saxlamaq
     */
    public function storeSignalingData($signalingData) {
        try {
            $sql = "INSERT INTO call_signaling (call_id, sender_id, type, data, created_at) 
                    VALUES (?, ?, ?, ?, NOW())";
            
            $params = [
                $signalingData['call_id'],
                $signalingData['sender_id'],
                $signalingData['type'],
                json_encode($signalingData['data'])
            ];
            
            return $this->db->insert($sql, $params);
            
        } catch (Exception $e) {
            error_log("Store signaling data error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Zəng iştirakçılarını əldə etmək
     */
    private function getCallParticipants($callId) {
        try {
            $sql = "SELECT cp.*, u.full_name, u.avatar 
                    FROM call_participants cp
                    LEFT JOIN users u ON cp.user_id = u.id
                    WHERE cp.call_id = ?";
            
            return $this->db->selectAll($sql, [$callId]);
            
        } catch (Exception $e) {
            error_log("Get call participants error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Zəng iştirakçısı əlavə etmək
     */
    private function addCallParticipant($callId) {
        try {
            // Zəng məlumatlarını əldə etmək
            $call = $this->getCallById($callId);
            if (!$call) {
                return false;
            }
            
            // Hər iki iştirakçını əlavə etmək
            $sql = "INSERT INTO call_participants (call_id, user_id, joined_at) VALUES (?, ?, NOW())";
            
            $this->db->insert($sql, [$callId, $call['caller_id']]);
            $this->db->insert($sql, [$callId, $call['recipient_id']]);
            
            return true;
            
        } catch (Exception $e) {
            error_log("Add call participant error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Bütün zəngləri əldə etmək (admin üçün)
     */
    public function getCalls($filters = []) {
        try {
            $conditions = [];
            $params = [];
            
            if (!empty($filters['user_id'])) {
                $conditions[] = "(c.caller_id = ? OR c.recipient_id = ?)";
                $params[] = $filters['user_id'];
                $params[] = $filters['user_id'];
            }
            
            if (!empty($filters['status'])) {
                $conditions[] = "c.status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['call_type'])) {
                $conditions[] = "c.call_type = ?";
                $params[] = $filters['call_type'];
            }
            
            if (!empty($filters['date_from'])) {
                $conditions[] = "DATE(c.started_at) >= ?";
                $params[] = $filters['date_from'];
            }
            
            if (!empty($filters['date_to'])) {
                $conditions[] = "DATE(c.started_at) <= ?";
                $params[] = $filters['date_to'];
            }
            
            $whereClause = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";
            
            $sql = "SELECT c.*, 
                           u1.full_name as caller_name, u1.avatar as caller_avatar,
                           u2.full_name as recipient_name, u2.avatar as recipient_avatar
                    FROM calls c
                    LEFT JOIN users u1 ON c.caller_id = u1.id
                    LEFT JOIN users u2 ON c.recipient_id = u2.id
                    {$whereClause}
                    ORDER BY c.started_at DESC";
            
            if (isset($filters['limit'])) {
                $sql .= " LIMIT " . intval($filters['limit']);
            }
            
            if (isset($filters['offset'])) {
                $sql .= " OFFSET " . intval($filters['offset']);
            }
            
            return $this->db->selectAll($sql, $params);
            
        } catch (Exception $e) {
            error_log("Get calls error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Zəng sayını əldə etmək
     */
    public function getCallsCount($filters = []) {
        try {
            $conditions = [];
            $params = [];
            
            if (!empty($filters['user_id'])) {
                $conditions[] = "(caller_id = ? OR recipient_id = ?)";
                $params[] = $filters['user_id'];
                $params[] = $filters['user_id'];
            }
            
            if (!empty($filters['status'])) {
                $conditions[] = "status = ?";
                $params[] = $filters['status'];
            }
            
            if (!empty($filters['call_type'])) {
                $conditions[] = "call_type = ?";
                $params[] = $filters['call_type'];
            }
            
            if (!empty($filters['date_from'])) {
                $conditions[] = "DATE(started_at) >= ?";
                $params[] = $filters['date_from'];
            }
            
            if (!empty($filters['date_to'])) {
                $conditions[] = "DATE(started_at) <= ?";
                $params[] = $filters['date_to'];
            }
            
            $whereClause = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";
            
            $sql = "SELECT COUNT(*) as count FROM calls {$whereClause}";
            
            $result = $this->db->selectOne($sql, $params);
            return $result['count'] ?? 0;
            
        } catch (Exception $e) {
            error_log("Get calls count error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Zəngi yeniləmək (reytinq və rəy əlavə etmək)
     */
    public function updateCall($callId, $updateData) {
        try {
            $allowedFields = ['quality_rating', 'feedback'];
            $setClause = [];
            $params = [];
            
            foreach ($allowedFields as $field) {
                if (isset($updateData[$field])) {
                    $setClause[] = "{$field} = ?";
                    $params[] = $updateData[$field];
                }
            }
            
            if (empty($setClause)) {
                return false;
            }
            
            $params[] = $callId;
            $sql = "UPDATE calls SET " . implode(", ", $setClause) . " WHERE id = ?";
            
            return $this->db->update($sql, $params);
            
        } catch (Exception $e) {
            error_log("Update call error: " . $e->getMessage());
            return false;
        }
    }
}
?>