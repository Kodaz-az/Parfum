<?php
/**
 * Parfüm POS Sistemi - Sale Sinfi
 * Yaradıldığı tarix: 2025-07-21
 */

class Sale {
    private $db;
    private $user;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->user = new User();
    }
    
    public function getAllSales($filters = []) {
        $currentUser = $this->user->getCurrentUser();
        
        $where = '1=1';
        $params = [];
        
        // Role-based filtering
        if ($currentUser['role'] === 'seller') {
            $where .= ' AND s.user_id = ?';
            $params[] = $currentUser['id'];
        }
        
        if (!empty($filters['user_id'])) {
            $where .= ' AND s.user_id = ?';
            $params[] = $filters['user_id'];
        }
        
        if (!empty($filters['date_from'])) {
            $where .= ' AND DATE(s.created_at) >= ?';
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where .= ' AND DATE(s.created_at) <= ?';
            $params[] = $filters['date_to'];
        }
        
        if (!empty($filters['payment_method'])) {
            $where .= ' AND s.payment_method = ?';
            $params[] = $filters['payment_method'];
        }
        
        if (!empty($filters['payment_status'])) {
            $where .= ' AND s.payment_status = ?';
            $params[] = $filters['payment_status'];
        }
        
        if (!empty($filters['search'])) {
            $where .= ' AND (s.sale_number LIKE ? OR s.customer_name LIKE ? OR s.customer_phone LIKE ?)';
            $search = '%' . $filters['search'] . '%';
            $params = array_merge($params, [$search, $search, $search]);
        }
        
        $orderBy = $filters['order_by'] ?? 's.created_at';
        $orderDir = $filters['order_dir'] ?? 'DESC';
        $limit = $filters['limit'] ?? 50;
        $offset = ($filters['page'] ?? 1 - 1) * $limit;
        
        return $this->db->select(
            "SELECT s.*, u.full_name as seller_name,
                    COUNT(sd.id) as items_count
             FROM sales s
             INNER JOIN users u ON s.user_id = u.id
             LEFT JOIN sale_details sd ON s.id = sd.sale_id
             WHERE {$where}
             GROUP BY s.id
             ORDER BY {$orderBy} {$orderDir}
             LIMIT {$limit} OFFSET {$offset}",
            $params
        );
    }
    
    public function getSaleById($id) {
        $currentUser = $this->user->getCurrentUser();
        
        $where = 's.id = ?';
        $params = [$id];
        
        // Role-based access control
        if ($currentUser['role'] === 'seller') {
            $where .= ' AND s.user_id = ?';
            $params[] = $currentUser['id'];
        }
        
        $sale = $this->db->selectOne(
            "SELECT s.*, u.full_name as seller_name, u.username as seller_username
             FROM sales s
             INNER JOIN users u ON s.user_id = u.id
             WHERE {$where}",
            $params
        );
        
        if ($sale) {
            // Get sale details
            $sale['details'] = $this->db->select(
                'SELECT sd.*, p.name as product_name, p.brand as product_brand
                 FROM sale_details sd
                 INNER JOIN products p ON sd.product_id = p.id
                 WHERE sd.sale_id = ?
                 ORDER BY sd.id',
                [$id]
            );
        }
        
        return $sale;
    }
    
    public function createSale($saleData, $saleDetails) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        // Validate sale data
        $this->validateSaleData($saleData, $saleDetails);
        
        try {
            $this->db->beginTransaction();
            
            // Generate sale number
            $saleNumber = $this->generateSaleNumber();
            
            // Calculate totals
            $totals = $this->calculateTotals($saleDetails, $saleData['discount_amount'] ?? 0);
            
            // Create sale record
            $saleId = $this->db->insert('sales', [
                'sale_number' => $saleNumber,
                'user_id' => $currentUser['id'],
                'customer_name' => sanitize($saleData['customer_name'] ?? ''),
                'customer_phone' => sanitize($saleData['customer_phone'] ?? ''),
                'customer_email' => sanitize($saleData['customer_email'] ?? ''),
                'total_amount' => $totals['total_amount'],
                'discount_amount' => $saleData['discount_amount'] ?? 0,
                'tax_amount' => $totals['tax_amount'],
                'final_amount' => $totals['final_amount'],
                'payment_method' => $saleData['payment_method'],
                'payment_status' => $saleData['payment_status'] ?? 'completed',
                'notes' => sanitize($saleData['notes'] ?? ''),
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            // Create sale details and update stock
            foreach ($saleDetails as $detail) {
                $this->db->insert('sale_details', [
                    'sale_id' => $saleId,
                    'product_id' => $detail['product_id'],
                    'quantity' => $detail['quantity'],
                    'unit_price' => $detail['unit_price'],
                    'total_price' => $detail['quantity'] * $detail['unit_price'],
                    'discount_rate' => $detail['discount_rate'] ?? 0
                ]);
                
                // Update product stock
                $this->updateProductStock($detail['product_id'], $detail['quantity']);
            }
            
            $this->db->commit();
            
            // Send notification
            $this->sendSaleNotification($saleId);
            
            return $saleId;
            
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    public function updateSale($id, $saleData, $saleDetails = null) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('manage_sales')) {
            throw new Exception('Satış yeniləmək icazəniz yoxdur');
        }
        
        $sale = $this->getSaleById($id);
        if (!$sale) {
            throw new Exception('Satış tapılmadı');
        }
        
        // Validate data
        if ($saleDetails) {
            $this->validateSaleData($saleData, $saleDetails);
        }
        
        try {
            $this->db->beginTransaction();
            
            // Update sale record
            $updateData = [
                'customer_name' => sanitize($saleData['customer_name'] ?? ''),
                'customer_phone' => sanitize($saleData['customer_phone'] ?? ''),
                'customer_email' => sanitize($saleData['customer_email'] ?? ''),
                'payment_method' => $saleData['payment_method'],
                'payment_status' => $saleData['payment_status'],
                'notes' => sanitize($saleData['notes'] ?? ''),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            if ($saleDetails) {
                // Recalculate totals
                $totals = $this->calculateTotals($saleDetails, $saleData['discount_amount'] ?? 0);
                $updateData['total_amount'] = $totals['total_amount'];
                $updateData['discount_amount'] = $saleData['discount_amount'] ?? 0;
                $updateData['tax_amount'] = $totals['tax_amount'];
                $updateData['final_amount'] = $totals['final_amount'];
                
                // Restore old stock quantities
                foreach ($sale['details'] as $oldDetail) {
                    $this->updateProductStock($oldDetail['product_id'], -$oldDetail['quantity']);
                }
                
                // Delete old details
                $this->db->delete('sale_details', 'sale_id = ?', [$id]);
                
                // Create new details and update stock
                foreach ($saleDetails as $detail) {
                    $this->db->insert('sale_details', [
                        'sale_id' => $id,
                        'product_id' => $detail['product_id'],
                        'quantity' => $detail['quantity'],
                        'unit_price' => $detail['unit_price'],
                        'total_price' => $detail['quantity'] * $detail['unit_price'],
                        'discount_rate' => $detail['discount_rate'] ?? 0
                    ]);
                    
                    $this->updateProductStock($detail['product_id'], $detail['quantity']);
                }
            }
            
            $this->db->update('sales', $updateData, 'id = ?', [$id]);
            
            $this->db->commit();
            
            return true;
            
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    public function deleteSale($id) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('manage_sales')) {
            throw new Exception('Satış silmək icazəniz yoxdur');
        }
        
        $sale = $this->getSaleById($id);
        if (!$sale) {
            throw new Exception('Satış tapılmadı');
        }
        
        try {
            $this->db->beginTransaction();
            
            // Restore stock quantities
            foreach ($sale['details'] as $detail) {
                $this->updateProductStock($detail['product_id'], -$detail['quantity']);
            }
            
            // Delete sale details
            $this->db->delete('sale_details', 'sale_id = ?', [$id]);
            
            // Delete sale
            $this->db->delete('sales', 'id = ?', [$id]);
            
            $this->db->commit();
            
            return true;
            
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    public function refundSale($id, $refundData) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('manage_sales')) {
            throw new Exception('Satış geri qaytarmaq icazəniz yoxdur');
        }
        
        $sale = $this->getSaleById($id);
        if (!$sale) {
            throw new Exception('Satış tapılmadı');
        }
        
        if ($sale['payment_status'] === 'refunded') {
            throw new Exception('Bu satış artıq geri qaytarılmışdır');
        }
        
        try {
            $this->db->beginTransaction();
            
            // Update sale status
            $this->db->update('sales', [
                'payment_status' => 'refunded',
                'notes' => $sale['notes'] . "\n\nGeri qaytarılma: " . sanitize($refundData['reason'] ?? ''),
                'updated_at' => date('Y-m-d H:i:s')
            ], 'id = ?', [$id]);
            
            // Restore stock quantities if specified
            if ($refundData['restore_stock'] ?? true) {
                foreach ($sale['details'] as $detail) {
                    $this->updateProductStock($detail['product_id'], -$detail['quantity']);
                }
            }
            
            $this->db->commit();
            
            return true;
            
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    public function getSalesStatistics($filters = []) {
        $currentUser = $this->user->getCurrentUser();
        
        $where = '1=1';
        $params = [];
        
        // Role-based filtering
        if ($currentUser['role'] === 'seller') {
            $where .= ' AND user_id = ?';
            $params[] = $currentUser['id'];
        }
        
        if (!empty($filters['user_id'])) {
            $where .= ' AND user_id = ?';
            $params[] = $filters['user_id'];
        }
        
        if (!empty($filters['date_from'])) {
            $where .= ' AND DATE(created_at) >= ?';
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where .= ' AND DATE(created_at) <= ?';
            $params[] = $filters['date_to'];
        }
        
        // Basic statistics
        $basicStats = $this->db->selectOne(
            "SELECT 
                COUNT(*) as total_sales,
                SUM(final_amount) as total_revenue,
                AVG(final_amount) as avg_sale_amount,
                SUM(CASE WHEN payment_status = 'completed' THEN final_amount ELSE 0 END) as completed_revenue,
                SUM(CASE WHEN payment_status = 'refunded' THEN final_amount ELSE 0 END) as refunded_amount
             FROM sales 
             WHERE {$where}",
            $params
        );
        
        // Payment method breakdown
        $paymentMethods = $this->db->select(
            "SELECT 
                payment_method,
                COUNT(*) as count,
                SUM(final_amount) as total_amount
             FROM sales 
             WHERE {$where}
             GROUP BY payment_method
             ORDER BY total_amount DESC",
            $params
        );
        
        // Daily sales (last 30 days)
        $dailySales = $this->db->select(
            "SELECT 
                DATE(created_at) as sale_date,
                COUNT(*) as daily_count,
                SUM(final_amount) as daily_amount
             FROM sales 
             WHERE {$where} AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
             GROUP BY DATE(created_at)
             ORDER BY sale_date DESC",
            $params
        );
        
        // Top selling products
        $topProducts = $this->db->select(
            "SELECT 
                p.name as product_name,
                p.brand as product_brand,
                SUM(sd.quantity) as total_quantity,
                SUM(sd.total_price) as total_revenue
             FROM sale_details sd
             INNER JOIN products p ON sd.product_id = p.id
             INNER JOIN sales s ON sd.sale_id = s.id
             WHERE {$where}
             GROUP BY sd.product_id, p.name, p.brand
             ORDER BY total_quantity DESC
             LIMIT 10",
            $params
        );
        
        return [
            'basic' => $basicStats,
            'payment_methods' => $paymentMethods,
            'daily_sales' => $dailySales,
            'top_products' => $topProducts
        ];
    }
    
    public function getRecentSales($limit = 10) {
        $currentUser = $this->user->getCurrentUser();
        
        $where = '1=1';
        $params = [];
        
        if ($currentUser['role'] === 'seller') {
            $where .= ' AND s.user_id = ?';
            $params[] = $currentUser['id'];
        }
        
        return $this->db->select(
            "SELECT s.*, u.full_name as seller_name
             FROM sales s
             INNER JOIN users u ON s.user_id = u.id
             WHERE {$where}
             ORDER BY s.created_at DESC
             LIMIT ?",
            array_merge($params, [$limit])
        );
    }
    
    public function generateReceipt($saleId) {
        $sale = $this->getSaleById($saleId);
        if (!$sale) {
            throw new Exception('Satış tapılmadı');
        }
        
        // Receipt template would be here
        // For now, return sale data
        return $sale;
    }
    
    public function exportSales($filters = [], $format = 'csv') {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('view_reports')) {
            throw new Exception('Satış ixrac etmək icazəniz yoxdur');
        }
        
        $sales = $this->getAllSales($filters);
        
        if ($format === 'csv') {
            return $this->exportSalesToCSV($sales);
        } else {
            throw new Exception('Dəstəklənməyən format');
        }
    }
    
    private function exportSalesToCSV($sales) {
        $filename = 'sales_' . date('Y-m-d_H-i-s') . '.csv';
        $filepath = UPLOAD_PATH . 'exports/' . $filename;
        
        if (!is_dir(dirname($filepath))) {
            mkdir(dirname($filepath), 0755, true);
        }
        
        $file = fopen($filepath, 'w');
        
        // UTF-8 BOM
        fwrite($file, "\xEF\xBB\xBF");
        
        // Headers
        fputcsv($file, [
            'Satış №', 'Satışçı', 'Müştəri', 'Telefon', 'Toplam məbləğ',
            'Endirim', 'Vergi', 'Yekun məbləğ', 'Ödəniş üsulu', 'Status', 'Tarix'
        ]);
        
        // Data
        foreach ($sales as $sale) {
            fputcsv($file, [
                $sale['sale_number'],
                $sale['seller_name'],
                $sale['customer_name'],
                $sale['customer_phone'],
                $sale['total_amount'],
                $sale['discount_amount'],
                $sale['tax_amount'],
                $sale['final_amount'],
                $sale['payment_method'],
                $sale['payment_status'],
                $sale['created_at']
            ]);
        }
        
        fclose($file);
        
        return $filepath;
    }
    
    private function generateSaleNumber() {
        $prefix = 'POS';
        $date = date('Ymd');
        
        // Get last sale number for today
        $lastSale = $this->db->selectOne(
            'SELECT sale_number FROM sales 
             WHERE sale_number LIKE ? 
             ORDER BY id DESC LIMIT 1',
            [$prefix . $date . '%']
        );
        
        if ($lastSale) {
            $lastNumber = intval(substr($lastSale['sale_number'], -4));
            $newNumber = $lastNumber + 1;
        } else {
            $newNumber = 1;
        }
        
        return $prefix . $date . str_pad($newNumber, 4, '0', STR_PAD_LEFT);
    }
    
    private function calculateTotals($saleDetails, $discountAmount = 0) {
        $totalAmount = 0;
        
        foreach ($saleDetails as $detail) {
            $lineTotal = $detail['quantity'] * $detail['unit_price'];
            $lineDiscount = $lineTotal * ($detail['discount_rate'] ?? 0) / 100;
            $totalAmount += $lineTotal - $lineDiscount;
        }
        
        $totalAmount -= $discountAmount;
        $taxRate = 18; // 18% VAT
        $taxAmount = $totalAmount * $taxRate / 100;
        $finalAmount = $totalAmount + $taxAmount;
        
        return [
            'total_amount' => $totalAmount,
            'tax_amount' => $taxAmount,
            'final_amount' => $finalAmount
        ];
    }
    
    private function updateProductStock($productId, $quantity) {
        $product = new Product();
        $product->updateStock($productId, $quantity, 'subtract');
    }
    
    private function validateSaleData($saleData, $saleDetails) {
        if (empty($saleDetails)) {
            throw new Exception('Satış detalları tələb olunur');
        }
        
        if (empty($saleData['payment_method'])) {
            throw new Exception('Ödəniş üsulu seçin');
        }
        
        $allowedPaymentMethods = ['cash', 'card', 'online', 'mixed'];
        if (!in_array($saleData['payment_method'], $allowedPaymentMethods)) {
            throw new Exception('Düzgün ödəniş üsulu seçin');
        }
        
        // Validate each sale detail
        foreach ($saleDetails as $detail) {
            if (empty($detail['product_id']) || empty($detail['quantity']) || empty($detail['unit_price'])) {
                throw new Exception('Satış detalları tam daxil edilməlidir');
            }
            
            if ($detail['quantity'] <= 0) {
                throw new Exception('Miqdar 0-dan böyük olmalıdır');
            }
            
            if ($detail['unit_price'] <= 0) {
                throw new Exception('Qiymət 0-dan böyük olmalıdır');
            }
            
            // Check product exists and has enough stock
            $product = $this->db->selectOne('SELECT * FROM products WHERE id = ?', [$detail['product_id']]);
            if (!$product) {
                throw new Exception('Məhsul tapılmadı: ' . $detail['product_id']);
            }
            
            if ($product['stock_quantity'] < $detail['quantity']) {
                throw new Exception($product['name'] . ' məhsulunda kifayət qədər stok yoxdur');
            }
        }
    }
    
    private function sendSaleNotification($saleId) {
        // Send notification to managers about new sale
        // Implementation would go here
    }
}

?>