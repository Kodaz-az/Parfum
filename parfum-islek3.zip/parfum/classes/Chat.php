<?php
/**
 * Parfüm POS Sistemi - Chat Sinfi
 * Yaradıldığı tarix: 2025-07-21
 */

class Chat {
    private $db;
    private $user;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->user = new User();
    }
    
    public function createRoom($name, $type = 'private', $participants = []) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        try {
            $this->db->beginTransaction();
            
            // Otaq yarad
            $roomId = $this->db->insert('chat_rooms', [
                'name' => $name,
                'type' => $type,
                'created_by' => $currentUser['id'],
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            // Yaradanı əlavə et
            $this->db->insert('chat_participants', [
                'room_id' => $roomId,
                'user_id' => $currentUser['id'],
                'role' => 'admin',
                'joined_at' => date('Y-m-d H:i:s')
            ]);
            
            // Digər iştirakçıları əlavə et
            foreach ($participants as $participantId) {
                if ($participantId != $currentUser['id']) {
                    $this->db->insert('chat_participants', [
                        'room_id' => $roomId,
                        'user_id' => $participantId,
                        'role' => 'member',
                        'joined_at' => date('Y-m-d H:i:s')
                    ]);
                }
            }
            
            $this->db->commit();
            return $roomId;
            
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    public function getOrCreatePrivateRoom($userId1, $userId2) {
        // Mövcud privat otağı tap
        $room = $this->db->selectOne(
            'SELECT cr.* FROM chat_rooms cr
             INNER JOIN chat_participants cp1 ON cr.id = cp1.room_id AND cp1.user_id = ?
             INNER JOIN chat_participants cp2 ON cr.id = cp2.room_id AND cp2.user_id = ?
             WHERE cr.type = "private"
             GROUP BY cr.id
             HAVING COUNT(cp1.user_id) = 2',
            [$userId1, $userId2]
        );
        
        if ($room) {
            return $room['id'];
        }
        
        // Yeni privat otaq yarad
        $user1 = $this->user->getUserById($userId1);
        $user2 = $this->user->getUserById($userId2);
        
        $roomName = $user1['full_name'] . ' & ' . $user2['full_name'];
        
        return $this->createRoom($roomName, 'private', [$userId1, $userId2]);
    }
    
    public function sendMessage($roomId, $content, $type = 'text', $metadata = []) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        // İstifadəçinin otaqda olub-olmadığını yoxla
        if (!$this->isUserInRoom($roomId, $currentUser['id'])) {
            throw new Exception('Bu otağa mesaj göndərmək icazəniz yoxdur');
        }
        
        $messageData = [
            'room_id' => $roomId,
            'sender_id' => $currentUser['id'],
            'message_type' => $type,
            'content' => $content,
            'metadata' => json_encode($metadata),
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $messageId = $this->db->insert('messages', $messageData);
        
        // Mesajı oxunmuş kimi qeyd et (göndərən üçün)
        $this->markAsRead($messageId, $currentUser['id']);
        
        // Real-time bildiriş göndər
        $this->sendRealTimeNotification($roomId, $messageId);
        
        return $messageId;
    }
    
    public function uploadFile($roomId, $file, $type = 'document') {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        if (!$this->isUserInRoom($roomId, $currentUser['id'])) {
            throw new Exception('Bu otağa fayl göndərmək icazəniz yoxdur');
        }
        
        $allowedTypes = [
            'image' => ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
            'audio' => ['audio/mpeg', 'audio/wav', 'audio/ogg'],
            'video' => ['video/mp4', 'video/webm', 'video/ogg'],
            'document' => ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document']
        ];
        
        if (!isset($allowedTypes[$type]) || !in_array($file['type'], $allowedTypes[$type])) {
            throw new Exception('Bu fayl tipi dəstəklənmir');
        }
        
        if ($file['size'] > MAX_FILE_SIZE) {
            throw new Exception('Fayl ölçüsü çox böyükdür');
        }
        
        $uploadDir = UPLOAD_PATH . 'chat/' . $type . 's/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '_' . time() . '.' . $extension;
        $filepath = $uploadDir . $filename;
        
        if (!move_uploaded_file($file['tmp_name'], $filepath)) {
            throw new Exception('Fayl yüklənmədi');
        }
        
        // Thumbnail yarad (şəkil üçün)
        $thumbnail = null;
        if ($type === 'image') {
            $thumbnail = $this->createThumbnail($filepath, $uploadDir . 'thumb_' . $filename);
        }
        
        // Fayl məlumatlarını bazaya yaz
        $fileId = $this->db->insert('file_uploads', [
            'user_id' => $currentUser['id'],
            'original_name' => $file['name'],
            'file_name' => $filename,
            'file_path' => $filepath,
            'file_type' => $type,
            'file_size' => $file['size'],
            'mime_type' => $file['type'],
            'category' => 'chat',
            'created_at' => date('Y-m-d H:i:s')
        ]);
        
        // Mesaj göndər
        $metadata = [
            'file_id' => $fileId,
            'original_name' => $file['name'],
            'file_size' => $file['size'],
            'mime_type' => $file['type']
        ];
        
        if ($thumbnail) {
            $metadata['thumbnail'] = 'thumb_' . $filename;
        }
        
        return $this->sendMessage($roomId, $file['name'], $type, $metadata);
    }
    
    private function createThumbnail($source, $destination, $width = 200, $height = 200) {
        $imageInfo = getimagesize($source);
        if (!$imageInfo) return false;
        
        $sourceWidth = $imageInfo[0];
        $sourceHeight = $imageInfo[1];
        $mimeType = $imageInfo['mime'];
        
        // Source image yarad
        switch ($mimeType) {
            case 'image/jpeg':
                $sourceImage = imagecreatefromjpeg($source);
                break;
            case 'image/png':
                $sourceImage = imagecreatefrompng($source);
                break;
            case 'image/gif':
                $sourceImage = imagecreatefromgif($source);
                break;
            default:
                return false;
        }
        
        // Aspect ratio hesabla
        $aspectRatio = $sourceWidth / $sourceHeight;
        if ($aspectRatio > 1) {
            $newWidth = $width;
            $newHeight = $width / $aspectRatio;
        } else {
            $newHeight = $height;
            $newWidth = $height * $aspectRatio;
        }
        
        // Thumbnail yarad
        $thumbnail = imagecreatetruecolor($newWidth, $newHeight);
        imagecopyresampled($thumbnail, $sourceImage, 0, 0, 0, 0, $newWidth, $newHeight, $sourceWidth, $sourceHeight);
        
        // Saxla
        $result = imagejpeg($thumbnail, $destination, 80);
        
        imagedestroy($sourceImage);
        imagedestroy($thumbnail);
        
        return $result;
    }
    
    public function getMessages($roomId, $page = 1, $limit = 50) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        if (!$this->isUserInRoom($roomId, $currentUser['id'])) {
            throw new Exception('Bu otağı görmək icazəniz yoxdur');
        }
        
        $offset = ($page - 1) * $limit;
        
        $messages = $this->db->select(
            'SELECT m.*, u.full_name as sender_name, u.avatar as sender_avatar,
                    r.content as reply_content, ru.full_name as reply_sender_name
             FROM messages m
             INNER JOIN users u ON m.sender_id = u.id
             LEFT JOIN messages r ON m.reply_to = r.id
             LEFT JOIN users ru ON r.sender_id = ru.id
             WHERE m.room_id = ? AND m.is_deleted = 0
             ORDER BY m.created_at DESC
             LIMIT ? OFFSET ?',
            [$roomId, $limit, $offset]
        );
        
        // Mesaj reaksiyalarını əlavə et
        foreach ($messages as &$message) {
            $message['reactions'] = $this->getMessageReactions($message['id']);
            $message['is_read'] = $this->isMessageRead($message['id'], $currentUser['id']);
        }
        
        return array_reverse($messages);
    }
    
    public function getRooms($userId = null) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        $userId = $userId ?: $currentUser['id'];
        
        $rooms = $this->db->select(
            'SELECT cr.*, 
                    (SELECT content FROM messages WHERE room_id = cr.id ORDER BY created_at DESC LIMIT 1) as last_message,
                    (SELECT created_at FROM messages WHERE room_id = cr.id ORDER BY created_at DESC LIMIT 1) as last_message_time,
                    (SELECT COUNT(*) FROM messages m 
                     WHERE m.room_id = cr.id 
                     AND m.sender_id != ? 
                     AND m.id NOT IN (SELECT message_id FROM message_reads WHERE user_id = ?)) as unread_count
             FROM chat_rooms cr
             INNER JOIN chat_participants cp ON cr.id = cp.room_id
             WHERE cp.user_id = ? AND cp.is_active = 1 AND cr.is_active = 1
             ORDER BY last_message_time DESC',
            [$userId, $userId, $userId]
        );
        
        // Hər otaq üçün iştirakçıları əlavə et
        foreach ($rooms as &$room) {
            $room['participants'] = $this->getRoomParticipants($room['id']);
            $room['last_message_time_ago'] = $room['last_message_time'] ? timeAgo($room['last_message_time']) : '';
        }
        
        return $rooms;
    }
    
    public function getRoomParticipants($roomId) {
        return $this->db->select(
            'SELECT u.id, u.full_name, u.avatar, u.role as user_role, cp.role as room_role
             FROM chat_participants cp
             INNER JOIN users u ON cp.user_id = u.id
             WHERE cp.room_id = ? AND cp.is_active = 1
             ORDER BY cp.joined_at ASC',
            [$roomId]
        );
    }
    
    public function isUserInRoom($roomId, $userId) {
        return $this->db->exists(
            'chat_participants',
            'room_id = ? AND user_id = ? AND is_active = 1',
            [$roomId, $userId]
        );
    }
    
    public function markAsRead($messageId, $userId) {
        return $this->db->query(
            'INSERT INTO message_reads (message_id, user_id, read_at) 
             VALUES (?, ?, ?) 
             ON DUPLICATE KEY UPDATE read_at = VALUES(read_at)',
            [$messageId, $userId, date('Y-m-d H:i:s')]
        );
    }
    
    public function markRoomAsRead($roomId, $userId) {
        $messages = $this->db->select(
            'SELECT id FROM messages WHERE room_id = ? AND sender_id != ?',
            [$roomId, $userId]
        );
        
        foreach ($messages as $message) {
            $this->markAsRead($message['id'], $userId);
        }
    }
    
    public function isMessageRead($messageId, $userId) {
        return $this->db->exists(
            'message_reads',
            'message_id = ? AND user_id = ?',
            [$messageId, $userId]
        );
    }
    
    public function addReaction($messageId, $reaction) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        return $this->db->query(
            'INSERT INTO message_reactions (message_id, user_id, reaction) 
             VALUES (?, ?, ?) 
             ON DUPLICATE KEY UPDATE reaction = VALUES(reaction)',
            [$messageId, $currentUser['id'], $reaction]
        );
    }
    
    public function removeReaction($messageId, $userId = null) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        $userId = $userId ?: $currentUser['id'];
        
        return $this->db->delete(
            'message_reactions',
            'message_id = ? AND user_id = ?',
            [$messageId, $userId]
        );
    }
    
    public function getMessageReactions($messageId) {
        $reactions = $this->db->select(
            'SELECT mr.reaction, u.full_name, u.avatar
             FROM message_reactions mr
             INNER JOIN users u ON mr.user_id = u.id
             WHERE mr.message_id = ?
             ORDER BY mr.created_at ASC',
            [$messageId]
        );
        
        // Reaksiyaları qruplaşdır
        $grouped = [];
        foreach ($reactions as $reaction) {
            $emoji = $reaction['reaction'];
            if (!isset($grouped[$emoji])) {
                $grouped[$emoji] = [
                    'emoji' => $emoji,
                    'count' => 0,
                    'users' => []
                ];
            }
            $grouped[$emoji]['count']++;
            $grouped[$emoji]['users'][] = [
                'name' => $reaction['full_name'],
                'avatar' => $reaction['avatar']
            ];
        }
        
        return array_values($grouped);
    }
    
    public function editMessage($messageId, $newContent) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        $message = $this->db->selectOne(
            'SELECT * FROM messages WHERE id = ? AND sender_id = ?',
            [$messageId, $currentUser['id']]
        );
        
        if (!$message) {
            throw new Exception('Mesaj tapılmadı və ya düzəliş icazəniz yoxdur');
        }
        
        return $this->db->update(
            'messages',
            [
                'content' => $newContent,
                'is_edited' => 1,
                'updated_at' => date('Y-m-d H:i:s')
            ],
            'id = ?',
            [$messageId]
        );
    }
    
    public function deleteMessage($messageId) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        $message = $this->db->selectOne(
            'SELECT * FROM messages WHERE id = ? AND sender_id = ?',
            [$messageId, $currentUser['id']]
        );
        
        if (!$message) {
            throw new Exception('Mesaj tapılmadı və ya silmək icazəniz yoxdur');
        }
        
        return $this->db->update(
            'messages',
            [
                'is_deleted' => 1,
                'content' => 'Bu mesaj silindi',
                'updated_at' => date('Y-m-d H:i:s')
            ],
            'id = ?',
            [$messageId]
        );
    }
    
    public function searchMessages($query, $roomId = null) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        $where = 'm.content LIKE ? AND m.is_deleted = 0';
        $params = ['%' . $query . '%'];
        
        if ($roomId) {
            $where .= ' AND m.room_id = ?';
            $params[] = $roomId;
            
            if (!$this->isUserInRoom($roomId, $currentUser['id'])) {
                throw new Exception('Bu otaqda axtarış icazəniz yoxdur');
            }
        } else {
            // Yalnız istifadəçinin daxil olduğu otaqlarda axtarış et
            $where .= ' AND m.room_id IN (
                SELECT room_id FROM chat_participants 
                WHERE user_id = ? AND is_active = 1
            )';
            $params[] = $currentUser['id'];
        }
        
        return $this->db->select(
            "SELECT m.*, u.full_name as sender_name, cr.name as room_name
             FROM messages m
             INNER JOIN users u ON m.sender_id = u.id
             INNER JOIN chat_rooms cr ON m.room_id = cr.id
             WHERE {$where}
             ORDER BY m.created_at DESC
             LIMIT 50",
            $params
        );
    }
    
    public function getUnreadCount($userId = null) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            return 0;
        }
        
        $userId = $userId ?: $currentUser['id'];
        
        $result = $this->db->selectOne(
            'SELECT COUNT(*) as count
             FROM messages m
             WHERE m.room_id IN (
                 SELECT room_id FROM chat_participants 
                 WHERE user_id = ? AND is_active = 1
             )
             AND m.sender_id != ?
             AND m.id NOT IN (
                 SELECT message_id FROM message_reads WHERE user_id = ?
             )',
            [$userId, $userId, $userId]
        );
        
        return $result['count'];
    }
    
    private function sendRealTimeNotification($roomId, $messageId) {
        // WebSocket server-ə bildiriş göndər
        $message = $this->db->selectOne(
            'SELECT m.*, u.full_name as sender_name, u.avatar as sender_avatar
             FROM messages m
             INNER JOIN users u ON m.sender_id = u.id
             WHERE m.id = ?',
            [$messageId]
        );
        
        $participants = $this->getRoomParticipants($roomId);
        
        $notification = [
            'type' => 'new_message',
            'room_id' => $roomId,
            'message' => $message,
            'participants' => array_column($participants, 'id')
        ];
        
        // WebSocket notification göndər (implementation WebSocket server-də olacaq)
        $this->sendToWebSocket($notification);
        
        // Push notification göndər
        $this->sendPushNotification($roomId, $message);
    }
    
    private function sendToWebSocket($data) {
        // WebSocket server-ə bağlantı qur və məlumat göndər
        try {
            $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            if (socket_connect($socket, WEBSOCKET_HOST, WEBSOCKET_PORT)) {
                socket_write($socket, json_encode($data));
                socket_close($socket);
            }
        } catch (Exception $e) {
            // Log error but don't throw
            error_log('WebSocket connection failed: ' . $e->getMessage());
        }
    }
    
    private function sendPushNotification($roomId, $message) {
        // Push notification implementation
        // Bu hissə ayrıca notification service ilə edilə bilər
    }
    
    public function leaveRoom($roomId, $userId = null) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        $userId = $userId ?: $currentUser['id'];
        
        return $this->db->update(
            'chat_participants',
            ['is_active' => 0],
            'room_id = ? AND user_id = ?',
            [$roomId, $userId]
        );
    }
    
    public function addParticipant($roomId, $userId) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser) {
            throw new Exception('İstifadəçi daxil olmamışdır');
        }
        
        // Admin icazəsi yoxla
        $isAdmin = $this->db->exists(
            'chat_participants',
            'room_id = ? AND user_id = ? AND role = "admin"',
            [$roomId, $currentUser['id']]
        );
        
        if (!$isAdmin) {
            throw new Exception('Bu əməliyyat üçün admin icazəsi lazımdır');
        }
        
        return $this->db->query(
            'INSERT INTO chat_participants (room_id, user_id, role, joined_at) 
             VALUES (?, ?, "member", ?) 
             ON DUPLICATE KEY UPDATE is_active = 1, joined_at = VALUES(joined_at)',
            [$roomId, $userId, date('Y-m-d H:i:s')]
        );
    }
}

?>