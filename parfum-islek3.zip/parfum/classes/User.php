<?php
/**
 * Parfüm POS Sistemi - User Sinfi
 * Yaradıldığı tarix: 2025-07-21
 */

class User {
    private $db;
    private $currentUser;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->loadCurrentUser();
    }
    
    public function register($data) {
        // Məlumatları təmizlə
        $username = sanitize($data['username']);
        $email = filter_var($data['email'], FILTER_VALIDATE_EMAIL);
        $password = $data['password'];
        $full_name = sanitize($data['full_name']);
        $phone = sanitize($data['phone'] ?? '');
        $role = in_array($data['role'], ['admin', 'manager', 'seller']) ? $data['role'] : 'seller';
        
        // Validation
        if (strlen($username) < 3) {
            throw new Exception('İstifadəçi adı ən azı 3 simvol olmalıdır');
        }
        
        if (!$email) {
            throw new Exception('Düzgün email daxil edin');
        }
        
        if (strlen($password) < 6) {
            throw new Exception('Şifrə ən azı 6 simvol olmalıdır');
        }
        
        // Unikallığı yoxla
        if ($this->db->exists('users', 'username = ?', [$username])) {
            throw new Exception('Bu istifadəçi adı artıq mövcuddur');
        }
        
        if ($this->db->exists('users', 'email = ?', [$email])) {
            throw new Exception('Bu email artıq mövcuddur');
        }
        
        try {
            $this->db->beginTransaction();
            
            // İstifadəçini əlavə et
            $userId = $this->db->insert('users', [
                'username' => $username,
                'email' => $email,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'full_name' => $full_name,
                'phone' => $phone,
                'role' => $role,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            // Profil yarad
            $this->db->insert('user_profiles', [
                'user_id' => $userId,
                'salary_type' => 'fixed',
                'base_salary' => 1000.00,
                'commission_rate' => 0.00,
                'created_at' => date('Y-m-d H:i:s')
            ]);
            
            $this->db->commit();
            return $userId;
            
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
    
    public function login($username, $password, $remember = false) {
        // İstifadəçini tap
        $user = $this->db->selectOne(
            'SELECT * FROM users WHERE (username = ? OR email = ?) AND is_active = 1',
            [$username, $username]
        );
        
        if (!$user || !password_verify($password, $user['password'])) {
            throw new Exception('İstifadəçi adı və ya şifrə yanlışdır');
        }
        
        // Last login güncəllə
        $this->db->update('users', 
            ['last_login' => date('Y-m-d H:i:s')], 
            'id = ?', 
            [$user['id']]
        );
        
        // Session yarad
        $this->createSession($user, $remember);
        
        return $user;
    }
    
    public function logout() {
        // Session məlumatlarını sil
        if (isset($_SESSION['user_id'])) {
            $this->db->delete('user_sessions', 'user_id = ?', [$_SESSION['user_id']]);
        }
        
        // Session təmizlə
        session_destroy();
        
        // Cookie-ləri sil
        if (isset($_COOKIE['remember_token'])) {
            setcookie('remember_token', '', time() - 3600, '/');
        }
    }
    
    private function createSession($user, $remember = false) {
        session_regenerate_id(true);
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['avatar'] = $user['avatar'];
        $_SESSION['last_activity'] = time();
        
        // Session məlumatlarını bazaya yaz
        $sessionData = [
            'id' => session_id(),
            'user_id' => $user['id'],
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'payload' => json_encode($_SESSION),
            'last_activity' => time()
        ];
        
        $this->db->query(
            'INSERT INTO user_sessions (id, user_id, ip_address, user_agent, payload, last_activity) 
             VALUES (?, ?, ?, ?, ?, ?) 
             ON DUPLICATE KEY UPDATE 
             payload = VALUES(payload), last_activity = VALUES(last_activity)',
            array_values($sessionData)
        );
        
        // Remember me
        if ($remember) {
            $token = generateToken();
            setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/', '', true, true);
            
            $this->db->update('users', 
                ['remember_token' => password_hash($token, PASSWORD_DEFAULT)], 
                'id = ?', 
                [$user['id']]
            );
        }
    }
    
    private function loadCurrentUser() {
        if (isset($_SESSION['user_id'])) {
            $this->currentUser = $this->getUserById($_SESSION['user_id']);
        } elseif (isset($_COOKIE['remember_token'])) {
            $this->handleRememberToken();
        }
    }
    
    private function handleRememberToken() {
        $token = $_COOKIE['remember_token'];
        $users = $this->db->select('SELECT * FROM users WHERE remember_token IS NOT NULL');
        
        foreach ($users as $user) {
            if (password_verify($token, $user['remember_token'])) {
                $this->createSession($user);
                $this->currentUser = $user;
                break;
            }
        }
    }
    
    public function isLoggedIn() {
        return $this->currentUser !== null;
    }
    
    public function getCurrentUser() {
        return $this->currentUser;
    }
    
    public function hasRole($role) {
        return $this->currentUser && $this->currentUser['role'] === $role;
    }
    
    public function hasPermission($permission) {
        if (!$this->currentUser) return false;
        
        $permissions = [
            'admin' => ['all'],
            'manager' => ['view_sales', 'create_sale', 'view_users', 'view_reports', 'manage_salary'],
            'seller' => ['create_sale', 'view_own_sales', 'chat', 'view_products']
        ];
        
        $userPermissions = $permissions[$this->currentUser['role']] ?? [];
        
        return in_array('all', $userPermissions) || in_array($permission, $userPermissions);
    }
    
    public function getUserById($id) {
        return $this->db->selectOne(
            'SELECT u.*, up.* FROM users u 
             LEFT JOIN user_profiles up ON u.id = up.user_id 
             WHERE u.id = ? AND u.is_active = 1',
            [$id]
        );
    }
    
    public function getAllUsers($filters = []) {
        $where = 'u.is_active = 1';
        $params = [];
        
        if (!empty($filters['role'])) {
            $where .= ' AND u.role = ?';
            $params[] = $filters['role'];
        }
        
        if (!empty($filters['search'])) {
            $where .= ' AND (u.full_name LIKE ? OR u.username LIKE ? OR u.email LIKE ?)';
            $search = '%' . $filters['search'] . '%';
            $params = array_merge($params, [$search, $search, $search]);
        }
        
        return $this->db->select(
            "SELECT u.*, up.salary_type, up.base_salary, up.commission_rate 
             FROM users u 
             LEFT JOIN user_profiles up ON u.id = up.user_id 
             WHERE {$where} 
             ORDER BY u.created_at DESC",
            $params
        );
    }
    
    public function updateProfile($userId, $data) {
        $allowedFields = ['full_name', 'email', 'phone', 'bio', 'birth_date', 'address'];
        $updateData = [];
        
        foreach ($allowedFields as $field) {
            if (isset($data[$field])) {
                $updateData[$field] = sanitize($data[$field]);
            }
        }
        
        if (!empty($updateData)) {
            $updateData['updated_at'] = date('Y-m-d H:i:s');
            
            if (isset($updateData['email'])) {
                // Email unikallığını yoxla
                if ($this->db->exists('users', 'email = ? AND id != ?', [$updateData['email'], $userId])) {
                    throw new Exception('Bu email artıq istifadə olunur');
                }
            }
            
            try {
                $this->db->beginTransaction();
                
                // User tablosunu güncəllə
                $userFields = ['full_name', 'email', 'phone'];
                $userUpdate = array_intersect_key($updateData, array_flip($userFields));
                if (!empty($userUpdate)) {
                    $this->db->update('users', $userUpdate, 'id = ?', [$userId]);
                }
                
                // Profile tablosunu güncəllə
                $profileFields = ['bio', 'birth_date', 'address'];
                $profileUpdate = array_intersect_key($updateData, array_flip($profileFields));
                if (!empty($profileUpdate)) {
                    $this->db->update('user_profiles', $profileUpdate, 'user_id = ?', [$userId]);
                }
                
                $this->db->commit();
                return true;
                
            } catch (Exception $e) {
                $this->db->rollback();
                throw $e;
            }
        }
        
        return false;
    }
    
    public function changePassword($userId, $currentPassword, $newPassword) {
        $user = $this->getUserById($userId);
        
        if (!password_verify($currentPassword, $user['password'])) {
            throw new Exception('Cari şifrə yanlışdır');
        }
        
        if (strlen($newPassword) < 6) {
            throw new Exception('Yeni şifrə ən azı 6 simvol olmalıdır');
        }
        
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        return $this->db->update('users', 
            ['password' => $hashedPassword, 'updated_at' => date('Y-m-d H:i:s')], 
            'id = ?', 
            [$userId]
        );
    }
    
    public function uploadAvatar($userId, $file) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($file['type'], $allowedTypes)) {
            throw new Exception('Yalnız JPG, PNG və GIF formatları qəbul edilir');
        }
        
        if ($file['size'] > $maxSize) {
            throw new Exception('Fayl ölçüsü 5MB-dan böyük ola bilməz');
        }
        
        $uploadDir = UPLOAD_PATH . 'avatars/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'avatar_' . $userId . '_' . time() . '.' . $extension;
        $filepath = $uploadDir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            // Köhnə avatarı sil
            $oldUser = $this->getUserById($userId);
            if ($oldUser['avatar'] && $oldUser['avatar'] !== 'default-avatar.png') {
                $oldFile = $uploadDir . $oldUser['avatar'];
                if (file_exists($oldFile)) {
                    unlink($oldFile);
                }
            }
            
            // Database-i güncəllə
            $this->db->update('users', 
                ['avatar' => $filename, 'updated_at' => date('Y-m-d H:i:s')], 
                'id = ?', 
                [$userId]
            );
            
            return $filename;
        } else {
            throw new Exception('Fayl yüklənmədi');
        }
    }
    
    public function getUserStats($userId) {
        $stats = [];
        
        // Satış statistikaları
        $salesStats = $this->db->selectOne(
            'SELECT 
                COUNT(*) as total_sales,
                SUM(final_amount) as total_revenue,
                AVG(final_amount) as avg_sale
             FROM sales 
             WHERE user_id = ? AND created_at >= ?',
            [$userId, date('Y-m-01')]
        );
        
        $stats['sales'] = $salesStats;
        
        // Maaş statistikaları
        $salaryStats = $this->db->selectOne(
            'SELECT 
                base_salary,
                commission_amount,
                bonus_amount,
                total_salary
             FROM salary_reports 
             WHERE user_id = ? AND month = ? AND year = ?',
            [$userId, date('n'), date('Y')]
        );
        
        $stats['salary'] = $salaryStats;
        
        // Chat statistikaları
        $chatStats = $this->db->selectOne(
            'SELECT COUNT(*) as message_count
             FROM messages 
             WHERE sender_id = ? AND created_at >= ?',
            [$userId, date('Y-m-01')]
        );
        
        $stats['chat'] = $chatStats;
        
        return $stats;
    }
    
    public function getOnlineUsers() {
        $thirtyMinutesAgo = time() - (30 * 60);
        
        return $this->db->select(
            'SELECT DISTINCT u.id, u.username, u.full_name, u.avatar, u.role
             FROM users u
             INNER JOIN user_sessions us ON u.id = us.user_id
             WHERE us.last_activity > ? AND u.is_active = 1
             ORDER BY us.last_activity DESC',
            [$thirtyMinutesAgo]
        );
    }
    
    public function updateLastActivity($userId) {
        $this->db->update('user_sessions', 
            ['last_activity' => time()], 
            'user_id = ?', 
            [$userId]
        );
        
        $_SESSION['last_activity'] = time();
    }
    
    public function deleteUser($userId) {
        if ($userId == $this->currentUser['id']) {
            throw new Exception('Öz hesabınızı silə bilməzsiniz');
        }
        
        return $this->db->update('users', 
            ['is_active' => 0, 'updated_at' => date('Y-m-d H:i:s')], 
            'id = ?', 
            [$userId]
        );
    }
    
    public function cleanExpiredSessions() {
        $expiredTime = time() - (24 * 60 * 60); // 24 saat
        
        return $this->db->delete('user_sessions', 'last_activity < ?', [$expiredTime]);
    }
}

?>