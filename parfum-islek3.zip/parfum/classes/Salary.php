<?php
/**
 * Parfüm POS Sistemi - Salary Class
 * Yaradıldığı tarix: 2025-07-21 10:57:50
 * Müəllif: Kodaz-az
 */

class Salary {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * İstifadəçinin maaş məlumatlarını əldə etmək
     */
    public function getUserSalaryInfo($userId) {
        try {
            $sql = "SELECT 
                        u.base_salary,
                        u.commission_rate,
                        COALESCE(sm.total_salary, 0) as current_month_salary,
                        COALESCE(sm.commission_amount, 0) as total_commission,
                        COALESCE(advance.total_advance, 0) as total_advance,
                        COALESCE(sm.bonus_amount, 0) as bonus_amount
                    FROM users u
                    LEFT JOIN salary_months sm ON u.id = sm.user_id 
                        AND sm.month = MONTH(NOW()) AND sm.year = YEAR(NOW())
                    LEFT JOIN (
                        SELECT user_id, SUM(amount) as total_advance
                        FROM salary_requests 
                        WHERE request_type = 'advance' AND status = 'approved'
                        AND MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())
                        GROUP BY user_id
                    ) advance ON u.id = advance.user_id
                    WHERE u.id = ?";
            
            return $this->db->selectOne($sql, [$userId]);
            
        } catch (Exception $e) {
            error_log("Get user salary info error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Maaş tarixini əldə etmək
     */
    public function getSalaryHistory($userId, $limit = 12) {
        try {
            $sql = "SELECT 
                        month,
                        year,
                        base_salary,
                        commission_amount,
                        bonus_amount,
                        penalty_amount,
                        advance_amount,
                        total_salary,
                        is_paid,
                        paid_at,
                        created_at
                    FROM salary_months
                    WHERE user_id = ?
                    ORDER BY year DESC, month DESC
                    LIMIT ?";
            
            return $this->db->selectAll($sql, [$userId, $limit]);
            
        } catch (Exception $e) {
            error_log("Get salary history error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Aylıq maaş hesablamaq
     */
    public function calculateMonthlySalary($userId, $month, $year) {
        try {
            // İstifadəçi məlumatlarını əldə etmək
            $user = $this->db->selectOne("SELECT * FROM users WHERE id = ?", [$userId]);
            if (!$user) {
                throw new Exception("İstifadəçi tapılmadı");
            }
            
            // Əsas maaş
            $baseSalary = floatval($user['base_salary']);
            
            // Komissiya hesablamaq
            $commissionAmount = $this->calculateCommission($userId, $month, $year);
            
            // Bonus əldə etmək
            $bonusAmount = $this->calculateBonus($userId, $month, $year);
            
            // Cərimə əldə etmək
            $penaltyAmount = $this->calculatePenalty($userId, $month, $year);
            
            // Avans əldə etmək
            $advanceAmount = $this->getMonthlyAdvance($userId, $month, $year);
            
            // Ümumi maaş hesablamaq
            $totalSalary = $baseSalary + $commissionAmount + $bonusAmount - $penaltyAmount - $advanceAmount;
            
            // Maaş cədvəlinə yazılmaq və ya yenilənmək
            $existingSalary = $this->db->selectOne(
                "SELECT id FROM salary_months WHERE user_id = ? AND month = ? AND year = ?",
                [$userId, $month, $year]
            );
            
            if ($existingSalary) {
                // Yeniləmək
                $sql = "UPDATE salary_months SET 
                            base_salary = ?,
                            commission_amount = ?,
                            bonus_amount = ?,
                            penalty_amount = ?,
                            advance_amount = ?,
                            total_salary = ?,
                            updated_at = NOW()
                        WHERE id = ?";
                
                $this->db->update($sql, [
                    $baseSalary, $commissionAmount, $bonusAmount, 
                    $penaltyAmount, $advanceAmount, $totalSalary,
                    $existingSalary['id']
                ]);
                
                return $existingSalary['id'];
            } else {
                // Yeni yaratmaq
                $sql = "INSERT INTO salary_months (
                            user_id, month, year, base_salary, commission_amount,
                            bonus_amount, penalty_amount, advance_amount, total_salary, created_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
                
                return $this->db->insert($sql, [
                    $userId, $month, $year, $baseSalary, $commissionAmount,
                    $bonusAmount, $penaltyAmount, $advanceAmount, $totalSalary
                ]);
            }
            
        } catch (Exception $e) {
            error_log("Calculate monthly salary error: " . $e->getMessage());
            throw new Exception("Maaş hesablana bilmədi");
        }
    }
    
    /**
     * Komissiya hesablamaq
     */
    private function calculateCommission($userId, $month, $year) {
        try {
            // İstifadəçinin komissiya faizini əldə etmək
            $user = $this->db->selectOne("SELECT commission_rate FROM users WHERE id = ?", [$userId]);
            $commissionRate = floatval($user['commission_rate'] ?? 0);
            
            if ($commissionRate <= 0) {
                return 0;
            }
            
            // Aylıq satışları əldə etmək
            $sql = "SELECT SUM(final_amount) as total_sales
                    FROM sales
                    WHERE user_id = ? AND MONTH(created_at) = ? AND YEAR(created_at) = ?
                    AND status = 'completed'";
            
            $result = $this->db->selectOne($sql, [$userId, $month, $year]);
            $totalSales = floatval($result['total_sales'] ?? 0);
            
            return $totalSales * ($commissionRate / 100);
            
        } catch (Exception $e) {
            error_log("Calculate commission error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Bonus hesablamaq
     */
    private function calculateBonus($userId, $month, $year) {
        try {
            $sql = "SELECT SUM(amount) as total_bonus
                    FROM salary_adjustments
                    WHERE user_id = ? AND adjustment_type = 'bonus'
                    AND MONTH(created_at) = ? AND YEAR(created_at) = ?";
            
            $result = $this->db->selectOne($sql, [$userId, $month, $year]);
            return floatval($result['total_bonus'] ?? 0);
            
        } catch (Exception $e) {
            error_log("Calculate bonus error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Cərimə hesablamaq
     */
    private function calculatePenalty($userId, $month, $year) {
        try {
            $sql = "SELECT SUM(amount) as total_penalty
                    FROM salary_adjustments
                    WHERE user_id = ? AND adjustment_type = 'penalty'
                    AND MONTH(created_at) = ? AND YEAR(created_at) = ?";
            
            $result = $this->db->selectOne($sql, [$userId, $month, $year]);
            return floatval($result['total_penalty'] ?? 0);
            
        } catch (Exception $e) {
            error_log("Calculate penalty error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Aylıq avans məbləğini əldə etmək
     */
    private function getMonthlyAdvance($userId, $month, $year) {
        try {
            $sql = "SELECT SUM(amount) as total_advance
                    FROM salary_requests
                    WHERE user_id = ? AND request_type = 'advance' AND status = 'approved'
                    AND MONTH(created_at) = ? AND YEAR(created_at) = ?";
            
            $result = $this->db->selectOne($sql, [$userId, $month, $year]);
            return floatval($result['total_advance'] ?? 0);
            
        } catch (Exception $e) {
            error_log("Get monthly advance error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Avans istəyi göndərmək
     */
    public function requestAdvance($userId, $amount, $reason) {
        try {
            // İstifadəçinin əsas maaşını yoxlamaq
            $user = $this->db->selectOne("SELECT base_salary FROM users WHERE id = ?", [$userId]);
            if (!$user) {
                throw new Exception("İstifadəçi tapılmadı");
            }
            
            $maxAdvance = $user['base_salary'] * 0.5; // Maksimum 50%
            
            if ($amount > $maxAdvance) {
                throw new Exception("Avans məbləği əsas maaşın 50%-ini keçə bilməz");
            }
            
            // Bu ay əvvəllər avans istəyib-istəmədiyini yoxlamaq
            $existingRequest = $this->db->selectOne(
                "SELECT id FROM salary_requests 
                 WHERE user_id = ? AND request_type = 'advance' 
                 AND MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())
                 AND status IN ('pending', 'approved')",
                [$userId]
            );
            
            if ($existingRequest) {
                throw new Exception("Bu ay artıq avans istəyi göndərilmişdir");
            }
            
            $sql = "INSERT INTO salary_requests (user_id, request_type, amount, reason, status, created_at) 
                    VALUES (?, 'advance', ?, ?, 'pending', NOW())";
            
            return $this->db->insert($sql, [$userId, $amount, $reason]);
            
        } catch (Exception $e) {
            error_log("Request advance error: " . $e->getMessage());
            throw new Exception($e->getMessage());
        }
    }
    
    /**
     * Gözləyən istəkləri əldə etmək
     */
    public function getPendingRequests($userId) {
        try {
            $sql = "SELECT * FROM salary_requests 
                    WHERE user_id = ? AND status = 'pending'
                    ORDER BY created_at DESC";
            
            return $this->db->selectAll($sql, [$userId]);
            
        } catch (Exception $e) {
            error_log("Get pending requests error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Bütün istəkləri əldə etmək (admin üçün)
     */
    public function getAllRequests() {
        try {
            $sql = "SELECT sr.*, u.full_name as user_name
                    FROM salary_requests sr
                    JOIN users u ON sr.user_id = u.id
                    ORDER BY sr.created_at DESC
                    LIMIT 50";
            
            return $this->db->selectAll($sql);
            
        } catch (Exception $e) {
            error_log("Get all requests error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * İstəyi təsdiqləmək
     */
    public function approveRequest($requestId) {
        try {
            $sql = "UPDATE salary_requests SET status = 'approved', processed_at = NOW() WHERE id = ?";
            return $this->db->update($sql, [$requestId]);
            
        } catch (Exception $e) {
            error_log("Approve request error: " . $e->getMessage());
            throw new Exception("İstək təsdiqlənmədi");
        }
    }
    
    /**
     * İstəyi rədd etmək
     */
    public function rejectRequest($requestId, $rejectionReason = '') {
        try {
            $sql = "UPDATE salary_requests SET status = 'rejected', rejection_reason = ?, processed_at = NOW() WHERE id = ?";
            return $this->db->update($sql, [$rejectionReason, $requestId]);
            
        } catch (Exception $e) {
            error_log("Reject request error: " . $e->getMessage());
            throw new Exception("İstək rədd edilmədi");
        }
    }
    
    /**
     * Maaş statistikalarını əldə etmək
     */
    public function getSalesStatistics($filters = []) {
        try {
            $dateFrom = $filters['date_from'] ?? date('Y-m-01');
            $dateTo = $filters['date_to'] ?? date('Y-m-t');
            $userId = $filters['user_id'] ?? null;
            
            $conditions = ["DATE(created_at) BETWEEN ? AND ?"];
            $params = [$dateFrom, $dateTo];
            
            if ($userId) {
                $conditions[] = "user_id = ?";
                $params[] = $userId;
            }
            
            $whereClause = "WHERE " . implode(" AND ", $conditions);
            
            $sql = "SELECT 
                        COUNT(*) as total_sales,
                        SUM(final_amount) as total_revenue,
                        AVG(final_amount) as avg_sale_amount
                    FROM sales
                    {$whereClause} AND status = 'completed'";
            
            $basic = $this->db->selectOne($sql, $params);
            
            return [
                'basic' => $basic
            ];
            
        } catch (Exception $e) {
            error_log("Get salary statistics error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Bütün maaş hesabatlarını əldə etmək
     */
    public function getAllSalaryReports($month, $year) {
        try {
            $sql = "SELECT sm.*, u.full_name as user_name
                    FROM salary_months sm
                    JOIN users u ON sm.user_id = u.id
                    WHERE sm.month = ? AND sm.year = ?
                    ORDER BY u.full_name";
            
            return $this->db->selectAll($sql, [$month, $year]);
            
        } catch (Exception $e) {
            error_log("Get all salary reports error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Aylıq maaş məlumatlarını əldə etmək
     */
    public function getMonthlySalary($userId, $month, $year) {
        try {
            $sql = "SELECT * FROM salary_months 
                    WHERE user_id = ? AND month = ? AND year = ?";
            
            $result = $this->db->selectOne($sql, [$userId, $month, $year]);
            
            if (!$result) {
                // Əgər hesablanmayıbsa, hesablamaq
                $this->calculateMonthlySalary($userId, $month, $year);
                $result = $this->db->selectOne($sql, [$userId, $month, $year]);
            }
            
            return $result ?: [];
            
        } catch (Exception $e) {
            error_log("Get monthly salary error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Maaş düzəlişi əlavə etmək
     */
    public function addSalaryAdjustment($userId, $type, $amount, $reason, $createdBy) {
        try {
            $allowedTypes = ['bonus', 'penalty', 'deduction'];
            if (!in_array($type, $allowedTypes)) {
                throw new Exception("Yanlış düzəliş növü");
            }
            
            $sql = "INSERT INTO salary_adjustments (user_id, adjustment_type, amount, reason, created_by, created_at) 
                    VALUES (?, ?, ?, ?, ?, NOW())";
            
            return $this->db->insert($sql, [$userId, $type, $amount, $reason, $createdBy]);
            
        } catch (Exception $e) {
            error_log("Add salary adjustment error: " . $e->getMessage());
            throw new Exception("Maaş düzəlişi əlavə edilmədi");
        }
    }
    
    /**
     * Maaşı ödənmiş kimi işarələmək
     */
    public function markAsPaid($salaryMonthId) {
        try {
            $sql = "UPDATE salary_months SET is_paid = 1, paid_at = NOW() WHERE id = ?";
            return $this->db->update($sql, [$salaryMonthId]);
            
        } catch (Exception $e) {
            error_log("Mark as paid error: " . $e->getMessage());
            throw new Exception("Maaş ödənmiş kimi işarələnmədi");
        }
    }
}
?>