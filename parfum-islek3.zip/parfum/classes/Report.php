<?php
/**
 * Parfüm POS Sistemi - Report Class
 * Yaradıldığı tarix: 2025-07-21 10:57:50
 * Müəllif: Kodaz-az
 */

class Report {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Satış hesabatı əldə etmək
     */
    public function getSalesReport($filters = []) {
        try {
            $dateFrom = $filters['date_from'] ?? date('Y-m-01');
            $dateTo = $filters['date_to'] ?? date('Y-m-t');
            $userId = $filters['user_id'] ?? null;
            $groupBy = $filters['group_by'] ?? 'day';
            
            $data = [
                'period' => [
                    'from' => $dateFrom,
                    'to' => $dateTo
                ],
                'summary' => $this->getSalesSummary($dateFrom, $dateTo, $userId),
                'daily_breakdown' => $this->getDailySalesBreakdown($dateFrom, $dateTo, $userId),
                'seller_performance' => $this->getSellerPerformance($dateFrom, $dateTo, $userId),
                'payment_methods' => $this->getPaymentMethodBreakdown($dateFrom, $dateTo, $userId),
                'top_products' => $this->getTopSellingProducts($dateFrom, $dateTo, $userId, 10)
            ];
            
            return $data;
            
        } catch (Exception $e) {
            error_log("Get sales report error: " . $e->getMessage());
            throw new Exception("Satış hesabatı yaradıla bilmədi");
        }
    }
    
    /**
     * Məhsul hesabatı əldə etmək
     */
    public function getProductReport($filters = []) {
        try {
            $data = [
                'summary' => $this->getProductSummary($filters),
                'stock_status' => $this->getStockStatusReport($filters),
                'category_breakdown' => $this->getCategoryBreakdown($filters),
                'brand_breakdown' => $this->getBrandBreakdown($filters),
                'low_stock_products' => $this->getLowStockProducts($filters),
                'top_selling_products' => $this->getTopSellingProductsDetailed($filters)
            ];
            
            return $data;
            
        } catch (Exception $e) {
            error_log("Get product report error: " . $e->getMessage());
            throw new Exception("Məhsul hesabatı yaradıla bilmədi");
        }
    }
    
    /**
     * Maliyyə hesabatı əldə etmək
     */
    public function getFinancialReport($filters = []) {
        try {
            $dateFrom = $filters['date_from'] ?? date('Y-m-01');
            $dateTo = $filters['date_to'] ?? date('Y-m-t');
            
            $data = [
                'period' => [
                    'from' => $dateFrom,
                    'to' => $dateTo
                ],
                'revenue' => $this->getRevenueAnalysis($dateFrom, $dateTo),
                'costs' => $this->getCostAnalysis($dateFrom, $dateTo),
                'profit_analysis' => $this->getProfitAnalysis($dateFrom, $dateTo),
                'monthly_trend' => $this->getMonthlyFinancialTrend($dateFrom, $dateTo),
                'expense_breakdown' => $this->getExpenseBreakdown($dateFrom, $dateTo)
            ];
            
            return $data;
            
        } catch (Exception $e) {
            error_log("Get financial report error: " . $e->getMessage());
            throw new Exception("Maliyyə hesabatı yaradıla bilmədi");
        }
    }
    
    /**
     * Inventar hərəkəti hesabatı əldə etmək
     */
    public function getInventoryMovementReport($filters = []) {
        try {
            $dateFrom = $filters['date_from'] ?? date('Y-m-01');
            $dateTo = $filters['date_to'] ?? date('Y-m-t');
            
            $data = [
                'period' => [
                    'from' => $dateFrom,
                    'to' => $dateTo
                ],
                'fast_moving' => $this->getFastMovingProducts($dateFrom, $dateTo),
                'slow_moving' => $this->getSlowMovingProducts($dateFrom, $dateTo),
                'stock_adjustments' => $this->getStockAdjustments($dateFrom, $dateTo),
                'inventory_value_trend' => $this->getInventoryValueTrend($dateFrom, $dateTo)
            ];
            
            return $data;
            
        } catch (Exception $e) {
            error_log("Get inventory report error: " . $e->getMessage());
            throw new Exception("Inventar hesabatı yaradıla bilmədi");
        }
    }
    
    /**
     * İstifadəçi performans hesabatı əldə etmək
     */
    public function getUserPerformanceReport($userId, $filters = []) {
        try {
            if (empty($userId)) {
                return null;
            }
            
            $dateFrom = $filters['date_from'] ?? date('Y-m-01');
            $dateTo = $filters['date_to'] ?? date('Y-m-t');
            
            $data = [
                'user_info' => $this->getUserInfo($userId),
                'sales_performance' => $this->getUserSalesPerformance($userId, $dateFrom, $dateTo),
                'daily_performance' => $this->getUserDailyPerformance($userId, $dateFrom, $dateTo),
                'chat_activity' => $this->getUserChatActivity($userId, $dateFrom, $dateTo),
                'target_achievement' => $this->getUserTargetAchievement($userId, $dateFrom, $dateTo)
            ];
            
            return $data;
            
        } catch (Exception $e) {
            error_log("Get user performance report error: " . $e->getMessage());
            throw new Exception("İstifadəçi performans hesabatı yaradıla bilmədi");
        }
    }
    
    // Private helper methods
    
    private function getSalesSummary($dateFrom, $dateTo, $userId = null) {
        $conditions = ["DATE(s.created_at) BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if ($userId) {
            $conditions[] = "s.user_id = ?";
            $params[] = $userId;
        }
        
        $whereClause = "WHERE " . implode(" AND ", $conditions);
        
        $sql = "SELECT 
                    COUNT(*) as total_sales,
                    SUM(s.final_amount) as total_revenue,
                    AVG(s.final_amount) as avg_sale_amount,
                    COUNT(DISTINCT s.user_id) as active_sellers,
                    SUM(s.total_items) as total_items_sold
                FROM sales s
                {$whereClause} AND s.status = 'completed'";
        
        return $this->db->selectOne($sql, $params);
    }
    
    private function getDailySalesBreakdown($dateFrom, $dateTo, $userId = null) {
        $conditions = ["DATE(s.created_at) BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if ($userId) {
            $conditions[] = "s.user_id = ?";
            $params[] = $userId;
        }
        
        $whereClause = "WHERE " . implode(" AND ", $conditions);
        
        $sql = "SELECT 
                    DATE(s.created_at) as sale_date,
                    COUNT(*) as daily_sales,
                    SUM(s.final_amount) as daily_revenue,
                    AVG(s.final_amount) as avg_sale_amount
                FROM sales s
                {$whereClause} AND s.status = 'completed'
                GROUP BY DATE(s.created_at)
                ORDER BY DATE(s.created_at)";
        
        return $this->db->selectAll($sql, $params);
    }
    
    private function getSellerPerformance($dateFrom, $dateTo, $userId = null) {
        $conditions = ["DATE(s.created_at) BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if ($userId) {
            $conditions[] = "s.user_id = ?";
            $params[] = $userId;
        }
        
        $whereClause = "WHERE " . implode(" AND ", $conditions);
        
        $sql = "SELECT 
                    u.id as seller_id,
                    u.full_name as seller_name,
                    COUNT(s.id) as sales_count,
                    SUM(s.final_amount) as total_revenue,
                    AVG(s.final_amount) as avg_sale_amount,
                    SUM(s.total_items) as total_items_sold
                FROM sales s
                JOIN users u ON s.user_id = u.id
                {$whereClause} AND s.status = 'completed'
                GROUP BY u.id, u.full_name
                ORDER BY total_revenue DESC";
        
        return $this->db->selectAll($sql, $params);
    }
    
    private function getPaymentMethodBreakdown($dateFrom, $dateTo, $userId = null) {
        $conditions = ["DATE(s.created_at) BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if ($userId) {
            $conditions[] = "s.user_id = ?";
            $params[] = $userId;
        }
        
        $whereClause = "WHERE " . implode(" AND ", $conditions);
        
        $sql = "SELECT 
                    s.payment_method,
                    COUNT(*) as count,
                    SUM(s.final_amount) as total_amount,
                    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM sales WHERE {$whereClause} AND status = 'completed'), 2) as percentage
                FROM sales s
                {$whereClause} AND s.status = 'completed'
                GROUP BY s.payment_method
                ORDER BY total_amount DESC";
        
        return $this->db->selectAll($sql, $params);
    }
    
    private function getTopSellingProducts($dateFrom, $dateTo, $userId = null, $limit = 10) {
        $conditions = ["DATE(s.created_at) BETWEEN ? AND ?"];
        $params = [$dateFrom, $dateTo];
        
        if ($userId) {
            $conditions[] = "s.user_id = ?";
            $params[] = $userId;
        }
        
        $whereClause = "WHERE " . implode(" AND ", $conditions);
        
        $sql = "SELECT 
                    p.id,
                    p.name as product_name,
                    p.brand as product_brand,
                    SUM(sd.quantity) as total_sold,
                    SUM(sd.quantity * sd.unit_price) as total_revenue
                FROM sale_details sd
                JOIN sales s ON sd.sale_id = s.id
                JOIN products p ON sd.product_id = p.id
                {$whereClause} AND s.status = 'completed'
                GROUP BY p.id, p.name, p.brand
                ORDER BY total_sold DESC
                LIMIT ?";
        
        $params[] = $limit;
        return $this->db->selectAll($sql, $params);
    }
    
    private function getProductSummary($filters = []) {
        $conditions = [];
        $params = [];
        
        if (!empty($filters['category'])) {
            $conditions[] = "category = ?";
            $params[] = $filters['category'];
        }
        
        if (!empty($filters['brand'])) {
            $conditions[] = "brand = ?";
            $params[] = $filters['brand'];
        }
        
        $whereClause = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";
        
        $sql = "SELECT 
                    COUNT(*) as total_products,
                    COUNT(DISTINCT category) as categories,
                    COUNT(DISTINCT brand) as brands,
                    SUM(CASE WHEN stock_quantity <= min_stock THEN 1 ELSE 0 END) as low_stock_count,
                    SUM(CASE WHEN stock_quantity = 0 THEN 1 ELSE 0 END) as out_of_stock_count,
                    SUM(stock_quantity * price) as total_inventory_value
                FROM products
                {$whereClause}";
        
        return $this->db->selectOne($sql, $params);
    }
    
    private function getStockStatusReport($filters = []) {
        $conditions = [];
        $params = [];
        
        if (!empty($filters['category'])) {
            $conditions[] = "category = ?";
            $params[] = $filters['category'];
        }
        
        if (!empty($filters['brand'])) {
            $conditions[] = "brand = ?";
            $params[] = $filters['brand'];
        }
        
        if (isset($filters['low_stock']) && $filters['low_stock']) {
            $conditions[] = "stock_quantity <= min_stock";
        }
        
        if (isset($filters['out_of_stock']) && $filters['out_of_stock']) {
            $conditions[] = "stock_quantity = 0";
        }
        
        $whereClause = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";
        
        $sql = "SELECT 
                    id,
                    name,
                    brand,
                    category,
                    stock_quantity,
                    min_stock,
                    price,
                    CASE 
                        WHEN stock_quantity = 0 THEN 'Stokda Yoxdur'
                        WHEN stock_quantity <= min_stock THEN 'Az Stok'
                        ELSE 'Normal'
                    END as stock_status
                FROM products
                {$whereClause}
                ORDER BY stock_quantity ASC";
        
        return $this->db->selectAll($sql, $params);
    }
    
    private function getCategoryBreakdown($filters = []) {
        $sql = "SELECT 
                    category,
                    COUNT(*) as product_count,
                    SUM(stock_quantity) as total_stock,
                    SUM(stock_quantity * price) as inventory_value
                FROM products
                GROUP BY category
                ORDER BY product_count DESC";
        
        return $this->db->selectAll($sql);
    }
    
    private function getBrandBreakdown($filters = []) {
        $sql = "SELECT 
                    brand,
                    COUNT(*) as product_count,
                    SUM(stock_quantity) as total_stock,
                    SUM(stock_quantity * price) as inventory_value
                FROM products
                WHERE brand IS NOT NULL AND brand != ''
                GROUP BY brand
                ORDER BY product_count DESC";
        
        return $this->db->selectAll($sql);
    }
    
    private function getLowStockProducts($filters = []) {
        $sql = "SELECT 
                    id,
                    name,
                    brand,
                    category,
                    stock_quantity,
                    min_stock,
                    price
                FROM products
                WHERE stock_quantity <= min_stock
                ORDER BY stock_quantity ASC
                LIMIT 20";
        
        return $this->db->selectAll($sql);
    }
    
    private function getTopSellingProductsDetailed($filters = []) {
        $dateFrom = $filters['date_from'] ?? date('Y-m-01');
        $dateTo = $filters['date_to'] ?? date('Y-m-t');
        
        $sql = "SELECT 
                    p.id,
                    p.name as product_name,
                    p.brand as product_brand,
                    p.category,
                    SUM(sd.quantity) as total_sold,
                    SUM(sd.quantity * sd.unit_price) as total_revenue,
                    p.stock_quantity as current_stock
                FROM sale_details sd
                JOIN sales s ON sd.sale_id = s.id
                JOIN products p ON sd.product_id = p.id
                WHERE DATE(s.created_at) BETWEEN ? AND ? AND s.status = 'completed'
                GROUP BY p.id, p.name, p.brand, p.category, p.stock_quantity
                ORDER BY total_sold DESC
                LIMIT 20";
        
        return $this->db->selectAll($sql, [$dateFrom, $dateTo]);
    }
    
    private function getRevenueAnalysis($dateFrom, $dateTo) {
        $sql = "SELECT 
                    SUM(final_amount) as total_revenue,
                    SUM(subtotal) as gross_revenue,
                    SUM(discount_amount) as total_discounts,
                    SUM(tax_amount) as total_tax,
                    COUNT(*) as total_transactions
                FROM sales
                WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed'";
        
        return $this->db->selectOne($sql, [$dateFrom, $dateTo]);
    }
    
    private function getCostAnalysis($dateFrom, $dateTo) {
        $sql = "SELECT 
                    SUM(sd.quantity * p.cost_price) as total_cost,
                    AVG(p.cost_price) as avg_cost_price
                FROM sale_details sd
                JOIN sales s ON sd.sale_id = s.id
                JOIN products p ON sd.product_id = p.id
                WHERE DATE(s.created_at) BETWEEN ? AND ? AND s.status = 'completed'";
        
        return $this->db->selectOne($sql, [$dateFrom, $dateTo]);
    }
    
    private function getProfitAnalysis($dateFrom, $dateTo) {
        $revenue = $this->getRevenueAnalysis($dateFrom, $dateTo);
        $costs = $this->getCostAnalysis($dateFrom, $dateTo);
        
        $totalRevenue = $revenue['total_revenue'] ?? 0;
        $totalCost = $costs['total_cost'] ?? 0;
        $grossProfit = $totalRevenue - $totalCost;
        $profitMargin = $totalRevenue > 0 ? ($grossProfit / $totalRevenue * 100) : 0;
        
        return [
            'gross_profit' => $grossProfit,
            'profit_margin' => $profitMargin,
            'total_revenue' => $totalRevenue,
            'total_cost' => $totalCost
        ];
    }
    
    private function getMonthlyFinancialTrend($dateFrom, $dateTo) {
        $sql = "SELECT 
                    DATE_FORMAT(created_at, '%Y-%m') as month,
                    SUM(final_amount) as monthly_revenue,
                    COUNT(*) as monthly_sales,
                    AVG(final_amount) as avg_sale_amount
                FROM sales
                WHERE DATE(created_at) BETWEEN ? AND ? AND status = 'completed'
                GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                ORDER BY month";
        
        return $this->db->selectAll($sql, [$dateFrom, $dateTo]);
    }
    
    private function getExpenseBreakdown($dateFrom, $dateTo) {
        // Bu funksiya gələcəkdə xərc cədvəli əlavə edildikdə genişləndirilə bilər
        return [];
    }
    
    private function getFastMovingProducts($dateFrom, $dateTo, $limit = 20) {
        $sql = "SELECT 
                    p.id,
                    p.name as product_name,
                    p.brand as product_brand,
                    SUM(sd.quantity) as total_sold,
                    SUM(sd.quantity * sd.unit_price) as total_revenue,
                    p.stock_quantity as current_stock
                FROM sale_details sd
                JOIN sales s ON sd.sale_id = s.id
                JOIN products p ON sd.product_id = p.id
                WHERE DATE(s.created_at) BETWEEN ? AND ? AND s.status = 'completed'
                GROUP BY p.id, p.name, p.brand, p.stock_quantity
                HAVING total_sold > 0
                ORDER BY total_sold DESC
                LIMIT ?";
        
        return $this->db->selectAll($sql, [$dateFrom, $dateTo, $limit]);
    }
    
    private function getSlowMovingProducts($dateFrom, $dateTo, $limit = 20) {
        $sql = "SELECT 
                    p.id,
                    p.name,
                    p.brand,
                    p.stock_quantity,
                    p.price,
                    (p.stock_quantity * p.price) as inventory_value,
                    COALESCE(sold.total_sold, 0) as total_sold
                FROM products p
                LEFT JOIN (
                    SELECT 
                        sd.product_id,
                        SUM(sd.quantity) as total_sold
                    FROM sale_details sd
                    JOIN sales s ON sd.sale_id = s.id
                    WHERE DATE(s.created_at) BETWEEN ? AND ? AND s.status = 'completed'
                    GROUP BY sd.product_id
                ) sold ON p.id = sold.product_id
                WHERE p.stock_quantity > 0
                ORDER BY COALESCE(sold.total_sold, 0) ASC, p.stock_quantity DESC
                LIMIT ?";
        
        return $this->db->selectAll($sql, [$dateFrom, $dateTo, $limit]);
    }
    
    private function getStockAdjustments($dateFrom, $dateTo) {
        // Bu funksiya gələcəkdə stok hərəkəti cədvəli əlavə edildikdə genişləndirilə bilər
        return [];
    }
    
    private function getInventoryValueTrend($dateFrom, $dateTo) {
        // Bu funksiya gələcəkdə inventar tarixi cədvəli əlavə edildikdə genişləndirilə bilər
        return [];
    }
    
    private function getUserInfo($userId) {
        $sql = "SELECT id, username, full_name, email, role, created_at FROM users WHERE id = ?";
        return $this->db->selectOne($sql, [$userId]);
    }
    
    private function getUserSalesPerformance($userId, $dateFrom, $dateTo) {
        $sql = "SELECT 
                    COUNT(*) as total_sales,
                    SUM(final_amount) as total_revenue,
                    AVG(final_amount) as avg_sale_amount,
                    SUM(total_items) as total_items_sold
                FROM sales
                WHERE user_id = ? AND DATE(created_at) BETWEEN ? AND ? AND status = 'completed'";
        
        return $this->db->selectOne($sql, [$userId, $dateFrom, $dateTo]);
    }
    
    private function getUserDailyPerformance($userId, $dateFrom, $dateTo) {
        $sql = "SELECT 
                    DATE(created_at) as sale_date,
                    COUNT(*) as daily_sales,
                    SUM(final_amount) as daily_revenue,
                    AVG(final_amount) as avg_sale_amount
                FROM sales
                WHERE user_id = ? AND DATE(created_at) BETWEEN ? AND ? AND status = 'completed'
                GROUP BY DATE(created_at)
                ORDER BY DATE(created_at)";
        
        return $this->db->selectAll($sql, [$userId, $dateFrom, $dateTo]);
    }
    
    private function getUserChatActivity($userId, $dateFrom, $dateTo) {
        $sql = "SELECT 
                    COUNT(*) as total_messages,
                    COUNT(DISTINCT DATE(created_at)) as active_days
                FROM chat_messages
                WHERE sender_id = ? AND DATE(created_at) BETWEEN ? AND ?";
        
        return $this->db->selectOne($sql, [$userId, $dateFrom, $dateTo]);
    }
    
    private function getUserTargetAchievement($userId, $dateFrom, $dateTo) {
        // Bu funksiya gələcəkdə satış hədəfləri əlavə edildikdə genişləndirilə bilər
        return [
            'target_amount' => 0,
            'achieved_amount' => 0,
            'achievement_percentage' => 0
        ];
    }
    
    /**
     * Xüsusi hesabat yaratmaq
     */
    public function generateCustomReport($reportData) {
        try {
            $sql = "INSERT INTO custom_reports (name, type, filters, format, created_by, created_at) 
                    VALUES (?, ?, ?, ?, ?, NOW())";
            
            $params = [
                $reportData['name'],
                $reportData['type'],
                json_encode($reportData['filters']),
                $reportData['format'],
                $reportData['created_by']
            ];
            
            return $this->db->insert($sql, $params);
            
        } catch (Exception $e) {
            error_log("Generate custom report error: " . $e->getMessage());
            throw new Exception("Xüsusi hesabat yaradıla bilmədi");
        }
    }
    
    /**
     * Hesabatı planlaşdırmaq
     */
    public function scheduleReport($scheduleData) {
        try {
            $sql = "INSERT INTO scheduled_reports (name, type, filters, format, frequency, day_of_week, day_of_month, time, recipients, created_by, is_active, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())";
            
            $params = [
                $scheduleData['name'],
                $scheduleData['type'],
                json_encode($scheduleData['filters']),
                $scheduleData['format'],
                $scheduleData['frequency'],
                $scheduleData['day_of_week'],
                $scheduleData['day_of_month'],
                $scheduleData['time'],
                json_encode($scheduleData['recipients']),
                $scheduleData['created_by']
            ];
            
            return $this->db->insert($sql, $params);
            
        } catch (Exception $e) {
            error_log("Schedule report error: " . $e->getMessage());
            throw new Exception("Hesabat planlaşdırıla bilmədi");
        }
    }
}
?>