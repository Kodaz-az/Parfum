<?php
/**
 * Parfüm POS Sistemi - Product Sinfi
 * Yaradıldığı tarix: 2025-07-21
 */

class Product {
    private $db;
    private $user;
    
    public function __construct() {
        $this->db = Database::getInstance();
        $this->user = new User();
    }
    
    public function getAllProducts($filters = []) {
        $where = 'is_active = 1';
        $params = [];
        
        if (!empty($filters['search'])) {
            $where .= ' AND (name LIKE ? OR brand LIKE ? OR barcode LIKE ?)';
            $search = '%' . $filters['search'] . '%';
            $params = array_merge($params, [$search, $search, $search]);
        }
        
        if (!empty($filters['category'])) {
            $where .= ' AND category = ?';
            $params[] = $filters['category'];
        }
        
        if (!empty($filters['brand'])) {
            $where .= ' AND brand = ?';
            $params[] = $filters['brand'];
        }
        
        if (!empty($filters['low_stock'])) {
            $where .= ' AND stock_quantity <= min_stock';
        }
        
        $orderBy = $filters['order_by'] ?? 'name';
        $orderDir = $filters['order_dir'] ?? 'ASC';
        
        return $this->db->select(
            "SELECT * FROM products 
             WHERE {$where} 
             ORDER BY {$orderBy} {$orderDir}",
            $params
        );
    }
    
    public function getProductById($id) {
        return $this->db->selectOne(
            'SELECT * FROM products WHERE id = ? AND is_active = 1',
            [$id]
        );
    }
    
    public function searchProducts($query, $limit = 20) {
        return $this->db->select(
            'SELECT * FROM products 
             WHERE (name LIKE ? OR brand LIKE ? OR barcode LIKE ?) 
             AND is_active = 1 
             ORDER BY name ASC 
             LIMIT ?',
            ["%{$query}%", "%{$query}%", "%{$query}%", $limit]
        );
    }
    
    public function createProduct($data) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('manage_products')) {
            throw new Exception('Məhsul əlavə etmək icazəniz yoxdur');
        }
        
        // Validation
        $this->validateProductData($data);
        
        // Check barcode uniqueness
        if (!empty($data['barcode']) && $this->db->exists('products', 'barcode = ?', [$data['barcode']])) {
            throw new Exception('Bu barkod artıq mövcuddur');
        }
        
        $productData = [
            'name' => sanitize($data['name']),
            'brand' => sanitize($data['brand'] ?? ''),
            'category' => sanitize($data['category'] ?? ''),
            'barcode' => sanitize($data['barcode'] ?? ''),
            'price' => $data['price'],
            'cost_price' => $data['cost_price'] ?? 0,
            'stock_quantity' => $data['stock_quantity'] ?? 0,
            'min_stock' => $data['min_stock'] ?? 5,
            'description' => sanitize($data['description'] ?? ''),
            'images' => json_encode($data['images'] ?? []),
            'size' => sanitize($data['size'] ?? ''),
            'gender' => $data['gender'] ?? 'unisex',
            'fragrance_family' => sanitize($data['fragrance_family'] ?? ''),
            'top_notes' => sanitize($data['top_notes'] ?? ''),
            'middle_notes' => sanitize($data['middle_notes'] ?? ''),
            'base_notes' => sanitize($data['base_notes'] ?? ''),
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        return $this->db->insert('products', $productData);
    }
    
    public function updateProduct($id, $data) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('manage_products')) {
            throw new Exception('Məhsul yeniləmək icazəniz yoxdur');
        }
        
        $product = $this->getProductById($id);
        if (!$product) {
            throw new Exception('Məhsul tapılmadı');
        }
        
        // Validation
        $this->validateProductData($data, $id);
        
        // Check barcode uniqueness
        if (!empty($data['barcode']) && 
            $this->db->exists('products', 'barcode = ? AND id != ?', [$data['barcode'], $id])) {
            throw new Exception('Bu barkod artıq mövcuddur');
        }
        
        $updateData = [
            'name' => sanitize($data['name']),
            'brand' => sanitize($data['brand'] ?? ''),
            'category' => sanitize($data['category'] ?? ''),
            'barcode' => sanitize($data['barcode'] ?? ''),
            'price' => $data['price'],
            'cost_price' => $data['cost_price'] ?? 0,
            'stock_quantity' => $data['stock_quantity'] ?? 0,
            'min_stock' => $data['min_stock'] ?? 5,
            'description' => sanitize($data['description'] ?? ''),
            'size' => sanitize($data['size'] ?? ''),
            'gender' => $data['gender'] ?? 'unisex',
            'fragrance_family' => sanitize($data['fragrance_family'] ?? ''),
            'top_notes' => sanitize($data['top_notes'] ?? ''),
            'middle_notes' => sanitize($data['middle_notes'] ?? ''),
            'base_notes' => sanitize($data['base_notes'] ?? ''),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        if (isset($data['images'])) {
            $updateData['images'] = json_encode($data['images']);
        }
        
        return $this->db->update('products', $updateData, 'id = ?', [$id]);
    }
    
    public function deleteProduct($id) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('manage_products')) {
            throw new Exception('Məhsul silmək icazəniz yoxdur');
        }
        
        $product = $this->getProductById($id);
        if (!$product) {
            throw new Exception('Məhsul tapılmadı');
        }
        
        // Check if product has sales
        $hasSales = $this->db->exists('sale_details', 'product_id = ?', [$id]);
        if ($hasSales) {
            // Soft delete
            return $this->db->update('products', 
                ['is_active' => 0, 'updated_at' => date('Y-m-d H:i:s')], 
                'id = ?', 
                [$id]
            );
        } else {
            // Hard delete
            return $this->db->delete('products', 'id = ?', [$id]);
        }
    }
    
    public function updateStock($id, $quantity, $operation = 'add') {
        $product = $this->getProductById($id);
        if (!$product) {
            throw new Exception('Məhsul tapılmadı');
        }
        
        $newQuantity = $product['stock_quantity'];
        
        switch ($operation) {
            case 'add':
                $newQuantity += $quantity;
                break;
            case 'subtract':
                $newQuantity -= $quantity;
                break;
            case 'set':
                $newQuantity = $quantity;
                break;
        }
        
        if ($newQuantity < 0) {
            throw new Exception('Stok miqdarı mənfi ola bilməz');
        }
        
        return $this->db->update('products', 
            ['stock_quantity' => $newQuantity, 'updated_at' => date('Y-m-d H:i:s')], 
            'id = ?', 
            [$id]
        );
    }
    
    public function getLowStockProducts() {
        return $this->db->select(
            'SELECT * FROM products 
             WHERE stock_quantity <= min_stock 
             AND is_active = 1 
             ORDER BY stock_quantity ASC'
        );
    }
    
    public function getCategories() {
        return $this->db->select(
            'SELECT DISTINCT category FROM products 
             WHERE category IS NOT NULL 
             AND category != "" 
             AND is_active = 1 
             ORDER BY category ASC'
        );
    }
    
    public function getBrands() {
        return $this->db->select(
            'SELECT DISTINCT brand FROM products 
             WHERE brand IS NOT NULL 
             AND brand != "" 
             AND is_active = 1 
             ORDER BY brand ASC'
        );
    }
    
    public function getProductStats() {
        $stats = [];
        
        // Total products
        $stats['total'] = $this->db->count('products', 'is_active = 1');
        
        // Low stock products
        $stats['low_stock'] = $this->db->count('products', 'stock_quantity <= min_stock AND is_active = 1');
        
        // Out of stock products
        $stats['out_of_stock'] = $this->db->count('products', 'stock_quantity = 0 AND is_active = 1');
        
        // Total value
        $totalValue = $this->db->selectOne(
            'SELECT SUM(price * stock_quantity) as total_value FROM products WHERE is_active = 1'
        );
        $stats['total_value'] = $totalValue['total_value'] ?? 0;
        
        // Categories count
        $stats['categories'] = $this->db->count('products', 'category IS NOT NULL AND category != "" AND is_active = 1', [], 'DISTINCT category');
        
        // Brands count
        $stats['brands'] = $this->db->count('products', 'brand IS NOT NULL AND brand != "" AND is_active = 1', [], 'DISTINCT brand');
        
        return $stats;
    }
    
    public function uploadProductImage($productId, $file) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('manage_products')) {
            throw new Exception('Şəkil yükləmək icazəniz yoxdur');
        }
        
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $maxSize = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($file['type'], $allowedTypes)) {
            throw new Exception('Yalnız JPG, PNG, GIF və WebP formatları qəbul edilir');
        }
        
        if ($file['size'] > $maxSize) {
            throw new Exception('Fayl ölçüsü 5MB-dan böyük ola bilməz');
        }
        
        $uploadDir = UPLOAD_PATH . 'products/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'product_' . $productId . '_' . uniqid() . '.' . $extension;
        $filepath = $uploadDir . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            // Add to product images
            $product = $this->getProductById($productId);
            $images = json_decode($product['images'], true) ?? [];
            $images[] = $filename;
            
            $this->db->update('products', 
                ['images' => json_encode($images), 'updated_at' => date('Y-m-d H:i:s')], 
                'id = ?', 
                [$productId]
            );
            
            return $filename;
        } else {
            throw new Exception('Fayl yüklənmədi');
        }
    }
    
    public function removeProductImage($productId, $filename) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('manage_products')) {
            throw new Exception('Şəkil silmək icazəniz yoxdur');
        }
        
        $product = $this->getProductById($productId);
        if (!$product) {
            throw new Exception('Məhsul tapılmadı');
        }
        
        $images = json_decode($product['images'], true) ?? [];
        $images = array_filter($images, function($img) use ($filename) {
            return $img !== $filename;
        });
        
        $this->db->update('products', 
            ['images' => json_encode(array_values($images)), 'updated_at' => date('Y-m-d H:i:s')], 
            'id = ?', 
            [$productId]
        );
        
        // Delete physical file
        $filepath = UPLOAD_PATH . 'products/' . $filename;
        if (file_exists($filepath)) {
            unlink($filepath);
        }
        
        return true;
    }
    
    public function generateBarcode() {
        do {
            $barcode = str_pad(rand(1, 999999999999), 12, '0', STR_PAD_LEFT);
        } while ($this->db->exists('products', 'barcode = ?', [$barcode]));
        
        return $barcode;
    }
    
    public function importProducts($csvFile) {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('manage_products')) {
            throw new Exception('Məhsul idxal etmək icazəniz yoxdur');
        }
        
        if (!file_exists($csvFile) || !is_readable($csvFile)) {
            throw new Exception('CSV faylı oxuna bilmir');
        }
        
        $handle = fopen($csvFile, 'r');
        if (!$handle) {
            throw new Exception('CSV faylı açıla bilmir');
        }
        
        $headers = fgetcsv($handle);
        $imported = 0;
        $errors = [];
        
        try {
            $this->db->beginTransaction();
            
            while (($data = fgetcsv($handle)) !== FALSE) {
                try {
                    $productData = array_combine($headers, $data);
                    $this->createProduct($productData);
                    $imported++;
                } catch (Exception $e) {
                    $errors[] = "Sətir " . ($imported + 1) . ": " . $e->getMessage();
                }
            }
            
            $this->db->commit();
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        } finally {
            fclose($handle);
        }
        
        return [
            'imported' => $imported,
            'errors' => $errors
        ];
    }
    
    public function exportProducts($format = 'csv') {
        $currentUser = $this->user->getCurrentUser();
        if (!$currentUser || !$this->user->hasPermission('view_reports')) {
            throw new Exception('Məhsul ixrac etmək icazəniz yoxdur');
        }
        
        $products = $this->getAllProducts();
        
        if ($format === 'csv') {
            return $this->exportToCSV($products);
        } elseif ($format === 'xlsx') {
            return $this->exportToExcel($products);
        } else {
            throw new Exception('Dəstəklənməyən format');
        }
    }
    
    private function exportToCSV($products) {
        $filename = 'products_' . date('Y-m-d_H-i-s') . '.csv';
        $filepath = UPLOAD_PATH . 'exports/' . $filename;
        
        if (!is_dir(dirname($filepath))) {
            mkdir(dirname($filepath), 0755, true);
        }
        
        $file = fopen($filepath, 'w');
        
        // UTF-8 BOM
        fwrite($file, "\xEF\xBB\xBF");
        
        // Headers
        fputcsv($file, [
            'ID', 'Ad', 'Brend', 'Kateqoriya', 'Barkod', 'Qiymət', 
            'Maya dəyəri', 'Stok', 'Min stok', 'Ölçü', 'Cins', 'Qoxu ailəsi'
        ]);
        
        // Data
        foreach ($products as $product) {
            fputcsv($file, [
                $product['id'],
                $product['name'],
                $product['brand'],
                $product['category'],
                $product['barcode'],
                $product['price'],
                $product['cost_price'],
                $product['stock_quantity'],
                $product['min_stock'],
                $product['size'],
                $product['gender'],
                $product['fragrance_family']
            ]);
        }
        
        fclose($file);
        
        return $filepath;
    }
    
    private function validateProductData($data, $id = null) {
        if (empty($data['name'])) {
            throw new Exception('Məhsul adı tələb olunur');
        }
        
        if (strlen($data['name']) < 2) {
            throw new Exception('Məhsul adı ən azı 2 simvol olmalıdır');
        }
        
        if (empty($data['price']) || $data['price'] <= 0) {
            throw new Exception('Düzgün qiymət daxil edin');
        }
        
        if (isset($data['cost_price']) && $data['cost_price'] < 0) {
            throw new Exception('Maya dəyəri mənfi ola bilməz');
        }
        
        if (isset($data['stock_quantity']) && $data['stock_quantity'] < 0) {
            throw new Exception('Stok miqdarı mənfi ola bilməz');
        }
        
        if (isset($data['min_stock']) && $data['min_stock'] < 0) {
            throw new Exception('Minimum stok miqdarı mənfi ola bilməz');
        }
        
        if (isset($data['gender']) && !in_array($data['gender'], ['male', 'female', 'unisex'])) {
            throw new Exception('Düzgün cins seçin');
        }
    }
}

?>