<?php
/**
 * Parfüm POS Sistemi - Notification Class
 * Yaradıldığı tarix: 2025-07-21 10:52:27
 * Müəllif: Kodaz-az
 */

class Notification {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Bildiriş yaratmaq
     */
    public function createNotification($notificationData) {
        try {
            $sql = "INSERT INTO notifications (user_id, type, title, message, data, sender_id, priority, expires_at, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            
            $params = [
                $notificationData['user_id'],
                $notificationData['type'],
                $notificationData['title'],
                $notificationData['message'],
                json_encode($notificationData['data']),
                $notificationData['sender_id'] ?? null,
                $notificationData['priority'] ?? 'normal',
                $notificationData['expires_at'] ?? null
            ];
            
            return $this->db->insert($sql, $params);
            
        } catch (Exception $e) {
            error_log("Create notification error: " . $e->getMessage());
            throw new Exception("Bildiriş yaradıla bilmədi");
        }
    }
    
    /**
     * İstifadəçinin bildirişlərini əldə etmək
     */
    public function getUserNotifications($filters = []) {
        try {
            $conditions = ["n.user_id = ?"];
            $params = [$filters['user_id']];
            
            if (!empty($filters['type'])) {
                $conditions[] = "n.type = ?";
                $params[] = $filters['type'];
            }
            
            if (isset($filters['is_read'])) {
                $conditions[] = "n.is_read = ?";
                $params[] = $filters['is_read'];
            }
            
            // Müddəti keçməmiş bildirişlər
            $conditions[] = "(n.expires_at IS NULL OR n.expires_at > NOW())";
            
            $whereClause = "WHERE " . implode(" AND ", $conditions);
            
            $sql = "SELECT n.*, u.full_name as sender_name, u.avatar as sender_avatar
                    FROM notifications n
                    LEFT JOIN users u ON n.sender_id = u.id
                    {$whereClause}
                    ORDER BY n.created_at DESC";
            
            if (isset($filters['limit'])) {
                $sql .= " LIMIT " . intval($filters['limit']);
            }
            
            if (isset($filters['offset'])) {
                $sql .= " OFFSET " . intval($filters['offset']);
            }
            
            $notifications = $this->db->selectAll($sql, $params);
            
            // JSON data-nı decode etmək
            foreach ($notifications as &$notification) {
                $notification['data'] = json_decode($notification['data'], true);
            }
            
            return $notifications;
            
        } catch (Exception $e) {
            error_log("Get user notifications error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Bildirişi ID ilə əldə etmək
     */
    public function getNotificationById($notificationId) {
        try {
            $sql = "SELECT n.*, u.full_name as sender_name, u.avatar as sender_avatar
                    FROM notifications n
                    LEFT JOIN users u ON n.sender_id = u.id
                    WHERE n.id = ?";
            
            $notification = $this->db->selectOne($sql, [$notificationId]);
            
            if ($notification) {
                $notification['data'] = json_decode($notification['data'], true);
            }
            
            return $notification;
            
        } catch (Exception $e) {
            error_log("Get notification by ID error: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Oxunmamış bildirişləri əldə etmək
     */
    public function getUnreadNotifications($userId, $limit = 10) {
        try {
            $sql = "SELECT n.*, u.full_name as sender_name, u.avatar as sender_avatar
                    FROM notifications n
                    LEFT JOIN users u ON n.sender_id = u.id
                    WHERE n.user_id = ? AND n.is_read = 0 
                    AND (n.expires_at IS NULL OR n.expires_at > NOW())
                    ORDER BY n.created_at DESC
                    LIMIT ?";
            
            $notifications = $this->db->selectAll($sql, [$userId, $limit]);
            
            foreach ($notifications as &$notification) {
                $notification['data'] = json_decode($notification['data'], true);
            }
            
            return $notifications;
            
        } catch (Exception $e) {
            error_log("Get unread notifications error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Bildirişi oxunmuş kimi işarələmək
     */
    public function markAsRead($notificationId) {
        try {
            $sql = "UPDATE notifications SET is_read = 1, read_at = NOW() WHERE id = ?";
            return $this->db->update($sql, [$notificationId]);
            
        } catch (Exception $e) {
            error_log("Mark as read error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Bütün bildirişləri oxunmuş kimi işarələmək
     */
    public function markAllAsRead($userId) {
        try {
            $sql = "UPDATE notifications SET is_read = 1, read_at = NOW() 
                    WHERE user_id = ? AND is_read = 0";
            
            return $this->db->update($sql, [$userId]);
            
        } catch (Exception $e) {
            error_log("Mark all as read error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Bildirişi silmək
     */
    public function deleteNotification($notificationId) {
        try {
            $sql = "DELETE FROM notifications WHERE id = ?";
            return $this->db->delete($sql, [$notificationId]);
            
        } catch (Exception $e) {
            error_log("Delete notification error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Bütün bildirişləri təmizləmək
     */
    public function clearAllNotifications($userId) {
        try {
            $sql = "DELETE FROM notifications WHERE user_id = ?";
            return $this->db->delete($sql, [$userId]);
            
        } catch (Exception $e) {
            error_log("Clear all notifications error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Oxunmamış bildiriş sayını əldə etmək
     */
    public function getUnreadCount($userId) {
        try {
            $sql = "SELECT COUNT(*) as count FROM notifications 
                    WHERE user_id = ? AND is_read = 0 
                    AND (expires_at IS NULL OR expires_at > NOW())";
            
            $result = $this->db->selectOne($sql, [$userId]);
            return $result['count'] ?? 0;
            
        } catch (Exception $e) {
            error_log("Get unread count error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Toplam bildiriş sayını əldə etmək
     */
    public function getTotalCount($userId) {
        try {
            $sql = "SELECT COUNT(*) as count FROM notifications 
                    WHERE user_id = ? AND (expires_at IS NULL OR expires_at > NOW())";
            
            $result = $this->db->selectOne($sql, [$userId]);
            return $result['count'] ?? 0;
            
        } catch (Exception $e) {
            error_log("Get total count error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Bildiriş sayını filtrlə əldə etmək
     */
    public function getNotificationCount($filters = []) {
        try {
            $conditions = ["user_id = ?"];
            $params = [$filters['user_id']];
            
            if (!empty($filters['type'])) {
                $conditions[] = "type = ?";
                $params[] = $filters['type'];
            }
            
            if (isset($filters['is_read'])) {
                $conditions[] = "is_read = ?";
                $params[] = $filters['is_read'];
            }
            
            $conditions[] = "(expires_at IS NULL OR expires_at > NOW())";
            
            $whereClause = "WHERE " . implode(" AND ", $conditions);
            
            $sql = "SELECT COUNT(*) as count FROM notifications {$whereClause}";
            
            $result = $this->db->selectOne($sql, $params);
            return $result['count'] ?? 0;
            
        } catch (Exception $e) {
            error_log("Get notification count error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Push bildiriş abunəliyi yaratmaq
     */
    public function subscribePush($subscriptionData) {
        try {
            // Mövcud abunəliyi yoxlamaq
            $existing = $this->db->selectOne(
                "SELECT id FROM push_subscriptions WHERE user_id = ? AND endpoint = ?",
                [$subscriptionData['user_id'], $subscriptionData['endpoint']]
            );
            
            if ($existing) {
                // Mövcud abunəliyi yeniləmək
                $sql = "UPDATE push_subscriptions SET p256dh = ?, auth = ?, user_agent = ?, updated_at = NOW() 
                        WHERE id = ?";
                
                $this->db->update($sql, [
                    $subscriptionData['p256dh'],
                    $subscriptionData['auth'],
                    $subscriptionData['user_agent'],
                    $existing['id']
                ]);
                
                return $existing['id'];
            } else {
                // Yeni abunəlik yaratmaq
                $sql = "INSERT INTO push_subscriptions (user_id, endpoint, p256dh, auth, user_agent, created_at) 
                        VALUES (?, ?, ?, ?, ?, NOW())";
                
                return $this->db->insert($sql, [
                    $subscriptionData['user_id'],
                    $subscriptionData['endpoint'],
                    $subscriptionData['p256dh'],
                    $subscriptionData['auth'],
                    $subscriptionData['user_agent']
                ]);
            }
            
        } catch (Exception $e) {
            error_log("Subscribe push error: " . $e->getMessage());
            throw new Exception("Push abunəliyi yaradıla bilmədi");
        }
    }
    
    /**
     * İstifadəçinin push abunəliklərini əldə etmək
     */
    public function getUserPushSubscriptions($userId) {
        try {
            $sql = "SELECT * FROM push_subscriptions WHERE user_id = ? AND is_active = 1";
            return $this->db->selectAll($sql, [$userId]);
            
        } catch (Exception $e) {
            error_log("Get user push subscriptions error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Müddəti keçmiş bildirişləri təmizləmək
     */
    public function cleanExpiredNotifications() {
        try {
            $sql = "DELETE FROM notifications WHERE expires_at IS NOT NULL AND expires_at < NOW()";
            return $this->db->delete($sql);
            
        } catch (Exception $e) {
            error_log("Clean expired notifications error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Sistem bildirişi göndərmək (bütün istifadəçilərə)
     */
    public function sendSystemNotification($notificationData) {
        try {
            // Aktiv istifadəçiləri əldə etmək
            $users = $this->db->selectAll("SELECT id FROM users WHERE is_active = 1");
            
            $sql = "INSERT INTO notifications (user_id, type, title, message, data, sender_id, priority, created_at) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
            
            $insertedCount = 0;
            
            foreach ($users as $user) {
                $params = [
                    $user['id'],
                    $notificationData['type'] ?? 'system',
                    $notificationData['title'],
                    $notificationData['message'],
                    json_encode($notificationData['data'] ?? []),
                    $notificationData['sender_id'] ?? null,
                    $notificationData['priority'] ?? 'normal'
                ];
                
                if ($this->db->insert($sql, $params)) {
                    $insertedCount++;
                }
            }
            
            return $insertedCount;
            
        } catch (Exception $e) {
            error_log("Send system notification error: " . $e->getMessage());
            throw new Exception("Sistem bildirişi göndərilmədi");
        }
    }
    
    /**
     * Az stok xəbərdarlığı yaratmaq
     */
    public function createLowStockAlert($productData) {
        try {
            // Admin və menecer istifadəçiləri əldə etmək
            $users = $this->db->selectAll(
                "SELECT id FROM users WHERE role IN ('admin', 'manager') AND is_active = 1"
            );
            
            $title = "Az Stok Xəbərdarlığı";
            $message = "{$productData['name']} məhsulunda yalnız {$productData['stock_quantity']} ədəd qalıb";
            
            $data = [
                'product_id' => $productData['id'],
                'product_name' => $productData['name'],
                'current_stock' => $productData['stock_quantity'],
                'min_stock' => $productData['min_stock']
            ];
            
            foreach ($users as $user) {
                $this->createNotification([
                    'user_id' => $user['id'],
                    'type' => 'low_stock',
                    'title' => $title,
                    'message' => $message,
                    'data' => $data,
                    'priority' => 'high'
                ]);
            }
            
            return count($users);
            
        } catch (Exception $e) {
            error_log("Create low stock alert error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Yeni satış bildirişi yaratmaq
     */
    public function createSaleNotification($saleData) {
        try {
            // Admin və menecer istifadəçiləri əldə etmək
            $users = $this->db->selectAll(
                "SELECT id FROM users WHERE role IN ('admin', 'manager') AND is_active = 1"
            );
            
            $title = "Yeni Satış";
            $message = "Yeni satış: #{$saleData['sale_number']} - {$saleData['final_amount']} ₼";
            
            $data = [
                'sale_id' => $saleData['id'],
                'sale_number' => $saleData['sale_number'],
                'amount' => $saleData['final_amount'],
                'seller_name' => $saleData['seller_name']
            ];
            
            foreach ($users as $user) {
                // Özünə bildiriş göndərməmək
                if ($user['id'] != $saleData['user_id']) {
                    $this->createNotification([
                        'user_id' => $user['id'],
                        'type' => 'new_sale',
                        'title' => $title,
                        'message' => $message,
                        'data' => $data,
                        'priority' => 'normal'
                    ]);
                }
            }
            
            return count($users);
            
        } catch (Exception $e) {
            error_log("Create sale notification error: " . $e->getMessage());
            return 0;
        }
    }
}
?>