<?php
/**
 * Satış Sistemi - POS və Satış İdarəetməsi
 * Kodaz-az - 2025-07-21 14:21:20 (UTC)
 * Login: Kodaz-az
 */

$currentUserId = $_SESSION['user_id'];
$currentUserRole = $_SESSION['role'];

if (!function_exists('generateSaleNumber')) {
    function generateSaleNumber() {
        $prefix = 'S';
        $date = date('Ymd');
        $random = str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT);
        
        return $prefix . $date . '-' . $random;
    }
}
// Add sale action
if ($action === 'add_sale' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = Database::getInstance();
        
        $customerName = trim($_POST['customer_name'] ?? '');
        $customerPhone = trim($_POST['customer_phone'] ?? '');
        $customerEmail = trim($_POST['customer_email'] ?? '');
        $paymentMethod = $_POST['payment_method'] ?? 'cash';
        $notes = trim($_POST['notes'] ?? '');
        $products = json_decode($_POST['products'] ?? '[]', true);
        $discount = floatval($_POST['discount'] ?? 0);
        $discountType = $_POST['discount_type'] ?? 'amount'; // amount or percentage
        
        if (empty($products)) {
            throw new Exception('Məhsul seçilməyib');
        }
        
        // Calculate totals
        $subtotal = 0;
        $totalItems = 0;
        
        foreach ($products as $product) {
            $subtotal += $product['price'] * $product['quantity'];
            $totalItems += $product['quantity'];
        }
        
        // Apply discount
        $discountAmount = 0;
        if ($discount > 0) {
            if ($discountType === 'percentage') {
                $discountAmount = ($subtotal * $discount) / 100;
            } else {
                $discountAmount = $discount;
            }
        }
        
        $afterDiscount = $subtotal - $discountAmount;
        $taxRate = 18; // 18% VAT
        $taxAmount = $afterDiscount * ($taxRate / 100);
        $finalAmount = $afterDiscount + $taxAmount;
        
        // Generate sale number
        $saleNumber = generateSaleNumber();
        
        // Start transaction
        $db->beginTransaction();
        
        try {
            // Insert sale
            $saleId = $db->insert("
                INSERT INTO sales (
                    sale_number, user_id, customer_name, customer_phone, customer_email,
                    subtotal, discount_amount, tax_amount, final_amount, payment_method,
                    total_items, notes, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'completed', NOW())
            ", [
                $saleNumber, $currentUserId, $customerName, $customerPhone, $customerEmail,
                $subtotal, $discountAmount, $taxAmount, $finalAmount, $paymentMethod,
                $totalItems, $notes
            ]);
            
            // Insert sale details and update stock
            foreach ($products as $product) {
                // Check stock availability
                $currentStock = $db->selectOne("SELECT stock_quantity FROM products WHERE id = ?", [$product['id']]);
                
                if ($currentStock['stock_quantity'] < $product['quantity']) {
                    throw new Exception("'{$product['name']}' məhsulu üçün kifayət qədər stok yoxdur");
                }
                
                // Insert sale detail
                $db->insert("
                    INSERT INTO sale_details (sale_id, product_id, quantity, unit_price, total_price, created_at)
                    VALUES (?, ?, ?, ?, ?, NOW())
                ", [$saleId, $product['id'], $product['quantity'], $product['price'], $product['price'] * $product['quantity']]);
                
                // Update stock
                $db->update("
                    UPDATE products 
                    SET stock_quantity = stock_quantity - ?, updated_at = NOW()
                    WHERE id = ?
                ", [$product['quantity'], $product['id']]);
            }
            
            // Insert activity log
            $db->insert("
                INSERT INTO activity_logs (user_id, action, description, created_at)
                VALUES (?, 'sale_created', ?, NOW())
            ", [$currentUserId, "Yeni satış yaradıldı: {$saleNumber}"]);
            
            $db->commit();
            
            $_SESSION['success_message'] = "Satış uğurla tamamlandı! Satış nömrəsi: " . $saleNumber;
            header('Location: ?page=sales&action=receipt&id=' . $saleId);
            exit;
            
        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Satış xətası: " . $e->getMessage();
    }
}

// Delete sale (only admin)
if ($action === 'delete' && $id > 0 && $currentUserRole === 'admin') {
    try {
        $db = Database::getInstance();
        
        // Get sale details for stock restoration
        $saleDetails = $db->selectAll("SELECT product_id, quantity FROM sale_details WHERE sale_id = ?", [$id]);
        
        $db->beginTransaction();
        
        try {
            // Restore stock
            foreach ($saleDetails as $detail) {
                $db->update("
                    UPDATE products 
                    SET stock_quantity = stock_quantity + ?
                    WHERE id = ?
                ", [$detail['quantity'], $detail['product_id']]);
            }
            
            // Delete sale details
            $db->delete("DELETE FROM sale_details WHERE sale_id = ?", [$id]);
            
            // Delete sale
            $db->delete("DELETE FROM sales WHERE id = ?", [$id]);
            
            $db->commit();
            
            $_SESSION['success_message'] = "Satış uğurla silindi və stok bərpa edildi!";
            
        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Satış silinə bilmədi: " . $e->getMessage();
    }
    
    header('Location: ?page=sales');
    exit;
}

// Get sales for listing
try {
    $db = Database::getInstance();
    
    $search = $_GET['search'] ?? '';
    $dateFrom = $_GET['date_from'] ?? date('Y-m-d', strtotime('-7 days'));
    $dateTo = $_GET['date_to'] ?? date('Y-m-d');
    $sellerId = $_GET['seller'] ?? '';
    $paymentMethod = $_GET['payment_method'] ?? '';
    $status = $_GET['status'] ?? '';
    
    $sql = "SELECT s.*, u.full_name as seller_name
            FROM sales s
            LEFT JOIN users u ON s.user_id = u.id
            WHERE DATE(s.created_at) BETWEEN ? AND ?";
    $params = [$dateFrom, $dateTo];
    
    if (!empty($search)) {
        $sql .= " AND (s.sale_number LIKE ? OR s.customer_name LIKE ? OR s.customer_phone LIKE ?)";
        $searchTerm = "%{$search}%";
        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
    }
    
    if (!empty($sellerId)) {
        $sql .= " AND s.user_id = ?";
        $params[] = $sellerId;
    } elseif ($currentUserRole === 'seller') {
        $sql .= " AND s.user_id = ?";
        $params[] = $currentUserId;
    }
    
    if (!empty($paymentMethod)) {
        $sql .= " AND s.payment_method = ?";
        $params[] = $paymentMethod;
    }
    
    if (!empty($status)) {
        $sql .= " AND s.status = ?";
        $params[] = $status;
    }
    
    $sql .= " ORDER BY s.created_at DESC";
    $sales = $db->selectAll($sql, $params);
    
    // Get sellers for filter
    $sellers = $db->selectAll("SELECT id, full_name FROM users WHERE is_active = 1 ORDER BY full_name");
    
    // Calculate totals
    $totalAmount = array_sum(array_column($sales, 'final_amount'));
    $totalCount = count($sales);
    $totalDiscount = array_sum(array_column($sales, 'discount_amount'));
    $totalTax = array_sum(array_column($sales, 'tax_amount'));
    
} catch (Exception $e) {
    $sales = [];
    $sellers = [];
    $totalAmount = 0;
    $totalCount = 0;
    $totalDiscount = 0;
    $totalTax = 0;
}

// Receipt view
if ($action === 'receipt' && $id > 0) {
    try {
        $db = Database::getInstance();
        
        $sale = $db->selectOne("
            SELECT s.*, u.full_name as seller_name
            FROM sales s
            LEFT JOIN users u ON s.user_id = u.id
            WHERE s.id = ?
        ", [$id]);
        
        if (!$sale) {
            $_SESSION['error_message'] = "Satış tapılmadı!";
            header('Location: ?page=sales');
            exit;
        }
        
        $saleDetails = $db->selectAll("
            SELECT sd.*, p.name as product_name, p.brand, p.size
            FROM sale_details sd
            LEFT JOIN products p ON sd.product_id = p.id
            WHERE sd.sale_id = ?
        ", [$id]);
        
        $pageTitle = "Qəbz - " . $sale['sale_number'];
        include 'includes/header.php';
        ?>
        
        <style>
        .receipt-container {
            max-width: 400px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: var(--box-shadow);
            overflow: hidden;
        }
        
        .receipt-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .receipt-content {
            padding: 30px;
        }
        
        .receipt-section {
            margin-bottom: 25px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e9ecef;
        }
        
        .receipt-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }
        
        .receipt-table {
            width: 100%;
            margin-bottom: 20px;
        }
        
        .receipt-table td {
            padding: 8px 0;
            vertical-align: top;
        }
        
        .receipt-total {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }
        
        @media print {
            body * {
                visibility: hidden;
            }
            
            .receipt-container,
            .receipt-container * {
                visibility: visible;
            }
            
            .receipt-container {
                position: absolute;
                left: 0;
                top: 0;
                max-width: none;
                width: 100%;
                box-shadow: none;
                border-radius: 0;
            }
            
            .no-print {
                display: none !important;
            }
        }
        </style>
        
        <div class="receipt-container">
            <div class="receipt-header">
                <h2><?= PWA_NAME ?></h2>
                <p>Kodaz.az Professional POS System</p>
                <div style="margin-top: 15px; font-size: 1.1rem;">
                    <strong>SATIŞ QƏBZİ</strong>
                </div>
            </div>
            
            <div class="receipt-content">
                <!-- Sale Info -->
                <div class="receipt-section">
                    <table class="receipt-table">
                        <tr>
                            <td><strong>Satış №:</strong></td>
                            <td style="text-align: right;"><?= htmlspecialchars($sale['sale_number']) ?></td>
                        </tr>
                        <tr>
                            <td><strong>Tarix:</strong></td>
                            <td style="text-align: right;"><?= date('d.m.Y H:i', strtotime($sale['created_at'])) ?></td>
                        </tr>
                        <tr>
                            <td><strong>Satışçı:</strong></td>
                            <td style="text-align: right;"><?= htmlspecialchars($sale['seller_name']) ?></td>
                        </tr>
                        <?php if ($sale['customer_name']): ?>
                        <tr>
                            <td><strong>Müştəri:</strong></td>
                            <td style="text-align: right;"><?= htmlspecialchars($sale['customer_name']) ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php if ($sale['customer_phone']): ?>
                        <tr>
                            <td><strong>Telefon:</strong></td>
                            <td style="text-align: right;"><?= htmlspecialchars($sale['customer_phone']) ?></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td><strong>Ödəniş:</strong></td>
                            <td style="text-align: right;">
                                <?php
                                $paymentLabels = [
                                    'cash' => '💵 Nağd',
                                    'card' => '💳 Kart',
                                    'transfer' => '🏦 Köçürmə'
                                ];
                                echo $paymentLabels[$sale['payment_method']] ?? $sale['payment_method'];
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Products -->
                <div class="receipt-section">
                    <h5 style="margin-bottom: 15px;">MƏHSULLAR</h5>
                    <?php foreach ($saleDetails as $detail): ?>
                        <div style="margin-bottom: 12px;">
                            <div style="display: flex; justify-content: space-between; font-weight: bold;">
                                <span><?= htmlspecialchars($detail['product_name']) ?></span>
                                <span>₼<?= number_format($detail['total_price'], 2) ?></span>
                            </div>
                            <div style="display: flex; justify-content: space-between; font-size: 0.9rem; color: #6c757d;">
                                <span>
                                    <?= htmlspecialchars($detail['brand']) ?>
                                    <?= $detail['size'] ? ' - ' . htmlspecialchars($detail['size']) : '' ?>
                                </span>
                                <span><?= $detail['quantity'] ?> x ₼<?= number_format($detail['unit_price'], 2) ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Totals -->
                <div class="receipt-section">
                    <table class="receipt-table">
                        <tr>
                            <td>Ara Cəmi:</td>
                            <td style="text-align: right;">₼<?= number_format($sale['subtotal'], 2) ?></td>
                        </tr>
                        <?php if ($sale['discount_amount'] > 0): ?>
                        <tr style="color: var(--danger-color);">
                            <td>Endirim:</td>
                            <td style="text-align: right;">-₼<?= number_format($sale['discount_amount'], 2) ?></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td>KDV (18%):</td>
                            <td style="text-align: right;">₼<?= number_format($sale['tax_amount'], 2) ?></td>
                        </tr>
                    </table>
                    
                    <div class="receipt-total">
                        <div style="display: flex; justify-content: space-between; font-size: 1.3rem; font-weight: bold;">
                            <span>CƏMİ:</span>
                            <span>₼<?= number_format($sale['final_amount'], 2) ?></span>
                        </div>
                    </div>
                </div>
                
                <?php if ($sale['notes']): ?>
                <div class="receipt-section">
                    <h6>Qeydlər:</h6>
                    <p style="font-style: italic; color: #6c757d;"><?= nl2br(htmlspecialchars($sale['notes'])) ?></p>
                </div>
                <?php endif; ?>
                
                <!-- Footer -->
                <div style="text-align: center; margin-top: 30px; color: #6c757d;">
                    <p><strong>Təşəkkür edirik!</strong></p>
                    <p style="font-size: 0.9rem;">Kodaz.az &copy; <?= date('Y') ?></p>
                    <p style="font-size: 0.8rem;">Professional POS System</p>
                </div>
            </div>
        </div>
        
        <div class="no-print" style="text-align: center; margin: 30px 0;">
            <button onclick="window.print()" class="btn btn-primary">
                <i class="fas fa-print"></i> Çap Et
            </button>
            <a href="?page=sales" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Satışlara Qayıt
            </a>
            <button onclick="shareReceipt()" class="btn btn-info">
                <i class="fas fa-share"></i> Paylaş
            </button>
        </div>
        
        <script>
        function shareReceipt() {
            if (navigator.share) {
                navigator.share({
                    title: 'Satış Qəbzi - <?= $sale['sale_number'] ?>',
                    text: 'Satış qəbzi: ₼<?= number_format($sale['final_amount'], 2) ?>',
                    url: window.location.href
                });
            } else {
                // Fallback - copy to clipboard
                navigator.clipboard.writeText(window.location.href).then(() => {
                    alert('Link panoya kopyalandı!');
                });
            }
        }
        </script>
        
        <?php
        include 'includes/footer.php';
        return;
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Qəbz yüklənə bilmədi: " . $e->getMessage();
        header('Location: ?page=sales');
        exit;
    }
}

// POS interface
if ($action === 'new' || $action === 'pos') {
    try {
        $db = Database::getInstance();
        
        // Get products for POS
        $products = $db->selectAll("
            SELECT id, name, brand, price, stock_quantity, size, category
            FROM products 
            WHERE is_active = 1 AND stock_quantity > 0 
            ORDER BY name
        ");
        
        // Get categories for filter
        $categories = $db->selectAll("
            SELECT DISTINCT category 
            FROM products 
            WHERE is_active = 1 AND category IS NOT NULL AND category != ''
            ORDER BY category
        ");
        
    } catch (Exception $e) {
        $products = [];
        $categories = [];
    }
    
    $pageTitle = "POS Sistemi - " . PWA_NAME;
    include 'includes/header.php';
    ?>
    
    <style>
    .pos-container {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 25px;
        height: calc(100vh - 150px);
        min-height: 600px;
    }
    
    .pos-products {
        background: white;
        border-radius: 15px;
        box-shadow: var(--box-shadow);
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }
    
    .pos-cart {
        background: white;
        border-radius: 15px;
        box-shadow: var(--box-shadow);
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }
    
    .pos-header {
        padding: 20px 25px;
        border-bottom: 1px solid #e9ecef;
        background: #f8f9fa;
    }
    
    .pos-search {
        display: flex;
        gap: 15px;
        align-items: center;
        margin-bottom: 15px;
    }
    
    .search-input {
        flex: 1;
        padding: 12px 16px;
        border: 2px solid #e9ecef;
        border-radius: 25px;
        font-size: 0.9rem;
        transition: var(--transition);
    }
    
    .search-input:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
    }
    
    .category-filter {
        padding: 8px 15px;
        border: 2px solid #e9ecef;
        border-radius: 20px;
        background: white;
        cursor: pointer;
        transition: var(--transition);
    }
    
    .category-filter:focus {
        outline: none;
        border-color: var(--primary-color);
    }
    
    .products-grid {
        flex: 1;
        padding: 20px;
        overflow-y: auto;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 15px;
        align-content: start;
    }
    
    .product-card {
        border: 2px solid #e9ecef;
        border-radius: 12px;
        padding: 15px;
        text-align: center;
        cursor: pointer;
        transition: var(--transition);
        background: white;
        position: relative;
    }
    
    .product-card:hover {
        border-color: var(--primary-color);
        background: linear-gradient(135deg, rgba(102, 126, 234, 0.05), rgba(118, 75, 162, 0.05));
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .product-card.selected {
        border-color: var(--primary-color);
        background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
    }
    
    .product-emoji {
        font-size: 2.5rem;
        margin-bottom: 10px;
        display: block;
    }
    
    .product-name {
        font-weight: bold;
        margin-bottom: 5px;
        font-size: 0.95rem;
        line-height: 1.3;
    }
    
    .product-brand {
        color: #6c757d;
        font-size: 0.8rem;
        margin-bottom: 8px;
    }
    
    .product-price {
        color: var(--primary-color);
        font-weight: bold;
        font-size: 1.1rem;
        margin-bottom: 5px;
    }
    
    .product-stock {
        color: #6c757d;
        font-size: 0.75rem;
    }
    
    .cart-header {
        padding: 20px 25px;
        border-bottom: 1px solid #e9ecef;
        background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        color: white;
    }
    
    .cart-items {
        flex: 1;
        padding: 20px;
        overflow-y: auto;
    }
    
    .cart-item {
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 15px 0;
        border-bottom: 1px solid #f0f0f0;
    }
    
    .cart-item:last-child {
        border-bottom: none;
    }
    
    .cart-item-info {
        flex: 1;
        min-width: 0;
    }
    
    .cart-item-name {
        font-weight: bold;
        font-size: 0.9rem;
        margin-bottom: 3px;
    }
    
    .cart-item-brand {
        color: #6c757d;
        font-size: 0.8rem;
    }
    
    .cart-item-controls {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .qty-btn {
        width: 32px;
        height: 32px;
        border: 1px solid #e9ecef;
        border-radius: 6px;
        background: white;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: var(--transition);
    }
    
    .qty-btn:hover {
        background: var(--primary-color);
        color: white;
        border-color: var(--primary-color);
    }
    
    .qty-input {
        width: 50px;
        text-align: center;
        border: 1px solid #e9ecef;
        border-radius: 6px;
        padding: 6px;
        font-weight: bold;
    }
    
    .remove-btn {
        background: var(--danger-color);
        color: white;
        border: none;
        width: 32px;
        height: 32px;
        border-radius: 6px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .cart-footer {
        padding: 20px;
        border-top: 1px solid #e9ecef;
        background: #f8f9fa;
    }
    
    .cart-totals {
        margin-bottom: 20px;
    }
    
    .total-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
    }
    
    .total-row.final {
        border-top: 2px solid #e9ecef;
        padding-top: 12px;
        margin-top: 12px;
        font-weight: bold;
        font-size: 1.2rem;
        color: var(--success-color);
    }
    
    .customer-info {
        margin-bottom: 15px;
    }
    
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
        margin-bottom: 10px;
    }
    
    .empty-cart {
        text-align: center;
        padding: 40px 20px;
        color: #6c757d;
    }
    
    .empty-cart-icon {
        font-size: 3rem;
        margin-bottom: 15px;
        opacity: 0.3;
    }
    
    .checkout-btn {
        width: 100%;
        padding: 15px;
        background: linear-gradient(135deg, var(--success-color), #20c997);
        color: white;
        border: none;
        border-radius: 10px;
        font-size: 1.1rem;
        font-weight: bold;
        cursor: pointer;
        transition: var(--transition);
    }
    
    .checkout-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(40, 167, 69, 0.3);
    }
    
    .checkout-btn:disabled {
        background: #6c757d;
        cursor: not-allowed;
        transform: none;
        box-shadow: none;
    }
    
    @media (max-width: 1024px) {
        .pos-container {
            grid-template-columns: 1fr;
            height: auto;
        }
        
        .pos-cart {
            order: -1;
            height: 400px;
        }
    }
    
    @media (max-width: 768px) {
        .products-grid {
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
        }
        
        .form-row {
            grid-template-columns: 1fr;
        }
        
        .pos-search {
            flex-direction: column;
            align-items: stretch;
        }
    }
    </style>
    
    <div style="margin-bottom: 20px;">
        <h2 style="color: var(--dark-color); margin-bottom: 5px;">
            🛒 POS Sistemi
        </h2>
        <p style="color: #6c757d;">
            Məhsulları seçin və satış əməliyyatını tamamlayın
        </p>
    </div>
    
    <div class="pos-container">
        <!-- Products Panel -->
        <div class="pos-products">
            <div class="pos-header">
                <h4 style="margin-bottom: 15px;">📦 Məhsul Kataloqu</h4>
                
                <div class="pos-search">
                    <input type="text" id="product-search" class="search-input" placeholder="🔍 Məhsul, brand və ya barkod axtar...">
                    
                    <select id="category-filter" class="category-filter">
                        <option value="">Bütün kateqoriyalar</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= htmlspecialchars($category['category']) ?>">
                                <?= htmlspecialchars($category['category']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div style="display: flex; justify-content: space-between; align-items: center; font-size: 0.9rem; color: #6c757d;">
                    <span>Mövcud: <strong id="product-count"><?= count($products) ?></strong> məhsul</span>
                    <button onclick="clearSearch()" class="btn btn-sm btn-secondary">
                        <i class="fas fa-times"></i> Təmizlə
                    </button>
                </div>
            </div>
            
            <?php if (empty($products)): ?>
                <div style="flex: 1; display: flex; align-items: center; justify-content: center; flex-direction: column; color: #6c757d;">
                    <i class="fas fa-box-open" style="font-size: 4rem; margin-bottom: 20px; opacity: 0.3;"></i>
                    <h4>Satış üçün məhsul yoxdur</h4>
                    <p>Məhsul əlavə etmək üçün inventar bölməsinə keçin</p>
                    <a href="?page=products&action=add" class="btn btn-primary" style="margin-top: 15px;">
                        📦 Məhsul Əlavə Et
                    </a>
                </div>
            <?php else: ?>
                <div class="products-grid" id="products-grid">
                    <?php foreach ($products as $product): ?>
                        <div class="product-card" onclick="addToCart(<?= htmlspecialchars(json_encode($product)) ?>)" data-category="<?= htmlspecialchars($product['category'] ?? '') ?>">
                            <span class="product-emoji">
                                <?php
                                // Product emoji based on category or name
                                $name = strtolower($product['name']);
                                $category = strtolower($product['category'] ?? '');
                                
                                if (strpos($category, 'kişi') !== false || strpos($name, 'men') !== false) echo '👨';
                                elseif (strpos($category, 'qadın') !== false || strpos($name, 'women') !== false) echo '👩';
                                elseif (strpos($category, 'deodorant') !== false || strpos($name, 'deo') !== false) echo '🧴';
                                elseif (strpos($category, 'yağ') !== false || strpos($name, 'oil') !== false) echo '🫗';
                                else echo '🧴';
                                ?>
                            </span>
                            
                            <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
                            <div class="product-brand"><?= htmlspecialchars($product['brand']) ?></div>
                            <?php if ($product['size']): ?>
                                <div style="font-size: 0.75rem; color: #adb5bd; margin-bottom: 5px;">
                                    <?= htmlspecialchars($product['size']) ?>
                                </div>
                            <?php endif; ?>
                            <div class="product-price">₼<?= number_format($product['price'], 2) ?></div>
                            <div class="product-stock">Stok: <?= $product['stock_quantity'] ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Cart Panel -->
        <div class="pos-cart">
            <div class="cart-header">
                <h4 style="margin: 0;">🛒 Satış Səbəti</h4>
                <div style="font-size: 0.9rem; opacity: 0.9; margin-top: 5px;">
                    <span id="cart-count">0</span> məhsul
                </div>
            </div>
            
            <div class="cart-items" id="cart-items">
                <div class="empty-cart">
                    <div class="empty-cart-icon">🛒</div>
                    <h5>Səbət boşdur</h5>
                    <p>Məhsul əlavə etmək üçün sol tərəfdən seçin</p>
                </div>
            </div>
            
            <div class="cart-footer">
                <!-- Cart Totals -->
                <div class="cart-totals" id="cart-totals" style="display: none;">
                    <div class="total-row">
                        <span>Ara cəmi:</span>
                        <span id="subtotal">₼0.00</span>
                    </div>
                    
                    <div class="total-row">
                        <span>Endirim:</span>
                        <span id="discount-amount" style="color: var(--danger-color);">₼0.00</span>
                    </div>
                    
                    <div class="total-row">
                        <span>KDV (18%):</span>
                        <span id="tax-amount">₼0.00</span>
                    </div>
                    
                    <div class="total-row final">
                        <span>CƏMİ:</span>
                        <span id="final-total">₼0.00</span>
                    </div>
                </div>
                
                <!-- Customer Info -->
                <div class="customer-info">
                    <div class="form-row">
                        <input type="text" id="customer-name" placeholder="Müştəri adı (ixtiyari)" class="form-control">
                        <input type="tel" id="customer-phone" placeholder="Telefon" class="form-control">
                    </div>
                    
                    <div class="form-row">
                        <input type="email" id="customer-email" placeholder="Email (ixtiyari)" class="form-control">
                        <select id="payment-method" class="form-control">
                            <option value="cash">💵 Nağd</option>
                            <option value="card">💳 Kart</option>
                            <option value="transfer">🏦 Köçürmə</option>
                        </select>
                    </div>
                    
                    <div class="form-row">
                        <input type="number" id="discount" placeholder="Endirim məbləği" class="form-control" min="0" step="0.01">
                        <select id="discount-type" class="form-control">
                            <option value="amount">Məbləğ (₼)</option>
                            <option value="percentage">Faiz (%)</option>
                        </select>
                    </div>
                    
                    <textarea id="notes" placeholder="Qeydlər (ixtiyari)" class="form-control" rows="2" style="margin-top: 10px;"></textarea>
                </div>
                
                <!-- Action Buttons -->
                <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 10px;">
                    <button onclick="clearCart()" class="btn btn-secondary">
                        <i class="fas fa-trash"></i> Təmizlə
                    </button>
                    
                    <button onclick="checkout()" class="checkout-btn" id="checkout-btn" disabled>
                        <i class="fas fa-check"></i> Satış Tamamla
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    let cart = [];
    let isProcessing = false;
    
    // Add product to cart
    function addToCart(product) {
        if (isProcessing) return;
        
        const existingItem = cart.find(item => item.id === product.id);
        
        if (existingItem) {
            if (existingItem.quantity < product.stock_quantity) {
                existingItem.quantity += 1;
                updateCartDisplay();
                showToast('success', `${product.name} miqdarı artırıldı`);
            } else {
                showToast('warning', 'Kifayət qədər stok yoxdur');
            }
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                brand: product.brand,
                price: parseFloat(product.price),
                quantity: 1,
                stock: product.stock_quantity,
                size: product.size || ''
            });
            updateCartDisplay();
            showToast('success', `${product.name} səbətə əlavə edildi`);
        }
        
        // Highlight selected product
        document.querySelectorAll('.product-card').forEach(card => {
            card.classList.remove('selected');
        });
        event.currentTarget.classList.add('selected');
        
        setTimeout(() => {
            event.currentTarget.classList.remove('selected');
        }, 500);
    }
    
    // Update cart display
    function updateCartDisplay() {
        const cartContainer = document.getElementById('cart-items');
        const cartTotals = document.getElementById('cart-totals');
        const cartCount = document.getElementById('cart-count');
        const checkoutBtn = document.getElementById('checkout-btn');
        
        cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
        
        if (cart.length === 0) {
            cartContainer.innerHTML = `
                <div class="empty-cart">
                    <div class="empty-cart-icon">🛒</div>
                    <h5>Səbət boşdur</h5>
                    <p>Məhsul əlavə etmək üçün sol tərəfdən seçin</p>
                </div>
            `;
            cartTotals.style.display = 'none';
            checkoutBtn.disabled = true;
        } else {
            cartContainer.innerHTML = cart.map(item => `
                <div class="cart-item">
                    <div class="cart-item-info">
                        <div class="cart-item-name">${item.name}</div>
                        <div class="cart-item-brand">${item.brand} ${item.size ? '- ' + item.size : ''}</div>
                        <div style="font-size: 0.8rem; color: var(--success-color); font-weight: bold;">
                            ₼${item.price.toFixed(2)} × ${item.quantity} = ₼${(item.price * item.quantity).toFixed(2)}
                        </div>
                    </div>
                    
                    <div class="cart-item-controls">
                        <button class="qty-btn" onclick="updateQuantity(${item.id}, -1)">
                            <i class="fas fa-minus"></i>
                        </button>
                        
                        <input type="number" class="qty-input" value="${item.quantity}" 
                               onchange="setQuantity(${item.id}, this.value)" min="1" max="${item.stock}">
                        
                        <button class="qty-btn" onclick="updateQuantity(${item.id}, 1)">
                            <i class="fas fa-plus"></i>
                        </button>
                        
                        <button class="remove-btn" onclick="removeFromCart(${item.id})" title="Sil">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `).join('');
            
            cartTotals.style.display = 'block';
            checkoutBtn.disabled = false;
            updateTotals();
        }
    }
    
    // Update quantity
    function updateQuantity(productId, change) {
        const item = cart.find(item => item.id === productId);
        if (item) {
            const newQuantity = item.quantity + change;
            
            if (newQuantity <= 0) {
                removeFromCart(productId);
            } else if (newQuantity <= item.stock) {
                item.quantity = newQuantity;
                updateCartDisplay();
            } else {
                showToast('warning', 'Kifayət qədər stok yoxdur');
            }
        }
    }
    
    // Set quantity directly
    function setQuantity(productId, quantity) {
        const item = cart.find(item => item.id === productId);
        if (item) {
            const qty = parseInt(quantity) || 1;
            
            if (qty <= 0) {
                removeFromCart(productId);
            } else if (qty <= item.stock) {
                item.quantity = qty;
                updateCartDisplay();
            } else {
                showToast('warning', `Maksimum ${item.stock} ədəd mövcuddur`);
                updateCartDisplay(); // Reset to previous value
            }
        }
    }
    
    // Remove from cart
    function removeFromCart(productId) {
        cart = cart.filter(item => item.id !== productId);
        updateCartDisplay();
        showToast('info', 'Məhsul səbətdən silindi');
    }
    
    // Clear cart
    function clearCart() {
        if (cart.length > 0 && confirm('Səbəti təmizləmək istədiyinizə əminsiniz?')) {
            cart = [];
            updateCartDisplay();
            showToast('info', 'Səbət təmizləndi');
        }
    }
    
    // Update totals
    function updateTotals() {
        const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        
        const discount = parseFloat(document.getElementById('discount').value) || 0;
        const discountType = document.getElementById('discount-type').value;
        
        let discountAmount = 0;
        if (discount > 0) {
            if (discountType === 'percentage') {
                discountAmount = (subtotal * discount) / 100;
            } else {
                discountAmount = discount;
            }
        }
        
        const afterDiscount = subtotal - discountAmount;
        const taxAmount = afterDiscount * 0.18; // 18% VAT
        const finalTotal = afterDiscount + taxAmount;
        
        document.getElementById('subtotal').textContent = `₼${subtotal.toFixed(2)}`;
        document.getElementById('discount-amount').textContent = `-₼${discountAmount.toFixed(2)}`;
        document.getElementById('tax-amount').textContent = `₼${taxAmount.toFixed(2)}`;
        document.getElementById('final-total').textContent = `₼${finalTotal.toFixed(2)}`;
    }
    
    // Checkout
    function checkout() {
        if (isProcessing || cart.length === 0) return;
        
        const customerName = document.getElementById('customer-name').value.trim();
        const customerPhone = document.getElementById('customer-phone').value.trim();
        const customerEmail = document.getElementById('customer-email').value.trim();
        const paymentMethod = document.getElementById('payment-method').value;
        const notes = document.getElementById('notes').value.trim();
        const discount = parseFloat(document.getElementById('discount').value) || 0;
        const discountType = document.getElementById('discount-type').value;
        
        // Validation
        if (!paymentMethod) {
            showToast('error', 'Ödəniş metodunu seçin');
            return;
        }
        
        if (customerEmail && !isValidEmail(customerEmail)) {
            showToast('error', 'Düzgün email ünvanı daxil edin');
            return;
        }
        
        isProcessing = true;
        const checkoutBtn = document.getElementById('checkout-btn');
        const originalText = checkoutBtn.innerHTML;
        
        checkoutBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Emal edilir...';
        checkoutBtn.disabled = true;
        
        // Create form and submit
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '?page=sales&action=add_sale';
        
        form.innerHTML = `
            <input type="hidden" name="customer_name" value="${customerName}">
            <input type="hidden" name="customer_phone" value="${customerPhone}">
            <input type="hidden" name="customer_email" value="${customerEmail}">
            <input type="hidden" name="payment_method" value="${paymentMethod}">
            <input type="hidden" name="notes" value="${notes}">
            <input type="hidden" name="discount" value="${discount}">
            <input type="hidden" name="discount_type" value="${discountType}">
            <input type="hidden" name="products" value='${JSON.stringify(cart)}'>
        `;
        
        document.body.appendChild(form);
        form.submit();
    }
    
    // Search and filter functions
    function setupSearch() {
        const searchInput = document.getElementById('product-search');
        const categoryFilter = document.getElementById('category-filter');
        
        searchInput.addEventListener('input', filterProducts);
        categoryFilter.addEventListener('change', filterProducts);
        
        // Discount input listener
        document.getElementById('discount').addEventListener('input', updateTotals);
        document.getElementById('discount-type').addEventListener('change', updateTotals);
    }
    
    function filterProducts() {
        const searchTerm = document.getElementById('product-search').value.toLowerCase();
        const selectedCategory = document.getElementById('category-filter').value;
        const productCards = document.querySelectorAll('.product-card');
        let visibleCount = 0;
        
        productCards.forEach(card => {
            const productName = card.querySelector('.product-name').textContent.toLowerCase();
            const productBrand = card.querySelector('.product-brand').textContent.toLowerCase();
            const productCategory = card.dataset.category || '';
            
            const matchesSearch = productName.includes(searchTerm) || productBrand.includes(searchTerm);
            const matchesCategory = !selectedCategory || productCategory === selectedCategory;
            
            if (matchesSearch && matchesCategory) {
                card.style.display = 'block';
                visibleCount++;
            } else {
                card.style.display = 'none';
            }
        });
        
        document.getElementById('product-count').textContent = visibleCount;
    }
    
    function clearSearch() {
        document.getElementById('product-search').value = '';
        document.getElementById('category-filter').value = '';
        filterProducts();
    }
    
    // Utility functions
    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
    
    function showToast(type, message) {
        const toast = document.createElement('div');
        toast.className = `alert alert-${type}`;
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 2000;
            min-width: 300px;
            animation: slideIn 0.3s ease;
        `;
        
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        
        toast.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="fas fa-${icons[type]}"></i>
                <span>${message}</span>
                <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; font-size: 1.2rem; cursor: pointer; margin-left: auto;">×</button>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 4000);
    }
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // F1 - Clear cart
        if (e.key === 'F1') {
            e.preventDefault();
            clearCart();
        }
        
        // F2 - Focus search
        if (e.key === 'F2') {
            e.preventDefault();
            document.getElementById('product-search').focus();
        }
        
        // F3 - Checkout
        if (e.key === 'F3') {
            e.preventDefault();
            if (cart.length > 0) checkout();
        }
        
        // Enter in customer name field - focus phone
        if (e.key === 'Enter' && e.target.id === 'customer-name') {
            e.preventDefault();
            document.getElementById('customer-phone').focus();
        }
        
        // Enter in customer phone field - checkout
        if (e.key === 'Enter' && e.target.id === 'customer-phone') {
            e.preventDefault();
            if (cart.length > 0) checkout();
        }
    });
    
    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        setupSearch();
        updateCartDisplay();
        
        // Show keyboard shortcuts
        console.log('Klaviatur qısayolları:');
        console.log('F1 - Səbəti təmizlə');
        console.log('F2 - Axtarış sahəsinə fokus');
        console.log('F3 - Satış tamamla');
    });
    
    // Auto-save cart to localStorage
    setInterval(() => {
        if (cart.length > 0) {
            localStorage.setItem('pos_cart', JSON.stringify(cart));
        } else {
            localStorage.removeItem('pos_cart');
        }
    }, 5000);
    
    // Restore cart from localStorage
    window.addEventListener('load', () => {
        const savedCart = localStorage.getItem('pos_cart');
        if (savedCart) {
            try {
                cart = JSON.parse(savedCart);
                updateCartDisplay();
            } catch (e) {
                console.warn('Saved cart data is corrupted');
                localStorage.removeItem('pos_cart');
            }
        }
    });
    </script>
    
    <?php
    include 'includes/footer.php';
    return;
}

$pageTitle = "Satışlar - " . PWA_NAME;
include 'includes/header.php';
?>

<!-- Sales List View -->
<div style="margin-bottom: 25px;">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
        <div>
            <h2 style="color: var(--dark-color); margin-bottom: 5px;">📋 Satış İdarəetməsi</h2>
            <p style="color: #6c757d;">Satış tarixçəsi və analitika</p>
        </div>
        
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <a href="?page=sales&action=new" class="btn btn-primary">
                <i class="fas fa-plus"></i> Yeni Satış
            </a>
            <a href="?page=reports&type=sales" class="btn btn-info">
                <i class="fas fa-chart-bar"></i> Hesabat
            </a>
        </div>
    </div>
</div>

<!-- Statistics Cards -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 30px;">
    <div style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; padding: 25px; border-radius: 15px; text-align: center;">
        <div style="font-size: 1.8rem; margin-bottom: 8px;">💰</div>
        <div style="font-size: 2rem; font-weight: bold; margin-bottom: 5px;">₼<?= number_format($totalAmount, 2) ?></div>
        <div style="opacity: 0.9;">Cəmi Satış Məbləği</div>
    </div>
    
    <div style="background: linear-gradient(135deg, var(--success-color), #20c997); color: white; padding: 25px; border-radius: 15px; text-align: center;">
        <div style="font-size: 1.8rem; margin-bottom: 8px;">📊</div>
        <div style="font-size: 2rem; font-weight: bold; margin-bottom: 5px;"><?= $totalCount ?></div>
        <div style="opacity: 0.9;">Satış Sayı</div>
    </div>
    
    <div style="background: linear-gradient(135deg, var(--info-color), #138496); color: white; padding: 25px; border-radius: 15px; text-align: center;">
        <div style="font-size: 1.8rem; margin-bottom: 8px;">📈</div>
        <div style="font-size: 2rem; font-weight: bold; margin-bottom: 5px;">₼<?= $totalCount > 0 ? number_format($totalAmount / $totalCount, 2) : '0.00' ?></div>
        <div style="opacity: 0.9;">Orta Satış</div>
    </div>
    
    <div style="background: linear-gradient(135deg, var(--warning-color), #ffb300); color: white; padding: 25px; border-radius: 15px; text-align: center;">
        <div style="font-size: 1.8rem; margin-bottom: 8px;">🎯</div>
        <div style="font-size: 2rem; font-weight: bold; margin-bottom: 5px;">₼<?= number_format($totalDiscount, 2) ?></div>
        <div style="opacity: 0.9;">Cəmi Endirim</div>
    </div>
</div>

<!-- Filters -->
<div class="content-box">
    <h4 style="margin-bottom: 20px;">🔍 Filterlər və Axtarış</h4>
    
    <form method="GET">
        <input type="hidden" name="page" value="sales">
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
            <div class="form-group" style="margin-bottom: 0;">
                <label>Axtarış:</label>
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Satış №, müştəri adı və ya telefon" class="form-control">
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label>Başlanğıc Tarix:</label>
                <input type="date" name="date_from" value="<?= htmlspecialchars($dateFrom) ?>" class="form-control">
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label>Bitmə Tarix:</label>
                <input type="date" name="date_to" value="<?= htmlspecialchars($dateTo) ?>" class="form-control">
            </div>
            
            <?php if ($currentUserRole !== 'seller'): ?>
            <div class="form-group" style="margin-bottom: 0;">
                <label>Satışçı:</label>
                <select name="seller" class="form-control">
                    <option value="">Hamısı</option>
                    <?php foreach ($sellers as $seller): ?>
                        <option value="<?= $seller['id'] ?>" <?= $sellerId == $seller['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($seller['full_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label>Ödəniş Metodu:</label>
                <select name="payment_method" class="form-control">
                    <option value="">Hamısı</option>
                    <option value="cash" <?= $paymentMethod === 'cash' ? 'selected' : '' ?>>💵 Nağd</option>
                    <option value="card" <?= $paymentMethod === 'card' ? 'selected' : '' ?>>💳 Kart</option>
                    <option value="transfer" <?= $paymentMethod === 'transfer' ? 'selected' : '' ?>>🏦 Köçürmə</option>
                </select>
            </div>
            
            <button type="submit" class="btn btn-primary" style="height: 47px;">
                <i class="fas fa-search"></i> Filtrələ
            </button>
        </div>
    </form>
</div>

<!-- Sales List -->
<div class="content-box">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; flex-wrap: wrap; gap: 15px;">
        <h4>📋 Satış Siyahısı (<?= count($sales) ?>)</h4>
        
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <button onclick="exportSales()" class="btn btn-success btn-sm">
                <i class="fas fa-file-excel"></i> Excel
            </button>
            
            <button onclick="printSales()" class="btn btn-info btn-sm">
                <i class="fas fa-print"></i> Çap
            </button>
        </div>
    </div>
    
    <?php if (empty($sales)): ?>
        <div style="text-align: center; padding: 60px 20px; color: #6c757d;">
            <i class="fas fa-receipt" style="font-size: 4rem; margin-bottom: 20px; opacity: 0.3;"></i>
        

            <h4>Satış tapılmadı</h4>
            <p>Seçilmiş kriteriləra uyğun satış yoxdur və ya hələ satış edilməyib.</p>
            <a href="?page=sales&action=new" class="btn btn-primary" style="margin-top: 15px;">
                <i class="fas fa-plus"></i> İlk Satışı Et
            </a>
        </div>
    <?php else: ?>
        <div style="overflow-x: auto;">
            <table class="table">
                <thead>
                    <tr>
                        <th style="width: 120px;">Satış №</th>
                        <th>Tarix/Vaxt</th>
                        <?php if ($currentUserRole !== 'seller'): ?>
                            <th>Satışçı</th>
                        <?php endif; ?>
                        <th>Müştəri</th>
                        <th style="text-align: center;">Məhsul</th>
                        <th style="text-align: right;">Ara Cəmi</th>
                        <th style="text-align: right;">Endirim</th>
                        <th style="text-align: right;">Cəmi</th>
                        <th style="text-align: center;">Ödəniş</th>
                        <th style="text-align: center;">Status</th>
                        <th style="text-align: center;">Əməliyyat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sales as $sale): ?>
                        <tr style="<?= $sale['status'] === 'cancelled' ? 'opacity: 0.6;' : '' ?>">
                            <td>
                                <strong style="color: var(--primary-color);">
                                    <?= htmlspecialchars($sale['sale_number']) ?>
                                </strong>
                            </td>
                            <td>
                                <div style="font-weight: bold;">
                                    <?= date('d.m.Y', strtotime($sale['created_at'])) ?>
                                </div>
                                <small style="color: #6c757d;">
                                    <i class="fas fa-clock"></i> <?= date('H:i', strtotime($sale['created_at'])) ?>
                                </small>
                            </td>
                            <?php if ($currentUserRole !== 'seller'): ?>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 8px;">
                                        <div style="width: 30px; height: 30px; border-radius: 50%; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center; font-size: 0.8rem; font-weight: bold;">
                                            <?= strtoupper(substr($sale['seller_name'] ?? 'U', 0, 1)) ?>
                                        </div>
                                        <div>
                                            <div style="font-weight: bold; font-size: 0.9rem;">
                                                <?= htmlspecialchars($sale['seller_name'] ?? 'Naməlum') ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            <?php endif; ?>
                            <td>
                                <?php if ($sale['customer_name']): ?>
                                    <div style="font-weight: bold;">
                                        <i class="fas fa-user"></i> <?= htmlspecialchars($sale['customer_name']) ?>
                                    </div>
                                <?php else: ?>
                                    <em style="color: #6c757d;">Anonim müştəri</em>
                                <?php endif; ?>
                                
                                <?php if ($sale['customer_phone']): ?>
                                    <div style="font-size: 0.8rem; color: #6c757d; margin-top: 2px;">
                                        <i class="fas fa-phone"></i> <?= htmlspecialchars($sale['customer_phone']) ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($sale['customer_email']): ?>
                                    <div style="font-size: 0.8rem; color: #6c757d; margin-top: 2px;">
                                        <i class="fas fa-envelope"></i> <?= htmlspecialchars($sale['customer_email']) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <span class="badge badge-info" style="font-size: 0.8rem;">
                                    <?= $sale['total_items'] ?> ədəd
                                </span>
                            </td>
                            <td style="text-align: right;">
                                <strong>₼<?= number_format($sale['subtotal'], 2) ?></strong>
                            </td>
                            <td style="text-align: right;">
                                <?php if ($sale['discount_amount'] > 0): ?>
                                    <span style="color: var(--danger-color); font-weight: bold;">
                                        -₼<?= number_format($sale['discount_amount'], 2) ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: #6c757d;">-</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: right;">
                                <strong style="color: var(--success-color); font-size: 1.1rem;">
                                    ₼<?= number_format($sale['final_amount'], 2) ?>
                                </strong>
                                <?php if ($sale['tax_amount'] > 0): ?>
                                    <div style="font-size: 0.7rem; color: #6c757d;">
                                        KDV: ₼<?= number_format($sale['tax_amount'], 2) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <?php
                                $paymentLabels = [
                                    'cash' => ['💵', 'Nağd', 'success'],
                                    'card' => ['💳', 'Kart', 'info'],
                                    'transfer' => ['🏦', 'Köçürmə', 'warning']
                                ];
                                $payment = $paymentLabels[$sale['payment_method']] ?? ['💰', $sale['payment_method'], 'secondary'];
                                ?>
                                <span class="badge badge-<?= $payment[2] ?>" style="font-size: 0.75rem;">
                                    <?= $payment[0] ?> <?= $payment[1] ?>
                                </span>
                            </td>
                            <td style="text-align: center;">
                                <?php
                                $statusLabels = [
                                    'completed' => ['✅', 'Tamamlandı', 'success'],
                                    'pending' => ['⏳', 'Gözləyir', 'warning'],
                                    'cancelled' => ['❌', 'Ləğv edildi', 'danger']
                                ];
                                $status = $statusLabels[$sale['status']] ?? ['❓', $sale['status'], 'secondary'];
                                ?>
                                <span class="badge badge-<?= $status[2] ?>" style="font-size: 0.75rem;">
                                    <?= $status[0] ?> <?= $status[1] ?>
                                </span>
                            </td>
                            <td style="text-align: center;">
                                <div style="display: flex; flex-direction: column; gap: 5px;">
                                    <a href="?page=sales&action=receipt&id=<?= $sale['id'] ?>" 
                                       class="btn btn-primary btn-sm" style="padding: 4px 8px; font-size: 0.75rem;">
                                        <i class="fas fa-receipt"></i> Qəbz
                                    </a>
                                    
                                    <button onclick="viewSaleDetails(<?= $sale['id'] ?>)" 
                                            class="btn btn-info btn-sm" style="padding: 4px 8px; font-size: 0.75rem;">
                                        <i class="fas fa-eye"></i> Detallar
                                    </button>
                                    
                                    <?php if ($currentUserRole === 'admin' && $sale['status'] !== 'cancelled'): ?>
                                        <button onclick="deleteSale(<?= $sale['id'] ?>, '<?= htmlspecialchars($sale['sale_number']) ?>')" 
                                                class="btn btn-danger btn-sm" style="padding: 4px 8px; font-size: 0.75rem;">
                                            <i class="fas fa-trash"></i> Sil
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr style="background: linear-gradient(135deg, #f8f9fa, #e9ecef); font-weight: bold;">
                        <td colspan="<?= $currentUserRole !== 'seller' ? '5' : '4' ?>">
                            <strong>CƏMİ</strong>
                        </td>
                        <td style="text-align: center;">
                            <strong><?= array_sum(array_column($sales, 'total_items')) ?></strong>
                        </td>
                        <td style="text-align: right;">
                            <strong>₼<?= number_format(array_sum(array_column($sales, 'subtotal')), 2) ?></strong>
                        </td>
                        <td style="text-align: right;">
                            <strong style="color: var(--danger-color);">
                                -₼<?= number_format($totalDiscount, 2) ?>
                            </strong>
                        </td>
                        <td style="text-align: right;">
                            <strong style="color: var(--success-color); font-size: 1.2rem;">
                                ₼<?= number_format($totalAmount, 2) ?>
                            </strong>
                        </td>
                        <td colspan="3"></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        
        <!-- Summary Statistics -->
        <div style="margin-top: 25px; padding: 20px; background: linear-gradient(135deg, #f8f9fa, #e9ecef); border-radius: 12px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 20px; text-align: center;">
                <div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-color);">
                        <?= $totalCount ?>
                    </div>
                    <div style="font-size: 0.9rem; color: #6c757d;">Satış Sayı</div>
                </div>
                
                <div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--success-color);">
                        ₼<?= number_format($totalAmount, 2) ?>
                    </div>
                    <div style="font-size: 0.9rem; color: #6c757d;">Cəmi Məbləğ</div>
                </div>
                
                <div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--info-color);">
                        ₼<?= $totalCount > 0 ? number_format($totalAmount / $totalCount, 2) : '0.00' ?>
                    </div>
                    <div style="font-size: 0.9rem; color: #6c757d;">Orta Satış</div>
                </div>
                
                <div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--warning-color);">
                        ₼<?= number_format($totalTax, 2) ?>
                    </div>
                    <div style="font-size: 0.9rem; color: #6c757d;">Cəmi KDV</div>
                </div>
                
                <div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--danger-color);">
                        ₼<?= number_format($totalDiscount, 2) ?>
                    </div>
                    <div style="font-size: 0.9rem; color: #6c757d;">Cəmi Endirim</div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- Sale Details Modal -->
<div class="modal" id="saleDetailsModal">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h5 class="modal-title">
                <i class="fas fa-info-circle"></i> Satış Detalları
            </h5>
            <button class="modal-close" onclick="closeModal('saleDetailsModal')">×</button>
        </div>
        <div id="saleDetailsContent">
            <div style="text-align: center; padding: 40px;">
                <i class="fas fa-spinner fa-spin" style="font-size: 2rem; color: var(--primary-color);"></i>
                <p style="margin-top: 15px;">Yüklənir...</p>
            </div>
        </div>
    </div>
</div>

<script>
// Export functions
function exportSales() {
    const table = document.querySelector('.table');
    if (table) {
        const csv = tableToCSV(table);
        downloadCSV(csv, `satislar_${new Date().toISOString().split('T')[0]}.csv`);
    }
}

function printSales() {
    const printContent = document.querySelector('.content-box').innerHTML;
    const printWindow = window.open('', '_blank');
    
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Satış Siyahısı - ${new Date().toLocaleDateString('az-AZ')}</title>
            <style>
                body { font-family: Arial, sans-serif; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                .no-print { display: none; }
            </style>
        </head>
        <body>
            <h1>Satış Siyahısı</h1>
            <p>Tarix: ${new Date().toLocaleDateString('az-AZ')}</p>
            ${printContent}
        </body>
        </html>
    `);
    
    printWindow.document.close();
    printWindow.print();
    printWindow.close();
}

function tableToCSV(table) {
    const rows = table.querySelectorAll('tr');
    const csv = [];
    
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const cols = row.querySelectorAll('td, th');
        const csvRow = [];
        
        for (let j = 0; j < cols.length; j++) {
            csvRow.push('"' + cols[j].textContent.trim().replace(/"/g, '""') + '"');
        }
        
        csv.push(csvRow.join(','));
    }
    
    return csv.join('\n');
}

function downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

// View sale details
function viewSaleDetails(saleId) {
    const modal = document.getElementById('saleDetailsModal');
    const content = document.getElementById('saleDetailsContent');
    
    modal.classList.add('show');
    
    // Show loading
    content.innerHTML = `
        <div style="text-align: center; padding: 40px;">
            <i class="fas fa-spinner fa-spin" style="font-size: 2rem; color: var(--primary-color);"></i>
            <p style="margin-top: 15px;">Yüklənir...</p>
        </div>
    `;
    
    // Fetch sale details
    fetch(`?page=sales&action=get_details&id=${saleId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displaySaleDetails(data.sale, data.details);
            } else {
                content.innerHTML = `
                    <div style="text-align: center; padding: 40px; color: var(--danger-color);">
                        <i class="fas fa-exclamation-circle" style="font-size: 2rem; margin-bottom: 15px;"></i>
                        <p>Məlumat yüklənə bilmədi: ${data.error}</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            content.innerHTML = `
                <div style="text-align: center; padding: 40px; color: var(--danger-color);">
                    <i class="fas fa-exclamation-circle" style="font-size: 2rem; margin-bottom: 15px;"></i>
                    <p>Sistem xətası baş verdi</p>
                </div>
            `;
        });
}

function displaySaleDetails(sale, details) {
    const content = document.getElementById('saleDetailsContent');
    
    content.innerHTML = `
        <div style="padding: 20px;">
            <!-- Sale Info -->
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div>
                        <strong>Satış №:</strong> ${sale.sale_number}<br>
                        <strong>Tarix:</strong> ${new Date(sale.created_at).toLocaleString('az-AZ')}<br>
                        <strong>Satışçı:</strong> ${sale.seller_name}<br>
                        <strong>Status:</strong> <span class="badge badge-success">${sale.status}</span>
                    </div>
                    <div>
                        <strong>Müştəri:</strong> ${sale.customer_name || 'Anonim'}<br>
                        <strong>Telefon:</strong> ${sale.customer_phone || '-'}<br>
                        <strong>Email:</strong> ${sale.customer_email || '-'}<br>
                        <strong>Ödəniş:</strong> ${sale.payment_method}
                    </div>
                </div>
            </div>
            
            <!-- Products -->
            <div style="margin-bottom: 20px;">
                <h6 style="margin-bottom: 15px; color: var(--dark-color);">
                    <i class="fas fa-box"></i> Satılan Məhsullar
                </h6>
                
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: #f8f9fa;">
                                <th style="padding: 10px; border: 1px solid #e9ecef;">Məhsul</th>
                                <th style="padding: 10px; border: 1px solid #e9ecef; text-align: center;">Miqdar</th>
                                <th style="padding: 10px; border: 1px solid #e9ecef; text-align: right;">Vahid Qiymət</th>
                                <th style="padding: 10px; border: 1px solid #e9ecef; text-align: right;">Cəmi</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${details.map(detail => `
                                <tr>
                                    <td style="padding: 10px; border: 1px solid #e9ecef;">
                                        <div style="font-weight: bold;">${detail.product_name}</div>
                                        <div style="font-size: 0.8rem; color: #6c757d;">${detail.brand || ''} ${detail.size ? '- ' + detail.size : ''}</div>
                                    </td>
                                    <td style="padding: 10px; border: 1px solid #e9ecef; text-align: center;">
                                        <strong>${detail.quantity}</strong>
                                    </td>
                                    <td style="padding: 10px; border: 1px solid #e9ecef; text-align: right;">
                                        ₼${parseFloat(detail.unit_price).toFixed(2)}
                                    </td>
                                    <td style="padding: 10px; border: 1px solid #e9ecef; text-align: right;">
                                        <strong>₼${parseFloat(detail.total_price).toFixed(2)}</strong>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Totals -->
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span>Ara Cəmi:</span>
                    <strong>₼${parseFloat(sale.subtotal).toFixed(2)}</strong>
                </div>
                
                ${sale.discount_amount > 0 ? `
                    <div style="display: flex; justify-content: space-between; margin-bottom: 10px; color: var(--danger-color);">
                        <span>Endirim:</span>
                        <strong>-₼${parseFloat(sale.discount_amount).toFixed(2)}</strong>
                    </div>
                ` : ''}
                
                <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                    <span>KDV (18%):</span>
                    <strong>₼${parseFloat(sale.tax_amount).toFixed(2)}</strong>
                </div>
                
                <hr style="margin: 15px 0;">
                
                <div style="display: flex; justify-content: space-between; font-size: 1.2rem;">
                    <span><strong>CƏMİ:</strong></span>
                    <strong style="color: var(--success-color);">₼${parseFloat(sale.final_amount).toFixed(2)}</strong>
                </div>
            </div>
            
            ${sale.notes ? `
                <div style="margin-top: 20px; padding: 15px; background: #e3f2fd; border-radius: 8px;">
                    <h6 style="margin-bottom: 10px; color: var(--info-color);">
                        <i class="fas fa-sticky-note"></i> Qeydlər:
                    </h6>
                    <p style="margin: 0; font-style: italic;">${sale.notes}</p>
                </div>
            ` : ''}
            
            <!-- Actions -->
            <div style="margin-top: 25px; text-align: center;">
                <a href="?page=sales&action=receipt&id=${sale.id}" class="btn btn-primary" target="_blank">
                    <i class="fas fa-receipt"></i> Qəbzi Göstər
                </a>
                
                <button onclick="closeModal('saleDetailsModal')" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Bağla
                </button>
            </div>
        </div>
    `;
}

// Delete sale function
function deleteSale(saleId, saleNumber) {
    if (confirm(`"${saleNumber}" nömrəli satışı silmək istədiyinizə əminsiniz?\n\nBu əməliyyat:\n- Satışı tamamilə siləcək\n- Məhsul stoklarını bərpa edəcək\n- Geri qaytarıla bilməz`)) {
        const confirmation = prompt('Təsdiq etmək üçün "SIL" yazın:');
        
        if (confirmation === 'SIL') {
            window.location.href = `?page=sales&action=delete&id=${saleId}`;
        } else {
            alert('Təsdiq edilmədi. Satış silinmədi.');
        }
    }
}

// Modal functions
function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('show');
    }
});

// Auto-refresh for real-time updates
setInterval(() => {
    // Check for new sales (in production, use WebSocket)
    console.log('Auto-refresh check...');
}, 30000);

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl+N - New sale
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        window.location.href = '?page=sales&action=new';
    }
    
    // Ctrl+F - Focus search
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }
    
    // Escape - Close modals
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal.show').forEach(modal => {
            modal.classList.remove('show');
        });
    }
});

// Initialize tooltips and enhance UX
document.addEventListener('DOMContentLoaded', function() {
    // Add loading states to buttons
    document.querySelectorAll('a[href*="receipt"]').forEach(link => {
        link.addEventListener('click', function() {
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Yüklənir...';
        });
    });
    
    // Auto-submit form on date change
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        input.addEventListener('change', function() {
            // Small delay to allow user to change both dates
            setTimeout(() => {
                this.closest('form').submit();
            }, 500);
        });
    });
    
    // Show success animations
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('success') === '1') {
        showSuccessAnimation();
    }
});

function showSuccessAnimation() {
    const animation = document.createElement('div');
    animation.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: var(--success-color);
        color: white;
        padding: 30px 40px;
        border-radius: 15px;
        font-size: 1.2rem;
        font-weight: bold;
        z-index: 3000;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        animation: successPulse 2s ease-in-out;
    `;
    
    animation.innerHTML = `
        <div style="text-align: center;">
            <i class="fas fa-check-circle" style="font-size: 3rem; margin-bottom: 15px;"></i>
            <div>Satış Uğurla Tamamlandı!</div>
        </div>
    `;
    
    document.body.appendChild(animation);
    
    setTimeout(() => {
        animation.remove();
    }, 2000);
}

// Add CSS animation
const style = document.createElement('style');
style.textContent = `
    @keyframes successPulse {
        0% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
        50% { opacity: 1; transform: translate(-50%, -50%) scale(1.1); }
        100% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
    }
`;
document.head.appendChild(style);

console.log('Sales system initialized');
console.log('Total sales loaded:', <?= count($sales) ?>);
console.log('Keyboard shortcuts: Ctrl+N (New Sale), Ctrl+F (Search), ESC (Close modals)');
</script>

<?php include 'includes/footer.php'; ?>