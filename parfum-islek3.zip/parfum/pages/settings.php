<?php
/**
 * Sistem Tənzimləmələri
 * Kodaz-az - 2025-07-21 13:58:37 (UTC)
 * Login: Kodaz-az
 */

$currentUserRole = $_SESSION['role'];

// Permission check - only admin can access settings
if ($currentUserRole !== 'admin') {
    $_SESSION['error_message'] = "Bu səhifəyə giriş icazəniz yoxdur!";
    header('Location: ?page=dashboard');
    exit;
}

// Handle settings update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update') {
    try {
        $db = Database::getInstance();
        
        $settings = [
            'site_name' => trim($_POST['site_name'] ?? ''),
            'site_description' => trim($_POST['site_description'] ?? ''),
            'contact_email' => trim($_POST['contact_email'] ?? ''),
            'contact_phone' => trim($_POST['contact_phone'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
            'tax_rate' => floatval($_POST['tax_rate'] ?? 18),
            'currency' => trim($_POST['currency'] ?? 'AZN'),
            'default_commission' => floatval($_POST['default_commission'] ?? 5),
            'min_stock_alert' => intval($_POST['min_stock_alert'] ?? 5),
            'backup_frequency' => trim($_POST['backup_frequency'] ?? 'daily'),
            'notification_email' => trim($_POST['notification_email'] ?? ''),
            'maintenance_mode' => isset($_POST['maintenance_mode']) ? 1 : 0,
            'allow_registration' => isset($_POST['allow_registration']) ? 1 : 0,
            'enable_notifications' => isset($_POST['enable_notifications']) ? 1 : 0,
            'enable_sms' => isset($_POST['enable_sms']) ? 1 : 0,
            'receipt_footer' => trim($_POST['receipt_footer'] ?? ''),
            'business_hours' => trim($_POST['business_hours'] ?? '')
        ];
        
        $errors = [];
        
        // Validation
        if (empty($settings['site_name'])) $errors[] = "Sayt adı tələb olunur";
        if (!empty($settings['contact_email']) && !filter_var($settings['contact_email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Düzgün email daxil edin";
        }
        if ($settings['tax_rate'] < 0 || $settings['tax_rate'] > 100) {
            $errors[] = "Vergi dərəcəsi 0-100 arasında olmalıdır";
        }
        
        if (empty($errors)) {
            // Update or insert settings
            foreach ($settings as $key => $value) {
                $existing = $db->selectOne("SELECT id FROM settings WHERE setting_key = ?", [$key]);
                
                if ($existing) {
                    $db->update("UPDATE settings SET setting_value = ?, updated_at = NOW() WHERE setting_key = ?", [$value, $key]);
                } else {
                    $db->insert("INSERT INTO settings (setting_key, setting_value, created_at) VALUES (?, ?, NOW())", [$key, $value]);
                }
            }
            
            $_SESSION['success_message'] = "Tənzimləmələr uğurla yeniləndi!";
            header('Location: ?page=settings');
            exit;
        } else {
            $_SESSION['error_message'] = implode('<br>', $errors);
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Tənzimləmələr yenilənə bilmədi: " . $e->getMessage();
    }
}

// Database maintenance actions
if ($action === 'backup_db') {
    try {
        $backupFile = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
        $backupPath = 'backups/' . $backupFile;
        
        // Create backups directory if not exists
        if (!is_dir('backups')) {
            mkdir('backups', 0755, true);
        }
        
        // Simple backup (in real scenario, use mysqldump)
        $tables = ['users', 'products', 'sales', 'sale_details', 'chat_messages', 'settings'];
        $backup = "-- Database Backup - " . date('Y-m-d H:i:s') . "\n\n";
        
        $db = Database::getInstance();
        
        foreach ($tables as $table) {
            $backup .= "-- Table: $table\n";
            $backup .= "DROP TABLE IF EXISTS `$table`;\n";
            
            // Get table structure (simplified)
            $structure = $db->selectAll("SHOW CREATE TABLE `$table`");
            if ($structure) {
                $backup .= $structure[0]['Create Table'] . ";\n\n";
            }
            
            // Get table data
            $data = $db->selectAll("SELECT * FROM `$table`");
            if ($data) {
                $backup .= "-- Data for table: $table\n";
                foreach ($data as $row) {
                    $values = array_map(function($val) {
                        return $val === null ? 'NULL' : "'" . addslashes($val) . "'";
                    }, array_values($row));
                    
                    $backup .= "INSERT INTO `$table` VALUES (" . implode(', ', $values) . ");\n";
                }
                $backup .= "\n";
            }
        }
        
        file_put_contents($backupPath, $backup);
        
        $_SESSION['success_message'] = "Verilənlər bazası ehtiyat nüsxəsi yaradıldı: $backupFile";
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Ehtiyat nüsxəsi yaradıla bilmədi: " . $e->getMessage();
    }
    
    header('Location: ?page=settings');
    exit;
}

if ($action === 'clear_logs') {
    try {
        $db = Database::getInstance();
        
        // Clear old activity logs (keep last 30 days)
        $db->delete("DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)");
        
        // Clear old notifications (keep last 7 days)
        $db->delete("DELETE FROM notifications WHERE created_at < DATE_SUB(NOW(), INTERVAL 7 DAY)");
        
        $_SESSION['success_message'] = "Köhnə qeydlər təmizləndi!";
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Qeydlər təmizlənə bilmədi: " . $e->getMessage();
    }
    
    header('Location: ?page=settings');
    exit;
}

// Get current settings
try {
    $db = Database::getInstance();
    
    $settingsData = $db->selectAll("SELECT setting_key, setting_value FROM settings");
    $currentSettings = [];
    
    foreach ($settingsData as $setting) {
        $currentSettings[$setting['setting_key']] = $setting['setting_value'];
    }
    
    // Default values if not set
    $defaults = [
        'site_name' => PWA_NAME,
        'site_description' => 'Parfüm Satış və İnventar Sistemi',
        'contact_email' => '',
        'contact_phone' => '',
        'address' => '',
        'tax_rate' => 18,
        'currency' => 'AZN',
        'default_commission' => 5,
        'min_stock_alert' => 5,
        'backup_frequency' => 'daily',
        'notification_email' => '',
        'maintenance_mode' => 0,
        'allow_registration' => 1,
        'enable_notifications' => 1,
        'enable_sms' => 0,
        'receipt_footer' => 'Təşəkkür edirik! - Kodaz.az',
        'business_hours' => 'B.e - Şənbə: 09:00-18:00'
    ];
    
    $settings = array_merge($defaults, $currentSettings);
    
    // System statistics
    $systemStats = [
        'total_users' => $db->selectOne("SELECT COUNT(*) as count FROM users")['count'],
        'total_products' => $db->selectOne("SELECT COUNT(*) as count FROM products")['count'],
        'total_sales' => $db->selectOne("SELECT COUNT(*) as count FROM sales")['count'],
        'database_size' => 'N/A', // Would require specific MySQL queries
        'last_backup' => 'Manual only'
    ];
    
} catch (Exception $e) {
    $settings = [];
    $systemStats = [];
}

$pageTitle = "Tənzimləmələr - " . PWA_NAME;
include 'includes/header.php';
?>

<style>
.settings-tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 30px;
    flex-wrap: wrap;
    border-bottom: 2px solid #e9ecef;
}

.settings-tab {
    padding: 15px 25px;
    border: none;
    background: none;
    color: #6c757d;
    font-weight: 500;
    cursor: pointer;
    transition: var(--transition);
    border-bottom: 3px solid transparent;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 8px;
}

.settings-tab.active,
.settings-tab:hover {
    color: var(--primary-color);
    border-bottom-color: var(--primary-color);
    background: rgba(102, 126, 234, 0.1);
}

.settings-content {
    display: none;
}

.settings-content.active {
    display: block;
}

.settings-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
}

.settings-section {
    background: var(--white);
    padding: 30px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    margin-bottom: 20px;
}

.section-title {
    color: var(--dark-color);
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid #e9ecef;
    display: flex;
    align-items: center;
    gap: 10px;
}

.system-info {
    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 20px;
}

.system-info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-top: 15px;
}

.system-info-item {
    background: var(--white);
    padding: 15px;
    border-radius: 8px;
    text-align: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.system-info-value {
    font-size: 1.5rem;
    font-weight: bold;
    color: var(--primary-color);
    margin-bottom: 5px;
}

.system-info-label {
    color: #6c757d;
    font-size: 0.9rem;
}

.maintenance-banner {
    background: linear-gradient(135deg, #ffc107, #ffb300);
    color: var(--dark-color);
    padding: 20px;
    border-radius: 15px;
    margin-bottom: 30px;
    text-align: center;
    display: none;
}

.maintenance-banner.active {
    display: block;
}

.form-switch {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
}

.switch {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 28px;
}

.switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: 0.4s;
    border-radius: 28px;
}

.slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: 0.4s;
    border-radius: 50%;
}

input:checked + .slider {
    background-color: var(--primary-color);
}

input:checked + .slider:before {
    transform: translateX(22px);
}

@media (max-width: 768px) {
    .settings-grid {
        grid-template-columns: 1fr;
    }
    
    .settings-tabs {
        flex-direction: column;
    }
}
</style>

<!-- Maintenance Mode Banner -->
<div class="maintenance-banner <?= ($settings['maintenance_mode'] ?? 0) ? 'active' : '' ?>">
    <h4><i class="fas fa-tools"></i> Baxım Rejimi Aktiv</h4>
    <p>Sayt hal-hazırda baxım rejimindədir. Yalnız adminlər giriş edə bilər.</p>
</div>

<!-- Settings Tabs -->
<div class="settings-tabs">
    <button class="settings-tab active" onclick="showTab('general')">
        <i class="fas fa-cog"></i> Ümumi
    </button>
    <button class="settings-tab" onclick="showTab('business')">
        <i class="fas fa-store"></i> Biznes
    </button>
    <button class="settings-tab" onclick="showTab('notifications')">
        <i class="fas fa-bell"></i> Bildirişlər
    </button>
    <button class="settings-tab" onclick="showTab('system')">
        <i class="fas fa-server"></i> Sistem
    </button>
    <button class="settings-tab" onclick="showTab('maintenance')">
        <i class="fas fa-tools"></i> Baxım
    </button>
</div>

<form method="POST">
    <input type="hidden" name="action" value="update">
    
    <!-- General Settings -->
    <div id="general" class="settings-content active">
        <div class="settings-grid">
            <div class="settings-section">
                <h4 class="section-title">
                    <i class="fas fa-info-circle"></i> Əsas Məlumatlar
                </h4>
                
                <div class="form-group">
                    <label>Sayt Adı *</label>
                    <input type="text" name="site_name" value="<?= htmlspecialchars($settings['site_name']) ?>" required class="form-control">
                </div>
                
                <div class="form-group">
                    <label>Sayt Təsviri</label>
                    <textarea name="site_description" rows="3" class="form-control"><?= htmlspecialchars($settings['site_description']) ?></textarea>
                </div>
                
                <div class="form-group">
                    <label>Əlaqə Email</label>
                    <input type="email" name="contact_email" value="<?= htmlspecialchars($settings['contact_email']) ?>" class="form-control">
                </div>
                
                <div class="form-group">
                    <label>Əlaqə Telefonu</label>
                    <input type="tel" name="contact_phone" value="<?= htmlspecialchars($settings['contact_phone']) ?>" class="form-control">
                </div>
                
                <div class="form-group">
                    <label>Ünvan</label>
                    <textarea name="address" rows="3" class="form-control"><?= htmlspecialchars($settings['address']) ?></textarea>
                </div>
            </div>
            
            <div class="settings-section">
                <h4 class="section-title">
                    <i class="fas fa-shield-alt"></i> Sistem Təhlükəsizliyi
                </h4>
                
                <div class="form-switch">
                    <label class="switch">
                        <input type="checkbox" name="maintenance_mode" <?= ($settings['maintenance_mode'] ?? 0) ? 'checked' : '' ?>>
                        <span class="slider"></span>
                    </label>
                    <label>Baxım Rejimi</label>
                </div>
                
                <div class="form-switch">
                    <label class="switch">
                        <input type="checkbox" name="allow_registration" <?= ($settings['allow_registration'] ?? 1) ? 'checked' : '' ?>>
                        <span class="slider"></span>
                    </label>
                    <label>Qeydiyyata İcazə Ver</label>
                </div>
                
                <div class="form-group">
                    <label>Sistem Məlumatları</label>
                    <div class="system-info">
                        <div class="system-info-grid">
                            <div class="system-info-item">
                                <div class="system-info-value"><?= $systemStats['total_users'] ?></div>
                                <div class="system-info-label">İstifadəçi</div>
                            </div>
                            <div class="system-info-item">
                                <div class="system-info-value"><?= $systemStats['total_products'] ?></div>
                                <div class="system-info-label">Məhsul</div>
                            </div>
                            <div class="system-info-item">
                                <div class="system-info-value"><?= $systemStats['total_sales'] ?></div>
                                <div class="system-info-label">Satış</div>
                            </div>
                            <div class="system-info-item">
                                <div class="system-info-value">v<?= APP_VERSION ?></div>
                                <div class="system-info-label">Versiya</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Business Settings -->
    <div id="business" class="settings-content">
        <div class="settings-grid">
            <div class="settings-section">
                <h4 class="section-title">
                    <i class="fas fa-calculator"></i> Maliyyə Tənzimləmələri
                </h4>
                
                <div class="form-group">
                    <label>Vergi Dərəcəsi (%)</label>
                    <input type="number" name="tax_rate" value="<?= $settings['tax_rate'] ?>" min="0" max="100" step="0.01" class="form-control">
                    <small class="form-text text-muted">VAT və ya digər vergilər üçün</small>
                </div>
                
                <div class="form-group">
                    <label>Valyuta</label>
                    <select name="currency" class="form-control">
                        <option value="AZN" <?= ($settings['currency'] ?? 'AZN') === 'AZN' ? 'selected' : '' ?>>AZN (₼)</option>
                        <option value="USD" <?= ($settings['currency'] ?? 'AZN') === 'USD' ? 'selected' : '' ?>>USD ($)</option>
                        <option value="EUR" <?= ($settings['currency'] ?? 'AZN') === 'EUR' ? 'selected' : '' ?>>EUR (€)</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Default Komissiya Dərəcəsi (%)</label>
                    <input type="number" name="default_commission" value="<?= $settings['default_commission'] ?>" min="0" max="100" step="0.01" class="form-control">
                    <small class="form-text text-muted">Yeni işçilər üçün standart komissiya</small>
                </div>
                
                <div class="form-group">
                    <label>Minimum Stok Xəbərdarlığı</label>
                    <input type="number" name="min_stock_alert" value="<?= $settings['min_stock_alert'] ?>" min="1" class="form-control">
                    <small class="form-text text-muted">Bu rəqəmə çatanda xəbərdarlıq göstər</small>
                </div>
            </div>
            
            <div class="settings-section">
                <h4 class="section-title">
                    <i class="fas fa-receipt"></i> Qəbz Tənzimləmələri
                </h4>
                
                <div class="form-group">
                    <label>Qəbz Alt Mətn</label>
                    <textarea name="receipt_footer" rows="3" class="form-control" placeholder="Təşəkkür edirik!"><?= htmlspecialchars($settings['receipt_footer']) ?></textarea>
                    <small class="form-text text-muted">Qəbzin altında göstəriləcək mətn</small>
                </div>
                
                <div class="form-group">
                    <label>İş Saatları</label>
                    <input type="text" name="business_hours" value="<?= htmlspecialchars($settings['business_hours']) ?>" class="form-control" placeholder="B.e - Şənbə: 09:00-18:00">
                    <small class="form-text text-muted">Qəbzdə göstəriləcək iş saatları</small>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Notifications Settings -->
    <div id="notifications" class="settings-content">
        <div class="settings-section">
            <h4 class="section-title">
                <i class="fas fa-bell"></i> Bildiriş Tənzimləmələri
            </h4>
            
            <div class="form-switch">
                <label class="switch">
                    <input type="checkbox" name="enable_notifications" <?= ($settings['enable_notifications'] ?? 1) ? 'checked' : '' ?>>
                    <span class="slider"></span>
                </label>
                <label>Email Bildirişlərini Aktivləşdir</label>
            </div>
            
            <div class="form-switch">
                <label class="switch">
                    <input type="checkbox" name="enable_sms" <?= ($settings['enable_sms'] ?? 0) ? 'checked' : '' ?>>
                    <span class="slider"></span>
                </label>
                <label>SMS Bildirişlərini Aktivləşdir</label>
            </div>
            
            <div class="form-group">
                <label>Bildiriş Email Ünvanı</label>
                <input type="email" name="notification_email" value="<?= htmlspecialchars($settings['notification_email']) ?>" class="form-control">
                <small class="form-text text-muted">Sistem bildirişləri bu ünvana göndəriləcək</small>
            </div>
            
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-top: 20px;">
                <h6><i class="fas fa-info-circle"></i> Bildiriş Növləri</h6>
                <ul style="margin-top: 10px; padding-left: 20px;">
                    <li>Az stok xəbərdarlıqları</li>
                    <li>Yeni istifadəçi qeydiyyatları</li>
                    <li>Böyük məbləğli satışlar</li>
                    <li>Sistem xətaları</li>
                    <li>Gündəlik hesabatlar</li>
                </ul>
            </div>
        </div>
    </div>
    
    <!-- System Settings -->
    <div id="system" class="settings-content">
        <div class="settings-section">
            <h4 class="section-title">
                <i class="fas fa-database"></i> Verilənlər Bazası
            </h4>
            
            <div class="form-group">
                <label>Ehtiyat Nüsxə Tezliyi</label>
                <select name="backup_frequency" class="form-control">
                    <option value="daily" <?= ($settings['backup_frequency'] ?? 'daily') === 'daily' ? 'selected' : '' ?>>Gündəlik</option>
                    <option value="weekly" <?= ($settings['backup_frequency'] ?? 'daily') === 'weekly' ? 'selected' : '' ?>>Həftəlik</option>
                    <option value="monthly" <?= ($settings['backup_frequency'] ?? 'daily') === 'monthly' ? 'selected' : '' ?>>Aylıq</option>
                    <option value="manual" <?= ($settings['backup_frequency'] ?? 'daily') === 'manual' ? 'selected' : '' ?>>Manual</option>
                </select>
            </div>
            
            <div style="display: flex; gap: 15px; margin-top: 20px;">
                <a href="?page=settings&action=backup_db" class="btn btn-warning" onclick="return confirm('Ehtiyat nüsxəsi yaratmaq istədiyinizə əminsiniz?')">
                    <i class="fas fa-download"></i> Ehtiyat Nüsxəsi Yarat
                </a>
                
                <a href="?page=settings&action=clear_logs" class="btn btn-info" onclick="return confirm('Köhnə qeydləri silmək istədiyinizə əminsiniz?')">
                    <i class="fas fa-broom"></i> Qeydləri Təmizlə
                </a>
            </div>
            
            <div style="background: #e3f2fd; padding: 20px; border-radius: 10px; margin-top: 20px;">
                <h6><i class="fas fa-info-circle"></i> Sistem Məlumatları</h6>
                <div style="margin-top: 15px; font-size: 0.9rem;">
                    <div><strong>PHP Versiyası:</strong> <?= phpversion() ?></div>
                    <div><strong>Server:</strong> <?= $_SERVER['SERVER_SOFTWARE'] ?? 'N/A' ?></div>
                    <div><strong>Diskdə Yer:</strong> <?= function_exists('disk_free_space') ? round(disk_free_space('/') / 1024 / 1024 / 1024, 2) . ' GB' : 'N/A' ?></div>
                    <div><strong>Yaddaş Limiti:</strong> <?= ini_get('memory_limit') ?></div>
                    <div><strong>Maksimum Fayl Ölçüsü:</strong> <?= ini_get('upload_max_filesize') ?></div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Maintenance -->
    <div id="maintenance" class="settings-content">
        <div class="settings-section">
            <h4 class="section-title">
                <i class="fas fa-tools"></i> Sistem Baxımı
            </h4>
            
            <div style="background: #fff3cd; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                <h6><i class="fas fa-exclamation-triangle"></i> Diqqət!</h6>
                <p style="margin: 10px 0 0 0;">Bu əməliyyatlar sistemin işləməsinə təsir edə bilər. Ehtiyatlı olun!</p>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; text-align: center;">
                    <i class="fas fa-database" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 10px;"></i>
                    <h6>Verilənlər Bazası</h6>
                    <p style="font-size: 0.8rem; color: #6c757d;">Baza optimallaşdırması</p>
                    <button type="button" class="btn btn-primary btn-sm" onclick="optimizeDatabase()">
                        Optimallaşdır
                    </button>
                </div>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; text-align: center;">
                    <i class="fas fa-broom" style="font-size: 2rem; color: var(--warning-color); margin-bottom: 10px;"></i>
                    <h6>Cache Təmizlə</h6>
                    <p style="font-size: 0.8rem; color: #6c757d;">Müvəqqəti faylları sil</p>
                    <button type="button" class="btn btn-warning btn-sm" onclick="clearCache()">
                        Təmizlə
                    </button>
                </div>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; text-align: center;">
                    <i class="fas fa-sync" style="font-size: 2rem; color: var(--info-color); margin-bottom: 10px;"></i>
                    <h6>Sistem Yenilə</h6>
                    <p style="font-size: 0.8rem; color: #6c757d;">Sistemi yenidən başlat</p>
                    <button type="button" class="btn btn-info btn-sm" onclick="restartSystem()">
                        Yenilə
                    </button>
                </div>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; text-align: center;">
                    <i class="fas fa-shield-alt" style="font-size: 2rem; color: var(--success-color); margin-bottom: 10px;"></i>
                    <h6>Təhlükəsizlik</h6>
                    <p style="font-size: 0.8rem; color: #6c757d;">Sistem yoxlaması</p>
                    <button type="button" class="btn btn-success btn-sm" onclick="securityScan()">
                        Yoxla
                    </button>
                </div>
            </div>
            
            <div style="margin-top: 30px; background: #d4edda; padding: 20px; border-radius: 10px;">
                <h6><i class="fas fa-check-circle"></i> Son Baxım Əməliyyatları</h6>
                <div style="margin-top: 15px; font-size: 0.9rem;">
                    <div>✅ Son ehtiyat nüsxəsi: Manual</div>
                    <div>✅ Son qeyd təmizlənməsi: Hələ edilməyib</div>
                    <div>✅ Son güncəlləmə: <?= date('d.m.Y H:i') ?></div>
                    <div>✅ Sistem statusu: Sağlam</div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Save Button -->
   

    <!-- Save Button -->
    <div style="position: sticky; bottom: 20px; text-align: center; margin-top: 30px;">
        <button type="submit" class="btn btn-primary" style="padding: 15px 40px; font-size: 1.1rem;">
            <i class="fas fa-save"></i> Tənzimləmələri Saxla
        </button>
    </div>
</form>

<script>
// Tab switching
function showTab(tabName) {
    // Hide all content
    document.querySelectorAll('.settings-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Remove active class from all tabs
    document.querySelectorAll('.settings-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected content
    document.getElementById(tabName).classList.add('active');
    
    // Add active class to clicked tab
    event.target.classList.add('active');
    
    // Store active tab in localStorage
    localStorage.setItem('activeSettingsTab', tabName);
}

// Restore last active tab
document.addEventListener('DOMContentLoaded', function() {
    const lastTab = localStorage.getItem('activeSettingsTab');
    if (lastTab && document.getElementById(lastTab)) {
        showTab(lastTab);
        document.querySelector(`[onclick="showTab('${lastTab}')"]`).classList.add('active');
    }
});

// Maintenance functions
function optimizeDatabase() {
    if (confirm('Verilənlər bazasını optimallaşdırmaq istədiyinizə əminsiniz?')) {
        showLoading('Verilənlər bazası optimallaşdırılır...');
        
        // Simulate optimization
        setTimeout(() => {
            hideLoading();
            alert('Verilənlər bazası uğurla optimallaşdırıldı!');
        }, 3000);
    }
}

function clearCache() {
    if (confirm('Cache təmizlənsin?')) {
        showLoading('Cache təmizlənir...');
        
        // Simulate cache clearing
        setTimeout(() => {
            hideLoading();
            alert('Cache uğurla təmizləndi!');
        }, 2000);
    }
}

function restartSystem() {
    if (confirm('Sistemi yenidən başlatmaq istədiyinizə əminsiniz? Bu 1-2 dəqiqə çəkə bilər.')) {
        showLoading('Sistem yenidən başladılır...');
        
        setTimeout(() => {
            hideLoading();
            alert('Sistem uğurla yenidən başladıldı!');
            location.reload();
        }, 4000);
    }
}

function securityScan() {
    showLoading('Təhlükəsizlik yoxlanılır...');
    
    setTimeout(() => {
        hideLoading();
        alert('Təhlükəsizlik yoxlaması tamamlandı. Heç bir problem tapılmadı.');
    }, 3000);
}

function showLoading(message) {
    const loadingDiv = document.createElement('div');
    loadingDiv.id = 'loading-overlay';
    loadingDiv.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.8);
        color: white;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        font-size: 1.2rem;
    `;
    
    loadingDiv.innerHTML = `
        <div style="text-align: center;">
            <div style="font-size: 3rem; margin-bottom: 20px;">
                <i class="fas fa-spinner fa-spin"></i>
            </div>
            <div>${message}</div>
        </div>
    `;
    
    document.body.appendChild(loadingDiv);
}

function hideLoading() {
    const loadingDiv = document.getElementById('loading-overlay');
    if (loadingDiv) {
        loadingDiv.remove();
    }
}

// Form validation
document.querySelector('form').addEventListener('submit', function(e) {
    const siteName = document.querySelector('input[name="site_name"]').value.trim();
    const taxRate = parseFloat(document.querySelector('input[name="tax_rate"]').value);
    
    if (!siteName) {
        alert('Sayt adı tələb olunur!');
        e.preventDefault();
        return;
    }
    
    if (taxRate < 0 || taxRate > 100) {
        alert('Vergi dərəcəsi 0-100 arasında olmalıdır!');
        e.preventDefault();
        return;
    }
    
    // Show saving indicator
    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saxlanılır...';
    submitBtn.disabled = true;
    
    // Re-enable after 3 seconds (in case of error)
    setTimeout(() => {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }, 3000);
});

// Maintenance mode toggle warning
document.querySelector('input[name="maintenance_mode"]').addEventListener('change', function() {
    if (this.checked) {
        if (confirm('Baxım rejimini aktivləşdirmək istədiyinizə əminsiniz? Bu, digər istifadəçilərin sisteme girişini məhdudlaşdıracaq.')) {
            document.querySelector('.maintenance-banner').classList.add('active');
        } else {
            this.checked = false;
        }
    } else {
        document.querySelector('.maintenance-banner').classList.remove('active');
    }
});

console.log('Settings system initialized');
console.log('Active tab:', localStorage.getItem('activeSettingsTab') || 'general');
</script>

<?php include 'includes/footer.php'; ?>