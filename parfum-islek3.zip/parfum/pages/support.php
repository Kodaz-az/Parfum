<?php
/**
 * Admin Support Sistemi - Customer Support Management
 * Kodaz-az - 2025-07-21 14:45:31 (UTC)
 * Login: Kodaz-az
 */

$currentUserId = $_SESSION['user_id'];
$currentUserRole = $_SESSION['role'];

// Permission check - only admin and manager can access
if (!in_array($currentUserRole, ['admin', 'manager'])) {
    $_SESSION['error_message'] = "Bu səhifəyə giriş icazəniz yoxdur!";
    header('Location: ?page=dashboard');
    exit;
}

// Handle reply to support ticket
if ($action === 'reply' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = Database::getInstance();
        
        $ticketId = intval($_POST['ticket_id'] ?? 0);
        $message = trim($_POST['message'] ?? '');
        $status = $_POST['status'] ?? 'open';
        
        if (empty($message)) {
            throw new Exception('Cavab mesajı boş ola bilməz');
        }
        
        // Get ticket info
        $ticket = $db->selectOne("SELECT * FROM support_tickets WHERE id = ?", [$ticketId]);
        if (!$ticket) {
            throw new Exception('Ticket tapılmadı');
        }
        
        // Insert reply
        $replyId = $db->insert("
            INSERT INTO support_replies (ticket_id, user_id, message, is_admin_reply, created_at)
            VALUES (?, ?, ?, 1, NOW())
        ", [$ticketId, $currentUserId, $message]);
        
        // Update ticket status and last activity
        $db->update("
            UPDATE support_tickets 
            SET status = ?, last_activity = NOW(), admin_id = ?
            WHERE id = ?
        ", [$status, $currentUserId, $ticketId]);
        
        // Send notification to customer if available
        if ($ticket['user_email']) {
            // In production, send email notification
            // sendSupportReplyEmail($ticket['user_email'], $ticket['subject'], $message);
        }
        
        $_SESSION['success_message'] = "Cavab göndərildi və ticket statusu yeniləndi!";
        header('Location: ?page=support&action=view&id=' . $ticketId);
        exit;
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Cavab göndərilə bilmədi: " . $e->getMessage();
    }
}

// Handle ticket status change
if ($action === 'update_status' && $id > 0) {
    try {
        $db = Database::getInstance();
        
        $status = $_GET['status'] ?? 'open';
        $allowedStatuses = ['open', 'in_progress', 'resolved', 'closed'];
        
        if (!in_array($status, $allowedStatuses)) {
            throw new Exception('Yanlış status');
        }
        
        $updated = $db->update("
            UPDATE support_tickets 
            SET status = ?, admin_id = ?, last_activity = NOW()
            WHERE id = ?
        ", [$status, $currentUserId, $id]);
        
        if ($updated) {
            $_SESSION['success_message'] = "Ticket statusu yeniləndi: " . ucfirst($status);
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Status yenilənə bilmədi: " . $e->getMessage();
    }
    
    header('Location: ?page=support');
    exit;
}

// Get support tickets
try {
    $db = Database::getInstance();
    
    $status = $_GET['status_filter'] ?? '';
    $priority = $_GET['priority'] ?? '';
    $category = $_GET['category'] ?? '';
    $search = $_GET['search'] ?? '';
    $sortBy = $_GET['sort_by'] ?? 'created_at';
    $sortOrder = $_GET['sort_order'] ?? 'DESC';
    
    $sql = "SELECT st.*, 
            admin.full_name as admin_name,
            (SELECT COUNT(*) FROM support_replies sr WHERE sr.ticket_id = st.id) as reply_count,
            (SELECT MAX(created_at) FROM support_replies sr WHERE sr.ticket_id = st.id) as last_reply_date
            FROM support_tickets st
            LEFT JOIN users admin ON st.admin_id = admin.id
            WHERE 1=1";
    
    $params = [];
    
    if (!empty($status)) {
        $sql .= " AND st.status = ?";
        $params[] = $status;
    }
    
    if (!empty($priority)) {
        $sql .= " AND st.priority = ?";
        $params[] = $priority;
    }
    
    if (!empty($category)) {
        $sql .= " AND st.category = ?";
        $params[] = $category;
    }
    
    if (!empty($search)) {
        $sql .= " AND (st.subject LIKE ? OR st.user_name LIKE ? OR st.user_email LIKE ?)";
        $searchTerm = "%{$search}%";
        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
    }
    
    $allowedSorts = ['created_at', 'last_activity', 'priority', 'status', 'subject'];
    if (!in_array($sortBy, $allowedSorts)) $sortBy = 'created_at';
    if (!in_array($sortOrder, ['ASC', 'DESC'])) $sortOrder = 'DESC';
    
    $sql .= " ORDER BY st.{$sortBy} {$sortOrder}";
    
    $tickets = $db->selectAll($sql, $params);
    
    // Get statistics
    $stats = $db->selectOne("
        SELECT 
            COUNT(*) as total_tickets,
            SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END) as open_tickets,
            SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_tickets,
            SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolved_tickets,
            SUM(CASE WHEN status = 'closed' THEN 1 ELSE 0 END) as closed_tickets,
            SUM(CASE WHEN priority = 'high' THEN 1 ELSE 0 END) as high_priority_tickets,
            AVG(CASE WHEN status = 'resolved' THEN TIMESTAMPDIFF(HOUR, created_at, last_activity) ELSE NULL END) as avg_resolution_time
        FROM support_tickets
    ");
    
} catch (Exception $e) {
    $tickets = [];
    $stats = [
        'total_tickets' => 0, 'open_tickets' => 0, 'in_progress_tickets' => 0,
        'resolved_tickets' => 0, 'closed_tickets' => 0, 'high_priority_tickets' => 0,
        'avg_resolution_time' => 0
    ];
}

// View single ticket
if ($action === 'view' && $id > 0) {
    try {
        $db = Database::getInstance();
        
        $ticket = $db->selectOne("
            SELECT st.*, admin.full_name as admin_name
            FROM support_tickets st
            LEFT JOIN users admin ON st.admin_id = admin.id
            WHERE st.id = ?
        ", [$id]);
        
        if (!$ticket) {
            $_SESSION['error_message'] = "Ticket tapılmadı!";
            header('Location: ?page=support');
            exit;
        }
        
        // Get replies
        $replies = $db->selectAll("
            SELECT sr.*, u.full_name as user_name
            FROM support_replies sr
            LEFT JOIN users u ON sr.user_id = u.id
            WHERE sr.ticket_id = ?
            ORDER BY sr.created_at ASC
        ", [$id]);
        
        // Mark as viewed by admin
        $db->update("UPDATE support_tickets SET viewed_by_admin = 1 WHERE id = ?", [$id]);
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Ticket yüklənə bilmədi: " . $e->getMessage();
        header('Location: ?page=support');
        exit;
    }
}

$pageTitle = "Support İdarəetməsi - " . PWA_NAME;
include 'includes/header.php';
?>

<style>
.support-header {
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: white;
    padding: 30px;
    border-radius: 20px;
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
}

.support-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 200px;
    height: 200px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    text-align: center;
    border-left: 5px solid var(--primary-color);
    transition: var(--transition);
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
}

.stat-value {
    font-size: 2rem;
    font-weight: bold;
    color: var(--primary-color);
    margin-bottom: 8px;
}

.stat-label {
    color: #6c757d;
    font-size: 0.9rem;
}

.ticket-item {
    background: white;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    margin-bottom: 20px;
    overflow: hidden;
    transition: var(--transition);
    cursor: pointer;
}

.ticket-item:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.ticket-header {
    padding: 20px 25px;
    background: #f8f9fa;
    border-bottom: 1px solid #e9ecef;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.ticket-content {
    padding: 25px;
}

.ticket-footer {
    padding: 15px 25px;
    background: #f8f9fa;
    border-top: 1px solid #e9ecef;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.priority-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: bold;
    text-transform: uppercase;
}

.priority-low { background: #d4edda; color: #155724; }
.priority-medium { background: #fff3cd; color: #856404; }
.priority-high { background: #f8d7da; color: #721c24; }

.status-badge {
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: bold;
}

.status-open { background: #cce5ff; color: #004085; }
.status-in_progress { background: #fff3cd; color: #856404; }
.status-resolved { background: #d4edda; color: #155724; }
.status-closed { background: #e2e3e5; color: #383d41; }

.reply-section {
    background: white;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    margin-top: 30px;
    overflow: hidden;
}

.reply-item {
    padding: 20px 25px;
    border-bottom: 1px solid #f0f0f0;
}

.reply-item:last-child {
    border-bottom: none;
}

.reply-admin {
    background: linear-gradient(135deg, rgba(102, 126, 234, 0.1), rgba(118, 75, 162, 0.1));
}

.reply-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}

.reply-author {
    font-weight: bold;
    color: var(--primary-color);
}

.reply-time {
    font-size: 0.8rem;
    color: #6c757d;
}

.reply-content {
    line-height: 1.6;
    color: var(--dark-color);
}

.filters-panel {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    margin-bottom: 30px;
}

.quick-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.quick-action-btn {
    padding: 8px 15px;
    border-radius: 20px;
    border: none;
    cursor: pointer;
    font-size: 0.8rem;
    transition: var(--transition);
    text-decoration: none;
    color: white;
}

@media (max-width: 768px) {
    .ticket-header {
        flex-direction: column;
        align-items: stretch;
        gap: 15px;
    }
    
    .ticket-footer {
        flex-direction: column;
        align-items: stretch;
        gap: 10px;
    }
}
</style>

<?php if ($action === 'view' && isset($ticket)): ?>
    <!-- Single Ticket View -->
    <div style="margin-bottom: 20px;">
        <a href="?page=support" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Geri
        </a>
    </div>
    
    <div class="ticket-item">
        <div class="ticket-header">
            <div>
                <h3 style="margin: 0; color: var(--dark-color);">
                    <?= htmlspecialchars($ticket['subject']) ?>
                </h3>
                <div style="margin-top: 5px; font-size: 0.9rem; color: #6c757d;">
                    Ticket #<?= $ticket['id'] ?> • <?= date('d.m.Y H:i', strtotime($ticket['created_at'])) ?>
                </div>
            </div>
            
            <div style="display: flex; align-items: center; gap: 15px;">
                <span class="priority-badge priority-<?= $ticket['priority'] ?>">
                    <?= ucfirst($ticket['priority']) ?> Priority
                </span>
                
                <span class="status-badge status-<?= $ticket['status'] ?>">
                    <?= ucfirst(str_replace('_', ' ', $ticket['status'])) ?>
                </span>
            </div>
        </div>
        
        <div class="ticket-content">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 20px;">
                <div>
                    <h6 style="color: var(--primary-color); margin-bottom: 10px;">Müştəri Məlumatları</h6>
                    <div><strong>Ad:</strong> <?= htmlspecialchars($ticket['user_name']) ?></div>
                    <div><strong>Email:</strong> <?= htmlspecialchars($ticket['user_email']) ?></div>
                    <div><strong>Telefon:</strong> <?= htmlspecialchars($ticket['user_phone'] ?: 'Yoxdur') ?></div>
                </div>
                
                <div>
                    <h6 style="color: var(--primary-color); margin-bottom: 10px;">Ticket Məlumatları</h6>
                    <div><strong>Kateqoriya:</strong> <?= htmlspecialchars($ticket['category']) ?></div>
                    <div><strong>Admin:</strong> <?= htmlspecialchars($ticket['admin_name'] ?: 'Təyin edilməyib') ?></div>
                    <div><strong>Son aktivlik:</strong> <?= date('d.m.Y H:i', strtotime($ticket['last_activity'])) ?></div>
                </div>
            </div>
            
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px;">
                <h6 style="margin-bottom: 10px; color: var(--dark-color);">İlkin Mesaj:</h6>
                <div style="line-height: 1.6;">
                    <?= nl2br(htmlspecialchars($ticket['message'])) ?>
                </div>
            </div>
        </div>
        
        <div class="ticket-footer">
            <div class="quick-actions">
                <a href="?page=support&action=update_status&id=<?= $ticket['id'] ?>&status=in_progress" 
                   class="quick-action-btn" style="background: var(--warning-color);">
                    <i class="fas fa-play"></i> İşləmə Başla
                </a>
                
                <a href="?page=support&action=update_status&id=<?= $ticket['id'] ?>&status=resolved" 
                   class="quick-action-btn" style="background: var(--success-color);">
                    <i class="fas fa-check"></i> Həll Et
                </a>
                
                <a href="?page=support&action=update_status&id=<?= $ticket['id'] ?>&status=closed" 
                   class="quick-action-btn" style="background: var(--danger-color);">
                    <i class="fas fa-times"></i> Bağla
                </a>
                
                <button onclick="printTicket()" class="quick-action-btn" style="background: var(--info-color);">
                    <i class="fas fa-print"></i> Çap Et
                </button>
            </div>
        </div>
    </div>
    
    <!-- Replies Section -->
    <?php if (!empty($replies)): ?>
    <div class="reply-section">
        <div style="padding: 20px 25px; background: #f8f9fa; border-bottom: 1px solid #e9ecef;">
            <h5 style="margin: 0; color: var(--dark-color);">
                <i class="fas fa-comments"></i> Cavablar (<?= count($replies) ?>)
            </h5>
        </div>
        
        <?php foreach ($replies as $reply): ?>
            <div class="reply-item <?= $reply['is_admin_reply'] ? 'reply-admin' : '' ?>">
                <div class="reply-header">
                    <div class="reply-author">
                        <?php if ($reply['is_admin_reply']): ?>
                            <i class="fas fa-user-shield"></i> <?= htmlspecialchars($reply['user_name'] ?: 'Admin') ?>
                            <span style="font-size: 0.7rem; background: var(--primary-color); color: white; padding: 2px 6px; border-radius: 10px; margin-left: 8px;">ADMIN</span>
                        <?php else: ?>
                            <i class="fas fa-user"></i> Müştəri
                        <?php endif; ?>
                    </div>
                    
                    <div class="reply-time">
                        <i class="fas fa-clock"></i>
                        <?= date('d.m.Y H:i', strtotime($reply['created_at'])) ?>
                    </div>
                </div>
                
                <div class="reply-content">
                    <?= nl2br(htmlspecialchars($reply['message'])) ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    
    <!-- Reply Form -->
    <div style="background: white; border-radius: 15px; box-shadow: var(--box-shadow); padding: 30px; margin-top: 30px;">
        <h5 style="margin-bottom: 20px; color: var(--dark-color);">
            <i class="fas fa-reply"></i> Cavab Yaz
        </h5>
        
        <form method="POST">
            <input type="hidden" name="action" value="reply">
            <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
            
            <div class="form-group">
                <label>Cavab Mesajı *</label>
                <textarea name="message" rows="6" class="form-control" required placeholder="Müştəriyə cavabınızı yazın..."></textarea>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label>Ticket Statusu</label>
                    <select name="status" class="form-control">
                        <option value="open" <?= $ticket['status'] === 'open' ? 'selected' : '' ?>>Açıq</option>
                        <option value="in_progress" <?= $ticket['status'] === 'in_progress' ? 'selected' : '' ?>>İşlənir</option>
                        <option value="resolved" <?= $ticket['status'] === 'resolved' ? 'selected' : '' ?>>Həll Edildi</option>
                        <option value="closed" <?= $ticket['status'] === 'closed' ? 'selected' : '' ?>>Bağlandı</option>
                    </select>
                </div>
                
                <div style="display: flex; align-items: end; gap: 15px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> Cavab Göndər
                    </button>
                    
                    <button type="button" onclick="saveDraft()" class="btn btn-secondary">
                        <i class="fas fa-save"></i> Draft Saxla
                    </button>
                </div>
            </div>
        </form>
    </div>

<?php else: ?>
    <!-- Support Dashboard -->
    <div class="support-header">
        <div style="position: relative; z-index: 1;">
            <h1 style="margin-bottom: 10px;">🎧 Support İdarəetməsi</h1>
            <p style="opacity: 0.9; font-size: 1.1rem;">Müştəri dəstəyi və sorğu idarəetmə sistemi</p>
            <div style="margin-top: 15px;">
                <span style="background: rgba(255,255,255,0.2); padding: 8px 15px; border-radius: 20px; font-size: 0.9rem;">
                    <i class="fas fa-clock"></i> Son yeniləmə: <?= date('d.m.Y H:i') ?>
                </span>
            </div>
        </div>
    </div>
    
    <!-- Statistics -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-value"><?= $stats['total_tickets'] ?></div>
            <div class="stat-label">Cəmi Ticket</div>
        </div>
        
        <div class="stat-card" style="border-color: var(--info-color);">
            <div class="stat-value" style="color: var(--info-color);"><?= $stats['open_tickets'] ?></div>
            <div class="stat-label">Açıq Ticketlər</div>
        </div>
        
        <div class="stat-card" style="border-color: var(--warning-color);">
            <div class="stat-value" style="color: var(--warning-color);"><?= $stats['in_progress_tickets'] ?></div>
            <div class="stat-label">İşlənən</div>
        </div>
        
        <div class="stat-card" style="border-color: var(--success-color);">
            <div class="stat-value" style="color: var(--success-color);"><?= $stats['resolved_tickets'] ?></div>
            <div class="stat-label">Həll Edilən</div>
        </div>
        
        <div class="stat-card" style="border-color: var(--danger-color);">
            <div class="stat-value" style="color: var(--danger-color);"><?= $stats['high_priority_tickets'] ?></div>
            <div class="stat-label">Yüksək Prioritet</div>
        </div>
        
        <div class="stat-card" style="border-color: var(--secondary-color);">
            <div class="stat-value" style="color: var(--secondary-color);">
                <?= $stats['avg_resolution_time'] ? round($stats['avg_resolution_time']) . 'h' : '0h' ?>
            </div>
            <div class="stat-label">Orta Həll Vaxtı</div>
        </div>
    </div>
    
    <!-- Filters -->
    <div class="filters-panel">
        <h4 style="margin-bottom: 20px;">🔍 Filterlər və Axtarış</h4>
        
        <form method="GET">
            <input type="hidden" name="page" value="support">
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Axtarış</label>
                    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Mövzu, ad, email..." class="form-control">
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Status</label>
                    <select name="status_filter" class="form-control">
                        <option value="">Hamısı</option>
                        <option value="open" <?= $status === 'open' ? 'selected' : '' ?>>Açıq</option>
                        <option value="in_progress" <?= $status === 'in_progress' ? 'selected' : '' ?>>İşlənir</option>
                        <option value="resolved" <?= $status === 'resolved' ? 'selected' : '' ?>>Həll Edildi</option>
                        <option value="closed" <?= $status === 'closed' ? 'selected' : '' ?>>Bağlandı</option>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Prioritet</label>
                    <select name="priority" class="form-control">
                        <option value="">Hamısı</option>
                        <option value="low" <?= $priority === 'low' ? 'selected' : '' ?>>Aşağı</option>
                        <option value="medium" <?= $priority === 'medium' ? 'selected' : '' ?>>Orta</option>
                        <option value="high" <?= $priority === 'high' ? 'selected' : '' ?>>Yüksək</option>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Kateqoriya</label>
                    <select name="category" class="form-control">
                        <option value="">Hamısı</option>
                        <option value="technical" <?= $category === 'technical' ? 'selected' : '' ?>>Texniki</option>
                        <option value="billing" <?= $category === 'billing' ? 'selected' : '' ?>>Billing</option>
                        <option value="feature" <?= $category === 'feature' ? 'selected' : '' ?>>Funksiya</option>
                        <option value="other" <?= $category === 'other' ? 'selected' : '' ?>>Digər</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary" style="height: 47px;">
                    <i class="fas fa-search"></i> Filtrələ
                </button>
            </div>
        </form>
    </div>
    
    <!-- Tickets List -->
    <?php if (empty($tickets)): ?>
        <div style="text-align: center; padding: 60px 20px; color: #6c757d;">
            <i class="fas fa-ticket-alt" style="font-size: 4rem; margin-bottom: 20px; opacity: 0.3;"></i>
            <h4>Support ticket tapılmadı</h4>
            <p>Filterlərə uyğun ticket yoxdur və ya hələ heç bir müraciət daxil olmayıb.</p>
            <div style="margin-top: 20px;">
                <a href="?page=support" class="btn btn-secondary">
                    <i class="fas fa-refresh"></i> Sıfırla
                </a>
            </div>
        </div>
    <?php else: ?>
        <div style="margin-bottom: 30px;">
            <?php foreach ($tickets as $ticket): ?>
                <div class="ticket-item" onclick="window.location.href='?page=support&action=view&id=<?= $ticket['id'] ?>'">
                    <div class="ticket-header">
                        <div>
                            <h5 style="margin: 0; color: var(--dark-color);">
                                <?= htmlspecialchars($ticket['subject']) ?>
                            </h5>
                            <div style="margin-top: 5px; font-size: 0.85rem; color: #6c757d;">
                                <i class="fas fa-user"></i> <?= htmlspecialchars($ticket['user_name']) ?> • 
                                <i class="fas fa-envelope"></i> <?= htmlspecialchars($ticket['user_email']) ?> • 
                                <i class="fas fa-clock"></i> <?= date('d.m.Y H:i', strtotime($ticket['created_at'])) ?>
                            </div>
                        </div>
                        
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span class="priority-badge priority-<?= $ticket['priority'] ?>">
                                <?= ucfirst($ticket['priority']) ?>
                            </span>
                            
                            <span class="status-badge status-<?= $ticket['status'] ?>">
                                <?= ucfirst(str_replace('_', ' ', $ticket['status'])) ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="ticket-content">
                        <div style="color: #6c757d; margin-bottom: 15px; font-size: 0.9rem;">
                            <strong>Kateqoriya:</strong> <?= htmlspecialchars($ticket['category']) ?>
                        </div>
                        
                        <div style="line-height: 1.6; color: var(--dark-color);">
                            <?= nl2br(htmlspecialchars(substr($ticket['message'], 0, 200))) ?>
                            <?= strlen($ticket['message']) > 200 ? '...' : '' ?>
                        </div>
                    </div>
                    
                    <div class="ticket-footer">
                        <div style="display: flex; align-items: center; gap: 15px; font-size: 0.85rem; color: #6c757d;">
                            <span>
                                <i class="fas fa-comments"></i> <?= $ticket['reply_count'] ?> cavab
                            </span>
                            
                            <?php if ($ticket['admin_name']): ?>
                                <span>
                                    <i class="fas fa-user-shield"></i> <?= htmlspecialchars($ticket['admin_name']) ?>
                                </span>
                            <?php endif; ?>
                            
                            <?php if ($ticket['last_reply_date']): ?>
                                <span>
                                    <i class="fas fa-reply"></i> Son cavab: <?= date('d.m H:i', strtotime($ticket['last_reply_date'])) ?>
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="quick-actions">
                            <button onclick="event.stopPropagation(); updateTicketStatus(<?= $ticket['id'] ?>, 'in_progress')" 
                                    class="quick-action-btn" style="background: var(--warning-color);" title="İşləmə Başla">
                                <i class="fas fa-play"></i>
                            </button>
                            
                            <button onclick="event.stopPropagation(); updateTicketStatus(<?= $ticket['id'] ?>, 'resolved')" 
                                    class="quick-action-btn" style="background: var(--success-color);" title="Həll Et">
                                <i class="fas fa-check"></i>
                            </button>
                            
                            <button onclick="event.stopPropagation(); window.location.href='?page=support&action=view&id=<?= $ticket['id'] ?>'" 
                                    class="quick-action-btn" style="background: var(--info-color);" title="Bax">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Summary -->
        <div style="background: linear-gradient(135deg, #f8f9fa, #e9ecef); padding: 25px; border-radius: 15px; margin-top: 30px;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 20px; text-align: center;">
                <div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--primary-color);">
                        <?= count($tickets) ?>
                    </div>
                    <div style="font-size: 0.9rem; color: #6c757d;">Göstərilən Ticket</div>
                </div>
                
                <div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--info-color);">
                        <?= count(array_filter($tickets, function($t) { return $t['status'] === 'open'; })) ?>
                    </div>
                    <div style="font-size: 0.9rem; color: #6c757d;">Açıq</div>
                </div>
                
                <div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--warning-color);">
                        <?= count(array_filter($tickets, function($t) { return $t['priority'] === 'high'; })) ?>
                    </div>
                    <div style="font-size: 0.9rem; color: #6c757d;">Yüksək Prioritet</div>
                </div>
                
                <div>
                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--success-color);">
                        <?= round(array_sum(array_column($tickets, 'reply_count')) / max(count($tickets), 1), 1) ?>
                    </div>
                    <div style="font-size: 0.9rem; color: #6c757d;">Orta Cavab Sayı</div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<script>
function updateTicketStatus(ticketId, status) {
    if (confirm(`Ticket statusunu "${status}" olaraq dəyişdirmək istəyirsiniz?`)) {
        window.location.href = `?page=support&action=update_status&id=${ticketId}&status=${status}`;
    }
}

function printTicket() {
    window.print();
}

function saveDraft() {
    const message = document.querySelector('textarea[name="message"]').value;
    const ticketId = document.querySelector('input[name="ticket_id"]').value;
    
    if (message.trim()) {
        localStorage.setItem(`draft_ticket_${ticketId}`, message);
        
        // Show toast notification
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--success-color);
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            z-index: 2000;
            animation: slideUp 0.3s ease;
        `;
        toast.innerHTML = '<i class="fas fa-check"></i> Draft saxlanıldı';
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }
}

// Load draft on page load
document.addEventListener('DOMContentLoaded', function() {
    const ticketIdInput = document.querySelector('input[name="ticket_id"]');
    if (ticketIdInput) {
        const ticketId = ticketIdInput.value;
        const draft = localStorage.getItem(`draft_ticket_${ticketId}`);
        
        if (draft) {
            const textarea = document.querySelector('textarea[name="message"]');
            if (textarea && !textarea.value) {
                textarea.value = draft;
                
                // Show draft indicator
                const indicator = document.createElement('div');
                indicator.style.cssText = `
                    background: #fff3cd;
                    color: #856404;
                    padding: 10px;
                    border-radius: 5px;
                    margin-bottom: 10px;
                    font-size: 0.9rem;
                `;
                indicator.innerHTML = '<i class="fas fa-info-circle"></i> Draft mətn yükləndi';
                
                textarea.parentNode.insertBefore(indicator, textarea);
            }
        }
    }
});

// Auto-refresh for new tickets
setInterval(() => {
    // In production, check for new tickets via AJAX
    console.log('Checking for new support tickets...');
}, 30000);

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl+R - Refresh
    if (e.ctrlKey && e.key === 'r') {
        e.preventDefault();
        location.reload();
    }
    
    // Ctrl+F - Focus search
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }
});

console.log('Support system initialized');
console.log('Total tickets loaded:', <?= count($tickets) ?>);
console.log('Statistics:', <?= json_encode($stats) ?>);
</script>

<?php include 'includes/footer.php'; ?>