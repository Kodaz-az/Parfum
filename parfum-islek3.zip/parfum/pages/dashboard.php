<?php
/**
 * Dashboard Səhifəsi - Ana İdarə Paneli
 * Kodaz-az - 2025-07-21 14:18:30 (UTC)
 * Login: Kodaz-az
 */

// Database və statistika məlumatları
try {
    $db = Database::getInstance();
    
    // Cari istifadəçi məlumatları
    $currentUser = [
        'id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'full_name' => $_SESSION['full_name'],
        'role' => $_SESSION['role'],
        'email' => $_SESSION['email'] ?? ''
    ];
    
    // Bugünkü statistikalar
    $todayStats = $db->selectOne("
        SELECT 
            COUNT(*) as sales_count,
            COALESCE(SUM(final_amount), 0) as total_revenue,
            COALESCE(SUM(subtotal), 0) as subtotal,
            COALESCE(SUM(tax_amount), 0) as tax_amount,
            COALESCE(AVG(final_amount), 0) as avg_sale
        FROM sales 
        WHERE DATE(created_at) = CURDATE()" . 
        ($currentUser['role'] === 'seller' ? " AND user_id = " . $currentUser['id'] : '')
    );
    
    // Bu həftəki statistikalar
    $weekStats = $db->selectOne("
        SELECT 
            COUNT(*) as sales_count,
            COALESCE(SUM(final_amount), 0) as total_revenue
        FROM sales 
        WHERE YEARWEEK(created_at) = YEARWEEK(NOW())" .
        ($currentUser['role'] === 'seller' ? " AND user_id = " . $currentUser['id'] : '')
    );
    
    // Bu aylıq statistikalar
    $monthStats = $db->selectOne("
        SELECT 
            COUNT(*) as sales_count,
            COALESCE(SUM(final_amount), 0) as total_revenue
        FROM sales 
        WHERE MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())" .
        ($currentUser['role'] === 'seller' ? " AND user_id = " . $currentUser['id'] : '')
    );
    
    // Son 7 günün statistikası (grafik üçün)
    $weeklyChart = $db->selectAll("
        SELECT 
            DATE(created_at) as sale_date,
            COUNT(*) as daily_sales,
            COALESCE(SUM(final_amount), 0) as daily_revenue
        FROM sales 
        WHERE DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)" .
        ($currentUser['role'] === 'seller' ? " AND user_id = " . $currentUser['id'] : '') . "
        GROUP BY DATE(created_at)
        ORDER BY sale_date DESC
        LIMIT 7
    ");
    
    // Son satışlar
    $recentSales = $db->selectAll("
        SELECT s.*, u.full_name as seller_name
        FROM sales s
        LEFT JOIN users u ON s.user_id = u.id
        WHERE 1=1" . 
        ($currentUser['role'] === 'seller' ? " AND s.user_id = " . $currentUser['id'] : '') . "
        ORDER BY s.created_at DESC
        LIMIT 8
    ");
    
    // Məhsul statistikaları
    $productStats = $db->selectOne("
        SELECT 
            COUNT(*) as total_products,
            SUM(CASE WHEN stock_quantity <= min_stock THEN 1 ELSE 0 END) as low_stock_count,
            SUM(CASE WHEN stock_quantity = 0 THEN 1 ELSE 0 END) as out_of_stock_count,
            SUM(stock_quantity) as total_stock
        FROM products 
        WHERE is_active = 1
    ");
    
    // Online istifadəçilər (son 5 dəqiqədə aktiv olanlar)
    $onlineUsers = $db->selectAll("
        SELECT id, full_name, role, last_activity
        FROM users 
        WHERE is_active = 1 
        AND last_activity >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        AND id != ?
        ORDER BY last_activity DESC
        LIMIT 6
    ", [$currentUser['id']]);
    
    // Az qalan məhsullar
    $lowStockProducts = $db->selectAll("
        SELECT name, brand, stock_quantity, min_stock
        FROM products 
        WHERE stock_quantity <= min_stock AND is_active = 1 
        ORDER BY stock_quantity ASC 
        LIMIT 5
    ");
    
    // Top satılan məhsullar (bu ay)
    $topProducts = $db->selectAll("
        SELECT 
            p.name,
            p.brand,
            SUM(sd.quantity) as total_sold,
            SUM(sd.total_price) as total_revenue
        FROM sale_details sd
        JOIN products p ON sd.product_id = p.id
        JOIN sales s ON sd.sale_id = s.id
        WHERE MONTH(s.created_at) = MONTH(NOW()) 
        AND YEAR(s.created_at) = YEAR(NOW())" .
        ($currentUser['role'] === 'seller' ? " AND s.user_id = " . $currentUser['id'] : '') . "
        GROUP BY p.id
        ORDER BY total_sold DESC
        LIMIT 5
    ");
    
    // Performans məlumatları (əvvəlki ayla müqayisə)
    $lastMonthStats = $db->selectOne("
        SELECT 
            COUNT(*) as sales_count,
            COALESCE(SUM(final_amount), 0) as total_revenue
        FROM sales 
        WHERE MONTH(created_at) = MONTH(NOW()) - 1 
        AND YEAR(created_at) = YEAR(NOW())" .
        ($currentUser['role'] === 'seller' ? " AND user_id = " . $currentUser['id'] : '')
    );
    
    // Həftəlik performans trendi (son 4 həftə)
    $weeklyTrend = $db->selectAll("
        SELECT 
            WEEK(created_at) as week_num,
            COUNT(*) as weekly_sales,
            SUM(final_amount) as weekly_revenue
        FROM sales 
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 4 WEEK)" .
        ($currentUser['role'] === 'seller' ? " AND user_id = " . $currentUser['id'] : '') . "
        GROUP BY WEEK(created_at)
        ORDER BY week_num DESC
        LIMIT 4
    ");
    
} catch (Exception $e) {
    // Default values in case of error
    $todayStats = ['sales_count' => 0, 'total_revenue' => 0, 'subtotal' => 0, 'tax_amount' => 0, 'avg_sale' => 0];
    $weekStats = ['sales_count' => 0, 'total_revenue' => 0];
    $monthStats = ['sales_count' => 0, 'total_revenue' => 0];
    $lastMonthStats = ['sales_count' => 0, 'total_revenue' => 0];
    $recentSales = [];
    $onlineUsers = [];
    $lowStockProducts = [];
    $topProducts = [];
    $productStats = ['total_products' => 0, 'low_stock_count' => 0, 'out_of_stock_count' => 0, 'total_stock' => 0];
    $weeklyChart = [];
    $weeklyTrend = [];
}

// Helper functions
function formatMoney($amount) {
    return '₼' . number_format($amount, 2);
}

function timeAgo($datetime) {
    $time = time() - strtotime($datetime);
    
    if ($time < 60) return 'İndi';
    if ($time < 3600) return floor($time/60) . ' dəq əvvəl';
    if ($time < 86400) return floor($time/3600) . ' saat əvvəl';
    if ($time < 2592000) return floor($time/86400) . ' gün əvvəl';
    return date('d.m.Y', strtotime($datetime));
}

function calculatePercentageChange($current, $previous) {
    if ($previous == 0) return $current > 0 ? 100 : 0;
    return round((($current - $previous) / $previous) * 100, 1);
}

$pageTitle = "Ana Səhifə - " . PWA_NAME;
include 'includes/header.php';
?>

<style>
.dashboard-welcome {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    border-radius: 20px;
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
}

.dashboard-welcome::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 200px;
    height: 200px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
}

.welcome-content {
    position: relative;
    z-index: 1;
}

.welcome-time {
    font-size: 0.9rem;
    opacity: 0.9;
    margin-top: 10px;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 25px;
    margin-bottom: 30px;
}

.stat-card {
    background: var(--white);
    padding: 25px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    position: relative;
    transition: var(--transition);
    cursor: pointer;
    border-left: 5px solid var(--primary-color);
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
}

.stat-card.success { border-left-color: var(--success-color); }
.stat-card.warning { border-left-color: var(--warning-color); }
.stat-card.danger { border-left-color: var(--danger-color); }
.stat-card.info { border-left-color: var(--info-color); }

.stat-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.stat-icon {
    width: 50px;
    height: 50px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: white;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
}

.stat-icon.success { background: linear-gradient(135deg, var(--success-color), #20c997); }
.stat-icon.warning { background: linear-gradient(135deg, var(--warning-color), #ffb300); }
.stat-icon.danger { background: linear-gradient(135deg, var(--danger-color), #e74c3c); }
.stat-icon.info { background: linear-gradient(135deg, var(--info-color), #138496); }

.stat-number {
    font-size: 2.2rem;
    font-weight: bold;
    color: var(--dark-color);
    margin-bottom: 5px;
}

.stat-label {
    color: #6c757d;
    font-size: 0.9rem;
    margin-bottom: 10px;
}

.stat-change {
    font-size: 0.8rem;
    padding: 4px 8px;
    border-radius: 20px;
    font-weight: 600;
}

.stat-change.positive {
    background: rgba(40, 167, 69, 0.1);
    color: var(--success-color);
}

.stat-change.negative {
    background: rgba(220, 53, 69, 0.1);
    color: var(--danger-color);
}

.dashboard-grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 30px;
    margin-bottom: 30px;
}

.dashboard-card {
    background: var(--white);
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    overflow: hidden;
}

.card-header {
    padding: 20px 25px;
    border-bottom: 1px solid #e9ecef;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #f8f9fa;
}

.card-title {
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--dark-color);
    margin: 0;
    display: flex;
    align-items: center;
    gap: 10px;
}

.card-content {
    padding: 25px;
}

.quick-actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.quick-action {
    background: var(--white);
    padding: 25px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    text-decoration: none;
    color: inherit;
    text-align: center;
    transition: var(--transition);
    border: 2px solid transparent;
}

.quick-action:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
    border-color: var(--primary-color);
    text-decoration: none;
    color: inherit;
}

.quick-action-icon {
    font-size: 2.5rem;
    margin-bottom: 15px;
    color: var(--primary-color);
}

.quick-action-title {
    font-weight: bold;
    margin-bottom: 8px;
    color: var(--dark-color);
}

.quick-action-desc {
    font-size: 0.85rem;
    color: #6c757d;
}

.chart-container {
    background: var(--white);
    padding: 25px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    margin-bottom: 30px;
}

.sales-list {
    max-height: 400px;
    overflow-y: auto;
}

.sale-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 0;
    border-bottom: 1px solid #f0f0f0;
    transition: var(--transition);
}

.sale-item:hover {
    background: #f8f9fa;
    margin: 0 -25px;
    padding: 15px 25px;
}

.sale-item:last-child {
    border-bottom: none;
}

.sale-info {
    flex: 1;
}

.sale-number {
    font-weight: bold;
    color: var(--primary-color);
    margin-bottom: 5px;
}

.sale-details {
    font-size: 0.85rem;
    color: #6c757d;
}

.sale-amount {
    text-align: right;
}

.sale-price {
    font-weight: bold;
    color: var(--success-color);
    font-size: 1.1rem;
}

.sale-time {
    font-size: 0.8rem;
    color: #adb5bd;
    margin-top: 3px;
}

.online-users-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.online-user {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    background: #f8f9fa;
    border-radius: 10px;
    transition: var(--transition);
}

.online-user:hover {
    background: #e3f2fd;
}

.user-avatar-small {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: var(--primary-color);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    position: relative;
}

.online-indicator {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 10px;
    height: 10px;
    background: var(--success-color);
    border: 2px solid white;
    border-radius: 50%;
}

.user-details {
    flex: 1;
    min-width: 0;
}

.user-name {
    font-weight: 600;
    font-size: 0.9rem;
    margin-bottom: 2px;
}

.user-role {
    font-size: 0.75rem;
    color: #6c757d;
    text-transform: capitalize;
}

.product-list {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.product-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px;
    background: #f8f9fa;
    border-radius: 8px;
}

.product-name {
    font-weight: 600;
    font-size: 0.9rem;
}

.product-brand {
    font-size: 0.8rem;
    color: #6c757d;
}

.stock-badge {
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 0.75rem;
    font-weight: 600;
}

.stock-critical {
    background: #f8d7da;
    color: #721c24;
}

.stock-low {
    background: #fff3cd;
    color: #856404;
}

.empty-state {
    text-align: center;
    padding: 40px 20px;
    color: #6c757d;
}

.empty-state-icon {
    font-size: 3rem;
    margin-bottom: 15px;
    opacity: 0.3;
}

@media (max-width: 1024px) {
    .dashboard-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .quick-actions-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .dashboard-welcome {
        padding: 20px;
    }
    
    .stat-card {
        padding: 20px;
    }
}
</style>

<!-- Welcome Section -->
<div class="dashboard-welcome">
    <div class="welcome-content">
        <h1>🎯 Xoş gəlmisiniz, <?= htmlspecialchars($currentUser['full_name']) ?>!</h1>
        <p style="font-size: 1.1rem; margin: 10px 0 0 0; opacity: 0.95;">
            <?php 
            $hour = date('H');
            if ($hour < 12) echo "☀️ Gün xeyir! ";
            elseif ($hour < 17) echo "🌤️ Günortanız xeyir! ";
            else echo "🌙 Axşamınız xeyir! ";
            ?>
            Bu gün də uğurlu satışlar üçün hazırsınız!
        </p>
        <div class="welcome-time">
            📅 <?= date('l, d F Y') ?> | 🕐 <span class="live-time"><?= date('H:i:s') ?></span> | 
            🎭 <?= ucfirst($currentUser['role']) ?>
        </div>
    </div>
</div>

<!-- Main Statistics -->
<div class="stats-grid">
    <div class="stat-card" onclick="window.location.href='?page=sales'">
        <div class="stat-header">
            <div class="stat-icon">
                <i class="fas fa-calendar-day"></i>
            </div>
            <div class="stat-change positive">
                <i class="fas fa-arrow-up"></i> Bugün
            </div>
        </div>
        <div class="stat-number"><?= formatMoney($todayStats['total_revenue']) ?></div>
        <div class="stat-label">Bugünkü Satış</div>
        <small style="color: #6c757d;"><?= $todayStats['sales_count'] ?> əməliyyat • Orta: <?= formatMoney($todayStats['avg_sale']) ?></small>
    </div>
    
    <div class="stat-card success" onclick="window.location.href='?page=sales'">
        <div class="stat-header">
            <div class="stat-icon success">
                <i class="fas fa-chart-line"></i>
            </div>
            <div class="stat-change <?= calculatePercentageChange($monthStats['total_revenue'], $lastMonthStats['total_revenue']) >= 0 ? 'positive' : 'negative' ?>">
                <i class="fas fa-arrow-<?= calculatePercentageChange($monthStats['total_revenue'], $lastMonthStats['total_revenue']) >= 0 ? 'up' : 'down' ?>"></i>
                <?= abs(calculatePercentageChange($monthStats['total_revenue'], $lastMonthStats['total_revenue'])) ?>%
            </div>
        </div>
        <div class="stat-number"><?= formatMoney($monthStats['total_revenue']) ?></div>
        <div class="stat-label">Bu Aylıq Satış</div>
        <small style="color: #6c757d;"><?= $monthStats['sales_count'] ?> satış • Həftəlik: <?= formatMoney($weekStats['total_revenue']) ?></small>
    </div>
    
    <div class="stat-card info" onclick="window.location.href='?page=products'">
        <div class="stat-header">
            <div class="stat-icon info">
                <i class="fas fa-boxes"></i>
            </div>
            <?php if ($productStats['low_stock_count'] > 0): ?>
                <div class="stat-change negative">
                    <i class="fas fa-exclamation-triangle"></i> <?= $productStats['low_stock_count'] ?> az
                </div>
            <?php else: ?>
                <div class="stat-change positive">
                    <i class="fas fa-check"></i> Normal
                </div>
            <?php endif; ?>
        </div>
        <div class="stat-number"><?= number_format($productStats['total_products']) ?></div>
        <div class="stat-label">Cəmi Məhsul</div>
        <small style="color: #6c757d;">Stok: <?= number_format($productStats['total_stock']) ?> • Bitən: <?= $productStats['out_of_stock_count'] ?></small>
    </div>
    
    <div class="stat-card warning" onclick="window.location.href='?page=users'">
        <div class="stat-header">
            <div class="stat-icon warning">
                <i class="fas fa-users"></i>
            </div>
            <div class="stat-change positive">
                <i class="fas fa-circle"></i> <?= count($onlineUsers) ?> online
            </div>
        </div>
        <div class="stat-number"><?= count($onlineUsers) + 1 ?></div>
        <div class="stat-label">Aktiv Komanda</div>
        <small style="color: #6c757d;">Siz daxil olmaqla</small>
    </div>
</div>

<!-- Quick Actions -->
<div class="quick-actions-grid">
    <a href="?page=sales&action=new" class="quick-action">
        <div class="quick-action-icon">🛒</div>
        <div class="quick-action-title">Yeni Satış</div>
        <div class="quick-action-desc">POS sistemi ilə tez satış</div>
    </a>
    
    <a href="?page=products&action=add" class="quick-action">
        <div class="quick-action-icon">📦</div>
        <div class="quick-action-title">Məhsul Əlavə Et</div>
        <div class="quick-action-desc">Inventara yeni məhsul</div>
    </a>
    
    <a href="?page=reports" class="quick-action">
        <div class="quick-action-icon">📊</div>
        <div class="quick-action-title">Hesabat Al</div>
        <div class="quick-action-desc">Analiz və statistika</div>
    </a>
    
    <a href="?page=chat" class="quick-action">
        <div class="quick-action-icon">💬</div>
        <div class="quick-action-title">Team Chat</div>
        <div class="quick-action-desc">Komanda ilə əlaqə</div>
    </a>
</div>

<!-- Charts Section -->
<?php if (!empty($weeklyChart)): ?>
<div class="chart-container">
    <h4 style="margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
        <i class="fas fa-chart-area"></i> Son 7 Günün Satış Trendi
    </h4>
    <canvas id="weeklyChart" style="max-height: 300px;"></canvas>
</div>
<?php endif; ?>

<!-- Main Dashboard Grid -->
<div class="dashboard-grid">
    <!-- Recent Sales -->
    <div class="dashboard-card">
        <div class="card-header">
            <h5 class="card-title">
                <i class="fas fa-shopping-cart"></i> Son Satışlar
            </h5>
            <a href="?page=sales" style="color: var(--primary-color); text-decoration: none; font-size: 0.9rem;">
                Hamısını gör →
            </a>
        </div>
        <div class="card-content">
            <?php if (empty($recentSales)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">🛒</div>
                    <h5>Hələ satış yoxdur</h5>
                    <p>İlk satışınızı etmək üçün POS sistemini istifadə edin</p>
                    <a href="?page=sales&action=new" class="btn btn-primary" style="margin-top: 15px;">
                        🚀 İlk Satışı Et
                    </a>
                </div>
            <?php else: ?>
                <div class="sales-list">
                    <?php foreach ($recentSales as $sale): ?>
                        <div class="sale-item">
                            <div class="sale-info">
                                <div class="sale-number">#<?= htmlspecialchars($sale['sale_number']) ?></div>
                                <div class="sale-details">
                                    <?php if ($currentUser['role'] !== 'seller'): ?>
                                        👤 <?= htmlspecialchars($sale['seller_name']) ?>
                                    <?php endif; ?>
                                    <?= $sale['customer_name'] ? ' • 👥 ' . htmlspecialchars($sale['customer_name']) : '' ?>
                                    <?= $sale['customer_phone'] ? ' • 📞 ' . htmlspecialchars($sale['customer_phone']) : '' ?>
                                </div>
                            </div>
                            <div class="sale-amount">
                                <div class="sale-price"><?= formatMoney($sale['final_amount']) ?></div>
                                <div class="sale-time">
                                    🕐 <?= timeAgo($sale['created_at']) ?> • 📦 <?= $sale['total_items'] ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Right Sidebar -->
    <div style="display: flex; flex-direction: column; gap: 20px;">
        <!-- Online Users -->
        <div class="dashboard-card">
            <div class="card-header">
                <h6 class="card-title">
                    <i class="fas fa-users"></i> Online Komanda
                </h6>
                <span style="font-size: 0.8rem; color: var(--success-color);">
                    <i class="fas fa-circle"></i> <?= count($onlineUsers) ?> online
                </span>
            </div>
            <div class="card-content">
                <?php if (empty($onlineUsers)): ?>
                    <div style="text-align: center; padding: 20px; color: #6c757d;">
                        <i class="fas fa-user-slash" style="font-size: 1.5rem; margin-bottom: 10px; opacity: 0.3;"></i>
                        <p>Başqa istifadəçi online deyil</p>
                    </div>
                <?php else: ?>
                    <div class="online-users-list">
                        <?php foreach ($onlineUsers as $user): ?>
                            <div class="online-user">
                                <div class="user-avatar-small">
                                    <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                                    <span class="online-indicator"></span>
                                </div>
                                <div class="user-details">
                                    <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
                                    <div class="user-role"><?= $user['role'] ?></div>
                                </div>
                                <div style="display: flex; gap: 5px;">
                                    <button onclick="startChat(<?= $user['id'] ?>)" style="background: none; border: none; color: var(--primary-color); cursor: pointer; padding: 5px;" title="Chat">
                                        <i class="fas fa-comment"></i>
                                    </button>
                                    <button onclick="startCall(<?= $user['id'] ?>)" style="background: none; border: none; color: var(--success-color); cursor: pointer; padding: 5px;" title="Zəng">
                                        <i class="fas fa-phone"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Low Stock Alert -->
        <?php if (!empty($lowStockProducts)): ?>
        <div class="dashboard-card">
            <div class="card-header">
                <h6 class="card-title">
                    <i class="fas fa-exclamation-triangle"></i> Az Stok Xəbərdarlığı
                </h6>
                <span style="font-size: 0.8rem; color: var(--danger-color);">
                    <?= count($lowStockProducts) ?> məhsul
                </span>
            </div>
            <div class="card-content">
                <div class="product-list">
                    <?php foreach ($lowStockProducts as $product): ?>
                        <div class="product-item">
                            <div>
                                <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
                                <div class="product-brand"><?= htmlspecialchars($product['brand']) ?></div>
                            </div>
                            <div class="stock-badge <?= $product['stock_quantity'] == 0 ? 'stock-critical' : 'stock-low' ?>">
                                <?= $product['stock_quantity'] ?>/<?= $product['min_stock'] ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div style="text-align: center; margin-top: 15px;">
                    <a href="?page=products" class="btn btn-warning btn-sm">
                        📦 Məhsulları İdarə Et
                    </a>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Top Products -->
        <?php if (!empty($topProducts)): ?>
        <div class="dashboard-card">
            <div class="card-header">
                <h6 class="card-title">
                    <i class="fas fa-star"></i> Top Məhsullar
                </h6>
                <span style="font-size: 0.8rem; color: var(--info-color);">Bu ay</span>
            </div>
            <div class="card-content">
                <div class="product-list">
                    <?php foreach ($topProducts as $index => $product): ?>
                        <div class="product-item">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <span style="width: 20px; height: 20px; border-radius: 50%; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center; font-size: 0.7rem; font-weight: bold;">
                                    <?= $index + 1 ?>
                                </span>
                                <div>
                                    <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
                                    <div class="product-brand"><?= htmlspecialchars($product['brand']) ?></div>
                                </div>
                            </div>
                            <div style="text-align: right; font-size: 0.8rem;">
                                <div style="font-weight: bold; color: var(--success-color);">
                                    <?= $product['total_sold'] ?> sat.
                                </div>
                                <div style="color: #6c757d;">
                                    <?= formatMoney($product['total_revenue']) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- System Info Footer -->
<div style="background: linear-gradient(135deg, #f8f9fa, #e9ecef); padding: 25px; border-radius: 15px; margin-top: 30px;">
    <h5 style="margin-bottom: 20px; color: var(--dark-color);">
        <i class="fas fa-info-circle"></i> Sistem Məlumatları
    </h5>
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
        <div style="text-align: center; background: white; padding: 15px; border-radius: 10px;">
            <div style="font-size: 1.5rem; color: var(--primary-color); margin-bottom: 5px;">📱</div>
            <div style="font-weight: bold;">Versiya</div>
            <div style="color: #6c757d; font-size: 0.9rem;">v<?= APP_VERSION ?></div>
        </div>
        
        <div style="text-align: center; background: white; padding: 15px; border-radius: 10px;">
            <div style="font-size: 1.5rem; color: var(--success-color); margin-bottom: 5px;">🌐</div>
            <div style="font-weight: bold;">Status</div>
            <div style="color: var(--success-color); font-size: 0.9rem;">✅ Aktiv</div>
        </div>
        
        <div style="text-align: center; background: white; padding: 15px; border-radius: 10px;">
            <div style="font-size: 1.5rem; color: var(--info-color); margin-bottom: 5px;">👨‍💻</div>
            <div style="font-weight: bold;">Developer</div>
            <div style="color: #6c757d; font-size: 0.9rem;">Kodaz.az</div>
        </div>
        
        <div style="text-align: center; background: white; padding: 15px; border-radius: 10px;">
            <div style="font-size: 1.5rem; color: var(--warning-color); margin-bottom: 5px;">🕐</div>
            <div style="font-weight: bold;">Server Vaxtı</div>
            <div style="color: #6c757d; font-size: 0.9rem;">
                <span class="live-time"><?= date('H:i:s') ?></span>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Real-time clock update
function updateClock() {
    const now = new Date();
    const timeElements = document.querySelectorAll('.live-time');
    timeElements.forEach(el => {
        el.textContent = now.toLocaleTimeString('az-AZ');
    });
}
setInterval(updateClock, 1000);

// Chart initialization
<?php if (!empty($weeklyChart)): ?>
const ctx = document.getElementById('weeklyChart').getContext('2d');
const chart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [<?= implode(',', array_map(function($day) { 
            return '"' . date('d.m', strtotime($day['sale_date'])) . '"'; 
        }, array_reverse($weeklyChart))) ?>],
        datasets: [{
            label: 'Gündəlik Satış (₼)',
            data: [<?= implode(',', array_column(array_reverse($weeklyChart), 'daily_revenue')) ?>],
            borderColor: '#667eea',
            backgroundColor: 'rgba(102, 126, 234, 0.1)',
            tension: 0.4,
            fill: true,
            pointBackgroundColor: '#667eea',
            pointBorderColor: '#ffffff',
            pointBorderWidth: 2,
            pointRadius: 6,
            pointHoverRadius: 8
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: 'rgba(0, 0, 0, 0.8)',
                titleColor: '#ffffff',
                bodyColor: '#ffffff',
                borderColor: '#667eea',
                borderWidth: 1,
                cornerRadius: 8,
                displayColors: false,
                callbacks: {
                    label: function(context) {
                        return 'Satış: ₼' + context.parsed.y.toLocaleString('az-AZ');
                    }
                }
            }
        },
        scales: {
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    color: '#6c757d'
                }
            },
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(0, 0, 0, 0.1)'
                },
                ticks: {
                    color: '#6c757d',
                    callback: function(value) {
                        return '₼' + value.toLocaleString('az-AZ');
                    }
                }
            }
        },
        interaction: {
            mode: 'nearest',
            axis: 'x',
            intersect: false
        }
    }
});
<?php endif; ?>

// User interaction functions
function startChat(userId) {
    window.location.href = `?page=chat&user=${userId}`;
}

function startCall(userId) {
    window.location.href = `?page=calls&user=${userId}`;
}

// Stats card hover effects
document.querySelectorAll('.stat-card').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-5px)';
        this.style.boxShadow = '0 10px 30px rgba(0,0,0,0.15)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
        this.style.boxShadow = 'var(--box-shadow)';
    });
});

// Quick action hover effects
document.querySelectorAll('.quick-action').forEach(action => {
    action.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-5px)';
        this.style.borderColor = 'var(--primary-color)';
    });
    
    action.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
        this.style.borderColor = 'transparent';
    });
});

// Auto refresh dashboard data every 30 seconds
setInterval(function() {
    // In a real implementation, this would fetch updated data via AJAX
    console.log('Dashboard auto-refresh triggered');
}, 30000);

// Performance monitoring
console.log('Dashboard loaded successfully');
console.log('User: <?= $currentUser['username'] ?>', 'Role: <?= $currentUser['role'] ?>');
console.log('Today Sales: <?= $todayStats['sales_count'] ?>', 'Revenue: ₼<?= $todayStats['total_revenue'] ?>');
console.log('Online Users: <?= count($onlineUsers) ?>', 'Low Stock: <?= $productStats['low_stock_count'] ?>');

// PWA app install prompt handling
let deferredPrompt;
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    
    // Show install button or notification
    const installBanner = document.createElement('div');
    installBanner.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 20px;
        background: linear-gradient(135deg, #667eea, #764ba2);
        color: white;
        padding: 15px 20px;
        border-radius: 10px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        z-index: 1000;
        display: flex;
        align-items: center;
        gap: 15px;
        max-width: 300px;
    `;
    
    installBanner.innerHTML = `
        <i class="fas fa-download" style="font-size: 1.2rem;"></i>
        <div style="flex: 1;">
            <div style="font-weight: bold; margin-bottom: 3px;">Tətbiqi Quraşdır</div>
            <div style="font-size: 0.8rem; opacity: 0.9;">Daha sürətli giriş üçün</div>
        </div>
        <button onclick="installApp()" style="background: rgba(255,255,255,0.2); border: none; color: white; padding: 8px 12px; border-radius: 6px; cursor: pointer;">
            Quraşdır
        </button>
        <button onclick="this.parentElement.remove()" style="background: none; border: none; color: white; cursor: pointer; padding: 5px;">
            ×
        </button>
    `;
    
    document.body.appendChild(installBanner);
    
    // Auto-hide after 10 seconds
    setTimeout(() => {
        if (installBanner.parentElement) {
            installBanner.remove();
        }
    }, 10000);
});

function installApp() {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                console.log('User accepted the A2HS prompt');
            }
            deferredPrompt = null;
        });
        
        // Remove install banner
        document.querySelector('[onclick="installApp()"]').closest('div').remove();
    }
}
</script>

<?php include 'includes/footer.php'; ?>