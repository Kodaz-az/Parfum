<?php
/**
 * Parfüm POS Sistemi - Login Səhifəsi
 * Yaradıldığı tarix: 2025-07-21
 */

$user = new User();

// Əgər artıq daxil olmuşsa, dashboard-a yönləndir
if ($user->isLoggedIn()) {
    redirect('dashboard');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Təhlükəsizlik xətası. Səhifəni yeniləyin.';
    } else {
        try {
            $username = $_POST['username'] ?? '';
            $password = $_POST['password'] ?? '';
            $remember = isset($_POST['remember']);
            
            if (empty($username) || empty($password)) {
                throw new Exception('İstifadəçi adı və şifrə tələb olunur');
            }
            
            $loggedUser = $user->login($username, $password, $remember);
            
            // Successful login
            $success = 'Uğurla daxil oldunuz!';
            
            // Redirect after a short delay
            header('Refresh: 1; url=' . BASE_URL . 'dashboard');
            
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="az" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş - <?= PWA_NAME ?></title>
    
    <!-- PWA Meta tags -->
    <meta name="theme-color" content="<?= PWA_THEME_COLOR ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="<?= PWA_SHORT_NAME ?>">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>assets/icons/favicon-32x32.png">
    <link rel="apple-touch-icon" href="<?= BASE_URL ?>assets/icons/icon-192x192.png">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/app.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/login.css">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Preconnect -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-background">
            <div class="gradient-overlay"></div>
            <div class="particles" id="particles"></div>
        </div>
        
        <div class="login-content">
            <div class="login-card">
                <div class="login-header">
                    <div class="logo">
                        <i class="fas fa-spray-can"></i>
                        <h1><?= PWA_SHORT_NAME ?></h1>
                    </div>
                    <p class="subtitle">Professional Parfüm POS Sistemi</p>
                </div>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?= escape($error) ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?= escape($success) ?>
                        <div class="loading-spinner"></div>
                    </div>
                <?php endif; ?>
                
                <form method="POST" class="login-form" id="loginForm">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION[CSRF_TOKEN_NAME] ?>">
                    
                    <div class="form-group">
                        <label for="username">
                            <i class="fas fa-user"></i>
                            İstifadəçi adı və ya Email
                        </label>
                        <input 
                            type="text" 
                            id="username" 
                            name="username" 
                            required 
                            autocomplete="username"
                            value="<?= escape($_POST['username'] ?? '') ?>"
                            placeholder="İstifadəçi adınızı daxil edin"
                        >
                    </div>
                    
                    <div class="form-group">
                        <label for="password">
                            <i class="fas fa-lock"></i>
                            Şifrə
                        </label>
                        <div class="password-input">
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                required 
                                autocomplete="current-password"
                                placeholder="Şifrənizi daxil edin"
                            >
                            <button type="button" class="toggle-password" onclick="togglePassword()">
                                <i class="fas fa-eye" id="toggleIcon"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-options">
                        <label class="checkbox-label">
                            <input type="checkbox" name="remember" id="remember">
                            <span class="checkmark"></span>
                            Məni xatırla
                        </label>
                        <a href="#" class="forgot-link" onclick="showForgotPassword()">
                            Şifrəni unutmusunuz?
                        </a>
                    </div>
                    
                    <button type="submit" class="login-btn" id="loginBtn">
                        <span class="btn-text">Daxil ol</span>
                        <div class="btn-spinner" style="display: none;">
                            <i class="fas fa-spinner fa-spin"></i>
                        </div>
                    </button>
                </form>
                
                <div class="login-footer">
                    <p>Hesabınız yoxdur? <a href="<?= BASE_URL ?>register">Qeydiyyat</a></p>
                </div>
                
                <!-- Demo credentials -->
                <?php if (DEBUG_MODE): ?>
                <div class="demo-credentials">
                    <h4><i class="fas fa-info-circle"></i> Demo Hesablar</h4>
                    <div class="demo-accounts">
                        <div class="demo-account" onclick="fillCredentials('admin', 'password')">
                            <i class="fas fa-user-shield"></i>
                            <span>Admin</span>
                        </div>
                        <div class="demo-account" onclick="fillCredentials('manager1', 'password')">
                            <i class="fas fa-user-tie"></i>
                            <span>Menecer</span>
                        </div>
                        <div class="demo-account" onclick="fillCredentials('seller1', 'password')">
                            <i class="fas fa-user"></i>
                            <span>Satışçı</span>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Forgot Password Modal -->
    <div class="modal" id="forgotModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Şifrəni Bərpa Et</h3>
                <button class="modal-close" onclick="closeForgotPassword()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <p>Email ünvanınızı daxil edin, şifrə bərpası üçün link göndərəcəyik.</p>
                <form id="forgotForm">
                    <div class="form-group">
                        <label for="forgotEmail">Email ünvanı</label>
                        <input type="email" id="forgotEmail" required placeholder="email@example.com">
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i>
                        Göndər
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script src="<?= BASE_URL ?>assets/js/particles.js"></script>
    <script src="<?= BASE_URL ?>assets/js/login.js"></script>
    
    <script>
        // Initialize particles
        initParticles();
        
        // Form submission
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const btn = document.getElementById('loginBtn');
            const btnText = btn.querySelector('.btn-text');
            const btnSpinner = btn.querySelector('.btn-spinner');
            
            btnText.style.display = 'none';
            btnSpinner.style.display = 'inline-block';
            btn.disabled = true;
        });
        
        // Toggle password visibility
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.getElementById('toggleIcon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.className = 'fas fa-eye-slash';
            } else {
                passwordInput.type = 'password';
                toggleIcon.className = 'fas fa-eye';
            }
        }
        
        // Show forgot password modal
        function showForgotPassword() {
            document.getElementById('forgotModal').style.display = 'block';
        }
        
        // Close forgot password modal
        function closeForgotPassword() {
            document.getElementById('forgotModal').style.display = 'none';
        }
        
        // Fill demo credentials
        function fillCredentials(username, password) {
            document.getElementById('username').value = username;
            document.getElementById('password').value = password;
        }
        
        // Forgot password form
        document.getElementById('forgotForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('forgotEmail').value;
            
            // Simulate API call
            fetch('<?= BASE_URL ?>api/auth/forgot-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?= $_SESSION[CSRF_TOKEN_NAME] ?>'
                },
                body: JSON.stringify({ email: email })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Şifrə bərpası linki email ünvanınıza göndərildi.');
                    closeForgotPassword();
                } else {
                    alert(data.message || 'Xəta baş verdi.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Xəta baş verdi. Yenidən cəhd edin.');
            });
        });
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('forgotModal');
            if (event.target === modal) {
                closeForgotPassword();
            }
        }
        
        // PWA Installation
        let deferredPrompt;
        
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            
            // Show install button if needed
            const installBtn = document.createElement('button');
            installBtn.className = 'install-btn';
            installBtn.innerHTML = '<i class="fas fa-download"></i> Tətbiq yüklə';
            installBtn.onclick = installPWA;
            
            document.querySelector('.login-footer').appendChild(installBtn);
        });
        
        function installPWA() {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                deferredPrompt.userChoice.then((choiceResult) => {
                    if (choiceResult.outcome === 'accepted') {
                        console.log('User accepted the install prompt');
                    }
                    deferredPrompt = null;
                });
            }
        }
        
        // Service Worker registration
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', function() {
                navigator.serviceWorker.register('<?= BASE_URL ?>sw.js')
                .then(function(registration) {
                    console.log('ServiceWorker registration successful');
                })
                .catch(function(err) {
                    console.log('ServiceWorker registration failed: ', err);
                });
            });
        }
    </script>
</body>
</html>