<?php
/**
 * İstifadəçi İdarəetməsi
 * Kodaz-az - 2025-07-21 13:55:07 (UTC)
 * Login: Kodaz-az
 */

$currentUserId = $_SESSION['user_id'];
$currentUserRole = $_SESSION['role'];

// Permission check
if (!in_array($currentUserRole, ['admin', 'manager'])) {
    $_SESSION['error_message'] = "Bu səhifəyə giriş icazəniz yoxdur!";
    header('Location: ?page=dashboard');
    exit;
}

// Add user action
if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = Database::getInstance();
        
        $fullName = trim($_POST['full_name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $phone = trim($_POST['phone'] ?? '');
        $role = $_POST['role'] ?? 'seller';
        $salary = floatval($_POST['salary'] ?? 0);
        $commission = floatval($_POST['commission'] ?? 0);
        
        // Validation
        $errors = [];
        if (empty($fullName)) $errors[] = "Ad və soyad tələb olunur";
        if (empty($username) || strlen($username) < 3) $errors[] = "İstifadəçi adı ən azı 3 simvol olmalıdır";
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Düzgün email daxil edin";
        if (empty($password) || strlen($password) < 6) $errors[] = "Şifrə ən azı 6 simvol olmalıdır";
        
        // Check existing user
        $existingUser = $db->selectOne("SELECT id FROM users WHERE username = ? OR email = ?", [$username, $email]);
        if ($existingUser) {
            $errors[] = "Bu istifadəçi adı və ya email artıq mövcuddur";
        }
        
        if (empty($errors)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            $userId = $db->insert("
                INSERT INTO users (username, email, password, full_name, phone, role, salary, commission_rate, is_active, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())
            ", [$username, $email, $hashedPassword, $fullName, $phone, $role, $salary, $commission]);
            
            if ($userId) {
                $_SESSION['success_message'] = "İstifadəçi uğurla əlavə edildi!";
                header('Location: ?page=users');
                exit;
            }
        } else {
            $_SESSION['error_message'] = implode('<br>', $errors);
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "İstifadəçi əlavə edilə bilmədi: " . $e->getMessage();
    }
}

// Edit user action
if ($action === 'edit' && $id > 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = Database::getInstance();
        
        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $role = $_POST['role'] ?? 'seller';
        $salary = floatval($_POST['salary'] ?? 0);
        $commission = floatval($_POST['commission'] ?? 0);
        $isActive = intval($_POST['is_active'] ?? 1);
        $password = $_POST['password'] ?? '';
        
        $errors = [];
        if (empty($fullName)) $errors[] = "Ad və soyad tələb olunur";
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Düzgün email daxil edin";
        
        if (empty($errors)) {
            $sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, role = ?, salary = ?, commission_rate = ?, is_active = ?, updated_at = NOW() WHERE id = ?";
            $params = [$fullName, $email, $phone, $role, $salary, $commission, $isActive, $id];
            
            // Update password if provided
            if (!empty($password)) {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, role = ?, salary = ?, commission_rate = ?, is_active = ?, password = ?, updated_at = NOW() WHERE id = ?";
                $params = [$fullName, $email, $phone, $role, $salary, $commission, $isActive, $hashedPassword, $id];
            }
            
            $updated = $db->update($sql, $params);
            
            if ($updated) {
                $_SESSION['success_message'] = "İstifadəçi məlumatları yeniləndi!";
                header('Location: ?page=users');
                exit;
            }
        } else {
            $_SESSION['error_message'] = implode('<br>', $errors);
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "İstifadəçi yenilənə bilmədi: " . $e->getMessage();
    }
}

// Get single user for editing
if ($action === 'edit' && $id > 0) {
    try {
        $db = Database::getInstance();
        $editUser = $db->selectOne("SELECT * FROM users WHERE id = ?", [$id]);
        
        if (!$editUser) {
            $_SESSION['error_message'] = "İstifadəçi tapılmadı!";
            header('Location: ?page=users');
            exit;
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = "İstifadəçi yüklənə bilmədi: " . $e->getMessage();
        header('Location: ?page=users');
        exit;
    }
}

// Toggle user status
if ($action === 'toggle_status' && $id > 0) {
    try {
        $db = Database::getInstance();
        
        if ($id == $currentUserId) {
            $_SESSION['error_message'] = "Öz hesabınızı deaktiv edə bilməzsiniz!";
        } else {
            $user = $db->selectOne("SELECT is_active FROM users WHERE id = ?", [$id]);
            if ($user) {
                $newStatus = $user['is_active'] ? 0 : 1;
                $db->update("UPDATE users SET is_active = ?, updated_at = NOW() WHERE id = ?", [$newStatus, $id]);
                
                $statusText = $newStatus ? 'aktivləşdirildi' : 'deaktivləşdirildi';
                $_SESSION['success_message'] = "İstifadəçi {$statusText}!";
            }
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Status dəyişdirilə bilmədi: " . $e->getMessage();
    }
    
    header('Location: ?page=users');
    exit;
}

// Get users
try {
    $db = Database::getInstance();
    
    $search = $_GET['search'] ?? '';
    $roleFilter = $_GET['role_filter'] ?? '';
    $statusFilter = $_GET['status_filter'] ?? '';
    
    $sql = "SELECT u.*, 
            (SELECT COUNT(*) FROM sales s WHERE s.user_id = u.id) as total_sales,
            (SELECT SUM(final_amount) FROM sales s WHERE s.user_id = u.id) as total_revenue,
            (SELECT MAX(created_at) FROM sales s WHERE s.user_id = u.id) as last_sale_date
            FROM users u WHERE 1=1";
    $params = [];
    
    if (!empty($search)) {
        $sql .= " AND (u.full_name LIKE ? OR u.username LIKE ? OR u.email LIKE ?)";
        $searchTerm = "%{$search}%";
        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
    }
    
    if (!empty($roleFilter)) {
        $sql .= " AND u.role = ?";
        $params[] = $roleFilter;
    }
    
    if ($statusFilter !== '') {
        $sql .= " AND u.is_active = ?";
        $params[] = intval($statusFilter);
    }
    
    $sql .= " ORDER BY u.created_at DESC";
    
    $users = $db->selectAll($sql, $params);
    
    // Get statistics
    $stats = $db->selectOne("
        SELECT 
            COUNT(*) as total_users,
            SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_users,
            SUM(CASE WHEN role = 'seller' THEN 1 ELSE 0 END) as sellers_count,
            SUM(CASE WHEN role = 'manager' THEN 1 ELSE 0 END) as managers_count,
            SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admins_count,
            SUM(CASE WHEN last_activity >= DATE_SUB(NOW(), INTERVAL 5 MINUTE) THEN 1 ELSE 0 END) as online_count
        FROM users
    ");
    
} catch (Exception $e) {
    $users = [];
    $stats = ['total_users' => 0, 'active_users' => 0, 'sellers_count' => 0, 'managers_count' => 0, 'admins_count' => 0, 'online_count' => 0];
}

$pageTitle = "İstifadəçilər - " . PWA_NAME;
include 'includes/header.php';
?>

<style>
.user-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--white);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 1.2rem;
    margin-right: 15px;
    position: relative;
}

.user-avatar.online::after {
    content: '';
    position: absolute;
    bottom: 2px;
    right: 2px;
    width: 12px;
    height: 12px;
    background: var(--success-color);
    border: 2px solid var(--white);
    border-radius: 50%;
}

.role-badge {
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
}

.role-admin { background: #dc3545; color: white; }
.role-manager { background: #ffc107; color: #212529; }
.role-seller { background: #28a745; color: white; }

.user-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
    gap: 10px;
    text-align: center;
    font-size: 0.8rem;
}

.user-stat {
    padding: 8px;
    background: #f8f9fa;
    border-radius: 6px;
}

.user-actions {
    display: flex;
    gap: 5px;
    flex-wrap: wrap;
}

.user-item {
    display: flex;
    align-items: center;
    padding: 20px;
    border-bottom: 1px solid #e9ecef;
    transition: var(--transition);
}

.user-item:hover {
    background: #f8f9fa;
}

.user-details {
    flex: 1;
    min-width: 0;
}

.user-name {
    font-weight: bold;
    font-size: 1.1rem;
    margin-bottom: 5px;
}

.user-info {
    font-size: 0.9rem;
    color: #6c757d;
    margin-bottom: 8px;
}

.quick-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 15px;
    margin-bottom: 30px;
}

.quick-stat {
    background: var(--white);
    padding: 20px;
    border-radius: 12px;
    box-shadow: var(--box-shadow);
    text-align: center;
    border-left: 4px solid var(--primary-color);
}

.quick-stat-number {
    font-size: 1.8rem;
    font-weight: bold;
    color: var(--primary-color);
    margin-bottom: 5px;
}

.quick-stat-label {
    color: #6c757d;
    font-size: 0.9rem;
}
</style>

<!-- Statistics -->
<div class="quick-stats">
    <div class="quick-stat">
        <div class="quick-stat-number"><?= $stats['total_users'] ?></div>
        <div class="quick-stat-label">Cəmi İstifadəçi</div>
    </div>
    
    <div class="quick-stat" style="border-color: var(--success-color);">
        <div class="quick-stat-number" style="color: var(--success-color);"><?= $stats['active_users'] ?></div>
        <div class="quick-stat-label">Aktiv İstifadəçi</div>
    </div>
    
    <div class="quick-stat" style="border-color: var(--info-color);">
        <div class="quick-stat-number" style="color: var(--info-color);"><?= $stats['online_count'] ?></div>
        <div class="quick-stat-label">Online İndi</div>
    </div>
    
    <div class="quick-stat" style="border-color: var(--warning-color);">
        <div class="quick-stat-number" style="color: var(--warning-color);"><?= $stats['sellers_count'] ?></div>
        <div class="quick-stat-label">Satışçı</div>
    </div>
</div>

<?php if (in_array($action, ['add', 'edit'])): ?>
    <div class="content-box">
        <h3>
            <i class="fas fa-<?= $action === 'add' ? 'user-plus' : 'user-edit' ?>"></i>
            <?= $action === 'add' ? 'Yeni İstifadəçi Əlavə Et' : 'İstifadəçi Redaktə Et' ?>
        </h3>
        
        <form method="POST" style="margin-top: 25px;">
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-id-card"></i> Ad və Soyad *</label>
                    <input type="text" name="full_name" value="<?= htmlspecialchars($editUser['full_name'] ?? '') ?>" required class="form-control">
                </div>
                
                <?php if ($action === 'add'): ?>
                <div class="form-group">
                    <label><i class="fas fa-user"></i> İstifadəçi Adı *</label>
                    <input type="text" name="username" value="<?= htmlspecialchars($editUser['username'] ?? '') ?>" required class="form-control">
                </div>
                <?php endif; ?>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-envelope"></i> Email *</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($editUser['email'] ?? '') ?>" required class="form-control">
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-phone"></i> Telefon</label>
                    <input type="tel" name="phone" value="<?= htmlspecialchars($editUser['phone'] ?? '') ?>" class="form-control">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-user-tag"></i> Rol *</label>
                    <select name="role" required class="form-control">
                        <option value="seller" <?= ($editUser['role'] ?? '') === 'seller' ? 'selected' : '' ?>>Satışçı</option>
                        <?php if ($currentUserRole === 'admin'): ?>
                            <option value="manager" <?= ($editUser['role'] ?? '') === 'manager' ? 'selected' : '' ?>>Menecer</option>
                            <option value="admin" <?= ($editUser['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin</option>
                        <?php endif; ?>
                    </select>
                </div>
                
                <?php if ($action === 'edit'): ?>
                <div class="form-group">
                    <label><i class="fas fa-toggle-on"></i> Status</label>
                    <select name="is_active" class="form-control">
                        <option value="1" <?= ($editUser['is_active'] ?? 1) == 1 ? 'selected' : '' ?>>Aktiv</option>
                        <option value="0" <?= ($editUser['is_active'] ?? 1) == 0 ? 'selected' : '' ?>>Deaktiv</option>
                    </select>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="form-row">
                <div class="form-group">
                    <label><i class="fas fa-money-bill-wave"></i> Maaş (₼)</label>
                    <input type="number" name="salary" step="0.01" min="0" value="<?= $editUser['salary'] ?? '' ?>" class="form-control">
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-percentage"></i> Komissiya (%)</label>
                    <input type="number" name="commission" step="0.01" min="0" max="100" value="<?= $editUser['commission_rate'] ?? '' ?>" class="form-control">
                </div>
            </div>
            
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Şifrə <?= $action === 'edit' ? '(Boş buraxın dəyişdirmək istəmirsinizsə)' : '*' ?></label>
                <input type="password" name="password" <?= $action === 'add' ? 'required' : '' ?> class="form-control" placeholder="<?= $action === 'add' ? 'Minimum 6 simvol' : 'Yeni şifrə' ?>">
            </div>
            
            <?php if ($action === 'edit'): ?>
                <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <strong>Yaradılma tarixi:</strong> <?= date('d.m.Y H:i', strtotime($editUser['created_at'])) ?><br>
                    <?php if ($editUser['updated_at']): ?>
                        <strong>Son yeniləmə:</strong> <?= date('d.m.Y H:i', strtotime($editUser['updated_at'])) ?><br>
                    <?php endif; ?>
                    <strong>Son aktivlik:</strong> <?= date('d.m.Y H:i', strtotime($editUser['last_activity'])) ?>
                </div>
            <?php endif; ?>
            
            <div style="display: flex; gap: 15px; margin-top: 25px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> <?= $action === 'add' ? 'İstifadəçini Əlavə Et' : 'Dəyişiklikləri Saxla' ?>
                </button>
                <a href="?page=users" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Geri
                </a>
            </div>
        </form>
    </div>

<?php else: ?>
    <div class="content-box">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; flex-wrap: wrap; gap: 15px;">
            <h3><i class="fas fa-users"></i> İstifadəçi Siyahısı (<?= count($users) ?>)</h3>
            <a href="?page=users&action=add" class="btn btn-primary">
                <i class="fas fa-user-plus"></i> Yeni İstifadəçi
            </a>
        </div>
        
        <!-- Filter and Search -->
        <form method="GET" style="margin-bottom: 25px;">
            <input type="hidden" name="page" value="users">
            <div style="display: grid; grid-template-columns: 1fr 150px 150px 100px; gap: 15px; align-items: end;">
                <div class="form-group" style="margin-bottom: 0;">
                    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="🔍 Ad, username və ya email axtar..." class="form-control">
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <select name="role_filter" class="form-control">
                        <option value="">Bütün rollar</option>
                        <option value="seller" <?= $roleFilter === 'seller' ? 'selected' : '' ?>>Satışçı</option>
                        <option value="manager" <?= $roleFilter === 'manager' ? 'selected' : '' ?>>Menecer</option>
                        <option value="admin" <?= $roleFilter === 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <select name="status_filter" class="form-control">
                        <option value="">Bütün statuslar</option>
                        <option value="1" <?= $statusFilter === '1' ? 'selected' : '' ?>>Aktiv</option>
                        <option value="0" <?= $statusFilter === '0' ? 'selected' : '' ?>>Deaktiv</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary" style="height: 47px;">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </form>
        
        <?php if (empty($users)): ?>
            <div style="text-align: center; padding: 40px; color: #6c757d;">
                <i class="fas fa-users" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                <h4>İstifadəçi tapılmadı</h4>
                <p>Axtarış şərtlərinə uyğun istifadəçi yoxdur və ya hələ istifadəçi əlavə edilməyib.</p>
                <a href="?page=users&action=add" class="btn btn-primary" style="margin-top: 15px;">
                    <i class="fas fa-user-plus"></i> İlk İstifadəçini Əlavə Et
                </a>
            </div>
        <?php else: ?>
            <div>
                <?php foreach ($users as $user): ?>
                    <div class="user-item">
                        <div class="user-avatar <?= strtotime($user['last_activity']) > (time() - 300) ? 'online' : '' ?>">
                            <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                        </div>
                        
                        <div class="user-details">
                            <div class="user-name">
                                <?= htmlspecialchars($user['full_name']) ?>
                                <?php if (!$user['is_active']): ?>
                                    <span class="badge badge-danger" style="margin-left: 10px;">Deaktiv</span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="user-info">
                                <i class="fas fa-user"></i> @<?= htmlspecialchars($user['username']) ?> |
                                <i class="fas fa-envelope"></i> <?= htmlspecialchars($user['email']) ?> |
                                <span class="role-badge role-<?= $user['role'] ?>"><?= ucfirst($user['role']) ?></span>
                            </div>
                            
                            <div class="user-stats">
                                <div class="user-stat">
                                    <div style="font-weight: bold; color: var(--primary-color);"><?= $user['total_sales'] ?? 0 ?></div>
                                    <div>Satış</div>
                                </div>
                                <div class="user-stat">
                                    <div style="font-weight: bold; color: var(--success-color);">₼<?= number_format($user['total_revenue'] ?? 0, 0) ?></div>
                                    <div>Gəlir</div>
                                </div>
                                <div class="user-stat">
                                    <div style="font-weight: bold; color: var(--info-color);">₼<?= number_format($user['salary'] ?? 0, 0) ?></div>
                                    <div>Maaş</div>
                                </div>
                                <div class="user-stat">
                                    <div style="font-weight: bold; color: var(--warning-color);"><?= $user['commission_rate'] ?? 0 ?>%</div>
                                    <div>Komissiya</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="user-actions">
                            <a href="?page=users&action=edit&id=<?= $user['id'] ?>" class="btn btn-primary btn-sm">
                                <i class="fas fa-edit"></i> Redaktə
                            </a>
                            
                            <a href="?page=chat&user=<?= $user['id'] ?>" class="btn btn-info btn-sm">
                                <i class="fas fa-comments"></i> Chat
                            </a>
                            
                            <a href="?page=calls&user=<?= $user['id'] ?>" class="btn btn-success btn-sm">
                                <i class="fas fa-phone"></i> Zəng
                            </a>
                            
                            <?php if ($user['id'] != $currentUserId): ?>
                            <a href="?page=users&action=toggle_status&id=<?= $user['id'] ?>" 
                               class="btn btn-<?= $user['is_active'] ? 'warning' : 'success' ?> btn-sm"
                               onclick="return confirm('Status dəyişdirmək istədiyinizə əminsiniz?')">
                                <i class="fas fa-<?= $user['is_active'] ? 'ban' : 'check' ?>"></i>
                                <?= $user['is_active'] ? 'Deaktiv Et' : 'Aktiv Et' ?>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div style="margin-top: 25px; text-align: center; padding: 20px; background: #f8f9fa; border-radius: 12px;">
                <strong>
                    <i class="fas fa-info-circle"></i>
                    Cəmi: <?= count($users) ?> istifadəçi | 
                    <i class="fas fa-check-circle" style="color: var(--success-color);"></i>
                    Aktiv: <?= count(array_filter($users, function($u) { return $u['is_active']; })) ?> | 
                    <i class="fas fa-circle" style="color: var(--success-color);"></i>
                    Online: <?= count(array_filter($users, function($u) { return strtotime($u['last_activity']) > (time() - 300); })) ?>
                </strong>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<script>
// Auto-refresh online status every 30 seconds
setInterval(function() {
    // Update online indicators
    document.querySelectorAll('.user-avatar').forEach(avatar => {
        // This would be updated via WebSocket in a real implementation
    });
}, 30000);

console.log('Users management system initialized');
console.log('Total users loaded:', <?= count($users) ?>);
</script>

<?php include 'includes/footer.php'; ?>