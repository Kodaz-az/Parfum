<?php
/**
 * Parfüm POS Sistemi - Logout Səhifəsi
 * Yaradıldığı tarix: 2025-07-21
 */

require_once __DIR__ . '/../config/config.php';

$user = new User();

if ($user->isLoggedIn()) {
    $user->logout();
}

// AJAX istəyi üçün JSON cavab
if (isAjax()) {
    jsonResponse(['success' => true, 'message' => 'Uğurla çıxış etdiniz']);
}

// Normal istəq üçün yönləndirmə
redirect('login');
?>