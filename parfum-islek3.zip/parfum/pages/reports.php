<?php
/**
 * Hesabat Sistemi
 * Kodaz-az - 2025-07-21 13:47:37 (UTC)
 * Login: Kodaz-az
 */

$currentUserId = $_SESSION['user_id'];
$currentUserRole = $_SESSION['role'];

// Date filters
$dateFrom = $_GET['date_from'] ?? date('Y-m-01'); // This month start
$dateTo = $_GET['date_to'] ?? date('Y-m-d'); // Today
$reportType = $_GET['type'] ?? 'sales';
$sellerId = $_GET['seller_id'] ?? '';

try {
    $db = Database::getInstance();
    
    // Sales Report
    if ($reportType === 'sales') {
        $sql = "SELECT 
            DATE(s.created_at) as sale_date,
            COUNT(s.id) as total_sales,
            SUM(s.final_amount) as total_revenue,
            SUM(s.subtotal) as subtotal,
            SUM(s.tax_amount) as tax_amount,
            AVG(s.final_amount) as avg_sale,
            u.full_name as seller_name
        FROM sales s
        LEFT JOIN users u ON s.user_id = u.id
        WHERE DATE(s.created_at) BETWEEN ? AND ?";
        
        $params = [$dateFrom, $dateTo];
        
        if (!empty($sellerId)) {
            $sql .= " AND s.user_id = ?";
            $params[] = $sellerId;
        } elseif ($currentUserRole === 'seller') {
            $sql .= " AND s.user_id = ?";
            $params[] = $currentUserId;
        }
        
        $sql .= " GROUP BY DATE(s.created_at), s.user_id ORDER BY s.created_at DESC";
        
        $salesData = $db->selectAll($sql, $params);
        
        // Summary
        $summary = $db->selectOne("
            SELECT 
                COUNT(s.id) as total_sales,
                SUM(s.final_amount) as total_revenue,
                SUM(s.subtotal) as subtotal,
                SUM(s.tax_amount) as tax_amount,
                AVG(s.final_amount) as avg_sale,
                COUNT(DISTINCT s.user_id) as active_sellers
            FROM sales s
            WHERE DATE(s.created_at) BETWEEN ? AND ?" . 
            (!empty($sellerId) ? " AND s.user_id = $sellerId" : 
             ($currentUserRole === 'seller' ? " AND s.user_id = $currentUserId" : '')),
            $params
        );
    }
    
    // Product Report
    elseif ($reportType === 'products') {
        $productsData = $db->selectAll("
            SELECT 
                p.name,
                p.brand,
                p.category,
                p.price,
                p.stock_quantity,
                p.min_stock,
                COALESCE(sold.quantity_sold, 0) as quantity_sold,
                COALESCE(sold.revenue, 0) as revenue,
                (p.stock_quantity <= p.min_stock) as is_low_stock
            FROM products p
            LEFT JOIN (
                SELECT 
                    sd.product_id,
                    SUM(sd.quantity) as quantity_sold,
                    SUM(sd.total_price) as revenue
                FROM sale_details sd
                JOIN sales s ON sd.sale_id = s.id
                WHERE DATE(s.created_at) BETWEEN ? AND ?
                GROUP BY sd.product_id
            ) sold ON p.id = sold.product_id
            WHERE p.is_active = 1
            ORDER BY sold.quantity_sold DESC, p.name
        ", [$dateFrom, $dateTo]);
        
        $productSummary = $db->selectOne("
            SELECT 
                COUNT(*) as total_products,
                SUM(CASE WHEN stock_quantity <= min_stock THEN 1 ELSE 0 END) as low_stock_count,
                SUM(CASE WHEN stock_quantity = 0 THEN 1 ELSE 0 END) as out_of_stock,
                SUM(stock_quantity) as total_stock_value
            FROM products
            WHERE is_active = 1
        ");
    }
    
    // User Performance Report
    elseif ($reportType === 'users' && in_array($currentUserRole, ['admin', 'manager'])) {
        $usersData = $db->selectAll("
            SELECT 
                u.id,
                u.full_name,
                u.role,
                COUNT(s.id) as total_sales,
                SUM(s.final_amount) as total_revenue,
                AVG(s.final_amount) as avg_sale,
                MAX(s.created_at) as last_sale_date,
                u.last_activity
            FROM users u
            LEFT JOIN sales s ON u.id = s.user_id AND DATE(s.created_at) BETWEEN ? AND ?
            WHERE u.is_active = 1
            GROUP BY u.id
            ORDER BY total_revenue DESC
        ", [$dateFrom, $dateTo]);
    }
    
    // Financial Report
    elseif ($reportType === 'financial') {
        $financialData = $db->selectAll("
            SELECT 
                DATE(created_at) as date,
                SUM(final_amount) as daily_revenue,
                SUM(subtotal) as daily_subtotal,
                SUM(tax_amount) as daily_tax,
                COUNT(*) as daily_sales,
                payment_method
            FROM sales
            WHERE DATE(created_at) BETWEEN ? AND ?
            GROUP BY DATE(created_at), payment_method
            ORDER BY created_at DESC
        ", [$dateFrom, $dateTo]);
        
        $paymentMethods = $db->selectAll("
            SELECT 
                payment_method,
                COUNT(*) as count,
                SUM(final_amount) as total
            FROM sales
            WHERE DATE(created_at) BETWEEN ? AND ?
            GROUP BY payment_method
        ", [$dateFrom, $dateTo]);
    }
    
    // Get sellers for filter
    $sellers = $db->selectAll("SELECT id, full_name FROM users WHERE is_active = 1 AND role IN ('seller', 'manager') ORDER BY full_name");
    
} catch (Exception $e) {
    $error = $e->getMessage();
    $salesData = [];
    $summary = [];
    $sellers = [];
}

$pageTitle = "Hesabatlar - " . PWA_NAME;
include 'includes/header.php';
?>

<style>
.report-tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 30px;
    flex-wrap: wrap;
}

.report-tab {
    padding: 12px 20px;
    border: 2px solid #e9ecef;
    border-radius: 10px;
    text-decoration: none;
    color: #6c757d;
    font-weight: 500;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
}

.report-tab.active,
.report-tab:hover {
    border-color: var(--primary-color);
    background: var(--primary-color);
    color: var(--white);
    text-decoration: none;
    transform: translateY(-2px);
}

.chart-container {
    width: 100%;
    height: 400px;
    margin: 20px 0;
    background: var(--white);
    border-radius: 15px;
    padding: 20px;
    box-shadow: var(--box-shadow);
}

.export-buttons {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.kpi-card {
    background: var(--white);
    padding: 25px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    text-align: center;
    position: relative;
    overflow: hidden;
}

.kpi-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
}

.kpi-value {
    font-size: 2rem;
    font-weight: bold;
    color: var(--dark-color);
    margin-bottom: 5px;
}

.kpi-label {
    color: #6c757d;
    font-size: 0.9rem;
}

.kpi-change {
    font-size: 0.8rem;
    margin-top: 5px;
}

.kpi-change.positive { color: var(--success-color); }
.kpi-change.negative { color: var(--danger-color); }

.progress-bar {
    width: 100%;
    height: 8px;
    background: #e9ecef;
    border-radius: 4px;
    overflow: hidden;
    margin-top: 10px;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
    transition: width 0.3s ease;
}
</style>

<!-- Report Tabs -->
<div class="report-tabs">
    <a href="?page=reports&type=sales&date_from=<?= $dateFrom ?>&date_to=<?= $dateTo ?>" 
       class="report-tab <?= $reportType === 'sales' ? 'active' : '' ?>">
        <i class="fas fa-chart-line"></i> Satış Hesabatı
    </a>
    
    <a href="?page=reports&type=products&date_from=<?= $dateFrom ?>&date_to=<?= $dateTo ?>" 
       class="report-tab <?= $reportType === 'products' ? 'active' : '' ?>">
        <i class="fas fa-box"></i> Məhsul Hesabatı
    </a>
    
    <?php if (in_array($currentUserRole, ['admin', 'manager'])): ?>
    <a href="?page=reports&type=users&date_from=<?= $dateFrom ?>&date_to=<?= $dateTo ?>" 
       class="report-tab <?= $reportType === 'users' ? 'active' : '' ?>">
        <i class="fas fa-users"></i> İstifadəçi Performansı
    </a>
    
    <a href="?page=reports&type=financial&date_from=<?= $dateFrom ?>&date_to=<?= $dateTo ?>" 
       class="report-tab <?= $reportType === 'financial' ? 'active' : '' ?>">
        <i class="fas fa-dollar-sign"></i> Maliyyə Hesabatı
    </a>
    <?php endif; ?>
</div>

<!-- Filters -->
<div class="content-box">
    <h4><i class="fas fa-filter"></i> Filterlər</h4>
    
    <form method="GET" style="margin-top: 20px;">
        <input type="hidden" name="page" value="reports">
        <input type="hidden" name="type" value="<?= $reportType ?>">
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
            <div class="form-group" style="margin-bottom: 0;">
                <label>Başlanğıc Tarix:</label>
                <input type="date" name="date_from" value="<?= $dateFrom ?>" class="form-control">
            </div>
            
            <div class="form-group" style="margin-bottom: 0;">
                <label>Bitmə Tarix:</label>
                <input type="date" name="date_to" value="<?= $dateTo ?>" class="form-control">
            </div>
            
            <?php if ($reportType === 'sales' && $currentUserRole !== 'seller'): ?>
            <div class="form-group" style="margin-bottom: 0;">
                <label>Satışçı:</label>
                <select name="seller_id" class="form-control">
                    <option value="">Hamısı</option>
                    <?php foreach ($sellers as $seller): ?>
                        <option value="<?= $seller['id'] ?>" <?= $sellerId == $seller['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($seller['full_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-search"></i> Filterlə
            </button>
        </div>
    </form>
</div>

<!-- Export Buttons -->
<div class="export-buttons">
    <button onclick="exportToPDF()" class="btn btn-danger">
        <i class="fas fa-file-pdf"></i> PDF Yüklə
    </button>
    
    <button onclick="exportToExcel()" class="btn btn-success">
        <i class="fas fa-file-excel"></i> Excel Yüklə
    </button>
    
    <button onclick="printReport()" class="btn btn-info">
        <i class="fas fa-print"></i> Çap Et
    </button>
    
    <button onclick="emailReport()" class="btn btn-warning">
        <i class="fas fa-envelope"></i> Email Göndər
    </button>
</div>

<?php if ($reportType === 'sales'): ?>
    <!-- Sales Report -->
    <?php if (!empty($summary)): ?>
    <div class="kpi-grid">
        <div class="kpi-card">
            <div class="kpi-value">₼<?= number_format($summary['total_revenue'], 2) ?></div>
            <div class="kpi-label">Cəmi Satış</div>
            <div class="kpi-change positive">
                <i class="fas fa-arrow-up"></i> +12.5%
            </div>
        </div>
        
        <div class="kpi-card">
            <div class="kpi-value"><?= $summary['total_sales'] ?></div>
            <div class="kpi-label">Satış Sayı</div>
            <div class="kpi-change positive">
                <i class="fas fa-arrow-up"></i> +8.2%
            </div>
        </div>
        
        <div class="kpi-card">
            <div class="kpi-value">₼<?= number_format($summary['avg_sale'], 2) ?></div>
            <div class="kpi-label">Orta Çek</div>
            <div class="kpi-change negative">
                <i class="fas fa-arrow-down"></i> -2.1%
            </div>
        </div>
        
        <div class="kpi-card">
            <div class="kpi-value">₼<?= number_format($summary['tax_amount'], 2) ?></div>
            <div class="kpi-label">VAT Məbləği</div>
            <div class="kpi-change positive">
                <i class="fas fa-arrow-up"></i> +12.5%
            </div>
        </div>
    </div>
    
    <!-- Chart -->
    <div class="chart-container">
        <canvas id="salesChart"></canvas>
    </div>
    
    <!-- Sales Data Table -->
    <div class="content-box">
        <h4><i class="fas fa-table"></i> Gündəlik Satış Məlumatları</h4>
        
        <?php if (empty($salesData)): ?>
            <div style="text-align: center; padding: 40px; color: #6c757d;">
                <i class="fas fa-chart-line" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                <p>Seçilmiş tarix aralığında satış məlumatı yoxdur</p>
            </div>
        <?php else: ?>
            <div style="overflow-x: auto; margin-top: 20px;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tarix</th>
                            <?php if ($currentUserRole !== 'seller'): ?><th>Satışçı</th><?php endif; ?>
                            <th style="text-align: center;">Satış Sayı</th>
                            <th style="text-align: right;">Subtotal</th>
                            <th style="text-align: right;">VAT</th>
                            <th style="text-align: right;">Cəmi</th>
                            <th style="text-align: right;">Orta</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($salesData as $sale): ?>
                            <tr>
                                <td><?= date('d.m.Y', strtotime($sale['sale_date'])) ?></td>
                                <?php if ($currentUserRole !== 'seller'): ?>
                                    <td><?= htmlspecialchars($sale['seller_name'] ?? 'N/A') ?></td>
                                <?php endif; ?>
                                <td style="text-align: center;">
                                    <span class="badge badge-primary"><?= $sale['total_sales'] ?></span>
                                </td>
                                <td style="text-align: right;">₼<?= number_format($sale['subtotal'], 2) ?></td>
                                <td style="text-align: right;">₼<?= number_format($sale['tax_amount'], 2) ?></td>
                                <td style="text-align: right;">
                                    <strong>₼<?= number_format($sale['total_revenue'], 2) ?></strong>
                                </td>
                                <td style="text-align: right;">₼<?= number_format($sale['avg_sale'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr style="background: #f8f9fa; font-weight: bold;">
                            <td>CƏMI</td>
                            <?php if ($currentUserRole !== 'seller'): ?><td>-</td><?php endif; ?>
                            <td style="text-align: center;"><?= $summary['total_sales'] ?></td>
                            <td style="text-align: right;">₼<?= number_format($summary['subtotal'], 2) ?></td>
                            <td style="text-align: right;">₼<?= number_format($summary['tax_amount'], 2) ?></td>
                            <td style="text-align: right;">₼<?= number_format($summary['total_revenue'], 2) ?></td>
                            <td style="text-align: right;">₼<?= number_format($summary['avg_sale'], 2) ?></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

<?php elseif ($reportType === 'products'): ?>
    <!-- Products Report -->
    <?php if (!empty($productSummary)): ?>
    <div class="kpi-grid">
        <div class="kpi-card">
            <div class="kpi-value"><?= $productSummary['total_products'] ?></div>
            <div class="kpi-label">Cəmi Məhsul</div>
        </div>
        
        <div class="kpi-card">
            <div class="kpi-value"><?= $productSummary['low_stock_count'] ?></div>
            <div class="kpi-label">Az Stok</div>
            <?php if ($productSummary['low_stock_count'] > 0): ?>
                <div class="kpi-change negative">
                    <i class="fas fa-exclamation-triangle"></i> Diqqət
                </div>
            <?php endif; ?>
        </div>
        
        <div class="kpi-card">
            <div class="kpi-value"><?= $productSummary['out_of_stock'] ?></div>
            <div class="kpi-label">Bitən Məhsul</div>
            <?php if ($productSummary['out_of_stock'] > 0): ?>
                <div class="kpi-change negative">
                    <i class="fas fa-times-circle"></i> Kritik
                </div>
            <?php endif; ?>
        </div>
        
        <div class="kpi-card">
            <div class="kpi-value"><?= number_format($productSummary['total_stock_value']) ?></div>
            <div class="kpi-label">Cəmi Stok</div>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="content-box">
        <h4><i class="fas fa-box"></i> Məhsul Performansı</h4>
        
        <?php if (empty($productsData)): ?>
            <div style="text-align: center; padding: 40px; color: #6c757d;">
                <i class="fas fa-box" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                <p>Məhsul məlumatı yoxdur</p>
            </div>
        <?php else: ?>
            <div style="overflow-x: auto; margin-top: 20px;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Məhsul</th>
                            <th>Brand</th>
                            <th>Kateqoriya</th>
                            <th style="text-align: right;">Qiymət</th>
                            <th style="text-align: center;">Stok</th>
                            <th style="text-align: center;">Satılan</th>
                            <th style="text-align: right;">Gəlir</th>
                            <th style="text-align: center;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($productsData as $product): ?>
                            <tr>
                                <td>
                                    <strong><?= htmlspecialchars($product['name']) ?></strong>
                                </td>
                                <td><?= htmlspecialchars($product['brand']) ?></td>
                                <td><?= htmlspecialchars($product['category']) ?></td>
                                <td style="text-align: right;">₼<?= number_format($product['price'], 2) ?></td>
                                <td style="text-align: center;">
                                    <span class="<?= $product['is_low_stock'] ? 'badge badge-warning' : '' ?>">
                                        <?= $product['stock_quantity'] ?>
                                    </span>
                                </td>
                                <td style="text-align: center;">
                                    <span class="badge badge-success"><?= $product['quantity_sold'] ?></span>
                                </td>
                                <td style="text-align: right;">
                                    <strong>₼<?= number_format($product['revenue'], 2) ?></strong>
                                </td>
                                <td style="text-align: center;">
                                    <?php if ($product['stock_quantity'] <= 0): ?>
                                        <span class="badge badge-danger">Bitib</span>
                                    <?php elseif ($product['is_low_stock']): ?>
                                        <span class="badge badge-warning">Az Stok</span>
                                    <?php else: ?>
                                        <span class="badge badge-success">Normal</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

<?php elseif ($reportType === 'users' && in_array($currentUserRole, ['admin', 'manager'])): ?>
    <!-- Users Performance Report -->
    <div class="content-box">
        <h4><i class="fas fa-users"></i> İstifadəçi Performansı</h4>
        
        <?php if (empty($usersData)): ?>
            <div style="text-align: center; padding: 40px; color: #6c757d;">
                <i class="fas fa-users" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                <p>İstifadəçi məlumatı yoxdur</p>
            </div>
        <?php else: ?>
            <div style="overflow-x: auto; margin-top: 20px;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>İstifadəçi</th>
                            <th>Rol</th>
                            <th style="text-align: center;">Satış Sayı</th>
                            <th style="text-align: right;">Cəmi Gəlir</th>
                            <th style="text-align: right;">Orta Satış</th>
                            <th>Son Satış</th>
                            <th>Son Aktivlik</th>
                            <th style="text-align: center;">Performance</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usersData as $user): ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 35px; height: 35px; border-radius: 50%; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center; font-weight: bold;">
                                            <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                                        </div>
                                        <strong><?= htmlspecialchars($user['full_name']) ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge badge-info"><?= ucfirst($user['role']) ?></span>
                                </td>
                                <td style="text-align: center;">
                                    <span class="badge badge-primary"><?= $user['total_sales'] ?? 0 ?></span>
                                </td>
                                <td style="text-align: right;">
                                    <strong>₼<?= number_format($user['total_revenue'] ?? 0, 2) ?></strong>
                                </td>
                                <td style="text-align: right;">₼<?= number_format($user['avg_sale'] ?? 0, 2) ?></td>
                                <td>
                                    <?= $user['last_sale_date'] ? date('d.m.Y', strtotime($user['last_sale_date'])) : 'Yoxdur' ?>
                                </td>
                                <td>
                                    <?= date('d.m.Y H:i', strtotime($user['last_activity'])) ?>
                                </td>
                                <td style="text-align: center;">
                                    <?php
                                    $performance = ($user['total_revenue'] ?? 0) / max(1, $summary['total_revenue'] ?? 1) * 100;
                                    $performanceClass = $performance > 15 ? 'success' : ($performance > 5 ? 'warning' : 'danger');
                                    ?>
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: <?= min(100, $performance) ?>%; background: var(--<?= $performanceClass ?>-color);"></div>
                                    </div>
                                    <small><?= number_format($performance, 1) ?>%</small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

<?php elseif ($reportType === 'financial'): ?>
    <!-- Financial Report -->
    <div class="content-box">
        <h4><i class="fas fa-dollar-sign"></i> Maliyyə Hesabatı</h4>
        
        <!-- Payment Methods Chart -->
        <?php if (!empty($paymentMethods)): ?>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin: 20px 0;">
            <div>
                <h5>Ödəniş Metodları</h5>
                <div style="margin-top: 15px;">
                    <?php foreach ($paymentMethods as $method): ?>
                        <?php 
                        $percentage = ($method['total'] / array_sum(array_column($paymentMethods, 'total'))) * 100;
                        $methodLabels = [
                            'cash' => '💵 Nağd',
                            'card' => '💳 Kart',
                            'transfer' => '🏦 Köçürmə'
                        ];
                        ?>
                        <div style="margin-bottom: 15px;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                                <span><?= $methodLabels[$method['payment_method']] ?? $method['payment_method'] ?></span>
                                <span>₼<?= number_format($method['total'], 2) ?> (<?= number_format($percentage, 1) ?>%)</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: <?= $percentage ?>%;"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div>
                <h5>Gündəlik Trend</h5>
                <canvas id="dailyTrendChart" style="max-height: 300px;"></canvas>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Financial Data Table -->
        <?php if (!empty($financialData)): ?>
            <div style="overflow-x: auto; margin-top: 20px;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Tarix</th>
                            <th>Ödəniş Metodu</th>
                            <th style="text-align: center;">Satış Sayı</th>
                            <th style="text-align: right;">Subtotal</th>
                            <th style="text-align: right;">VAT</th>
                            <th style="text-align: right;">Cəmi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($financialData as $data): ?>
                            <tr>
                                <td><?= date('d.m.Y', strtotime($data['date'])) ?></td>
                                <td>
                                    <?php
                                    $methodLabels = [
                                        'cash' => '💵 Nağd',
                                        'card' => '💳 Kart',
                                        'transfer' => '🏦 Köçürmə'
                                    ];
                                    echo $methodLabels[$data['payment_method']] ?? $data['payment_method'];
                                    ?>
                                </td>
                                <td style="text-align: center;">
                                    <span class="badge badge-primary"><?= $data['daily_sales'] ?></span>
                                </td>
                                <td style="text-align: right;">₼<?= number_format($data['daily_subtotal'], 2) ?></td>
                                <td style="text-align: right;">₼<?= number_format($data['daily_tax'], 2) ?></td>
                                <td style="text-align: right;">
                                    <strong>₼<?= number_format($data['daily_revenue'], 2) ?></strong>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Export functions
function exportToPDF() {
    window.print();
}

function exportToExcel() {
    const table = document.querySelector('.table');
    if (table) {
        const csv = tableToCSV(table);
        downloadCSV(csv, 'hesabat_<?= $reportType ?>_<?= date("Y-m-d") ?>.csv');
    }
}

function printReport() {
    window.print();
}

function emailReport() {
    alert('Email funksiyası hazırlanmaqdadır...');
}

function tableToCSV(table) {
    const rows = table.querySelectorAll('tr');
    const csv = [];
    
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const cols = row.querySelectorAll('td, th');
        const csvRow = [];
        
        for (let j = 0; j < cols.length; j++) {
            csvRow.push('"' + cols[j].textContent.trim().replace(/"/g, '""') + '"');
        }
        
        csv.push(csvRow.join(','));
    }
    
    return csv.join('\n');
}

// ... (əvvəlki kod davam edir)

function downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

// Charts
<?php if ($reportType === 'sales' && !empty($salesData)): ?>
const salesCtx = document.getElementById('salesChart').getContext('2d');
const salesChart = new Chart(salesCtx, {
    type: 'line',
    data: {
        labels: [<?= implode(',', array_map(function($sale) { return '"' . date('d.m', strtotime($sale['sale_date'])) . '"'; }, $salesData)) ?>],
        datasets: [{
            label: 'Gündəlik Satış (₼)',
            data: [<?= implode(',', array_column($salesData, 'total_revenue')) ?>],
            borderColor: 'rgb(102, 126, 234)',
            backgroundColor: 'rgba(102, 126, 234, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: 'Satış Trendi'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '₼' + value.toLocaleString();
                    }
                }
            }
        }
    }
});
<?php endif; ?>

<?php if ($reportType === 'financial' && !empty($financialData)): ?>
const trendCtx = document.getElementById('dailyTrendChart').getContext('2d');
const trendChart = new Chart(trendCtx, {
    type: 'bar',
    data: {
        labels: [<?= implode(',', array_map(function($data) { return '"' . date('d.m', strtotime($data['date'])) . '"'; }, array_unique(array_column($financialData, 'date')))) ?>],
        datasets: [{
            label: 'Gündəlik Gəlir',
            data: [<?= implode(',', array_column($financialData, 'daily_revenue')) ?>],
            backgroundColor: 'rgba(102, 126, 234, 0.8)',
            borderColor: 'rgb(102, 126, 234)',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: 'Gündəlik Gəlir Trendi'
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return '₼' + value.toLocaleString();
                    }
                }
            }
        }
    }
});
<?php endif; ?>

console.log('Reports system initialized - <?= $reportType ?>');
</script>

<?php include 'includes/footer.php'; ?>