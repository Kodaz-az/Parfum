<?php
/**
 * İstifadəçi Profili - Advanced Profile Management with Avatar Upload
 * Kodaz-az - 2025-07-21 14:41:57 (UTC)
 * Login: Kodaz-az
 */

$currentUserId = $_SESSION['user_id'];

// Handle avatar upload
function handleAvatarUpload($file, $userId) {
    $uploadDir = 'uploads/avatars/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $maxSize = 2 * 1024 * 1024; // 2MB
    
    if (!in_array($file['type'], $allowedTypes)) {
        throw new Exception('Yalnız JPG, PNG, WebP və GIF formatları dəstəklənir');
    }
    
    if ($file['size'] > $maxSize) {
        throw new Exception('Şəkil ölçüsü 2MB-dan çox ola bilməz');
    }
    
    // Create thumbnail
    $imageInfo = getimagesize($file['tmp_name']);
    $width = $imageInfo[0];
    $height = $imageInfo[1];
    
    // Resize to 300x300
    $newWidth = 300;
    $newHeight = 300;
    
    $canvas = imagecreatetruecolor($newWidth, $newHeight);
    
    switch ($file['type']) {
        case 'image/jpeg':
            $source = imagecreatefromjpeg($file['tmp_name']);
            break;
        case 'image/png':
            $source = imagecreatefrompng($file['tmp_name']);
            imagealphablending($canvas, false);
            imagesavealpha($canvas, true);
            break;
        case 'image/webp':
            $source = imagecreatefromwebp($file['tmp_name']);
            break;
        case 'image/gif':
            $source = imagecreatefromgif($file['tmp_name']);
            break;
    }
    
    imagecopyresampled($canvas, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'avatar_' . $userId . '_' . time() . '.' . $extension;
    $filepath = $uploadDir . $filename;
    
    switch ($file['type']) {
        case 'image/jpeg':
            imagejpeg($canvas, $filepath, 90);
            break;
        case 'image/png':
            imagepng($canvas, $filepath);
            break;
        case 'image/webp':
            imagewebp($canvas, $filepath, 90);
            break;
        case 'image/gif':
            imagegif($canvas, $filepath);
            break;
    }
    
    imagedestroy($canvas);
    imagedestroy($source);
    
    return $filename;
}

// Profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'update') {
    try {
        $db = Database::getInstance();
        
        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        $bio = trim($_POST['bio'] ?? '');
        $location = trim($_POST['location'] ?? '');
        $birthDate = $_POST['birth_date'] ?? '';
        $gender = $_POST['gender'] ?? '';
        $language = $_POST['language'] ?? 'az';
        $timezone = $_POST['timezone'] ?? 'Asia/Baku';
        $notifications = $_POST['notifications'] ?? [];
        
        $errors = [];
        
        // Validate basic fields
        if (empty($fullName)) $errors[] = "Ad və soyad tələb olunur";
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Düzgün email daxil edin";
        
        // Check if email already exists for other users
        $existingUser = $db->selectOne("SELECT id FROM users WHERE email = ? AND id != ?", [$email, $currentUserId]);
        if ($existingUser) {
            $errors[] = "Bu email artıq başqa istifadəçi tərəfindən istifadə olunur";
        }
        
        // Password validation if changing
        if (!empty($newPassword)) {
            if (empty($currentPassword)) {
                $errors[] = "Mövcud şifrəni daxil edin";
            } else {
                // Verify current password
                $user = $db->selectOne("SELECT password FROM users WHERE id = ?", [$currentUserId]);
                if (!password_verify($currentPassword, $user['password'])) {
                    $errors[] = "Mövcud şifrə yanlışdır";
                }
            }
            
            if (strlen($newPassword) < 6) {
                $errors[] = "Yeni şifrə ən azı 6 simvol olmalıdır";
            }
            
            if ($newPassword !== $confirmPassword) {
                $errors[] = "Şifrələr uyğun gəlmir";
            }
        }
        
        if (empty($errors)) {
            // Handle avatar upload
            $avatarName = null;
            if (!empty($_FILES['avatar']['name'])) {
                try {
                    $currentUser = $db->selectOne("SELECT avatar FROM users WHERE id = ?", [$currentUserId]);
                    
                    $avatarName = handleAvatarUpload($_FILES['avatar'], $currentUserId);
                    
                    // Delete old avatar
                    if ($currentUser['avatar'] && file_exists('uploads/avatars/' . $currentUser['avatar'])) {
                        unlink('uploads/avatars/' . $currentUser['avatar']);
                    }
                } catch (Exception $e) {
                    $errors[] = "Avatar yüklənə bilmədi: " . $e->getMessage();
                }
            }
            
            if (empty($errors)) {
                // Update profile
                $sql = "UPDATE users SET full_name = ?, email = ?, phone = ?, bio = ?, location = ?, birth_date = ?, gender = ?, language = ?, timezone = ?, updated_at = NOW()";
                $params = [$fullName, $email, $phone, $bio, $location, $birthDate ?: null, $gender, $language, $timezone];
                
                if ($avatarName) {
                    $sql .= ", avatar = ?";
                    $params[] = $avatarName;
                }
                
                if (!empty($newPassword)) {
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    $sql .= ", password = ?";
                    $params[] = $hashedPassword;
                }
                
                $sql .= " WHERE id = ?";
                $params[] = $currentUserId;
                
                $updated = $db->update($sql, $params);
                
                // Update notification preferences
                $db->delete("DELETE FROM user_preferences WHERE user_id = ? AND preference_type = 'notification'", [$currentUserId]);
                
                foreach ($notifications as $notification) {
                    $db->insert("
                        INSERT INTO user_preferences (user_id, preference_type, preference_key, preference_value, created_at)
                        VALUES (?, 'notification', ?, '1', NOW())
                    ", [$currentUserId, $notification]);
                }
                
                if ($updated) {
                    // Update session
                    $_SESSION['full_name'] = $fullName;
                    $_SESSION['email'] = $email;
                    
                    $_SESSION['success_message'] = "Profil uğurla yeniləndi!";
                    header('Location: ?page=profile');
                    exit;
                }
            }
        }
        
        if (!empty($errors)) {
            $_SESSION['error_message'] = implode('<br>', $errors);
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Profil yenilənə bilmədi: " . $e->getMessage();
    }
}

// Get user data and statistics
try {
    $db = Database::getInstance();
    
    $user = $db->selectOne("SELECT * FROM users WHERE id = ?", [$currentUserId]);
    
    // User statistics
    $stats = $db->selectOne("
        SELECT 
            COUNT(s.id) as total_sales,
            SUM(s.final_amount) as total_revenue,
            AVG(s.final_amount) as avg_sale,
            MAX(s.created_at) as last_sale_date,
            COUNT(DISTINCT DATE(s.created_at)) as active_days
        FROM sales s
        WHERE s.user_id = ?
    ", [$currentUserId]);
    
    // Monthly performance (last 6 months)
    $monthlyPerformance = $db->selectAll("
        SELECT 
            YEAR(created_at) as year,
            MONTH(created_at) as month,
            COUNT(*) as sales_count,
            SUM(final_amount) as revenue
        FROM sales
        WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
        GROUP BY YEAR(created_at), MONTH(created_at)
        ORDER BY year DESC, month DESC
    ", [$currentUserId]);
    
    // Recent activity
    $recentActivity = $db->selectAll("
        SELECT 
            al.action,
            al.description,
            al.created_at
        FROM activity_logs al
        WHERE al.user_id = ?
        ORDER BY al.created_at DESC
        LIMIT 10
    ", [$currentUserId]);
    
    // Get notification preferences
    $notificationPrefs = $db->selectAll("
        SELECT preference_key
        FROM user_preferences
        WHERE user_id = ? AND preference_type = 'notification'
    ", [$currentUserId]);
    
    $enabledNotifications = array_column($notificationPrefs, 'preference_key');
    
    // Achievement system
    $achievements = [];
    
    if ($stats['total_sales'] >= 100) {
        $achievements[] = ['icon' => '🏆', 'title' => 'Satış Ustası', 'desc' => '100+ satış'];
    }
    if ($stats['total_revenue'] >= 10000) {
        $achievements[] = ['icon' => '💰', 'title' => 'Gəlir Kralı', 'desc' => '₼10,000+ gəlir'];
    }
    if ($stats['active_days'] >= 30) {
        $achievements[] = ['icon' => '⭐', 'title' => 'Fədakar İşçi', 'desc' => '30+ aktiv gün'];
    }
    
} catch (Exception $e) {
    $user = [];
    $stats = ['total_sales' => 0, 'total_revenue' => 0, 'avg_sale' => 0, 'last_sale_date' => null, 'active_days' => 0];
    $monthlyPerformance = [];
    $recentActivity = [];
    $enabledNotifications = [];
    $achievements = [];
}

$pageTitle = "Profil - " . PWA_NAME;
include 'includes/header.php';
?>

<style>
.profile-container {
    display: grid;
    grid-template-columns: 350px 1fr;
    gap: 30px;
    margin-bottom: 30px;
}

.profile-sidebar {
    background: white;
    border-radius: 20px;
    box-shadow: var(--box-shadow);
    overflow: hidden;
    height: fit-content;
    position: sticky;
    top: 20px;
}

.profile-main {
    background: white;
    border-radius: 20px;
    box-shadow: var(--box-shadow);
    padding: 30px;
}

.profile-avatar-section {
    text-align: center;
    padding: 30px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    position: relative;
}

.profile-avatar-wrapper {
    position: relative;
    display: inline-block;
    margin-bottom: 20px;
}

.profile-avatar {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 4px solid rgba(255, 255, 255, 0.3);
    object-fit: cover;
    background: rgba(255, 255, 255, 0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    font-weight: bold;
    color: white;
}

.avatar-upload-btn {
    position: absolute;
    bottom: 5px;
    right: 5px;
    width: 35px;
    height: 35px;
    border-radius: 50%;
    background: var(--success-color);
    color: white;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--transition);
    box-shadow: 0 2px 8px rgba(0,0,0,0.2);
}

.avatar-upload-btn:hover {
    transform: scale(1.1);
    background: #1e7e34;
}

.profile-info {
    padding: 25px;
}

.profile-stat {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 0;
    border-bottom: 1px solid #f0f0f0;
}

.profile-stat:last-child {
    border-bottom: none;
}

.stat-label {
    color: #6c757d;
    font-size: 0.9rem;
}

.stat-value {
    font-weight: bold;
    color: var(--dark-color);
}

.achievements-section {
    padding: 25px;
    background: #f8f9fa;
    border-top: 1px solid #e9ecef;
}

.achievement-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 12px 0;
    border-bottom: 1px solid #e9ecef;
}

.achievement-item:last-child {
    border-bottom: none;
}

.achievement-icon {
    font-size: 1.5rem;
}

.achievement-details {
    flex: 1;
}

.achievement-title {
    font-weight: bold;
    margin-bottom: 3px;
}

.achievement-desc {
    font-size: 0.8rem;
    color: #6c757d;
}

.form-tabs {
    display: flex;
    border-bottom: 2px solid #e9ecef;
    margin-bottom: 30px;
    gap: 0;
}

.form-tab {
    padding: 15px 25px;
    border: none;
    background: none;
    color: #6c757d;
    cursor: pointer;
    border-bottom: 3px solid transparent;
    transition: var(--transition);
    font-weight: 500;
}

.form-tab.active {
    color: var(--primary-color);
    border-bottom-color: var(--primary-color);
    background: rgba(102, 126, 234, 0.1);
}

.form-tab:hover {
    background: rgba(102, 126, 234, 0.05);
}

.tab-content {
    display: none;
}

.tab-content.active {
    display: block;
}

.avatar-crop-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.8);
    z-index: 3000;
    display: none;
    align-items: center;
    justify-content: center;
    backdrop-filter: blur(5px);
}

.avatar-crop-content {
    background: white;
    border-radius: 15px;
    padding: 30px;
    max-width: 500px;
    width: 90%;
    text-align: center;
}

.crop-preview {
    width: 300px;
    height: 300px;
    border-radius: 50%;
    margin: 20px auto;
    border: 3px solid var(--primary-color);
    overflow: hidden;
}

.notification-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px;
    background: #f8f9fa;
    border-radius: 10px;
    margin-bottom: 10px;
}

.notification-switch {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 28px;
}

.notification-switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: 0.4s;
    border-radius: 28px;
}

.slider:before {
    position: absolute;
    content: "";
    height: 20px;
    width: 20px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: 0.4s;
    border-radius: 50%;
}

input:checked + .slider {
    background-color: var(--primary-color);
}

input:checked + .slider:before {
    transform: translateX(22px);
}

@media (max-width: 1024px) {
    .profile-container {
        grid-template-columns: 1fr;
    }
    
    .profile-sidebar {
        position: static;
    }
}

@media (max-width: 768px) {
    .form-tabs {
        flex-wrap: wrap;
    }
    
    .form-tab {
        flex: 1;
        min-width: 120px;
    }
}
</style>

<div class="profile-container">
    <!-- Profile Sidebar -->
    <div class="profile-sidebar">
        <div class="profile-avatar-section">
            <div class="profile-avatar-wrapper">
                <?php if ($user['avatar']): ?>
                    <img src="uploads/avatars/<?= htmlspecialchars($user['avatar']) ?>" class="profile-avatar" alt="Avatar">
                <?php else: ?>
                    <div class="profile-avatar">
                        <?= strtoupper(substr($user['full_name'] ?? 'U', 0, 2)) ?>
                    </div>
                <?php endif; ?>
                
                <button class="avatar-upload-btn" onclick="document.getElementById('avatar-input').click()" title="Profil şəklini dəyişdir">
                    <i class="fas fa-camera"></i>
                </button>
                
                <input type="file" id="avatar-input" accept="image/*" style="display: none;">
            </div>
            
            <h3 style="margin-bottom: 5px;"><?= htmlspecialchars($user['full_name'] ?? 'İstifadəçi') ?></h3>
            <p style="opacity: 0.9; font-size: 0.9rem; margin: 0;">
                @<?= htmlspecialchars($user['username'] ?? '') ?> • 
                <span style="text-transform: capitalize;"><?= htmlspecialchars($user['role'] ?? '') ?></span>
            </p>
            
            <?php if ($user['bio']): ?>
                <p style="margin-top: 15px; opacity: 0.9; font-size: 0.9rem; font-style: italic;">
                    "<?= htmlspecialchars($user['bio']) ?>"
                </p>
            <?php endif; ?>
        </div>
        
        <div class="profile-info">
            <div class="profile-stat">
                <span class="stat-label">Cəmi Satış</span>
                <span class="stat-value"><?= $stats['total_sales'] ?></span>
            </div>
            
            <div class="profile-stat">
                <span class="stat-label">Cəmi Gəlir</span>
                <span class="stat-value">₼<?= number_format($stats['total_revenue'], 0) ?></span>
            </div>
            
            <div class="profile-stat">
                <span class="stat-label">Orta Satış</span>
                <span class="stat-value">₼<?= number_format($stats['avg_sale'], 2) ?></span>
            </div>
            
            <div class="profile-stat">
                <span class="stat-label">Aktiv Günlər</span>
                <span class="stat-value"><?= $stats['active_days'] ?></span>
            </div>
            
            <div class="profile-stat">
                <span class="stat-label">Qeydiyyat</span>
                <span class="stat-value"><?= date('d.m.Y', strtotime($user['created_at'] ?? 'now')) ?></span>
            </div>
            
            <div class="profile-stat">
                <span class="stat-label">Son Aktivlik</span>
                <span class="stat-value"><?= date('d.m H:i', strtotime($user['last_activity'] ?? 'now')) ?></span>
            </div>
        </div>
        
        <?php if (!empty($achievements)): ?>
        <div class="achievements-section">
            <h6 style="margin-bottom: 15px; color: var(--dark-color);">
                <i class="fas fa-trophy"></i> Nailiyyətlər
            </h6>
            
            <?php foreach ($achievements as $achievement): ?>
                <div class="achievement-item">
                    <div class="achievement-icon"><?= $achievement['icon'] ?></div>
                    <div class="achievement-details">
                        <div class="achievement-title"><?= $achievement['title'] ?></div>
                        <div class="achievement-desc"><?= $achievement['desc'] ?></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Profile Main -->
    <div class="profile-main">
        <h2 style="margin-bottom: 25px; color: var(--dark-color);">
            <i class="fas fa-user-edit"></i> Profil Tənzimləmələri
        </h2>
        
        <!-- Form Tabs -->
        <div class="form-tabs">
            <button class="form-tab active" onclick="showTab('personal')">
                <i class="fas fa-user"></i> Şəxsi Məlumatlar
            </button>
            <button class="form-tab" onclick="showTab('security')">
                <i class="fas fa-shield-alt"></i> Təhlükəsizlik
            </button>
            <button class="form-tab" onclick="showTab('preferences')">
                <i class="fas fa-cog"></i> Tənzimləmələr
            </button>
            <button class="form-tab" onclick="showTab('activity')">
                <i class="fas fa-history"></i> Aktivlik
            </button>
        </div>
        
        <form method="POST" enctype="multipart/form-data" id="profile-form">
            <input type="hidden" name="action" value="update">
            
            <!-- Personal Information Tab -->
            <div id="personal" class="tab-content active">
                <h4 style="margin-bottom: 20px; color: var(--primary-color);">Şəxsi Məlumatlar</h4>
                
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-id-card"></i> Ad və Soyad *</label>
                        <input type="text" name="full_name" value="<?= htmlspecialchars($user['full_name'] ?? '') ?>" required class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email *</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required class="form-control">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Telefon</label>
                        <input type="tel" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" class="form-control">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-birthday-cake"></i> Doğum Tarixi</label>
                        <input type="date" name="birth_date" value="<?= $user['birth_date'] ?? '' ?>" class="form-control">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-venus-mars"></i> Cins</label>
                        <select name="gender" class="form-control">
                            <option value="">Seçilməyib</option>
                            <option value="male" <?= ($user['gender'] ?? '') === 'male' ? 'selected' : '' ?>>Kişi</option>
                            <option value="female" <?= ($user['gender'] ?? '') === 'female' ? 'selected' : '' ?>>Qadın</option>
                            <option value="other" <?= ($user['gender'] ?? '') === 'other' ? 'selected' : '' ?>>Digər</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Məkan</label>
                        <input type="text" name="location" value="<?= htmlspecialchars($user['location'] ?? '') ?>" class="form-control" placeholder="Şəhər, Ölkə">
                    </div>
                </div>
                
                <div class="form-group">
                    <label><i class="fas fa-quote-left"></i> Bio</label>
                    <textarea name="bio" rows="3" class="form-control" placeholder="Özünüz haqqında qısa məlumat"><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
                </div>
            </div>
            
            <!-- Security Tab -->
            <div id="security" class="tab-content">
                <h4 style="margin-bottom: 20px; color: var(--primary-color);">Təhlükəsizlik Tənzimləmələri</h4>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 25px;">
                    <h6 style="color: var(--dark-color); margin-bottom: 15px;">
                        <i class="fas fa-key"></i> Şifrə Dəyişdirmə
                    </h6>
                    
                    <div class="form-group">
                        <label>Mövcud Şifrə</label>
                        <input type="password" name="current_password" class="form-control" placeholder="Şifrəni dəyişdirmək istəmirsinizsə boş buraxın">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Yeni Şifrə</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Minimum 6 simvol">
                        </div>
                        
                        <div class="form-group">
                            <label>Yeni Şifrə Təkrarı</label>
                            <input type="password" name="confirm_password" class="form-control" placeholder="Şifrəni təkrar edin">
                        </div>
                    </div>
                </div>
                
                <div style="background: #e3f2fd; padding: 20px; border-radius: 10px;">
                    <h6 style="color: var(--info-color); margin-bottom: 15px;">
                        <i class="fas fa-shield-alt"></i> Hesab Təhlükəsizliyi
                    </h6>
                    
                    <div style="display: grid; gap: 15px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <strong>İki Faktorlu Təsdiq</strong>
                                <div style="font-size: 0.8rem; color: #6c757d;">SMS və ya email ilə təsdiq</div>
                            </div>
                            <span class="badge badge-warning">Tezliklə</span>
                        </div>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <strong>Login Bildirişləri</strong>
                                <div style="font-size: 0.8rem; color: #6c757d;">Yeni cihazdan girişdə xəbər ver</div>
                            </div>
                            <label class="notification-switch">
                                <input type="checkbox" checked>
                                <span class="slider"></span>
                            </label>
                        </div>
                        
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <strong>Şifrə Müddəti</strong>
                                <div style="font-size: 0.8rem; color: #6c757d;">Son dəyişiklik: <?= $user['updated_at'] ? date('d.m.Y', strtotime($user['updated_at'])) : 'Heç vaxt' ?></div>
                            </div>
                            <span class="badge badge-<?= $user['updated_at'] && strtotime($user['updated_at']) > strtotime('-90 days') ? 'success' : 'warning' ?>">
                                <?= $user['updated_at'] && strtotime($user['updated_at']) > strtotime('-90 days') ? 'Yaxşı' : 'Köhnə' ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Preferences Tab -->
            <div id="preferences" class="tab-content">
                <h4 style="margin-bottom: 20px; color: var(--primary-color);">Sistem Tənzimləmələri</h4>
                
                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-language"></i> Dil</label>
                        <select name="language" class="form-control">
                            <option value="az" <?= ($user['language'] ?? 'az') === 'az' ? 'selected' : '' ?>>Azərbaycan</option>
                            <option value="en" <?= ($user['language'] ?? 'az') === 'en' ? 'selected' : '' ?>>English</option>
                            <option value="ru" <?= ($user['language'] ?? 'az') === 'ru' ? 'selected' : '' ?>>Русский</option>
                            <option value="tr" <?= ($user['language'] ?? 'az') === 'tr' ? 'selected' : '' ?>>Türkçe</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-clock"></i> Vaxt Zonası</label>
                        <select name="timezone" class="form-control">
                            <option value="Asia/Baku" <?= ($user['timezone'] ?? 'Asia/Baku') === 'Asia/Baku' ? 'selected' : '' ?>>Bakı (UTC+4)</option>
                            <option value="Europe/Istanbul" <?= ($user['timezone'] ?? '') === 'Europe/Istanbul' ? 'selected' : '' ?>>İstanbul (UTC+3)</option>
                            <option value="Europe/Moscow" <?= ($user['timezone'] ?? '') === 'Europe/Moscow' ? 'selected' : '' ?>>Moskva (UTC+3)</option>
                            <option value="UTC" <?= ($user['timezone'] ?? '') === 'UTC' ? 'selected' : '' ?>>UTC (GMT+0)</option>
                        </select>
                    </div>
                </div>
                
                <h5 style="margin: 25px 0 15px; color: var(--dark-color);">
                    <i class="fas fa-bell"></i> Bildiriş Tənzimləmələri
                </h5>
                
                <div style="display: grid; gap: 15px;">
                    <div class="notification-item">
                        <div>
                            <strong>Satış Bildirişləri</strong>
                            <div style="font-size: 0.8rem; color: #6c757d;">Yeni satış və ödəmələr haqqında</div>
                        </div>
                        <label class="notification-switch">
                            <input type="checkbox" name="notifications[]" value="sales" <?= in_array('sales', $enabledNotifications) ? 'checked' : '' ?>>
                            <span class="slider"></span>
                        </label>
                    </div>
                    
                    <div class="notification-item">
                        <div>
                            <strong>Stok Xəbərdarlıqları</strong>
                            <div style="font-size: 0.8rem; color: #6c757d;">Az stok və bitən məhsullar</div>
                        </div>
                        <label class="notification-switch">
                            <input type="checkbox" name="notifications[]" value="stock" <?= in_array('stock', $enabledNotifications) ? 'checked' : '' ?>>
                            <span class="slider"></span>
                        </label>
                    </div>
                    
                    <div class="notification-item">
                        <div>
                            <strong>Chat Mesajları</strong>
                            <div style="font-size: 0.8rem; color: #6c757d;">Yeni mesaj bildirişləri</div>
                        </div>
                        <label class="notification-switch">
                            <input type="checkbox" name="notifications[]" value="chat" <?= in_array('chat', $enabledNotifications) ? 'checked' : '' ?>>
                            <span class="slider"></span>
                        </label>
                    </div>
                    
                    <div class="notification-item">
                        <div>
                            <strong>Maaş Bildirişləri</strong>
                            <div style="font-size: 0.8rem; color: #6c757d;">Maaş hesablaması və ödəmələr</div>
                        </div>
                        <label class="notification-switch">
                            <input type="checkbox" name="notifications[]" value="salary" <?= in_array('salary', $enabledNotifications) ? 'checked' : '' ?>>
                            <span class="slider"></span>
                        </label>
                    </div>
                    
                    <div class="notification-item">
                        <div>
                            <strong>Sistem Yenilikləri</strong>
                            <div style="font-size: 0.8rem; color: #6c757d;">Yeni funksiyalar və güncəlləmələr</div>
                        </div>
                        <label class="notification-switch">
                            <input type="checkbox" name="notifications[]" value="system" <?= in_array('system', $enabledNotifications) ? 'checked' : '' ?>>
                            <span class="slider"></span>
                        </label>
                    </div>
                </div>
            </div>
            
            <!-- Activity Tab -->
            <div id="activity" class="tab-content">
                <h4 style="margin-bottom: 20px; color: var(--primary-color);">Son Aktivliklər</h4>
                
                <?php if (empty($recentActivity)): ?>
                    <div style="text-align: center; padding: 40px; color: #6c757d;">
                        <i class="fas fa-history" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                        <h5>Aktivlik tarixçəsi yoxdur</h5>
                        <p>Hələ heç bir fəaliyyət qeydə alınmayıb</p>
                    </div>
                <?php else: ?>
                    <div style="display: flex; flex-direction: column; gap: 15px;">
                        <?php foreach ($recentActivity as $activity): ?>
                            <div style="display: flex; align-items: center; gap: 15px; padding: 15px; background: #f8f9fa; border-radius: 10px;">
                                <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center;">
                                    <i class="fas fa-<?= 
                                        strpos($activity['action'], 'sale') !== false ? 'shopping-cart' : 
                                        (strpos($activity['action'], 'product') !== false ? 'box' : 
                                        (strpos($activity['action'], 'login') !== false ? 'sign-in-alt' : 'cog'))
                                    ?>"></i>
                                </div>
                                
                                <div style="flex: 1;">
                                    <div style="font-weight: bold; margin-bottom: 3px;">
                                        <?= htmlspecialchars($activity['description']) ?>
                                    </div>
                                    <div style="font-size: 0.8rem; color: #6c757d;">
                                        <i class="fas fa-clock"></i>
                                        <?= date('d.m.Y H:i', strtotime($activity['created_at'])) ?>
                                    </div>
                                </div>
                                
                                <div style="color: var(--success-color);">
                                    <i class="fas fa-check-circle"></i>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div style="text-align: center; margin-top: 25px;">
                        <button type="button" onclick="loadMoreActivity()" class="btn btn-secondary">
                            <i class="fas fa-plus"></i> Daha Çox
                        </button>
                    </div>
                <?php endif; ?>
                
                <!-- Performance Chart -->
                <?php if (!empty($monthlyPerformance)): ?>
                <div style="margin-top: 40px;">
                    <h5 style="margin-bottom: 20px; color: var(--dark-color);">
                        <i class="fas fa-chart-area"></i> Performans Trendi
                    </h5>
                    <canvas id="performanceChart" style="max-height: 300px;"></canvas>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Submit Button -->
            <div style="margin-top: 40px; text-align: center; border-top: 1px solid #e9ecef; padding-top: 25px;">
                <button type="submit" class="btn btn-primary" style="padding: 15px 40px; font-size: 1.1rem;">
                    <i class="fas fa-save"></i> Dəyişiklikləri Saxla
                </button>
                
                <button type="button" onclick="resetForm()" class="btn btn-secondary" style="padding: 15px 40px; font-size: 1.1rem; margin-left: 15px;">
                    <i class="fas fa-undo"></i> Sıfırla
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Avatar Crop Modal -->
<div class="avatar-crop-modal" id="avatarCropModal">
    <div class="avatar-crop-content">
        <h4 style="margin-bottom: 20px;">
            <i class="fas fa-crop"></i> Profil Şəklini Kəs
        </h4>
        
        <div class="crop-preview" id="cropPreview">
            <img id="cropImage" style="width: 100%; height: 100%; object-fit: cover;">
        </div>
        
        <div style="margin-top: 25px;">
            <button onclick="saveCroppedAvatar()" class="btn btn-primary">
                <i class="fas fa-check"></i> Təsdiq Et
            </button>
            
            <button onclick="closeCropModal()" class="btn btn-secondary">
                <i class="fas fa-times"></i> Ləğv Et
            </button>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Tab switching
function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    document.querySelectorAll('.form-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(tabName).classList.add('active');
    event.target.classList.add('active');
}

// Avatar upload handling
document.getElementById('avatar-input').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            showCropModal(e.target.result);
        };
        reader.readAsDataURL(file);
    }
});

function showCropModal(imageSrc) {
    const modal = document.getElementById('avatarCropModal');
    const cropImage = document.getElementById('cropImage');
    
    cropImage.src = imageSrc;
    modal.style.display = 'flex';
}

function closeCropModal() {
    document.getElementById('avatarCropModal').style.display = 'none';
}

function saveCroppedAvatar() {
    // In a real implementation, you would use a library like Cropper.js
    // For now, we'll just submit the form with the original image
    
    const form = document.getElementById('profile-form');
    const formData = new FormData();
    
    // Add avatar file
    const avatarInput = document.getElementById('avatar-input');
    if (avatarInput.files[0]) {
        formData.append('avatar', avatarInput.files[0]);
    }
    
    // Add other form data
    const formElements = form.elements;
    for (let element of formElements) {
        if (element.name && element.type !== 'file') {
            if (element.type === 'checkbox') {
                if (element.checked) {
                    formData.append(element.name, element.value);
                }
            } else {
                formData.append(element.name, element.value);
            }
        }
    }
    
    // Show loading
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Yüklənir...';
    submitBtn.disabled = true;
    
    fetch('?page=profile&action=update', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        // Reload page to see changes
        location.reload();
    })
    .catch(error => {
        alert('Xəta baş verdi');
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    });
    
    closeCropModal();
}

// ... (əvvəlki kod davam edir)

// Performance Chart
<?php if (!empty($monthlyPerformance)): ?>
const ctx = document.getElementById('performanceChart').getContext('2d');
const monthNames = ['Yan', 'Fev', 'Mar', 'Apr', 'May', 'İyn', 'İyl', 'Avq', 'Sen', 'Okt', 'Noy', 'Dek'];

const chart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [<?= implode(',', array_map(function($perf) use ($monthNames) { 
            return '"' . $monthNames[$perf['month'] - 1] . ' ' . $perf['year'] . '"'; 
        }, array_reverse($monthlyPerformance))) ?>],
        datasets: [{
            label: 'Aylıq Gəlir (₼)',
            data: [<?= implode(',', array_column(array_reverse($monthlyPerformance), 'revenue')) ?>],
            borderColor: '#667eea',
            backgroundColor: 'rgba(102, 126, 234, 0.1)',
            tension: 0.4,
            fill: true
        }, {
            label: 'Satış Sayı',
            data: [<?= implode(',', array_column(array_reverse($monthlyPerformance), 'sales_count')) ?>],
            borderColor: '#28a745',
            backgroundColor: 'rgba(40, 167, 69, 0.1)',
            tension: 0.4,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                type: 'linear',
                display: true,
                position: 'left',
                title: { display: true, text: 'Gəlir (₼)' }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                title: { display: true, text: 'Satış Sayı' },
                grid: { drawOnChartArea: false }
            }
        }
    }
});
<?php endif; ?>

// Form validation
document.getElementById('profile-form').addEventListener('submit', function(e) {
    const newPassword = document.querySelector('input[name="new_password"]').value;
    const confirmPassword = document.querySelector('input[name="confirm_password"]').value;
    const currentPassword = document.querySelector('input[name="current_password"]').value;
    
    if (newPassword) {
        if (!currentPassword) {
            alert('Yeni şifrə təyin etmək üçün mövcud şifrəni daxil edin');
            e.preventDefault();
            return;
        }
        
        if (newPassword.length < 6) {
            alert('Yeni şifrə ən azı 6 simvol olmalıdır');
            e.preventDefault();
            return;
        }
        
        if (newPassword !== confirmPassword) {
            alert('Şifrələr uyğun gəlmir');
            e.preventDefault();
            return;
        }
    }
});

function loadMoreActivity() {
    // In production, this would load more activities via AJAX
    alert('Daha çox aktivlik yüklənməsi hazırlanmaqdadır...');
}

function resetForm() {
    if (confirm('Bütün dəyişiklikləri sıfırlamaq istədiyinizə əminsiniz?')) {
        location.reload();
    }
}

console.log('Profile system initialized');
console.log('User: <?= $user['username'] ?? 'N/A' ?>', 'Role: <?= $user['role'] ?? 'N/A' ?>');
</script>

<?php include 'includes/footer.php'; ?>