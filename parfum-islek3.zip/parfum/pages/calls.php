<?php
/**
 * Video/Audio Zəng Sistemi - WebRTC
 * Kodaz-az - 2025-07-21 13:39:12 (UTC)
 * Login: Kodaz-az
 */

$currentUserId = $_SESSION['user_id'];
$currentUserName = $_SESSION['full_name'];

// Get target user for call
$targetUserId = $_GET['user'] ?? null;
$callType = $_GET['type'] ?? $_GET['action'] ?? 'video'; // video or voice
$targetUser = null;

if ($targetUserId) {
    try {
        $db = Database::getInstance();
        $targetUser = $db->selectOne("SELECT * FROM users WHERE id = ? AND is_active = 1", [$targetUserId]);
    } catch (Exception $e) {
        $targetUserId = null;
    }
}

// Call history
try {
    $db = Database::getInstance();
    
    // Get recent calls
    $recentCalls = $db->selectAll("
        SELECT c.*, 
        caller.full_name as caller_name,
        receiver.full_name as receiver_name
        FROM call_history c
        LEFT JOIN users caller ON c.caller_id = caller.id
        LEFT JOIN users receiver ON c.receiver_id = receiver.id
        WHERE c.caller_id = ? OR c.receiver_id = ?
        ORDER BY c.created_at DESC
        LIMIT 20
    ", [$currentUserId, $currentUserId]);
    
    // Get active users for calling
    $availableUsers = $db->selectAll("
        SELECT * FROM users 
        WHERE id != ? AND is_active = 1 
        AND last_activity >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)
        ORDER BY last_activity DESC
    ", [$currentUserId]);
    
} catch (Exception $e) {
    $recentCalls = [];
    $availableUsers = [];
}

$pageTitle = "Zənglər - " . PWA_NAME;
include 'includes/header.php';
?>

<style>
.calls-layout {
    display: grid;
    grid-template-columns: 350px 1fr;
    gap: 20px;
    height: calc(100vh - 200px);
}

.calls-sidebar {
    background: var(--white);
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    overflow: hidden;
}

.calls-main {
    background: var(--white);
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    position: relative;
    overflow: hidden;
}

.video-container {
    position: relative;
    width: 100%;
    height: 100%;
    background: #000;
    display: flex;
    align-items: center;
    justify-content: center;
}

.local-video,
.remote-video {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.local-video {
    position: absolute;
    top: 20px;
    right: 20px;
    width: 200px;
    height: 150px;
    border-radius: 10px;
    z-index: 10;
    border: 3px solid var(--white);
}

.call-controls {
    position: absolute;
    bottom: 30px;
    left: 50%;
    transform: translateX(-50%);
    display: flex;
    gap: 15px;
    z-index: 20;
}

.call-btn {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    border: none;
    color: var(--white);
    font-size: 1.5rem;
    cursor: pointer;
    transition: var(--transition);
    display: flex;
    align-items: center;
    justify-content: center;
}

.call-btn.mute { background: #6c757d; }
.call-btn.video { background: var(--info-color); }
.call-btn.end { background: var(--danger-color); }
.call-btn.answer { background: var(--success-color); }

.call-btn:hover {
    transform: scale(1.1);
}

.call-status {
    position: absolute;
    top: 30px;
    left: 30px;
    color: var(--white);
    background: rgba(0,0,0,0.7);
    padding: 15px 20px;
    border-radius: 10px;
    z-index: 20;
}

.call-info {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 10px;
}

.call-avatar {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: var(--primary-color);
    color: var(--white);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.call-placeholder {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: #6c757d;
    text-align: center;
    padding: 40px;
}

.call-placeholder i {
    font-size: 4rem;
    margin-bottom: 20px;
    opacity: 0.3;
}

.users-header {
    background: linear-gradient(135deg, var(--info-color), #138496);
    color: var(--white);
    padding: 20px;
    text-align: center;
}

.call-history-header {
    background: #f8f9fa;
    padding: 15px 20px;
    border-bottom: 1px solid #e9ecef;
    font-weight: bold;
    color: var(--dark-color);
}

.call-item {
    display: flex;
    align-items: center;
    padding: 15px 20px;
    border-bottom: 1px solid #f0f0f0;
    cursor: pointer;
    transition: var(--transition);
}

.call-item:hover {
    background: #f8f9fa;
}

.call-item-avatar {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    background: var(--primary-color);
    color: var(--white);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin-right: 15px;
}

.call-item-details {
    flex: 1;
    min-width: 0;
}

.call-item-name {
    font-weight: bold;
    font-size: 0.9rem;
    margin-bottom: 3px;
}

.call-item-info {
    font-size: 0.8rem;
    color: #6c757d;
}

.call-actions {
    display: flex;
    gap: 8px;
}

.call-action-btn {
    width: 35px;
    height: 35px;
    border-radius: 50%;
    border: none;
    color: var(--white);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.9rem;
}

.incoming-call-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.9);
    z-index: 3000;
    display: none;
    align-items: center;
    justify-content: center;
}

.incoming-call-content {
    background: var(--white);
    border-radius: 20px;
    padding: 40px;
    text-align: center;
    max-width: 400px;
    width: 90%;
}

.incoming-avatar {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    background: var(--primary-color);
    color: var(--white);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2rem;
    font-weight: bold;
    margin: 0 auto 20px;
}

.incoming-actions {
    display: flex;
    justify-content: center;
    gap: 30px;
    margin-top: 30px;
}

@media (max-width: 768px) {
    .calls-layout {
        grid-template-columns: 1fr;
        height: auto;
    }
    
    .calls-sidebar {
        order: 2;
        max-height: 300px;
    }
    
    .calls-main {
        order: 1;
        height: 500px;
    }
    
    .local-video {
        width: 120px;
        height: 90px;
        top: 10px;
        right: 10px;
    }
    
    .call-controls {
        bottom: 20px;
        gap: 10px;
    }
    
    .call-btn {
        width: 50px;
        height: 50px;
        font-size: 1.2rem;
    }
}
</style>

<div class="calls-layout">
    <!-- Sidebar -->
    <div class="calls-sidebar">
        <div class="users-header">
            <h4><i class="fas fa-phone"></i> Zəng Sistemi</h4>
            <small><?= count($availableUsers) ?> istifadəçi əlçatan</small>
        </div>
        
        <!-- Available Users -->
        <div class="call-history-header">
            <i class="fas fa-users"></i> Aktiv İstifadəçilər
        </div>
        
        <div style="max-height: 250px; overflow-y: auto;">
            <?php if (empty($availableUsers)): ?>
                <div style="padding: 20px; text-align: center; color: #6c757d;">
                    <i class="fas fa-user-slash" style="font-size: 1.5rem; margin-bottom: 10px; opacity: 0.3;"></i>
                    <p>Aktiv istifadəçi yoxdur</p>
                </div>
            <?php else: ?>
                <?php foreach ($availableUsers as $user): ?>
                    <div class="call-item">
                        <div class="call-item-avatar">
                            <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                        </div>
                        <div class="call-item-details">
                            <div class="call-item-name"><?= htmlspecialchars($user['full_name']) ?></div>
                            <div class="call-item-info">
                                <i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem;"></i>
                                Online - <?= ucfirst($user['role']) ?>
                            </div>
                        </div>
                        <div class="call-actions">
                            <button onclick="startCall(<?= $user['id'] ?>, 'voice')" 
                                    class="call-action-btn" style="background: var(--success-color);" 
                                    title="Səsli zəng">
                                <i class="fas fa-phone"></i>
                            </button>
                            <button onclick="startCall(<?= $user['id'] ?>, 'video')" 
                                    class="call-action-btn" style="background: var(--info-color);" 
                                    title="Video zəng">
                                <i class="fas fa-video"></i>
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        
        <!-- Call History -->
        <div class="call-history-header">
            <i class="fas fa-history"></i> Son Zənglər
        </div>
        
        <div style="flex: 1; overflow-y: auto;">
            <?php if (empty($recentCalls)): ?>
                <div style="padding: 20px; text-align: center; color: #6c757d;">
                    <i class="fas fa-phone-slash" style="font-size: 1.5rem; margin-bottom: 10px; opacity: 0.3;"></i>
                    <p>Zəng tarixçəsi yoxdur</p>
                </div>
            <?php else: ?>
                <?php foreach ($recentCalls as $call): ?>
                    <div class="call-item">
                        <div class="call-item-avatar">
                            <?php
                            $otherUser = $call['caller_id'] == $currentUserId ? $call['receiver_name'] : $call['caller_name'];
                            echo strtoupper(substr($otherUser, 0, 1));
                            ?>
                        </div>
                        <div class="call-item-details">
                            <div class="call-item-name"><?= htmlspecialchars($otherUser) ?></div>
                            <div class="call-item-info">
                                <i class="fas fa-<?= $call['call_type'] === 'video' ? 'video' : 'phone' ?>"></i>
                                <?= $call['caller_id'] == $currentUserId ? 'Gedən' : 'Gələn' ?> •
                                <?= date('d.m H:i', strtotime($call['created_at'])) ?>
                                <?php if ($call['duration']): ?>
                                    • <?= gmdate('H:i:s', $call['duration']) ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="call-actions">
                            <i class="fas fa-<?= $call['status'] === 'completed' ? 'check-circle' : ($call['status'] === 'missed' ? 'times-circle' : 'clock') ?>" 
                               style="color: <?= $call['status'] === 'completed' ? '#28a745' : ($call['status'] === 'missed' ? '#dc3545' : '#ffc107') ?>;"></i>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Main Call Area -->
    <div class="calls-main">
        <?php if ($targetUser): ?>
            <!-- Active Call Interface -->
            <div class="video-container">
                <video id="remoteVideo" class="remote-video" autoplay playsinline></video>
                <video id="localVideo" class="local-video" autoplay playsinline muted></video>
                
                <div class="call-status">
                    <div class="call-info">
                        <div class="call-avatar">
                            <?= strtoupper(substr($targetUser['full_name'], 0, 1)) ?>
                        </div>
                        <div>
                            <div style="font-weight: bold; font-size: 1.1rem;">
                                <?= htmlspecialchars($targetUser['full_name']) ?>
                            </div>
                            <div style="font-size: 0.9rem; opacity: 0.8;">
                                <span id="callStatus">Qoşulur...</span>
                            </div>
                        </div>
                    </div>
                    <div style="font-size: 0.9rem;">
                        <i class="fas fa-clock"></i> <span id="callTimer">00:00</span>
                    </div>
                </div>
                
                <div class="call-controls">
                    <button id="muteBtn" class="call-btn mute" onclick="toggleMute()" title="Mikrofonu bağla/aç">
                        <i class="fas fa-microphone"></i>
                    </button>
                    
                    <?php if ($callType === 'video'): ?>
                    <button id="videoBtn" class="call-btn video" onclick="toggleVideo()" title="Video bağla/aç">
                        <i class="fas fa-video"></i>
                    </button>
                    <?php endif; ?>
                    
                    <button id="endBtn" class="call-btn end" onclick="endCall()" title="Zəngi bitir">
                        <i class="fas fa-phone-slash"></i>
                    </button>
                </div>
            </div>
            
        <?php else: ?>
            <!-- Call Placeholder -->
            <div class="call-placeholder">
                <i class="fas fa-phone"></i>
                <h3>Zəng Sistemi</h3>
                <p>Video və ya səsli zəng etmək üçün sol tərəfdən istifadəçi seçin</p>
                
                <div style="margin-top: 30px; display: grid; grid-template-columns: 1fr 1fr; gap: 20px; max-width: 400px;">
                    <div style="text-align: center; padding: 20px; border: 2px dashed #e9ecef; border-radius: 10px;">
                        <i class="fas fa-phone" style="font-size: 2rem; color: var(--success-color); margin-bottom: 10px;"></i>
                        <h5>Səsli Zəng</h5>
                        <p style="font-size: 0.8rem; color: #6c757d;">HD keyfiyyətdə səs</p>
                    </div>
                    
                    <div style="text-align: center; padding: 20px; border: 2px dashed #e9ecef; border-radius: 10px;">
                        <i class="fas fa-video" style="font-size: 2rem; color: var(--info-color); margin-bottom: 10px;"></i>
                        <h5>Video Zəng</h5>
                        <p style="font-size: 0.8rem; color: #6c757d;">HD video + səs</p>
                    </div>
                </div>
                
                <div style="margin-top: 20px;">
                    <a href="?page=chat" class="btn btn-secondary">
                        <i class="fas fa-comments"></i> Chat-a keç
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Incoming Call Modal -->
<div class="incoming-call-modal" id="incomingCallModal">
    <div class="incoming-call-content">
        <div class="incoming-avatar" id="incomingAvatar">?</div>
        <h3 id="incomingCallerName">İstifadəçi</h3>
        <p style="color: #6c757d; margin: 10px 0;">
            <i class="fas fa-phone"></i> <span id="incomingCallType">Səsli</span> zəng
        </p>
        <div style="margin: 20px 0;">
            <div style="font-size: 0.9rem; color: #6c757d;">Gələn zəng...</div>
        </div>
        
        <div class="incoming-actions">
            <button onclick="declineCall()" class="call-btn end" style="width: 70px; height: 70px;">
                <i class="fas fa-phone-slash"></i>
            </button>
            <button onclick="acceptCall()" class="call-btn answer" style="width: 70px; height: 70px;">
                <i class="fas fa-phone"></i>
            </button>
        </div>
    </div>
</div>

<script>
let localStream = null;
let remoteStream = null;
let peerConnection = null;
let currentCall = null;
let callTimer = null;
let callStartTime = null;
let isMuted = false;
let isVideoOff = false;

const configuration = {
    iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
    ]
};

// Start call
async function startCall(userId, type = 'video') {
    try {
        currentCall = { userId, type, role: 'caller' };
        
        // Get user media
        const constraints = {
            audio: true,
            video: type === 'video'
        };
        
        localStream = await navigator.mediaDevices.getUserMedia(constraints);
        document.getElementById('localVideo').srcObject = localStream;
        
        // Create peer connection
        peerConnection = new RTCPeerConnection(configuration);
        
        // Add local stream to peer connection
        localStream.getTracks().forEach(track => {
            peerConnection.addTrack(track, localStream);
        });
        
        // Handle remote stream
        peerConnection.ontrack = (event) => {
            remoteStream = event.streams[0];
            document.getElementById('remoteVideo').srcObject = remoteStream;
        };
        
        // Handle ICE candidates
        peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                sendSignal('ice-candidate', event.candidate);
            }
        };
        
        // Create offer
        const offer = await peerConnection.createOffer();
        await peerConnection.setLocalDescription(offer);
        
        // Send offer to remote peer
        sendSignal('offer', offer);
        
        // Redirect to call page
        window.location.href = `?page=calls&user=${userId}&type=${type}`;
        
    } catch (error) {
        console.error('Start call error:', error);
        alert('Zəng başladıla bilmədi: ' + error.message);
    }
}

// Answer call
async function acceptCall() {
    try {
        document.getElementById('incomingCallModal').style.display = 'none';
        
        const constraints = {
            audio: true,
            video: currentCall.type === 'video'
        };
        
        localStream = await navigator.mediaDevices.getUserMedia(constraints);
        document.getElementById('localVideo').srcObject = localStream;
        
        // Create peer connection
        peerConnection = new RTCPeerConnection(configuration);
        
        // Add local stream
        localStream.getTracks().forEach(track => {
            peerConnection.addTrack(track, localStream);
        });
        
        // Handle remote stream
        peerConnection.ontrack = (event) => {
            remoteStream = event.streams[0];
            document.getElementById('remoteVideo').srcObject = remoteStream;
        };
        
        // Handle ICE candidates
        peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                sendSignal('ice-candidate', event.candidate);
            }
        };
        
        startCallTimer();
        updateCallStatus('Bağlandı');
        
    } catch (error) {
        console.error('Accept call error:', error);
        alert('Zəng qəbul edilə bilmədi');
    }
}

// Decline call
function declineCall() {
    document.getElementById('incomingCallModal').style.display = 'none';
    sendSignal('call-declined');
    currentCall = null;
}

// End call
function endCall() {
    // Stop all tracks
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
    }
    
    // Close peer connection
    if (peerConnection) {
        peerConnection.close();
    }
    
    // Stop timer
    if (callTimer) {
        clearInterval(callTimer);
    }
    
    // Send end signal
    sendSignal('call-ended');
    
    // Reset variables
    localStream = null;
    remoteStream = null;
    peerConnection = null;
    currentCall = null;
    callTimer = null;
    
    // Redirect back
    window.location.href = '?page=calls';
}

// Toggle mute
function toggleMute() {
    if (localStream) {
        const audioTrack = localStream.getAudioTracks()[0];
        if (audioTrack) {
            audioTrack.enabled = !audioTrack.enabled;
            isMuted = !audioTrack.enabled;
            
            const muteBtn = document.getElementById('muteBtn');
            const icon = muteBtn.querySelector('i');
            
            if (isMuted) {
                icon.className = 'fas fa-microphone-slash';
                muteBtn.style.background = '#dc3545';
            } else {
                icon.className = 'fas fa-microphone';
                muteBtn.style.background = '#6c757d';
            }
        }
    }
}

// Toggle video
function toggleVideo() {
    if (localStream) {
        const videoTrack = localStream.getVideoTracks()[0];
        if (videoTrack) {
            videoTrack.enabled = !videoTrack.enabled;
            isVideoOff = !videoTrack.enabled;
            
            const videoBtn = document.getElementById('videoBtn');
            const icon = videoBtn.querySelector('i');
            
            if (isVideoOff) {
                icon.className = 'fas fa-video-slash';
                videoBtn.style.background = '#dc3545';
            } else {
                icon.className = 'fas fa-video';
                videoBtn.style.background = '#17a2b8';
            }
        }
    }
}

// Start call timer
function startCallTimer() {
    callStartTime = Date.now();
    callTimer = setInterval(() => {
        const elapsed = Math.floor((Date.now() - callStartTime) / 1000);
        const minutes = Math.floor(elapsed / 60);
        const seconds = elapsed % 60;
        
        document.getElementById('callTimer').textContent = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }, 1000);
}

// Update call status
function updateCallStatus(status) {
    document.getElementById('callStatus').textContent = status;
}

// Send signal via WebSocket
function sendSignal(type, data = null) {
    if (typeof ws !== 'undefined' && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'webrtc-signal',
            signal_type: type,
            data: data,
            target_user: currentCall?.userId,
            call_type: currentCall?.type
        }));
    }
}

// Handle incoming signals
function handleSignal(signal) {
    switch(signal.signal_type) {
        case 'offer':
            handleOffer(signal.data);
            break;
        case 'answer':
            handleAnswer(signal.data);
            break;
        case 'ice-candidate':
            handleIceCandidate(signal.data);
            break;
        case 'call-declined':
            alert('Zəng rədd edildi');
            window.location.href = '?page=calls';
            break;
        case 'call-ended':
            alert('Zəng bitdi');
            endCall();
            break;
    }
}

// Handle incoming offer
async function handleOffer(offer) {
    // Show incoming call modal
    showIncomingCall(currentCall);
    
    // Set remote description
    await peerConnection.setRemoteDescription(offer);
    
    // Create answer
    const answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    
    // Send answer
    sendSignal('answer', answer);
}

// Handle answer
async function handleAnswer(answer) {
    await peerConnection.setRemoteDescription(answer);
    startCallTimer();
    updateCallStatus('Bağlandı');
}

// Handle ICE candidate
async function handleIceCandidate(candidate) {
    if (peerConnection) {
        await peerConnection.addIceCandidate(candidate);
    }
}

// Show incoming call
function showIncomingCall(call) {
    document.getElementById('incomingCallModal').style.display = 'flex';
    document.getElementById('incomingCallerName').textContent = call.callerName;
    document.getElementById('incomingCallType').textContent = call.type === 'video' ? 'Video' : 'Səsli';
    document.getElementById('incomingAvatar').textContent = call.callerName.charAt(0).toUpperCase();
}

// Initialize WebRTC if in call
<?php if ($targetUser): ?>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-start call if user is specified
    if (<?= $targetUserId ?>) {
        startCall(<?= $targetUserId ?>, '<?= $callType ?>');
    }
});
<?php endif; ?>

// WebSocket message handler for calls
if (typeof ws !== 'undefined') {
    const originalOnMessage = ws.onmessage;
    ws.onmessage = function(event) {
        const data = JSON.parse(event.data);
        
        if (data.type === 'webrtc-signal') {
            handleSignal(data);
        } else if (data.type === 'incoming-call') {
            currentCall = data.call;
            showIncomingCall(data.call);
        }
        
        // Call original handler if exists
        if (originalOnMessage) {
            originalOnMessage.call(this, event);
        }
    };
}

console.log('WebRTC call system initialized');
</script>

<?php include 'includes/footer.php'; ?>