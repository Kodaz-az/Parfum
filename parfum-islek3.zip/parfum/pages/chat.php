<?php
/**
 * Chat Sistemi - Real-time Messaging
 * Kodaz-az - 2025-07-21 13:39:12 (UTC)
 * Login: Kodaz-az
 */

// Get current user info
$currentUserId = $_SESSION['user_id'];
$currentUserName = $_SESSION['full_name'];

// Get target user if specified
$targetUserId = $_GET['user'] ?? null;
$targetUser = null;

if ($targetUserId) {
    try {
        $db = Database::getInstance();
        $targetUser = $db->selectOne("SELECT * FROM users WHERE id = ? AND is_active = 1", [$targetUserId]);
    } catch (Exception $e) {
        $targetUserId = null;
    }
}

// Send message action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'send') {
    try {
        $db = Database::getInstance();
        
        $receiverId = intval($_POST['receiver_id'] ?? 0);
        $message = trim($_POST['message'] ?? '');
        $messageType = $_POST['type'] ?? 'text';
        
        if (empty($message) || $receiverId <= 0) {
            throw new Exception('Mesaj və alıcı tələb olunur');
        }
        
        // Insert message
        $messageId = $db->insert("
            INSERT INTO chat_messages (sender_id, receiver_id, message, message_type, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ", [$currentUserId, $receiverId, $message, $messageType]);
        
        if ($messageId) {
            // Update last activity
            $db->update("UPDATE users SET last_activity = NOW() WHERE id = ?", [$currentUserId]);
            
            echo json_encode([
                'success' => true,
                'message_id' => $messageId,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
        } else {
            throw new Exception('Mesaj göndərilə bilmədi');
        }
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
    exit;
}

// Mark messages as read
if ($action === 'mark_read' && $targetUserId) {
    try {
        $db = Database::getInstance();
        $db->update("
            UPDATE chat_messages 
            SET is_read = 1, read_at = NOW() 
            WHERE sender_id = ? AND receiver_id = ? AND is_read = 0
        ", [$targetUserId, $currentUserId]);
        
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

// Get users list
try {
    $db = Database::getInstance();
    
    // Get all active users except current user
    $users = $db->selectAll("
        SELECT u.*, 
        (SELECT COUNT(*) FROM chat_messages cm 
         WHERE cm.sender_id = u.id AND cm.receiver_id = ? AND cm.is_read = 0) as unread_count,
        (SELECT message FROM chat_messages cm 
         WHERE (cm.sender_id = u.id AND cm.receiver_id = ?) OR (cm.sender_id = ? AND cm.receiver_id = u.id)
         ORDER BY cm.created_at DESC LIMIT 1) as last_message,
        (SELECT created_at FROM chat_messages cm 
         WHERE (cm.sender_id = u.id AND cm.receiver_id = ?) OR (cm.sender_id = ? AND cm.receiver_id = u.id)
         ORDER BY cm.created_at DESC LIMIT 1) as last_message_time
        FROM users u 
        WHERE u.id != ? AND u.is_active = 1 
        ORDER BY u.last_activity DESC
    ", [$currentUserId, $currentUserId, $currentUserId, $currentUserId, $currentUserId, $currentUserId]);
    
    // Get messages for selected user
    $messages = [];
    if ($targetUserId) {
        $messages = $db->selectAll("
            SELECT cm.*, 
            s.full_name as sender_name, s.avatar as sender_avatar,
            r.full_name as receiver_name, r.avatar as receiver_avatar
            FROM chat_messages cm
            LEFT JOIN users s ON cm.sender_id = s.id
            LEFT JOIN users r ON cm.receiver_id = r.id
            WHERE (cm.sender_id = ? AND cm.receiver_id = ?) OR (cm.sender_id = ? AND cm.receiver_id = ?)
            ORDER BY cm.created_at ASC
        ", [$currentUserId, $targetUserId, $targetUserId, $currentUserId]);
    }
    
} catch (Exception $e) {
    $users = [];
    $messages = [];
}

$pageTitle = "Chat - " . PWA_NAME;
include 'includes/header.php';
?>

<style>
.chat-layout {
    display: grid;
    grid-template-columns: 350px 1fr;
    gap: 20px;
    height: calc(100vh - 200px);
}

.chat-users {
    background: var(--white);
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    overflow: hidden;
}

.chat-main {
    background: var(--white);
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.users-header {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--white);
    padding: 20px;
    text-align: center;
}

.users-list {
    flex: 1;
    overflow-y: auto;
    max-height: calc(100vh - 300px);
}

.user-item {
    display: flex;
    align-items: center;
    padding: 15px 20px;
    border-bottom: 1px solid #f0f0f0;
    cursor: pointer;
    transition: var(--transition);
    text-decoration: none;
    color: inherit;
}

.user-item:hover,
.user-item.active {
    background: #f8f9ff;
    color: inherit;
    text-decoration: none;
}

.user-item.active {
    border-right: 4px solid var(--primary-color);
}

.user-avatar-small {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    background: var(--primary-color);
    color: var(--white);
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin-right: 15px;
    position: relative;
    font-size: 1.2rem;
}

.online-indicator {
    position: absolute;
    bottom: 2px;
    right: 2px;
    width: 12px;
    height: 12px;
    background: var(--success-color);
    border: 2px solid var(--white);
    border-radius: 50%;
}

.user-details {
    flex: 1;
    min-width: 0;
}

.user-name {
    font-weight: bold;
    font-size: 0.95rem;
    margin-bottom: 5px;
}

.last-message {
    font-size: 0.8rem;
    color: #6c757d;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.unread-badge {
    background: var(--danger-color);
    color: var(--white);
    border-radius: 50%;
    padding: 4px 8px;
    font-size: 0.7rem;
    font-weight: bold;
    min-width: 20px;
    text-align: center;
}

.chat-header {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--white);
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 15px;
}

.chat-messages {
    flex: 1;
    padding: 20px;
    overflow-y: auto;
    background: #f8f9fa;
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.message {
    display: flex;
    margin-bottom: 15px;
    animation: slideIn 0.3s ease;
}

.message.own {
    justify-content: flex-end;
}

.message-bubble {
    max-width: 70%;
    padding: 12px 16px;
    border-radius: 20px;
    background: var(--white);
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    position: relative;
    word-wrap: break-word;
}

.message.own .message-bubble {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--white);
}

.message-text {
    margin-bottom: 5px;
    line-height: 1.4;
}

.message-time {
    font-size: 0.7rem;
    opacity: 0.7;
    text-align: right;
}

.message.own .message-time {
    text-align: left;
}

.chat-input-area {
    padding: 20px;
    background: var(--white);
    border-top: 1px solid #e9ecef;
}

.chat-input-form {
    display: flex;
    gap: 10px;
    align-items: center;
}

.chat-input-form input {
    flex: 1;
    padding: 12px 16px;
    border: 1px solid #e9ecef;
    border-radius: 25px;
    outline: none;
    font-size: 0.9rem;
}

.chat-input-form input:focus {
    border-color: var(--primary-color);
}

.send-btn {
    width: 45px;
    height: 45px;
    border: none;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--white);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--transition);
}

.send-btn:hover {
    transform: scale(1.1);
}

.chat-placeholder {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: #6c757d;
    text-align: center;
}

.chat-placeholder i {
    font-size: 4rem;
    margin-bottom: 20px;
    opacity: 0.3;
}

@media (max-width: 768px) {
    .chat-layout {
        grid-template-columns: 1fr;
        height: auto;
    }
    
    .chat-users {
        order: 2;
        max-height: 300px;
    }
    
    .chat-main {
        order: 1;
        height: 500px;
    }
}
</style>

<div class="chat-layout">
    <!-- Users List -->
    <div class="chat-users">
        <div class="users-header">
            <h4><i class="fas fa-comments"></i> Komanda Chat</h4>
            <small><?= count($users) ?> istifadəçi online</small>
        </div>
        
        <div class="users-list">
            <?php if (empty($users)): ?>
                <div style="padding: 40px 20px; text-align: center; color: #6c757d;">
                    <i class="fas fa-users" style="font-size: 2rem; margin-bottom: 10px; opacity: 0.3;"></i>
                    <p>Başqa istifadəçi yoxdur</p>
                </div>
            <?php else: ?>
                <?php foreach ($users as $user): ?>
                    <a href="?page=chat&user=<?= $user['id'] ?>" 
                       class="user-item <?= $targetUserId == $user['id'] ? 'active' : '' ?>">
                        <div class="user-avatar-small">
                            <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                            <?php if (strtotime($user['last_activity']) > (time() - 300)): ?>
                                <span class="online-indicator"></span>
                            <?php endif; ?>
                        </div>
                        <div class="user-details">
                            <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
                            <div class="last-message">
                                <?php if ($user['last_message']): ?>
                                    <?= htmlspecialchars(substr($user['last_message'], 0, 40)) ?>
                                    <?= strlen($user['last_message']) > 40 ? '...' : '' ?>
                                <?php else: ?>
                                    Mesaj yoxdur
                                <?php endif; ?>
                            </div>
                        </div>
                        <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 5px;">
                            <?php if ($user['unread_count'] > 0): ?>
                                <span class="unread-badge"><?= $user['unread_count'] ?></span>
                            <?php endif; ?>
                            <?php if ($user['last_message_time']): ?>
                                <small style="font-size: 0.7rem; color: #adb5bd;">
                                    <?= date('H:i', strtotime($user['last_message_time'])) ?>
                                </small>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Chat Main -->
    <div class="chat-main">
        <?php if ($targetUser): ?>
            <!-- Chat Header -->
            <div class="chat-header">
                <div class="user-avatar-small">
                    <?= strtoupper(substr($targetUser['full_name'], 0, 1)) ?>
                    <?php if (strtotime($targetUser['last_activity']) > (time() - 300)): ?>
                        <span class="online-indicator"></span>
                    <?php endif; ?>
                </div>
                <div style="flex: 1;">
                    <div style="font-weight: bold; font-size: 1.1rem;">
                        <?= htmlspecialchars($targetUser['full_name']) ?>
                    </div>
                    <div style="font-size: 0.8rem; opacity: 0.9;">
                        <?php if (strtotime($targetUser['last_activity']) > (time() - 300)): ?>
                            <i class="fas fa-circle" style="color: #28a745; font-size: 0.6rem;"></i> Online
                        <?php else: ?>
                            Son görünmə: <?= date('d.m.Y H:i', strtotime($targetUser['last_activity'])) ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div style="display: flex; gap: 10px;">
                    <button onclick="startVideoCall(<?= $targetUser['id'] ?>)" class="btn btn-success btn-sm">
                        <i class="fas fa-video"></i>
                    </button>
                    <button onclick="startVoiceCall(<?= $targetUser['id'] ?>)" class="btn btn-info btn-sm">
                        <i class="fas fa-phone"></i>
                    </button>
                </div>
            </div>
            
            <!-- Messages -->
            <div class="chat-messages" id="chatMessages">
                <?php if (empty($messages)): ?>
                    <div style="text-align: center; padding: 40px; color: #6c757d;">
                        <i class="fas fa-comment-slash" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                        <p>Hələ mesaj yoxdur. İlk mesajı siz göndərin!</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($messages as $message): ?>
                        <div class="message <?= $message['sender_id'] == $currentUserId ? 'own' : '' ?>">
                            <div class="message-bubble">
                                <div class="message-text"><?= nl2br(htmlspecialchars($message['message'])) ?></div>
                                <div class="message-time">
                                    <?= date('H:i', strtotime($message['created_at'])) ?>
                                    <?php if ($message['sender_id'] == $currentUserId): ?>
                                        <i class="fas fa-check<?= $message['is_read'] ? '-double' : '' ?>" 
                                           style="margin-left: 5px; color: <?= $message['is_read'] ? '#28a745' : '#6c757d' ?>;"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            
            <!-- Input Area -->
            <div class="chat-input-area">
                <form class="chat-input-form" onsubmit="sendMessage(event)">
                    <input type="hidden" id="receiverId" value="<?= $targetUser['id'] ?>">
                    <input type="text" id="messageInput" placeholder="Mesajınızı yazın..." required>
                    <button type="submit" class="send-btn">
                        <i class="fas fa-paper-plane"></i>
                    </button>
                </form>
            </div>
            
        <?php else: ?>
            <!-- Placeholder -->
            <div class="chat-placeholder">
                <i class="fas fa-comments"></i>
                <h3>Chat Sistemi</h3>
                <p>Mesajlaşmaya başlamaq üçün sol tərəfdən istifadəçi seçin</p>
                <div style="margin-top: 20px;">
                    <a href="?page=calls" class="btn btn-primary">
                        <i class="fas fa-phone"></i> Video Zəng
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
let currentReceiverId = <?= $targetUserId ?? 'null' ?>;
let currentUserId = <?= $currentUserId ?>;
let lastMessageId = 0;

// Send message
function sendMessage(event) {
    event.preventDefault();
    
    const messageInput = document.getElementById('messageInput');
    const message = messageInput.value.trim();
    
    if (!message || !currentReceiverId) return;
    
    const formData = new FormData();
    formData.append('receiver_id', currentReceiverId);
    formData.append('message', message);
    formData.append('type', 'text');
    
    fetch('?page=chat&action=send', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            messageInput.value = '';
            loadMessages();
        } else {
            alert('Mesaj göndərilə bilmədi: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Send message error:', error);
        alert('Xəta baş verdi');
    });
}

// Load messages
function loadMessages() {
    if (!currentReceiverId) return;
    
    fetch(`?page=chat&action=get_messages&user=${currentReceiverId}&last_id=${lastMessageId}`)
    .then(response => response.json())
    .then(data => {
        if (data.success && data.messages.length > 0) {
            const messagesContainer = document.getElementById('chatMessages');
            
            data.messages.forEach(message => {
                const messageElement = createMessageElement(message);
                messagesContainer.appendChild(messageElement);
                lastMessageId = Math.max(lastMessageId, message.id);
            });
            
            scrollToBottom();
        }
    })
    .catch(error => console.error('Load messages error:', error));
}

// Create message element
function createMessageElement(message) {
    const div = document.createElement('div');
    div.className = `message ${message.sender_id == currentUserId ? 'own' : ''}`;
    
    const isRead = message.is_read;
    const readIcon = message.sender_id == currentUserId ? 
        `<i class="fas fa-check${isRead ? '-double' : ''}" style="margin-left: 5px; color: ${isRead ? '#28a745' : '#6c757d'};"></i>` : '';
    
    div.innerHTML = `
        <div class="message-bubble">
            <div class="message-text">${message.message.replace(/\n/g, '<br>')}</div>
            <div class="message-time">
                ${new Date(message.created_at).toLocaleTimeString('az-AZ', {hour: '2-digit', minute: '2-digit'})}
                ${readIcon}
            </div>
        </div>
    `;
    
    return div;
}

// Scroll to bottom
function scrollToBottom() {
    const messagesContainer = document.getElementById('chatMessages');
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Mark as read
function markAsRead() {
    if (!currentReceiverId) return;
    
    fetch(`?page=chat&action=mark_read&user=${currentReceiverId}`, {
        method: 'POST'
    });
}

// Call functions
function startVideoCall(userId) {
    window.location.href = `?page=calls&action=video&user=${userId}`;
}

function startVoiceCall(userId) {
    window.location.href = `?page=calls&action=voice&user=${userId}`;
}

// Enter key to send
document.getElementById('messageInput')?.addEventListener('keypress', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage(e);
    }
});

// Auto-refresh messages
if (currentReceiverId) {
    setInterval(loadMessages, 3000);
    markAsRead();
    scrollToBottom();
}

// WebSocket integration
if (typeof ws !== 'undefined' && ws.readyState === WebSocket.OPEN) {
    ws.onmessage = function(event) {
        const data = JSON.parse(event.data);
        
        if (data.type === 'chat_message' && data.message.receiver_id == currentUserId) {
            if (data.message.sender_id == currentReceiverId) {
                const messageElement = createMessageElement(data.message);
                document.getElementById('chatMessages').appendChild(messageElement);
                scrollToBottom();
                markAsRead();
            } else {
                // Update unread count for other users
                updateUnreadCounts();
            }
        }
    };
}

function updateUnreadCounts() {
    // Update unread counts in user list
    fetch('?page=chat&action=get_unread_counts')
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Object.keys(data.counts).forEach(userId => {
                const userItem = document.querySelector(`a[href*="user=${userId}"]`);
                if (userItem) {
                    const badge = userItem.querySelector('.unread-badge');
                    const count = data.counts[userId];
                    
                    if (count > 0) {
                        if (badge) {
                            badge.textContent = count;
                        } else {
                            // Create badge
                            const badgeElement = document.createElement('span');
                            badgeElement.className = 'unread-badge';
                            badgeElement.textContent = count;
                            userItem.querySelector('.user-details').parentNode.appendChild(badgeElement);
                        }
                    } else if (badge) {
                        badge.remove();
                    }
                }
            });
        }
    });
}

console.log('Chat system initialized for user:', currentUserId);
</script>

<?php include 'includes/footer.php'; ?>