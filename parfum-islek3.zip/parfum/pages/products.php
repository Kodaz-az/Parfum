<?php
/**
 * Məhsullar İdarəetməsi - Advanced Product Management
 * Kodaz-az - 2025-07-21 14:38:25 (UTC)
 * Login: Kodaz-az
 */

$currentUserId = $_SESSION['user_id'];
$currentUserRole = $_SESSION['role'];

// Handle image upload
function handleImageUpload($file, $productId) {
    $uploadDir = 'uploads/products/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    if (!in_array($file['type'], $allowedTypes)) {
        throw new Exception('Yalnız JPG, PNG, WebP və GIF formatları dəstəklənir');
    }
    
    if ($file['size'] > $maxSize) {
        throw new Exception('Şəkil ölçüsü 5MB-dan çox ola bilməz');
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'product_' . $productId . '_' . time() . '.' . $extension;
    $filepath = $uploadDir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return $filename;
    }
    
    throw new Exception('Şəkil yüklənə bilmədi');
}

// Add product action
if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = Database::getInstance();
        
        $name = trim($_POST['name'] ?? '');
        $brand = trim($_POST['brand'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        $costPrice = floatval($_POST['cost_price'] ?? 0);
        $stockQuantity = intval($_POST['stock_quantity'] ?? 0);
        $minStock = intval($_POST['min_stock'] ?? 5);
        $description = trim($_POST['description'] ?? '');
        $size = trim($_POST['size'] ?? '');
        $gender = $_POST['gender'] ?? 'unisex';
        $barcode = trim($_POST['barcode'] ?? '');
        $sku = trim($_POST['sku'] ?? '');
        $weight = floatval($_POST['weight'] ?? 0);
        $manufacturer = trim($_POST['manufacturer'] ?? '');
        $countryOrigin = trim($_POST['country_origin'] ?? '');
        
        // Validation
        $errors = [];
        if (empty($name)) $errors[] = "Məhsul adı tələb olunur";
        if (empty($brand)) $errors[] = "Brand tələb olunur";
        if ($price <= 0) $errors[] = "Qiymət 0-dan böyük olmalıdır";
        if ($stockQuantity < 0) $errors[] = "Stok miqdarı mənfi ola bilməz";
        
        // Check barcode uniqueness
        if (!empty($barcode)) {
            $existingBarcode = $db->selectOne("SELECT id FROM products WHERE barcode = ?", [$barcode]);
            if ($existingBarcode) {
                $errors[] = "Bu barkod artıq mövcuddur";
            }
        } else {
            // Generate barcode
            $barcode = 'PRD' . date('ymd') . str_pad(rand(1, 99999), 5, '0', STR_PAD_LEFT);
        }
        
        // Check SKU uniqueness
        if (!empty($sku)) {
            $existingSku = $db->selectOne("SELECT id FROM products WHERE sku = ?", [$sku]);
            if ($existingSku) {
                $errors[] = "Bu SKU artıq mövcuddur";
            }
        } else {
            $sku = strtoupper(substr($brand, 0, 3) . substr($name, 0, 3) . rand(100, 999));
        }
        
        if (empty($errors)) {
            $productId = $db->insert("
                INSERT INTO products (
                    name, brand, category, barcode, sku, price, cost_price, 
                    stock_quantity, min_stock, description, size, gender, 
                    weight, manufacturer, country_origin, is_active, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())
            ", [
                $name, $brand, $category, $barcode, $sku, $price, $costPrice,
                $stockQuantity, $minStock, $description, $size, $gender,
                $weight, $manufacturer, $countryOrigin
            ]);
            
            // Handle image upload
            if ($productId && !empty($_FILES['image']['name'])) {
                try {
                    $imageName = handleImageUpload($_FILES['image'], $productId);
                    $db->update("UPDATE products SET image = ? WHERE id = ?", [$imageName, $productId]);
                } catch (Exception $e) {
                    // Image upload failed, but product created
                    $_SESSION['warning_message'] = "Məhsul yaradıldı, lakin şəkil yüklənmədi: " . $e->getMessage();
                }
            }
            
            // Log activity
            $db->insert("
                INSERT INTO activity_logs (user_id, action, description, created_at)
                VALUES (?, 'product_created', ?, NOW())
            ", [$currentUserId, "Yeni məhsul əlavə edildi: {$name}"]);
            
            $_SESSION['success_message'] = "Məhsul uğurla əlavə edildi! Barkod: " . $barcode;
            header('Location: ?page=products');
            exit;
        } else {
            $_SESSION['error_message'] = implode('<br>', $errors);
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Məhsul əlavə edilə bilmədi: " . $e->getMessage();
    }
}

// Edit product action
if ($action === 'edit' && $id > 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = Database::getInstance();
        
        $name = trim($_POST['name'] ?? '');
        $brand = trim($_POST['brand'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        $costPrice = floatval($_POST['cost_price'] ?? 0);
        $stockQuantity = intval($_POST['stock_quantity'] ?? 0);
        $minStock = intval($_POST['min_stock'] ?? 5);
        $description = trim($_POST['description'] ?? '');
        $size = trim($_POST['size'] ?? '');
        $gender = $_POST['gender'] ?? 'unisex';
        $weight = floatval($_POST['weight'] ?? 0);
        $manufacturer = trim($_POST['manufacturer'] ?? '');
        $countryOrigin = trim($_POST['country_origin'] ?? '');
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        
        $errors = [];
        if (empty($name)) $errors[] = "Məhsul adı tələb olunur";
        if (empty($brand)) $errors[] = "Brand tələb olunur";
        if ($price <= 0) $errors[] = "Qiymət 0-dan böyük olmalıdır";
        
        if (empty($errors)) {
            // Get current product data
            $currentProduct = $db->selectOne("SELECT * FROM products WHERE id = ?", [$id]);
            
            $updated = $db->update("
                UPDATE products 
                SET name = ?, brand = ?, category = ?, price = ?, cost_price = ?, 
                    stock_quantity = ?, min_stock = ?, description = ?, size = ?, 
                    gender = ?, weight = ?, manufacturer = ?, country_origin = ?, 
                    is_active = ?, updated_at = NOW()
                WHERE id = ?
            ", [
                $name, $brand, $category, $price, $costPrice, $stockQuantity, 
                $minStock, $description, $size, $gender, $weight, $manufacturer, 
                $countryOrigin, $isActive, $id
            ]);
            
            // Handle new image upload
            if (!empty($_FILES['image']['name'])) {
                try {
                    $imageName = handleImageUpload($_FILES['image'], $id);
                    
                    // Delete old image
                    if ($currentProduct['image'] && file_exists('uploads/products/' . $currentProduct['image'])) {
                        unlink('uploads/products/' . $currentProduct['image']);
                    }
                    
                    $db->update("UPDATE products SET image = ? WHERE id = ?", [$imageName, $id]);
                } catch (Exception $e) {
                    $_SESSION['warning_message'] = "Məhsul yeniləndi, lakin şəkil dəyişdirilmədi: " . $e->getMessage();
                }
            }
            
            if ($updated) {
                $_SESSION['success_message'] = "Məhsul uğurla yeniləndi!";
                header('Location: ?page=products');
                exit;
            }
        } else {
            $_SESSION['error_message'] = implode('<br>', $errors);
        }
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Məhsul yenilənə bilmədi: " . $e->getMessage();
    }
}

// Get single product for editing
if ($action === 'edit' && $id > 0) {
    try {
        $db = Database::getInstance();
        $editProduct = $db->selectOne("SELECT * FROM products WHERE id = ?", [$id]);
        
        if (!$editProduct) {
            $_SESSION['error_message'] = "Məhsul tapılmadı!";
            header('Location: ?page=products');
            exit;
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Məhsul yüklənə bilmədi: " . $e->getMessage();
        header('Location: ?page=products');
        exit;
    }
}

// Toggle product status
if ($action === 'toggle_status' && $id > 0) {
    try {
        $db = Database::getInstance();
        $product = $db->selectOne("SELECT is_active FROM products WHERE id = ?", [$id]);
        
        if ($product) {
            $newStatus = $product['is_active'] ? 0 : 1;
            $db->update("UPDATE products SET is_active = ?, updated_at = NOW() WHERE id = ?", [$newStatus, $id]);
            
            $statusText = $newStatus ? 'aktivləşdirildi' : 'deaktivləşdirildi';
            $_SESSION['success_message'] = "Məhsul {$statusText}!";
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Status dəyişdirilə bilmədi: " . $e->getMessage();
    }
    
    header('Location: ?page=products');
    exit;
}

// Bulk operations
if ($action === 'bulk_action' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $db = Database::getInstance();
        $selectedProducts = $_POST['selected_products'] ?? [];
        $bulkAction = $_POST['bulk_action'] ?? '';
        
        if (empty($selectedProducts)) {
            throw new Exception('Məhsul seçilməyib');
        }
        
        $count = 0;
        foreach ($selectedProducts as $productId) {
            switch ($bulkAction) {
                case 'activate':
                    $db->update("UPDATE products SET is_active = 1 WHERE id = ?", [$productId]);
                    $count++;
                    break;
                    
                case 'deactivate':
                    $db->update("UPDATE products SET is_active = 0 WHERE id = ?", [$productId]);
                    $count++;
                    break;
                    
                case 'delete':
                    if ($currentUserRole === 'admin') {
                        $db->update("UPDATE products SET is_active = 0, deleted_at = NOW() WHERE id = ?", [$productId]);
                        $count++;
                    }
                    break;
            }
        }
        
        $_SESSION['success_message'] = "{$count} məhsul üçün əməliyyat tamamlandı!";
        
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Toplu əməliyyat uğursuz: " . $e->getMessage();
    }
    
    header('Location: ?page=products');
    exit;
}

// Get products
try {
    $db = Database::getInstance();
    
    $search = $_GET['search'] ?? '';
    $category = $_GET['category'] ?? '';
    $brand = $_GET['brand'] ?? '';
    $status = $_GET['status'] ?? '';
    $stockFilter = $_GET['stock_filter'] ?? '';
    $sortBy = $_GET['sort_by'] ?? 'created_at';
    $sortOrder = $_GET['sort_order'] ?? 'DESC';
    
    $sql = "SELECT p.*, 
            COALESCE(sales_data.total_sold, 0) as total_sold,
            COALESCE(sales_data.total_revenue, 0) as total_revenue
            FROM products p
            LEFT JOIN (
                SELECT sd.product_id, 
                       SUM(sd.quantity) as total_sold,
                       SUM(sd.total_price) as total_revenue
                FROM sale_details sd
                GROUP BY sd.product_id
            ) sales_data ON p.id = sales_data.product_id
            WHERE p.deleted_at IS NULL";
    
    $params = [];
    
    if (!empty($search)) {
        $sql .= " AND (p.name LIKE ? OR p.brand LIKE ? OR p.barcode LIKE ? OR p.sku LIKE ?)";
        $searchTerm = "%{$search}%";
        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    }
    
    if (!empty($category)) {
        $sql .= " AND p.category = ?";
        $params[] = $category;
    }
    
    if (!empty($brand)) {
        $sql .= " AND p.brand = ?";
        $params[] = $brand;
    }
    
    if ($status !== '') {
        $sql .= " AND p.is_active = ?";
        $params[] = intval($status);
    }
    
    if ($stockFilter === 'low') {
        $sql .= " AND p.stock_quantity <= p.min_stock";
    } elseif ($stockFilter === 'out') {
        $sql .= " AND p.stock_quantity = 0";
    }
    
    $allowedSorts = ['name', 'brand', 'category', 'price', 'stock_quantity', 'created_at', 'total_sold'];
    if (!in_array($sortBy, $allowedSorts)) $sortBy = 'created_at';
    if (!in_array($sortOrder, ['ASC', 'DESC'])) $sortOrder = 'DESC';
    
    $sql .= " ORDER BY p.{$sortBy} {$sortOrder}";
    
    $products = $db->selectAll($sql, $params);
    
    // Get filter options
    $categories = $db->selectAll("SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != '' ORDER BY category");
    $brands = $db->selectAll("SELECT DISTINCT brand FROM products WHERE brand IS NOT NULL AND brand != '' ORDER BY brand");
    
    // Get statistics
    $stats = $db->selectOne("
        SELECT 
            COUNT(*) as total_products,
            SUM(CASE WHEN is_active = 1 THEN 1 ELSE 0 END) as active_products,
            SUM(CASE WHEN stock_quantity <= min_stock THEN 1 ELSE 0 END) as low_stock_count,
            SUM(CASE WHEN stock_quantity = 0 THEN 1 ELSE 0 END) as out_of_stock_count,
            SUM(stock_quantity * price) as inventory_value,
            AVG(price) as avg_price
        FROM products 
        WHERE deleted_at IS NULL
    ");
    
} catch (Exception $e) {
    $products = [];
    $categories = [];
    $brands = [];
    $stats = [
        'total_products' => 0, 'active_products' => 0, 'low_stock_count' => 0, 
        'out_of_stock_count' => 0, 'inventory_value' => 0, 'avg_price' => 0
    ];
}

$pageTitle = "Məhsullar - " . PWA_NAME;
include 'includes/header.php';
?>

<style>
.products-header {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    padding: 30px;
    border-radius: 20px;
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
}

.products-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 200px;
    height: 200px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    text-align: center;
    border-left: 5px solid var(--primary-color);
    transition: var(--transition);
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.15);
}

.stat-value {
    font-size: 2rem;
    font-weight: bold;
    color: var(--primary-color);
    margin-bottom: 8px;
}

.stat-label {
    color: #6c757d;
    font-size: 0.9rem;
}

.filters-panel {
    background: white;
    padding: 25px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    margin-bottom: 25px;
}

.products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 25px;
    margin-bottom: 30px;
}

.product-card {
    background: white;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    overflow: hidden;
    transition: var(--transition);
    cursor: pointer;
    position: relative;
}

.product-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 40px rgba(0,0,0,0.15);
}

.product-image {
    width: 100%;
    height: 200px;
    background: linear-gradient(135deg, #f8f9fa, #e9ecef);
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
}

.product-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: var(--transition);
}

.product-card:hover .product-image img {
    transform: scale(1.1);
}

.product-placeholder {
    font-size: 3rem;
    color: #dee2e6;
}

.product-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 5px 10px;
    border-radius: 15px;
    font-size: 0.75rem;
    font-weight: bold;
    z-index: 2;
}

.badge-low-stock {
    background: #fff3cd;
    color: #856404;
}

.badge-out-stock {
    background: #f8d7da;
    color: #721c24;
}

.badge-bestseller {
    background: #d4edda;
    color: #155724;
}

.product-content {
    padding: 20px;
}

.product-name {
    font-weight: bold;
    font-size: 1.1rem;
    margin-bottom: 5px;
    color: var(--dark-color);
}

.product-brand {
    color: var(--primary-color);
    font-size: 0.9rem;
    margin-bottom: 10px;
    font-weight: 500;
}

.product-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-bottom: 15px;
    font-size: 0.85rem;
    color: #6c757d;
}

.product-price {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.price-current {
    font-size: 1.3rem;
    font-weight: bold;
    color: var(--success-color);
}

.price-cost {
    font-size: 0.8rem;
    color: #6c757d;
}

.product-stock {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding: 10px;
    background: #f8f9fa;
    border-radius: 8px;
}

.stock-info {
    font-size: 0.9rem;
}

.stock-bar {
    width: 100%;
    height: 6px;
    background: #e9ecef;
    border-radius: 3px;
    margin-top: 5px;
    overflow: hidden;
}

.stock-fill {
    height: 100%;
    border-radius: 3px;
    transition: width 0.3s ease;
}

.product-actions {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 8px;
}

.btn-icon {
    padding: 8px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    transition: var(--transition);
    font-size: 0.8rem;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    color: white;
}

.image-upload-area {
    border: 2px dashed #e9ecef;
    border-radius: 10px;
    padding: 30px;
    text-align: center;
    transition: var(--transition);
    cursor: pointer;
    margin-bottom: 20px;
    position: relative;
}

.image-upload-area:hover {
    border-color: var(--primary-color);
    background: rgba(102, 126, 234, 0.05);
}

.image-upload-area.dragover {
    border-color: var(--primary-color);
    background: rgba(102, 126, 234, 0.1);
}

.current-image {
    max-width: 200px;
    max-height: 200px;
    border-radius: 10px;
    margin-bottom: 15px;
}

@media (max-width: 768px) {
    .products-grid {
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    }
    
    .product-actions {
        grid-template-columns: 1fr;
    }
}
</style>

<!-- Header -->
<div class="products-header">
    <div style="position: relative; z-index: 1;">
        <h1 style="margin-bottom: 10px;">📦 Məhsul İdarəetməsi</h1>
        <p style="opacity: 0.9; font-size: 1.1rem;">Advanced inventory management system</p>
        <div style="margin-top: 15px; display: flex; gap: 15px; flex-wrap: wrap;">
            <a href="?page=products&action=add" class="btn" style="background: rgba(255,255,255,0.2);">
                <i class="fas fa-plus"></i> Yeni Məhsul
            </a>
            <button onclick="exportProducts()" class="btn" style="background: rgba(255,255,255,0.2);">
                <i class="fas fa-download"></i> Export
            </button>
            <button onclick="importProducts()" class="btn" style="background: rgba(255,255,255,0.2);">
                <i class="fas fa-upload"></i> Import
            </button>
        </div>
    </div>
</div>

<!-- Statistics -->
<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-value"><?= number_format($stats['total_products']) ?></div>
        <div class="stat-label">Cəmi Məhsul</div>
        <div style="font-size: 0.8rem; color: var(--success-color); margin-top: 5px;">
            <?= $stats['active_products'] ?> aktiv
        </div>
    </div>
    
    <div class="stat-card" style="border-color: var(--warning-color);">
        <div class="stat-value" style="color: var(--warning-color);"><?= $stats['low_stock_count'] ?></div>
        <div class="stat-label">Az Stok</div>
        <div style="font-size: 0.8rem; color: var(--danger-color); margin-top: 5px;">
            <?= $stats['out_of_stock_count'] ?> bitib
        </div>
    </div>
    
    <div class="stat-card" style="border-color: var(--success-color);">
        <div class="stat-value" style="color: var(--success-color);">₼<?= number_format($stats['inventory_value'], 0) ?></div>
        <div class="stat-label">İnventar Dəyəri</div>
        <div style="font-size: 0.8rem; color: #6c757d; margin-top: 5px;">
            Orta: ₼<?= number_format($stats['avg_price'], 2) ?>
        </div>
    </div>
</div>

<?php if (in_array($action, ['add', 'edit'])): ?>
    <!-- Add/Edit Form -->
    <div class="content-box">
        <h3>
            <i class="fas fa-<?= $action === 'add' ? 'plus' : 'edit' ?>"></i>
            <?= $action === 'add' ? 'Yeni Məhsul Əlavə Et' : 'Məhsul Redaktə Et' ?>
        </h3>
        
        <form method="POST" enctype="multipart/form-data" style="margin-top: 25px;">
            <!-- Image Upload -->
            <div class="form-group">
                <label>Məhsul Şəkli</label>
                <div class="image-upload-area" onclick="document.getElementById('image-input').click()">
                    <?php if ($action === 'edit' && $editProduct['image']): ?>
                        <img src="uploads/products/<?= htmlspecialchars($editProduct['image']) ?>" class="current-image" alt="Current image">
                        <div>Yeni şəkil yükləmək üçün klikləyin</div>
                    <?php else: ?>
                        <i class="fas fa-cloud-upload-alt" style="font-size: 3rem; color: #dee2e6; margin-bottom: 15px;"></i>
                        <div style="margin-bottom: 10px; font-weight: bold;">Şəkil yükləyin</div>
                        <div style="font-size: 0.9rem; color: #6c757d;">JPG, PNG, WebP və ya GIF (Max: 5MB)</div>
                    <?php endif; ?>
                </div>
                <input type="file" id="image-input" name="image" accept="image/*" style="display: none;">
            </div>
            
            <!-- Basic Information -->
            <div class="form-row">
                <div class="form-group">
                    <label>Məhsul Adı *</label>
                    <input type="text" name="name" value="<?= htmlspecialchars($editProduct['name'] ?? '') ?>" required class="form-control" placeholder="Məsələn: Chanel No.5">
                </div>
                
                <div class="form-group">
                    <label>Brand *</label>
                    <input type="text" name="brand" value="<?= htmlspecialchars($editProduct['brand'] ?? '') ?>" required class="form-control" list="brands-list">
                    <datalist id="brands-list">
                        <?php foreach ($brands as $brand): ?>
                            <option value="<?= htmlspecialchars($brand['brand']) ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>
            </div>
            
            <!-- Category and Details -->
            <div class="form-row">
                <div class="form-group">
                    <label>Kateqoriya</label>
                    <select name="category" class="form-control">
                        <option value="">Seçin...</option>
                        <option value="Kişi Parfümləri" <?= ($editProduct['category'] ?? '') === 'Kişi Parfümləri' ? 'selected' : '' ?>>Kişi Parfümləri</option>
                        <option value="Qadın Parfümləri" <?= ($editProduct['category'] ?? '') === 'Qadın Parfümləri' ? 'selected' : '' ?>>Qadın Parfümləri</option>
                        <option value="Uniseks Parfümlər" <?= ($editProduct['category'] ?? '') === 'Uniseks Parfümlər' ? 'selected' : '' ?>>Uniseks Parfümlər</option>
                        <option value="Nişə Parfümlər" <?= ($editProduct['category'] ?? '') === 'Nişə Parfümlər' ? 'selected' : '' ?>>Nişə Parfümlər</option>
                        <option value="Ətir Yağları" <?= ($editProduct['category'] ?? '') === 'Ətir Yağları' ? 'selected' : '' ?>>Ətir Yağları</option>
                        <option value="Deodorantlar" <?= ($editProduct['category'] ?? '') === 'Deodorantlar' ? 'selected' : '' ?>>Deodorantlar</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Cins</label>
                    <select name="gender" class="form-control">
                        <option value="unisex" <?= ($editProduct['gender'] ?? 'unisex') === 'unisex' ? 'selected' : '' ?>>Uniseks</option>
                        <option value="male" <?= ($editProduct['gender'] ?? '') === 'male' ? 'selected' : '' ?>>Kişi</option>
                        <option value="female" <?= ($editProduct['gender'] ?? '') === 'female' ? 'selected' : '' ?>>Qadın</option>
                    </select>
                </div>
            </div>
            
            <!-- Pricing -->
            <div class="form-row">
                <div class="form-group">
                    <label>Satış Qiyməti (₼) *</label>
                    <input type="number" name="price" step="0.01" min="0" value="<?= $editProduct['price'] ?? '' ?>" required class="form-control" placeholder="0.00">
                </div>
                
                <div class="form-group">
                    <label>Maya Dəyəri (₼)</label>
                    <input type="number" name="cost_price" step="0.01" min="0" value="<?= $editProduct['cost_price'] ?? '' ?>" class="form-control" placeholder="0.00">
                </div>
            </div>
            
            <!-- Stock Management -->
            <div class="form-row">
                <div class="form-group">
                    <label>Stok Miqdarı</label>
                    <input type="number" name="stock_quantity" min="0" value="<?= $editProduct['stock_quantity'] ?? '0' ?>" class="form-control">
                </div>
                
                <div class="form-group">
                    <label>Minimum Stok Xəbərdarlığı</label>
                    <input type="number" name="min_stock" min="1" value="<?= $editProduct['min_stock'] ?? '5' ?>" class="form-control">
                </div>
            </div>
            
            <!-- Additional Details -->
            <div class="form-row">
                <div class="form-group">
                    <label>Ölçü/Həcm</label>
                    <input type="text" name="size" value="<?= htmlspecialchars($editProduct['size'] ?? '') ?>" class="form-control" placeholder="Məsələn: 100ml, 50ml">
                </div>
                
                <div class="form-group">
                    <label>Çəki (qram)</label>
                    <input type="number" name="weight" step="0.1" min="0" value="<?= $editProduct['weight'] ?? '' ?>" class="form-control">
                </div>
            </div>
            
            <!-- Advanced Information -->
            <div class="form-row">
                <div class="form-group">
                    <label>İstehsalçı</label>
                    <input type="text" name="manufacturer" value="<?= htmlspecialchars($editProduct['manufacturer'] ?? '') ?>" class="form-control">
                </div>
                
                <div class="form-group">
                    <label>Mənşə Ölkəsi</label>
                    <input type="text" name="country_origin" value="<?= htmlspecialchars($editProduct['country_origin'] ?? '') ?>" class="form-control">
                </div>
            </div>
            
            <!-- Product Codes -->
            <div class="form-row">
                <div class="form-group">
                    <label>Barkod (İxtiyari)</label>
                    <input type="text" name="barcode" value="<?= htmlspecialchars($editProduct['barcode'] ?? '') ?>" class="form-control" placeholder="Boş buraxsanız avtomatik yaradılacaq">
                </div>
                
                <div class="form-group">
                    <label>SKU (İxtiyari)</label>
                    <input type="text" name="sku" value="<?= htmlspecialchars($editProduct['sku'] ?? '') ?>" class="form-control" placeholder="Məhsul kodu">
                </div>
            </div>
            
            <!-- Description -->
            <div class="form-group">
                <label>Təsvir</label>
                <textarea name="description" rows="4" class="form-control" placeholder="Məhsul haqqında ətraflı məlumat"><?= htmlspecialchars($editProduct['description'] ?? '') ?></textarea>
            </div>
            
            <?php if ($action === 'edit'): ?>
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="is_active" <?= ($editProduct['is_active'] ?? 1) ? 'checked' : '' ?>>
                        Məhsul aktiv
                    </label>
                </div>
                
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                    <h6 style="margin-bottom: 15px;">Məhsul Məlumatları</h6>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; font-size: 0.9rem;">
                        <div><strong>Barkod:</strong> <?= htmlspecialchars($editProduct['barcode']) ?></div>
                        <div><strong>SKU:</strong> <?= htmlspecialchars($editProduct['sku']) ?></div>
                        <div><strong>Yaradılma:</strong> <?= date('d.m.Y H:i', strtotime($editProduct['created_at'])) ?></div>
                        <div><strong>Son yeniləmə:</strong> <?= $editProduct['updated_at'] ? date('d.m.Y H:i', strtotime($editProduct['updated_at'])) : 'Yoxdur' ?></div>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- Submit Buttons -->
            <div style="display: flex; gap: 15px; margin-top: 30px;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> 
                    <?= $action === 'add' ? 'Məhsulu Yadda Saxla' : 'Dəyişiklikləri Saxla' ?>
                </button>
                
                <a href="?page=products" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Geri
                </a>
                
                <?php if ($action === 'add'): ?>
                <button type="button" onclick="resetForm()" class="btn btn-warning">
                    <i class="fas fa-undo"></i> Sıfırla
                </button>
                <?php endif; ?>
            </div>
        </form>
    </div>

<?php else: ?>
    <!-- Filters Panel -->
    <div class="filters-panel">
        <h4 style="margin-bottom: 20px;">🔍 Axtarış və Filterlər</h4>
        
        <form method="GET">
            <input type="hidden" name="page" value="products">
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; align-items: end;">
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Axtarış</label>
                    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Ad, brand, barkod, SKU..." class="form-control">
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Kateqoriya</label>
                    <select name="category" class="form-control">
                        <option value="">Hamısı</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= htmlspecialchars($cat['category']) ?>" <?= $category === $cat['category'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($cat['category']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Brand</label>
                    <select name="brand" class="form-control">
                        <option value="">Hamısı</option>
                        <?php foreach ($brands as $b): ?>
                            <option value="<?= htmlspecialchars($b['brand']) ?>" <?= $brand === $b['brand'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($b['brand']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="">Hamısı</option>
                        <option value="1" <?= $status === '1' ? 'selected' : '' ?>>Aktiv</option>
                        <option value="0" <?= $status === '0' ? 'selected' : '' ?>>Deaktiv</option>
                    </select>
                </div>
                
                <div class="form-group" style="margin-bottom: 0;">
                    <label>Stok</label>
                    <select name="stock_filter" class="form-control">
                        <option value="">Hamısı</option>
                        <option value="low" <?= $stockFilter === 'low' ? 'selected' : '' ?>>Az stok</option>
                        <option value="out" <?= $stockFilter === 'out' ? 'selected' : '' ?>>Bitən</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary" style="height: 47px;">
                    <i class="fas fa-search"></i> Filtrələ
                </button>
            </div>
            
            <!-- Sorting Options -->
            <div style="margin-top: 15px; display: flex; gap: 15px; align-items: center; flex-wrap: wrap;">
                <span style="font-weight: 500;">Sıralama:</span>
                
                <select name="sort_by" class="form-control" style="width: auto;">
                    <option value="created_at" <?= $sortBy === 'created_at' ? 'selected' : '' ?>>Tarix</option>
                    <option value="name" <?= $sortBy === 'name' ? 'selected' : '' ?>>Ad</option>
                    <option value="brand" <?= $sortBy === 'brand' ? 'selected' : '' ?>>Brand</option>
                    <option value="price" <?= $sortBy === 'price' ? 'selected' : '' ?>>Qiymət</option>
                    <option value="stock_quantity" <?= $sortBy === 'stock_quantity' ? 'selected' : '' ?>>Stok</option>
                    <option value="total_sold" <?= $sortBy === 'total_sold' ? 'selected' : '' ?>>Satış</option>
                </select>
                
                <select name="sort_order" class="form-control" style="width: auto;">
                    <option value="DESC" <?= $sortOrder === 'DESC' ? 'selected' : '' ?>>Azalan</option>
                    <option value="ASC" <?= $sortOrder === 'ASC' ? 'selected' : '' ?>>Artan</option>
                </select>
                
                <a href="?page=products" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Təmizlə
                </a>
            </div>
        </form>
    </div>
    
    <!-- Bulk Actions -->
    <?php if (!empty($products)): ?>
    <div style="background: white; padding: 20px; border-radius: 15px; box-shadow: var(--box-shadow); margin-bottom: 25px;">
        <form method="POST" id="bulk-form">
            <input type="hidden" name="action" value="bulk_action">
            
            <div style="display: flex; justify-content: between; align-items: center; flex-wrap: wrap; gap: 15px;">
                <div style="display: flex; align-items: center; gap: 15px;">
                    <label style="margin: 0;">
                        <input type="checkbox" id="select-all"> Hamısını seç
                    </label>
                    
                    <select name="bulk_action" id="bulk-action" class="form-control" style="width: auto;">
                        <option value="">Toplu əməliyyat seçin</option>
                        <option value="activate">Aktivləşdir</option>
                        <option value="deactivate">Deaktivləşdir</option>
                        <?php if ($currentUserRole === 'admin'): ?>
                            <option value="delete">Sil</option>
                        <?php endif; ?>
                    </select>
                    
                    <button type="button" onclick="executeBulkAction()" class="btn btn-warning" disabled id="bulk-btn">
                        <i class="fas fa-play"></i> İcra Et
                    </button>
                </div>
                
                <div style="color: #6c757d; font-size: 0.9rem;">
                    Cəmi: <strong><?= count($products) ?></strong> məhsul
                </div>
            </div>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- Products Grid -->
    <?php if (empty($products)): ?>
        <div style="text-align: center; padding: 60px 20px; color: #6c757d;">
            <i class="fas fa-box-open" style="font-size: 4rem; margin-bottom: 20px; opacity: 0.3;"></i>
            <h4>Məhsul tapılmadı</h4>
            <p>Axtarış şərtlərinə uyğun məhsul yoxdur və ya hələ məhsul əlavə edilməyib.</p>
            <a href="?page=products&action=add" class="btn btn-primary" style="margin-top: 15px;">
                <i class="fas fa-plus"></i> İlk Məhsulu Əlavə Et
            </a>
        </div>
    <?php else: ?>
        <div class="products-grid">
            <?php foreach ($products as $product): ?>
                <div class="product-card" onclick="viewProduct(<?= $product['id'] ?>)">
                    <input type="checkbox" name="selected_products[]" value="<?= $product['id'] ?>" 
                           style="position: absolute; top: 15px; left: 15px; z-index: 3;" 
                           onclick="event.stopPropagation();">
                    
                    <div class="product-image">
                        <?php if ($product['image']): ?>
                            <img src="uploads/products/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                        <?php else: ?>
                            <div class="product-placeholder">
                                <?php
                                $category = strtolower($product['category'] ?? '');
                                if (strpos($category, 'kişi') !== false) echo '👨';
                                elseif (strpos($category, 'qadın') !== false) echo '👩';
                                elseif (strpos($category, 'deodorant') !== false) echo '🧴';
                                else echo '🧴';
                                ?>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Status Badges -->
                        <?php if ($product['stock_quantity'] <= 0): ?>
                            <div class="product-badge badge-out-stock">Bitib</div>
                        <?php elseif ($product['stock_quantity'] <= $product['min_stock']): ?>
                            <div class="product-badge badge-low-stock">Az Stok</div>
                        <?php elseif ($product['total_sold'] > 50): ?>
                            <div class="product-badge badge-bestseller">Top Seller</div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="product-content">
                        <div class="product-name"><?= htmlspecialchars($product['name']) ?></div>
                        <div class="product-brand"><?= htmlspecialchars($product['brand']) ?></div>
                        
                        <div class="product-details">
                            <div><i class="fas fa-tag"></i> <?= htmlspecialchars($product['category'] ?: 'N/A') ?></div>
                            <div><i class="fas fa-weight"></i> <?= htmlspecialchars($product['size'] ?: 'N/A') ?></div>
                            <div><i class="fas fa-barcode"></i> <?= htmlspecialchars($product['sku'] ?: $product['barcode']) ?></div>
                            <div><i class="fas fa-chart-line"></i> <?= $product['total_sold'] ?> satıldı</div>
                        </div>
                        
                        <div class="product-price">
                            <div>
                                <div class="price-current">₼<?= number_format($product['price'], 2) ?></div>
                                <?php if ($product['cost_price'] > 0): ?>
                                    <div class="price-cost">Maya: ₼<?= number_format($product['cost_price'], 2) ?></div>
                                <?php endif; ?>
                            </div>
                            <div style="text-align: right;">
                                <?php if ($product['cost_price'] > 0): ?>
                                    <div style="font-weight: bold; color: var(--success-color);">
                                        <?= round((($product['price'] - $product['cost_price']) / $product['price']) * 100) ?>% profit
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="product-stock">
                            <div class="stock-info">
                                <strong><?= $product['stock_quantity'] ?></strong> / <?= $product['min_stock'] ?> min
                                <div class="stock-bar">
                                    <?php 
                                    $stockPercent = $product['min_stock'] > 0 ? min(100, ($product['stock_quantity'] / ($product['min_stock'] * 2)) * 100) : 100;
                                    $stockColor = $stockPercent > 50 ? '#28a745' : ($stockPercent > 25 ? '#ffc107' : '#dc3545');
                                    ?>
                                    <div class="stock-fill" style="width: <?= $stockPercent ?>%; background: <?= $stockColor ?>;"></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="product-actions">
                            <a href="?page=products&action=edit&id=<?= $product['id'] ?>" 
                               class="btn-icon" style="background: var(--primary-color);" 
                               onclick="event.stopPropagation();" title="Redaktə">
                                <i class="fas fa-edit"></i>
                            </a>
                            
                            <button onclick="addToQuickSale(<?= $product['id'] ?>); event.stopPropagation();" 
                                    class="btn-icon" style="background: var(--success-color);" title="Tez Satış">
                                <i class="fas fa-cart-plus"></i>
                            </button>
                            
                            <button onclick="toggleStatus(<?= $product['id'] ?>, <?= $product['is_active'] ?>); event.stopPropagation();" 
                                    class="btn-icon" style="background: <?= $product['is_active'] ? 'var(--warning-color)' : 'var(--info-color)' ?>;" 
                                    title="<?= $product['is_active'] ? 'Deaktiv Et' : 'Aktiv Et' ?>">
                                <i class="fas fa-<?= $product['is_active'] ? 'ban' : 'check' ?>"></i>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
<?php endif; ?>

<!-- Product Details Modal -->
<div class="modal" id="productModal">
    <div class="modal-content" style="max-width: 800px;">
        <div class="modal-header">
            <h5 class="modal-title">
                <i class="fas fa-box"></i> Məhsul Detalları
            </h5>
            <button class="modal-close" onclick="closeModal('productModal')">×</button>
        </div>
        <div id="productModalContent">
            <div style="text-align: center; padding: 40px;">
                <i class="fas fa-spinner fa-spin" style="font-size: 2rem; color: var(--primary-color);"></i>
                <p style="margin-top: 15px;">Yüklənir...</p>
            </div>
        </div>
    </div>
</div>

<script>
// Image upload preview
document.addEventListener('DOMContentLoaded', function() {
    const imageInput = document.getElementById('image-input');
    const uploadArea = document.querySelector('.image-upload-area');
    
    if (imageInput && uploadArea) {
        imageInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    uploadArea.innerHTML = `
                        <img src="${e.target.result}" class="current-image" alt="Preview">
                        <div>Şəkil seçildi: ${file.name}</div>
                        <div style="font-size: 0.8rem; color: var(--success-color); margin-top: 5px;">
                            <i class="fas fa-check"></i> Dəyişdirmək üçün yenidən klikləyin
                        </div>
                    `;
                };
                reader.readAsDataURL(file);
            }
        });
        
        // Drag & drop functionality
        uploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('dragover');
        });
        
        uploadArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
        });
        
        uploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                imageInput.files = files;
                imageInput.dispatchEvent(new Event('change'));
            }
        });
    }
    
    // Auto-generate SKU
    const nameInput = document.querySelector('input[name="name"]');
    const brandInput = document.querySelector('input[name="brand"]');
    const skuInput = document.querySelector('input[name="sku"]');
    
    if (nameInput && brandInput && skuInput && !skuInput.value) {
        function generateSku() {
            const name = nameInput.value.trim();
            const brand = brandInput.value.trim();
            
            if (name && brand) {
                const sku = (brand.substring(0, 3) + name.substring(0, 3) + Math.floor(Math.random() * 900 + 100)).toUpperCase();
                skuInput.value = sku;
            }
        }
        
        nameInput.addEventListener('blur', generateSku);
        brandInput.addEventListener('blur', generateSku);
    }
});

// Bulk selection
document.getElementById('select-all')?.addEventListener('change', function() {
    const checkboxes = document.querySelectorAll('input[name="selected_products[]"]');
    checkboxes.forEach(cb => cb.checked = this.checked);
    updateBulkButton();
});

document.addEventListener('change', function(e) {
    if (e.target.name === 'selected_products[]') {
        updateBulkButton();
    }
});

function updateBulkButton() {
    const selected = document.querySelectorAll('input[name="selected_products[]"]:checked');
    const bulkBtn = document.getElementById('bulk-btn');
    const bulkAction = document.getElementById('bulk-action');
    
    if (selected.length > 0 && bulkAction.value) {
        bulkBtn.disabled = false;
        bulkBtn.innerHTML = `<i class="fas fa-play"></i> İcra Et (${selected.length})`;
    } else {
        bulkBtn.disabled = true;
        bulkBtn.innerHTML = '<i class="fas fa-play"></i> İcra Et';
    }
}

document.getElementById('bulk-action')?.addEventListener('change', updateBulkButton);

function executeBulkAction() {
    const selected = document.querySelectorAll('input[name="selected_products[]"]:checked');
    const action = document.getElementById('bulk-action').value;
    
    if (selected.length === 0) {
        alert('Məhsul seçilməyib!');
        return;
    }
    
    if (!action) {
        alert('Əməliyyat seçin!');
        return;
    }
    
    const actionNames = {
        'activate': 'aktivləşdirəcək',
        'deactivate': 'deaktivləşdirəcək',
        'delete': 'siləcək'
    };
    
    if (confirm(`${selected.length} məhsulu ${actionNames[action]}. Davam etmək istəyirsiniz?`)) {
        document.getElementById('bulk-form').submit();
    }
}

// Product actions
function viewProduct(productId) {
    const modal = document.getElementById('productModal');
    const content = document.getElementById('productModalContent');
    
    modal.classList.add('show');
    
    fetch(`api/get_product.php?id=${productId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayProductDetails(data.product);
            } else {
                content.innerHTML = `
                    <div style="text-align: center; padding: 40px; color: var(--danger-color);">
                        <i class="fas fa-exclamation-circle" style="font-size: 2rem; margin-bottom: 15px;"></i>
                        <p>Məhsul məlumatı yüklənə bilmədi</p>
                    </div>
                `;
            }
        })
        .catch(error => {
            content.innerHTML = `
                <div style="text-align: center; padding: 40px; color: var(--danger-color);">
                    <i class="fas fa-exclamation-circle" style="font-size: 2rem; margin-bottom: 15px;"></i>
                    <p>Sistem xətası baş verdi</p>
                </div>
            `;
        });
}

f// ... (əvvəlki kod davam edir)

function displayProductDetails(product) {
    const content = document.getElementById('productModalContent');
    
    content.innerHTML = `
        <div style="padding: 25px;">
            <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 30px; margin-bottom: 25px;">
                <div>
                    ${product.image ? 
                        `<img src="uploads/products/${product.image}" style="width: 100%; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);" alt="${product.name}">` :
                        `<div style="width: 100%; height: 300px; background: linear-gradient(135deg, #f8f9fa, #e9ecef); border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 4rem; color: #dee2e6;">🧴</div>`
                    }
                </div>
                
                <div>
                    <h3 style="color: var(--primary-color); margin-bottom: 10px;">${product.name}</h3>
                    <h5 style="color: #6c757d; margin-bottom: 20px;">${product.brand}</h5>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                        <div><strong>Kateqoriya:</strong> ${product.category || 'N/A'}</div>
                        <div><strong>Cins:</strong> ${product.gender || 'Uniseks'}</div>
                        <div><strong>Ölçü:</strong> ${product.size || 'N/A'}</div>
                        <div><strong>Çəki:</strong> ${product.weight ? product.weight + 'q' : 'N/A'}</div>
                        <div><strong>Barkod:</strong> ${product.barcode}</div>
                        <div><strong>SKU:</strong> ${product.sku}</div>
                    </div>
                    
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                            <div>
                                <div style="font-size: 2rem; font-weight: bold; color: var(--success-color);">₼${parseFloat(product.price).toFixed(2)}</div>
                                <div style="color: #6c757d;">Satış Qiyməti</div>
                            </div>
                            ${product.cost_price > 0 ? `
                                <div>
                                    <div style="font-size: 1.5rem; font-weight: bold; color: var(--info-color);">₼${parseFloat(product.cost_price).toFixed(2)}</div>
                                    <div style="color: #6c757d;">Maya Dəyəri</div>
                                </div>
                            ` : ''}
                        </div>
                        ${product.cost_price > 0 ? `
                            <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #e9ecef;">
                                <div style="display: flex; justify-content: space-between;">
                                    <span>Mənfəət:</span>
                                    <strong style="color: var(--success-color);">₼${(parseFloat(product.price) - parseFloat(product.cost_price)).toFixed(2)} (${Math.round(((parseFloat(product.price) - parseFloat(product.cost_price)) / parseFloat(product.price)) * 100)}%)</strong>
                                </div>
                            </div>
                        ` : ''}
                    </div>
                    
                    <div style="background: ${product.stock_quantity <= 0 ? '#f8d7da' : product.stock_quantity <= product.min_stock ? '#fff3cd' : '#d4edda'}; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <div style="font-size: 1.5rem; font-weight: bold;">${product.stock_quantity}</div>
                                <div>Mövcud Stok</div>
                            </div>
                            <div style="text-align: right;">
                                <div style="color: #6c757d;">Min: ${product.min_stock}</div>
                                <div style="font-weight: bold; color: ${product.stock_quantity <= 0 ? 'var(--danger-color)' : product.stock_quantity <= product.min_stock ? 'var(--warning-color)' : 'var(--success-color)'};">
                                    ${product.stock_quantity <= 0 ? 'Bitib' : product.stock_quantity <= product.min_stock ? 'Az Stok' : 'Normal'}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            ${product.description ? `
                <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
                    <h6 style="margin-bottom: 10px;">Təsvir:</h6>
                    <p style="margin: 0; line-height: 1.6;">${product.description}</p>
                </div>
            ` : ''}
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">
                <div style="background: #e3f2fd; padding: 20px; border-radius: 10px;">
                    <h6 style="color: var(--info-color); margin-bottom: 15px;">
                        <i class="fas fa-chart-line"></i> Satış Statistikası
                    </h6>
                    <div style="font-size: 2rem; font-weight: bold; color: var(--info-color); margin-bottom: 5px;">${product.total_sold || 0}</div>
                    <div style="color: #6c757d;">Cəmi Satılan</div>
                    ${product.total_revenue > 0 ? `
                        <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid rgba(0,0,0,0.1);">
                            <strong style="color: var(--success-color);">₼${parseFloat(product.total_revenue).toFixed(2)}</strong>
                            <div style="font-size: 0.8rem; color: #6c757d;">Cəmi Gəlir</div>
                        </div>
                    ` : ''}
                </div>
                
                <div style="background: #f3e5f5; padding: 20px; border-radius: 10px;">
                    <h6 style="color: var(--secondary-color); margin-bottom: 15px;">
                        <i class="fas fa-info-circle"></i> Əlavə Məlumat
                    </h6>
                    ${product.manufacturer ? `<div><strong>İstehsalçı:</strong> ${product.manufacturer}</div>` : ''}
                    ${product.country_origin ? `<div><strong>Mənşə:</strong> ${product.country_origin}</div>` : ''}
                    <div><strong>Yaradılma:</strong> ${new Date(product.created_at).toLocaleDateString('az-AZ')}</div>
                    ${product.updated_at ? `<div><strong>Yenilənmə:</strong> ${new Date(product.updated_at).toLocaleDateString('az-AZ')}</div>` : ''}
                </div>
            </div>
            
            <div style="text-align: center;">
                <a href="?page=products&action=edit&id=${product.id}" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Redaktə Et
                </a>
                
                <button onclick="addToQuickSale(${product.id})" class="btn btn-success">
                    <i class="fas fa-cart-plus"></i> Tez Satış
                </button>
                
                <button onclick="closeModal('productModal')" class="btn btn-secondary">
                    <i class="fas fa-times"></i> Bağla
                </button>
            </div>
        </div>
    `;
}

function addToQuickSale(productId) {
    // Add to localStorage cart
    let cart = JSON.parse(localStorage.getItem('pos_cart') || '[]');
    
    fetch(`api/get_product.php?id=${productId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const product = data.product;
                const existingItem = cart.find(item => item.id === product.id);
                
                if (existingItem) {
                    existingItem.quantity += 1;
                } else {
                    cart.push({
                        id: product.id,
                        name: product.name,
                        brand: product.brand,
                        price: parseFloat(product.price),
                        quantity: 1,
                        stock: product.stock_quantity,
                        size: product.size || ''
                    });
                }
                
                localStorage.setItem('pos_cart', JSON.stringify(cart));
                
                showToast('success', `${product.name} POS səbətinə əlavə edildi`);
                
                // Show option to go to POS
                setTimeout(() => {
                    if (confirm('POS sisteminə keçmək istəyirsiniz?')) {
                        window.location.href = '?page=sales&action=new';
                    }
                }, 1000);
            }
        })
        .catch(error => {
            showToast('error', 'Məhsul əlavə edilə bilmədi');
        });
}

function toggleStatus(productId, currentStatus) {
    const action = currentStatus ? 'deaktivləşdir' : 'aktivləşdir';
    
    if (confirm(`Bu məhsulu ${action}mək istədiyinizə əminsiniz?`)) {
        window.location.href = `?page=products&action=toggle_status&id=${productId}`;
    }
}

function exportProducts() {
    const url = 'api/export_products.php?' + new URLSearchParams(window.location.search);
    window.open(url, '_blank');
}

function importProducts() {
    // Create file input
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv,.xlsx';
    
    input.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            const formData = new FormData();
            formData.append('import_file', file);
            
            showToast('info', 'Fayllar yüklənir...');
            
            fetch('api/import_products.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showToast('success', `${data.imported} məhsul uğurla import edildi`);
                    setTimeout(() => location.reload(), 2000);
                } else {
                    showToast('error', 'Import xətası: ' + data.error);
                }
            })
            .catch(error => {
                showToast('error', 'Sistem xətası baş verdi');
            });
        }
    });
    
    input.click();
}

function resetForm() {
    if (confirm('Formu sıfırlamaq istədiyinizə əminsiniz?')) {
        document.querySelector('form').reset();
        
        // Reset image upload area
        const uploadArea = document.querySelector('.image-upload-area');
        if (uploadArea) {
            uploadArea.innerHTML = `
                <i class="fas fa-cloud-upload-alt" style="font-size: 3rem; color: #dee2e6; margin-bottom: 15px;"></i>
                <div style="margin-bottom: 10px; font-weight: bold;">Şəkil yükləyin</div>
                <div style="font-size: 0.9rem; color: #6c757d;">JPG, PNG, WebP və ya GIF (Max: 5MB)</div>
            `;
        }
    }
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

function showToast(type, message) {
    const toast = document.createElement('div');
    toast.className = `alert alert-${type}`;
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 2000;
        min-width: 300px;
        animation: slideIn 0.3s ease;
    `;
    
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    
    toast.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
            <i class="fas fa-${icons[type]}"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()" style="background: none; border: none; font-size: 1.2rem; cursor: pointer; margin-left: auto;">×</button>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        if (toast.parentElement) {
            toast.remove();
        }
    }, 4000);
}

// Close modal when clicking outside
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('show');
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl+N - New product
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        window.location.href = '?page=products&action=add';
    }
    
    // Ctrl+F - Focus search
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        const searchInput = document.querySelector('input[name="search"]');
        if (searchInput) {
            searchInput.focus();
            searchInput.select();
        }
    }
    
    // Escape - Close modals
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal.show').forEach(modal => {
            modal.classList.remove('show');
        });
    }
});

console.log('Products system initialized');
console.log('Total products loaded:', <?= count($products) ?>);
console.log('Keyboard shortcuts: Ctrl+N (New Product), Ctrl+F (Search), ESC (Close modals)');
</script>

<?php include 'includes/footer.php'; ?>