<?php
/**
 * Parfüm POS Sistemi - Register Səhifəsi
 * Yaradıldığı tarix: 2025-07-21
 */

$user = new User();

// Əgər artıq daxil olmuşsa, dashboard-a yönləndir
if ($user->isLoggedIn()) {
    redirect('dashboard');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Təhlükəsizlik xətası. Səhifəni yeniləyin.';
    } else {
        try {
            $userData = [
                'username' => $_POST['username'] ?? '',
                'email' => $_POST['email'] ?? '',
                'password' => $_POST['password'] ?? '',
                'full_name' => $_POST['full_name'] ?? '',
                'phone' => $_POST['phone'] ?? '',
                'role' => 'seller' // Default role
            ];
            
            $userId = $user->register($userData);
            
            $success = 'Hesab uğurla yaradıldı! İndi daxil ola bilərsiniz.';
            
            // Redirect after success
            header('Refresh: 2; url=' . BASE_URL . 'login');
            
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="az" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Qeydiyyat - <?= PWA_NAME ?></title>
    
    <!-- PWA Meta tags -->
    <meta name="theme-color" content="<?= PWA_THEME_COLOR ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="<?= PWA_SHORT_NAME ?>">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="32x32" href="<?= BASE_URL ?>assets/icons/favicon-32x32.png">
    <link rel="apple-touch-icon" href="<?= BASE_URL ?>assets/icons/icon-192x192.png">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/app.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/login.css">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-background">
            <div class="gradient-overlay"></div>
            <div class="particles" id="particles"></div>
        </div>
        
        <div class="login-content">
            <div class="login-card">
                <div class="login-header">
                    <div class="logo">
                        <i class="fas fa-spray-can"></i>
                        <h1><?= PWA_SHORT_NAME ?></h1>
                    </div>
                    <p class="subtitle">Yeni hesab yaradın</p>
                </div>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?= escape($error) ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i>
                        <?= escape($success) ?>
                        <div class="loading-spinner"></div>
                    </div>
                <?php endif; ?>
                
                <form method="POST" class="login-form" id="registerForm">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION[CSRF_TOKEN_NAME] ?>">
                    
                    <div class="form-group">
                        <label for="full_name">
                            <i class="fas fa-user"></i>
                            Ad və Soyad
                        </label>
                        <input 
                            type="text" 
                            id="full_name" 
                            name="full_name" 
                            required 
                            value="<?= escape($_POST['full_name'] ?? '') ?>"
                            placeholder="Ad və soyadınızı daxil edin"
                        >
                    </div>
                    
                    <div class="form-group">
                        <label for="username">
                            <i class="fas fa-user-circle"></i>
                            İstifadəçi adı
                        </label>
                        <input 
                            type="text" 
                            id="username" 
                            name="username" 
                            required 
                            value="<?= escape($_POST['username'] ?? '') ?>"
                            placeholder="İstifadəçi adınızı daxil edin"
                        >
                    </div>
                    
                    <div class="form-group">
                        <label for="email">
                            <i class="fas fa-envelope"></i>
                            Email
                        </label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            required 
                            value="<?= escape($_POST['email'] ?? '') ?>"
                            placeholder="Email ünvanınızı daxil edin"
                        >
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">
                            <i class="fas fa-phone"></i>
                            Telefon (İstəyə görə)
                        </label>
                        <input 
                            type="tel" 
                            id="phone" 
                            name="phone" 
                            value="<?= escape($_POST['phone'] ?? '') ?>"
                            placeholder="+994501234567"
                        >
                    </div>
                    
                    <div class="form-group">
                        <label for="password">
                            <i class="fas fa-lock"></i>
                            Şifrə
                        </label>
                        <div class="password-input">
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                required 
                                placeholder="Şifrənizi daxil edin"
                            >
                            <button type="button" class="toggle-password" onclick="togglePassword('password')">
                                <i class="fas fa-eye" id="toggleIcon1"></i>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">
                            <i class="fas fa-lock"></i>
                            Şifrə təkrarı
                        </label>
                        <div class="password-input">
                            <input 
                                type="password" 
                                id="confirm_password" 
                                name="confirm_password" 
                                required 
                                placeholder="Şifrənizi təkrar daxil edin"
                            >
                            <button type="button" class="toggle-password" onclick="togglePassword('confirm_password')">
                                <i class="fas fa-eye" id="toggleIcon2"></i>
                            </button>
                        </div>
                    </div>
                    
                    <button type="submit" class="login-btn" id="registerBtn">
                        <span class="btn-text">Qeydiyyat</span>
                        <div class="btn-spinner" style="display: none;">
                            <i class="fas fa-spinner fa-spin"></i>
                        </div>
                    </button>
                </form>
                
                <div class="login-footer">
                    <p>Artıq hesabınız var? <a href="<?= BASE_URL ?>login">Daxil ol</a></p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script src="<?= BASE_URL ?>assets/js/particles.js"></script>
    
    <script>
        // Initialize particles
        initParticles();
        
        // Form validation
        function validateForm() {
            const fullName = document.getElementById('full_name').value.trim();
            const username = document.getElementById('username').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (fullName.length < 2) {
                showError('Ad və soyad ən azı 2 simvol olmalıdır');
                return false;
            }
            
            if (username.length < 3) {
                showError('İstifadəçi adı ən azı 3 simvol olmalıdır');
                return false;
            }
            
            if (!isValidEmail(email)) {
                showError('Düzgün email daxil edin');
                return false;
            }
            
            if (password.length < 6) {
                showError('Şifrə ən azı 6 simvol olmalıdır');
                return false;
            }
            
            if (password !== confirmPassword) {
                showError('Şifrələr uyğun gəlmir');
                return false;
            }
            
            return true;
        }
        
        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }
        
        function showError(message) {
            // Remove existing alerts
            const existingAlert = document.querySelector('.alert');
            if (existingAlert) {
                existingAlert.remove();
            }
            
            // Create new alert
            const alert = document.createElement('div');
            alert.className = 'alert alert-error';
            alert.innerHTML = `<i class="fas fa-exclamation-circle"></i>${message}`;
            
            // Insert before form
            const form = document.querySelector('.login-form');
            form.parentNode.insertBefore(alert, form);
            
            // Auto remove after 5 seconds
            setTimeout(() => {
                if (alert.parentNode) {
                    alert.remove();
                }
            }, 5000);
        }
        
        // Form submission
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            if (!validateForm()) {
                e.preventDefault();
                return false;
            }
            
            const btn = document.getElementById('registerBtn');
            const btnText = btn.querySelector('.btn-text');
            const btnSpinner = btn.querySelector('.btn-spinner');
            
            btnText.style.display = 'none';
            btnSpinner.style.display = 'inline-block';
            btn.disabled = true;
        });
        
        // Toggle password visibility
        function togglePassword(fieldId) {
            const passwordInput = document.getElementById(fieldId);
            const toggleIcon = passwordInput.nextElementSibling.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.className = 'fas fa-eye-slash';
            } else {
                passwordInput.type = 'password';
                toggleIcon.className = 'fas fa-eye';
            }
        }
        
        // Real-time validation
        document.getElementById('username').addEventListener('input', function() {
            const value = this.value.trim();
            if (value.length > 0 && value.length < 3) {
                this.style.borderColor = '#f59e0b';
            } else if (value.length >= 3) {
                this.style.borderColor = '#22c55e';
            } else {
                this.style.borderColor = '';
            }
        });
        
        document.getElementById('email').addEventListener('input', function() {
            const value = this.value.trim();
            if (value.length > 0) {
                if (isValidEmail(value)) {
                    this.style.borderColor = '#22c55e';
                } else {
                    this.style.borderColor = '#f59e0b';
                }
            } else {
                this.style.borderColor = '';
            }
        });
        
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            
            if (confirmPassword.length > 0) {
                if (password === confirmPassword) {
                    this.style.borderColor = '#22c55e';
                } else {
                    this.style.borderColor = '#f59e0b';
                }
            } else {
                this.style.borderColor = '';
            }
        });
    </script>
</body>
</html>