<?php
/**
 * Maaş İdarəetməsi Sistemi
 * Kodaz-az - 2025-07-21 13:55:07 (UTC)
 * Login: Kodaz-az
 */

$currentUserId = $_SESSION['user_id'];
$currentUserRole = $_SESSION['role'];

// Date filters
$month = $_GET['month'] ?? date('m');
$year = $_GET['year'] ?? date('Y');
$userId = $_GET['user_id'] ?? ($currentUserRole === 'seller' ? $currentUserId : '');

try {
    $db = Database::getInstance();
    
    // Get salary report for the specified month/year
    if ($userId) {
        // Individual salary report
        $salaryReport = $db->selectOne("
            SELECT sr.*, u.full_name, u.role, u.salary as base_salary, u.commission_rate
            FROM salary_reports sr
            LEFT JOIN users u ON sr.user_id = u.id
            WHERE sr.user_id = ? AND sr.month = ? AND sr.year = ?
        ", [$userId, $month, $year]);
        
        // If no report exists, create one
        if (!$salaryReport) {
            // Calculate salary for the month
            $salesData = $db->selectOne("
                SELECT 
                    COUNT(*) as total_sales,
                    SUM(final_amount) as total_revenue,
                    SUM(subtotal) as subtotal
                FROM sales 
                WHERE user_id = ? AND MONTH(created_at) = ? AND YEAR(created_at) = ?
            ", [$userId, $month, $year]);
            
            $user = $db->selectOne("SELECT * FROM users WHERE id = ?", [$userId]);
            
            if ($user && $salesData) {
                $baseSalary = $user['salary'] ?? 0;
                $commissionRate = $user['commission_rate'] ?? 0;
                $commissionAmount = ($salesData['subtotal'] * $commissionRate) / 100;
                $totalSalary = $baseSalary + $commissionAmount;
                
                // Insert salary report
                $reportId = $db->insert("
                    INSERT INTO salary_reports (user_id, month, year, base_salary, commission_rate, commission_amount, total_sales, total_revenue, total_salary, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ", [$userId, $month, $year, $baseSalary, $commissionRate, $commissionAmount, $salesData['total_sales'], $salesData['total_revenue'], $totalSalary]);
                
                if ($reportId) {
                    $salaryReport = $db->selectOne("
                        SELECT sr.*, u.full_name, u.role
                        FROM salary_reports sr
                        LEFT JOIN users u ON sr.user_id = u.id
                        WHERE sr.id = ?
                    ", [$reportId]);
                }
            }
        }
        
        // Get daily sales for chart
        $dailySales = $db->selectAll("
            SELECT 
                DATE(created_at) as sale_date,
                COUNT(*) as daily_sales,
                SUM(final_amount) as daily_revenue,
                SUM(subtotal) as daily_subtotal
            FROM sales 
            WHERE user_id = ? AND MONTH(created_at) = ? AND YEAR(created_at) = ?
            GROUP BY DATE(created_at)
            ORDER BY sale_date
        ", [$userId, $month, $year]);
        
    } else {
        // All users salary overview (for admin/manager)
        $allSalaries = $db->selectAll("
            SELECT sr.*, u.full_name, u.role
            FROM salary_reports sr
            LEFT JOIN users u ON sr.user_id = u.id
            WHERE sr.month = ? AND sr.year = ?
            ORDER BY sr.total_salary DESC
        ", [$month, $year]);
        
        // Summary
        $summary = $db->selectOne("
            SELECT 
                COUNT(DISTINCT sr.user_id) as total_employees,
                SUM(sr.base_salary) as total_base_salary,
                SUM(sr.commission_amount) as total_commission,
                SUM(sr.total_salary) as total_salary_expense,
                AVG(sr.total_salary) as avg_salary
            FROM salary_reports sr
            WHERE sr.month = ? AND sr.year = ?
        ", [$month, $year]);
    }
    
    // Get users for dropdown (if admin/manager)
    if (in_array($currentUserRole, ['admin', 'manager'])) {
        $users = $db->selectAll("SELECT id, full_name FROM users WHERE is_active = 1 ORDER BY full_name");
    }
    
} catch (Exception $e) {
    $error = $e->getMessage();
    $salaryReport = null;
    $allSalaries = [];
    $users = [];
    $summary = [];
}

$pageTitle = "Maaş Sistemi - " . PWA_NAME;
include 'includes/header.php';
?>

<style>
.salary-card {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: var(--white);
    padding: 30px;
    border-radius: 20px;
    margin-bottom: 30px;
    box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
}

.salary-amount {
    font-size: 3rem;
    font-weight: bold;
    margin-bottom: 10px;
}

.salary-details {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 20px;
    margin-top: 20px;
}

.salary-detail {
    background: rgba(255, 255, 255, 0.1);
    padding: 15px;
    border-radius: 10px;
    text-align: center;
}

.salary-detail-amount {
    font-size: 1.5rem;
    font-weight: bold;
    margin-bottom: 5px;
}

.salary-detail-label {
    font-size: 0.9rem;
    opacity: 0.9;
}

.month-selector {
    background: var(--white);
    padding: 20px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    margin-bottom: 30px;
}

.performance-metrics {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.metric-card {
    background: var(--white);
    padding: 20px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    text-align: center;
    border-left: 4px solid var(--primary-color);
}

.metric-value {
    font-size: 1.8rem;
    font-weight: bold;
    color: var(--primary-color);
    margin-bottom: 5px;
}

.metric-label {
    color: #6c757d;
    font-size: 0.9rem;
}

.salary-breakdown {
    background: var(--white);
    padding: 25px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    margin-bottom: 30px;
}

.breakdown-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 0;
    border-bottom: 1px solid #e9ecef;
}

.breakdown-item:last-child {
    border-bottom: none;
    font-weight: bold;
    font-size: 1.1rem;
    padding-top: 20px;
    border-top: 2px solid #e9ecef;
}

.chart-container {
    background: var(--white);
    padding: 25px;
    border-radius: 15px;
    box-shadow: var(--box-shadow);
    margin-bottom: 30px;
}
</style>

<!-- Month/Year Selector -->
<div class="month-selector">
    <form method="GET" style="display: flex; align-items: center; gap: 20px; flex-wrap: wrap;">
        <input type="hidden" name="page" value="salary">
        
        <div style="display: flex; align-items: center; gap: 10px;">
            <label style="font-weight: bold; color: var(--dark-color);">
                <i class="fas fa-calendar"></i> Tarix:
            </label>
            <select name="month" class="form-control" style="width: auto;">
                <?php
                $months = [
                    1 => 'Yanvar', 2 => 'Fevral', 3 => 'Mart', 4 => 'Aprel',
                    5 => 'May', 6 => 'İyun', 7 => 'İyul', 8 => 'Avqust',
                    9 => 'Sentyabr', 10 => 'Oktyabr', 11 => 'Noyabr', 12 => 'Dekabr'
                ];
                foreach ($months as $num => $name): ?>
                    <option value="<?= $num ?>" <?= $month == $num ? 'selected' : '' ?>><?= $name ?></option>
                <?php endforeach; ?>
            </select>
            
            <select name="year" class="form-control" style="width: auto;">
                <?php for ($y = date('Y'); $y >= 2020; $y--): ?>
                    <option value="<?= $y ?>" <?= $year == $y ? 'selected' : '' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
        </div>
        
        <?php if (in_array($currentUserRole, ['admin', 'manager']) && !empty($users)): ?>
        <div style="display: flex; align-items: center; gap: 10px;">
            <label style="font-weight: bold; color: var(--dark-color);">
                <i class="fas fa-user"></i> İstifadəçi:
            </label>
            <select name="user_id" class="form-control" style="width: auto;">
                <option value="">Hamısı</option>
                <?php foreach ($users as $user): ?>
                    <option value="<?= $user['id'] ?>" <?= $userId == $user['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($user['full_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <?php endif; ?>
        
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-search"></i> Göstər
        </button>
    </form>
</div>

<?php if ($userId && $salaryReport): ?>
    <!-- Individual Salary Report -->
    <div class="salary-card">
        <div style="display: flex; justify-content: between; align-items: center; margin-bottom: 20px;">
            <div>
                <h2 style="color: white; margin-bottom: 10px;">
                    <i class="fas fa-money-bill-wave"></i>
                    <?= htmlspecialchars($salaryReport['full_name']) ?>
                </h2>
                <p style="opacity: 0.9; margin: 0;">
                    <?= $months[$month] ?> <?= $year ?> - <?= ucfirst($salaryReport['role']) ?>
                </p>
            </div>
            <div class="salary-amount">
                ₼<?= number_format($salaryReport['total_salary'], 2) ?>
            </div>
        </div>
        
        <div class="salary-details">
            <div class="salary-detail">
                <div class="salary-detail-amount">₼<?= number_format($salaryReport['base_salary'], 2) ?></div>
                <div class="salary-detail-label">Əsas Maaş</div>
            </div>
            
            <div class="salary-detail">
                <div class="salary-detail-amount">₼<?= number_format($salaryReport['commission_amount'], 2) ?></div>
                <div class="salary-detail-label">Komissiya (<?= $salaryReport['commission_rate'] ?>%)</div>
            </div>
            
            <div class="salary-detail">
                <div class="salary-detail-amount"><?= $salaryReport['total_sales'] ?></div>
                <div class="salary-detail-label">Satış Sayı</div>
            </div>
            
            <div class="salary-detail">
                <div class="salary-detail-amount">₼<?= number_format($salaryReport['total_revenue'], 2) ?></div>
                <div class="salary-detail-label">Cəmi Gəlir</div>
            </div>
        </div>
    </div>
    
    <!-- Performance Metrics -->
    <div class="performance-metrics">
        <div class="metric-card">
            <div class="metric-value">
                ₼<?= $salaryReport['total_sales'] > 0 ? number_format($salaryReport['total_revenue'] / $salaryReport['total_sales'], 2) : '0.00' ?>
            </div>
            <div class="metric-label">Orta Satış</div>
        </div>
        
        <div class="metric-card" style="border-color: var(--success-color);">
            <div class="metric-value" style="color: var(--success-color);">
                <?= date('t', mktime(0, 0, 0, $month, 1, $year)) ?>/<?= $salaryReport['total_sales'] ?>
            </div>
            <div class="metric-label">Gün/Satış Nisbəti</div>
        </div>
        
        <div class="metric-card" style="border-color: var(--warning-color);">
            <div class="metric-value" style="color: var(--warning-color);">
                <?= $salaryReport['base_salary'] > 0 ? number_format(($salaryReport['commission_amount'] / $salaryReport['base_salary']) * 100, 1) : 0 ?>%
            </div>
            <div class="metric-label">Komissiya/Maaş</div>
        </div>
        
        <div class="metric-card" style="border-color: var(--info-color);">
            <div class="metric-value" style="color: var(--info-color);">
                ₼<?= $salaryReport['total_sales'] > 0 ? number_format($salaryReport['commission_amount'] / $salaryReport['total_sales'], 2) : '0.00' ?>
            </div>
            <div class="metric-label">Satış Başına Komissiya</div>
        </div>
    </div>
    
    <!-- Salary Breakdown -->
    <div class="salary-breakdown">
        <h4 style="margin-bottom: 20px;">
            <i class="fas fa-calculator"></i> Maaş Hesabatı
        </h4>
        
        <div class="breakdown-item">
            <span><i class="fas fa-dollar-sign"></i> Əsas Maaş</span>
            <span>₼<?= number_format($salaryReport['base_salary'], 2) ?></span>
        </div>
        
        <div class="breakdown-item">
            <span><i class="fas fa-percentage"></i> Komissiya (<?= $salaryReport['commission_rate'] ?>% × ₼<?= number_format($salaryReport['total_revenue'], 2) ?>)</span>
            <span>₼<?= number_format($salaryReport['commission_amount'], 2) ?></span>
        </div>
        
        <div class="breakdown-item">
            <span><i class="fas fa-minus-circle"></i> Vergilər (18% KDV)</span>
            <span>-₼<?= number_format($salaryReport['total_salary'] * 0.18, 2) ?></span>
        </div>
        
        <div class="breakdown-item">
            <span><i class="fas fa-hand-holding-usd"></i> Ələ Keçən Məbləğ</span>
            <span style="color: var(--success-color);">₼<?= number_format($salaryReport['total_salary'] * 0.82, 2) ?></span>
        </div>
    </div>
    
    <!-- Daily Performance Chart -->
    <?php if (!empty($dailySales)): ?>
    <div class="chart-container">
        <h4 style="margin-bottom: 20px;">
            <i class="fas fa-chart-line"></i> Gündəlik Performans
        </h4>
        <canvas id="dailyPerformanceChart" style="max-height: 400px;"></canvas>
    </div>
    <?php endif; ?>

<?php elseif (in_array($currentUserRole, ['admin', 'manager'])): ?>
    <!-- All Users Salary Overview -->
    <?php if (!empty($summary)): ?>
    <div class="performance-metrics">
        <div class="metric-card">
            <div class="metric-value"><?= $summary['total_employees'] ?></div>
            <div class="metric-label">İşçi Sayı</div>
        </div>
        
        <div class="metric-card" style="border-color: var(--success-color);">
            <div class="metric-value" style="color: var(--success-color);">
                ₼<?= number_format($summary['total_salary_expense'], 2) ?>
            </div>
            <div class="metric-label">Cəmi Maaş Xərci</div>
        </div>
        
        <div class="metric-card" style="border-color: var(--warning-color);">
            <div class="metric-value" style="color: var(--warning-color);">
                ₼<?= number_format($summary['avg_salary'], 2) ?>
            </div>
            <div class="metric-label">Orta Maaş</div>
        </div>
        
        <div class="metric-card" style="border-color: var(--info-color);">
            <div class="metric-value" style="color: var(--info-color);">
                ₼<?= number_format($summary['total_commission'], 2) ?>
            </div>
            <div class="metric-label">Cəmi Komissiya</div>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="content-box">
        <h4>
            <i class="fas fa-users"></i> 
            <?= $months[$month] ?> <?= $year ?> - Bütün İşçilər
        </h4>
        
        <?php if (empty($allSalaries)): ?>
            <div style="text-align: center; padding: 40px; color: #6c757d;">
                <i class="fas fa-money-bill-wave" style="font-size: 3rem; margin-bottom: 15px; opacity: 0.3;"></i>
                <h5>Maaş hesabatı yoxdur</h5>
                <p>Bu ay üçün hələ maaş hesabatı hazırlanmayıb.</p>
                <button onclick="generateAllSalaries()" class="btn btn-primary" style="margin-top: 15px;">
                    <i class="fas fa-calculator"></i> Maaş Hesabatlarını Hazırla
                </button>
            </div>
        <?php else: ?>
            <div style="overflow-x: auto; margin-top: 20px;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>İşçi</th>
                            <th>Rol</th>
                            <th style="text-align: right;">Əsas Maaş</th>
                            <th style="text-align: center;">Satış</th>
                            <th style="text-align: right;">Komissiya</th>
                            <th style="text-align: right;">Cəmi Maaş</th>
                            <th style="text-align: right;">Ələ Keçən</th>
                            <th style="text-align: center;">Əməliyyat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($allSalaries as $salary): ?>
                            <tr>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="width: 35px; height: 35px; border-radius: 50%; background: var(--primary-color); color: white; display: flex; align-items: center; justify-content: center; font-weight: bold;">
                                            <?= strtoupper(substr($salary['full_name'], 0, 1)) ?>
                                        </div>
                                        <strong><?= htmlspecialchars($salary['full_name']) ?></strong>
                                    </div>
                                </td>
                                <td>
                                    <span class="role-badge role-<?= $salary['role'] ?>">
                                        <?= ucfirst($salary['role']) ?>
                                    </span>
                                </td>
                                <td style="text-align: right;">₼<?= number_format($salary['base_salary'], 2) ?></td>
                                <td style="text-align: center;">
                                    <span class="badge badge-primary"><?= $salary['total_sales'] ?></span>
                                </td>
                                <td style="text-align: right;">
                                    ₼<?= number_format($salary['commission_amount'], 2) ?>
                                    <br><small style="color: #6c757d;">(<?= $salary['commission_rate'] ?>%)</small>
                                </td>
                                <td style="text-align: right;">
                                    <strong>₼<?= number_format($salary['total_salary'], 2) ?></strong>
                                </td>
                                <td style="text-align: right;">
                                    <strong style="color: var(--success-color);">
                                        ₼<?= number_format($salary['total_salary'] * 0.82, 2) ?>
                                    </strong>
                                </td>
                                <td style="text-align: center;">
                                    <a href="?page=salary&user_id=<?= $salary['user_id'] ?>&month=<?= $month ?>&year=<?= $year ?>" 
                                       class="btn btn-info btn-sm">
                                        <i class="fas fa-eye"></i> Bax
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr style="background: #f8f9fa; font-weight: bold;">
                            <td colspan="2">CƏMI</td>
                            <td style="text-align: right;">₼<?= number_format($summary['total_base_salary'], 2) ?></td>
                            <td style="text-align: center;">-</td>
                            <td style="text-align: right;">₼<?= number_format($summary['total_commission'], 2) ?></td>
                            <td style="text-align: right;">₼<?= number_format($summary['total_salary_expense'], 2) ?></td>
                            <td style="text-align: right;">₼<?= number_format($summary['total_salary_expense'] * 0.82, 2) ?></td>
                            <td>-</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        <?php endif; ?>
    </div>

<?php else: ?>
    <!-- Access Denied for sellers without specific user selection -->
    <div class="content-box" style="text-align: center; padding: 60px 40px;">
        <i class="fas fa-lock" style="font-size: 4rem; color: #ffc107; margin-bottom: 20px;"></i>
        <h3>Məhdudlaşdırılmış Giriş</h3>
        <p style="color: #6c757d; margin-bottom: 30px;">
            Yalnız öz maaş məlumatlarınızı görə bilərsiniz.
        </p>
        <a href="?page=salary&user_id=<?= $currentUserId ?>&month=<?= $month ?>&year=<?= $year ?>" class="btn btn-primary">
            <i class="fas fa-eye"></i> Mənim Maaşım
        </a>
    </div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
<?php if ($userId && !empty($dailySales)): ?>
// Daily Performance Chart
const ctx = document.getElementById('dailyPerformanceChart').getContext('2d');
const chart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [<?= implode(',', array_map(function($day) { return '"' . date('d.m', strtotime($day['sale_date'])) . '"'; }, $dailySales)) ?>],
        datasets: [{
            label: 'Gündəlik Satış (₼)',
            data: [<?= implode(',', array_column($dailySales, 'daily_revenue')) ?>],
            borderColor: 'rgb(102, 126, 234)',
            backgroundColor: 'rgba(102, 126, 234, 0.1)',
            tension: 0.4,
            fill: true
        }, {
            label: 'Satış Sayı',
            data: [<?= implode(',', array_column($dailySales, 'daily_sales')) ?>],
            borderColor: 'rgb(40, 167, 69)',
            backgroundColor: 'rgba(40, 167, 69, 0.1)',
            tension: 0.4,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            mode: 'index',
            intersect: false,
        },
        scales: {
            y: {
                type: 'linear',
                display: true,
                position: 'left',
                title: {
                    display: true,
                    text: 'Gəlir (₼)'
                }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                title: {
                    display: true,
                    text: 'Satış Sayı'
                },
                grid: {
                    drawOnChartArea: false,
                }
            }
        }
    }
});
<?php endif; ?>

// ... (əvvəlki kod davam edir)

function generateAllSalaries() {
    if (confirm('Bu ay üçün bütün işçilərin maaş hesabatlarını hazırlamaq istədiyinizə əminsiniz?')) {
        // Show loading
        const btn = event.target;
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Hazırlanır...';
        btn.disabled = true;
        
        // Make request to generate salaries
        fetch('?page=salary&action=generate_all', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                month: <?= $month ?>,
                year: <?= $year ?>
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Xəta: ' + data.error);
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        })
        .catch(error => {
            alert('Sistem xətası');
            btn.innerHTML = originalText;
            btn.disabled = false;
        });
    }
}

console.log('Salary system initialized');
console.log('Month: <?= $month ?>, Year: <?= $year ?>, User: <?= $userId ?>');
</script>

<?php include 'includes/footer.php'; ?>