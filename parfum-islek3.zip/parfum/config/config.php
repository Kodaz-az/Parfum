<?php
/**
 * Parfüm POS Sistemi - Konfiqurasiya
 * Yaradıldı: 2025-07-21 12:40:00
 * Müəllif: Kodaz-az
 */

// Error reporting (development üçün)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Məlumat Bazası Konfiqurasiyası - ÖZ MƏLUMATLARıNıZı DAXİL EDİN
define('DB_HOST', 'localhost');
define('DB_NAME', 'ezizov04_parfum');  // Sizin DB adınız
define('DB_USER', 'ezizov04_parfum');      // Sizin DB istifadəçiniz
define('DB_PASS', 'ezizovs074');   // Sizin DB şifrəniz
define('DB_PORT', '2083');
define('DB_CHARSET', 'utf8mb4');

// Tətbiq Konfiqurasiyası
define('APP_VERSION', '1.0.0');
define('ENVIRONMENT', 'development');

// PWA Konfiqurasiyası
define('PWA_NAME', 'Parfüm POS');
define('PWA_SHORT_NAME', 'POS');
define('PWA_DESCRIPTION', 'Parfüm satış və inventar sistemi');
define('PWA_THEME_COLOR', '#667eea');
define('PWA_BACKGROUND_COLOR', '#ffffff');

// Sistem URL
define('BASE_URL', 'https://kodaz.az/parfum/');
define('ROOT_PATH', __DIR__ . '/..');

// Təhlükəsizlik
define('SECRET_KEY', 'kodaz-parfum-secret-key-' . date('Y'));
define('CSRF_TOKEN_NAME', 'csrf_token');

// Saat Qurşağı
date_default_timezone_set('Asia/Baku');

// Session Konfiqurasiyası
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1); // HTTPS üçün
ini_set('session.use_strict_mode', 1);

// Upload Konfiqurasiyası
define('MAX_UPLOAD_SIZE', 10 * 1024 * 1024); // 10MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);
define('ALLOWED_FILE_TYPES', ['pdf', 'doc', 'docx', 'xls', 'xlsx']);

// Sistem Email
define('SYSTEM_EMAIL', 'admin@kodaz.az');
define('SYSTEM_NAME', 'Parfüm POS - Kodaz.az');

?>