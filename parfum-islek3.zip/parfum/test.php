<?php
echo "PHP işləyir: " . phpversion() . "<br>";
echo "Vaxt: " . date('Y-m-d H:i:s') . "<br>";
echo "Server: " . $_SERVER['SERVER_SOFTWARE'] . "<br>";
echo "Sistem hazırdır!";
?>