<?php
/**
 * Products Import API
 * Kodaz-az - 2025-07-21 14:50:56 (UTC)
 * Login: Kodaz-az
 */

header('Content-Type: application/json');
require_once '../config/config.php';
require_once '../includes/Database.php';

session_start();

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['admin', 'manager'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

if (!isset($_FILES['import_file'])) {
    echo json_encode(['success' => false, 'error' => 'File not uploaded']);
    exit;
}

$file = $_FILES['import_file'];

// Validate file
if ($file['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'error' => 'File upload error']);
    exit;
}

$allowedTypes = ['text/csv', 'application/csv', 'application/vnd.ms-excel'];
if (!in_array($file['type'], $allowedTypes)) {
    echo json_encode(['success' => false, 'error' => 'Only CSV files are allowed']);
    exit;
}

try {
    $db = Database::getInstance();
    
    $handle = fopen($file['tmp_name'], 'r');
    if (!$handle) {
        throw new Exception('Could not open file');
    }
    
    // Skip header row
    fgetcsv($handle);
    
    $imported = 0;
    $errors = [];
    
    $db->beginTransaction();
    
    while (($data = fgetcsv($handle)) !== FALSE) {
        try {
            // Expected CSV format: name, brand, category, price, cost_price, stock_quantity, min_stock, size, gender, description
            $name = trim($data[0] ?? '');
            $brand = trim($data[1] ?? '');
            $category = trim($data[2] ?? '');
            $price = floatval($data[3] ?? 0);
            $costPrice = floatval($data[4] ?? 0);
            $stockQuantity = intval($data[5] ?? 0);
            $minStock = intval($data[6] ?? 5);
            $size = trim($data[7] ?? '');
            $gender = trim($data[8] ?? 'unisex');
            $description = trim($data[9] ?? '');
            
            // Validation
            if (empty($name) || empty($brand) || $price <= 0) {
                $errors[] = "Row skipped: Invalid data - $name";
                continue;
            }
            
            // Generate barcode and SKU
            $barcode = 'PRD' . date('ymd') . str_pad($imported + 1, 5, '0', STR_PAD_LEFT);
            $sku = strtoupper(substr($brand, 0, 3) . substr($name, 0, 3) . rand(100, 999));
            
            // Insert product
            $productId = $db->insert("
                INSERT INTO products (
                    name, brand, category, barcode, sku, price, cost_price, 
                    stock_quantity, min_stock, size, gender, description, 
                    is_active, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, NOW())
            ", [
                $name, $brand, $category, $barcode, $sku, $price, $costPrice,
                $stockQuantity, $minStock, $size, $gender, $description
            ]);
            
            if ($productId) {
                $imported++;
            }
            
        } catch (Exception $e) {
            $errors[] = "Row error: " . $e->getMessage();
        }
    }
    
    fclose($handle);
    
    $db->commit();
    
    echo json_encode([
        'success' => true,
        'imported' => $imported,
        'errors' => $errors
    ]);
    
} catch (Exception $e) {
    if (isset($db)) {
        $db->rollback();
    }
    
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>