<?php
/**
 * Product API - Get Single Product
 * Kodaz-az - 2025-07-21 14:50:56 (UTC)
 * Login: Kodaz-az
 */

header('Content-Type: application/json');
require_once '../config/config.php';
require_once '../includes/Database.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$productId = $_GET['id'] ?? 0;

if (!$productId) {
    echo json_encode(['success' => false, 'error' => 'Product ID required']);
    exit;
}

try {
    $db = Database::getInstance();
    
    $product = $db->selectOne("
        SELECT p.*, 
               COALESCE(sales_data.total_sold, 0) as total_sold,
               COALESCE(sales_data.total_revenue, 0) as total_revenue
        FROM products p
        LEFT JOIN (
            SELECT sd.product_id, 
                   SUM(sd.quantity) as total_sold,
                   SUM(sd.total_price) as total_revenue
            FROM sale_details sd
            GROUP BY sd.product_id
        ) sales_data ON p.id = sales_data.product_id
        WHERE p.id = ? AND p.deleted_at IS NULL
    ", [$productId]);
    
    if (!$product) {
        echo json_encode(['success' => false, 'error' => 'Product not found']);
        exit;
    }
    
    echo json_encode([
        'success' => true,
        'product' => $product
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>