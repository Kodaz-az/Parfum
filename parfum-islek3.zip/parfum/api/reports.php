<?php
/**
 * Parfüm POS Sistemi - Reports API
 * Yaradıldığı tarix: 2025-07-21 10:48:02
 * Müəllif: Kodaz-az
 */

require_once '../classes/Report.php';

$report = new Report();

switch ($method) {
    case 'GET':
        if ($id) {
            if ($id === 'sales') {
                handleGetSalesReport();
            } else if ($id === 'products') {
                handleGetProductReport();
            } else if ($id === 'financial') {
                handleGetFinancialReport();
            } else if ($id === 'inventory') {
                handleGetInventoryReport();
            } else if ($id === 'user') {
                handleGetUserReport();
            } else if ($id === 'export') {
                handleExportReport();
            } else {
                throw new Exception('Invalid report type', 400);
            }
        } else {
            handleGetAvailableReports();
        }
        break;
        
    case 'POST':
        if ($action === 'generate') {
            handleGenerateReport();
        } else if ($action === 'schedule') {
            handleScheduleReport();
        } else {
            throw new Exception('Invalid report action', 400);
        }
        break;
        
    default:
        throw new Exception('Method not allowed', 405);
}

function handleGetAvailableReports() {
    global $response, $user, $currentUser;
    
    $availableReports = [
        'sales' => [
            'name' => 'Satış Hesabatı',
            'description' => 'Satış statistikaları və performans analizləri',
            'permission' => 'view_reports'
        ],
        'products' => [
            'name' => 'Məhsul Hesabatı',
            'description' => 'Məhsul inventarı və stok analizi',
            'permission' => 'view_reports'
        ],
        'financial' => [
            'name' => 'Maliyyə Hesabatı',
            'description' => 'Gəlir, xərc və mənfəət analizi',
            'permission' => 'view_financial_reports'
        ],
        'inventory' => [
            'name' => 'Inventar Hesabatı',
            'description' => 'Stok hərəkəti və inventar analizi',
            'permission' => 'view_reports'
        ],
        'user' => [
            'name' => 'İstifadəçi Performans Hesabatı',
            'description' => 'İstifadəçi fəaliyyəti və performans',
            'permission' => 'view_user_reports'
        ]
    ];
    
    // Filter reports based on user permissions
    $userReports = [];
    foreach ($availableReports as $key => $reportInfo) {
        if ($user->hasPermission($reportInfo['permission'])) {
            $userReports[$key] = $reportInfo;
        }
    }
    
    $response['success'] = true;
    $response['data'] = ['reports' => $userReports];
}

function handleGetSalesReport() {
    global $response, $report, $user, $currentUser;
    
    if (!$user->hasPermission('view_reports')) {
        throw new Exception('Permission denied', 403);
    }
    
    $filters = [
        'date_from' => $_GET['date_from'] ?? date('Y-m-01'),
        'date_to' => $_GET['date_to'] ?? date('Y-m-t'),
        'user_id' => $_GET['user_id'] ?? null,
        'payment_method' => $_GET['payment_method'] ?? '',
        'group_by' => $_GET['group_by'] ?? 'day'
    ];
    
    // Restrict to own sales for sellers
    if ($currentUser['role'] === 'seller') {
        $filters['user_id'] = $currentUser['id'];
    }
    
    try {
        $reportData = $report->getSalesReport($filters);
        
        $response['success'] = true;
        $response['data'] = $reportData;
        
    } catch (Exception $e) {
        throw new Exception('Failed to generate sales report: ' . $e->getMessage(), 500);
    }
}

function handleGetProductReport() {
    global $response, $report, $user;
    
    if (!$user->hasPermission('view_reports')) {
        throw new Exception('Permission denied', 403);
    }
    
    $filters = [
        'category' => $_GET['category'] ?? '',
        'brand' => $_GET['brand'] ?? '',
        'low_stock' => isset($_GET['low_stock']),
        'out_of_stock' => isset($_GET['out_of_stock']),
        'date_from' => $_GET['date_from'] ?? date('Y-m-01'),
        'date_to' => $_GET['date_to'] ?? date('Y-m-t')
    ];
    
    try {
        $reportData = $report->getProductReport($filters);
        
        $response['success'] = true;
        $response['data'] = $reportData;
        
    } catch (Exception $e) {
        throw new Exception('Failed to generate product report: ' . $e->getMessage(), 500);
    }
}

function handleGetFinancialReport() {
    global $response, $report, $user;
    
    if (!$user->hasPermission('view_financial_reports')) {
        throw new Exception('Permission denied', 403);
    }
    
    $filters = [
        'date_from' => $_GET['date_from'] ?? date('Y-m-01'),
        'date_to' => $_GET['date_to'] ?? date('Y-m-t'),
        'include_expenses' => isset($_GET['include_expenses']),
        'group_by' => $_GET['group_by'] ?? 'month'
    ];
    
    try {
        $reportData = $report->getFinancialReport($filters);
        
        $response['success'] = true;
        $response['data'] = $reportData;
        
    } catch (Exception $e) {
        throw new Exception('Failed to generate financial report: ' . $e->getMessage(), 500);
    }
}

function handleGetInventoryReport() {
    global $response, $report, $user;
    
    if (!$user->hasPermission('view_reports')) {
        throw new Exception('Permission denied', 403);
    }
    
    $filters = [
        'date_from' => $_GET['date_from'] ?? date('Y-m-01'),
        'date_to' => $_GET['date_to'] ?? date('Y-m-t'),
        'movement_type' => $_GET['movement_type'] ?? '',
        'category' => $_GET['category'] ?? ''
    ];
    
    try {
        $reportData = $report->getInventoryMovementReport($filters);
        
        $response['success'] = true;
        $response['data'] = $reportData;
        
    } catch (Exception $e) {
        throw new Exception('Failed to generate inventory report: ' . $e->getMessage(), 500);
    }
}

function handleGetUserReport() {
    global $response, $report, $user, $currentUser;
    
    if (!$user->hasPermission('view_user_reports')) {
        throw new Exception('Permission denied', 403);
    }
    
    $userId = $_GET['user_id'] ?? null;
    $filters = [
        'date_from' => $_GET['date_from'] ?? date('Y-m-01'),
        'date_to' => $_GET['date_to'] ?? date('Y-m-t'),
        'include_activity' => isset($_GET['include_activity']),
        'include_performance' => isset($_GET['include_performance'])
    ];
    
    // Users can only view their own reports unless they have admin permissions
    if (!$user->hasPermission('view_all_user_reports')) {
        $userId = $currentUser['id'];
    }
    
    if (!$userId) {
        throw new Exception('User ID is required', 400);
    }
    
    try {
        $reportData = $report->getUserPerformanceReport($userId, $filters);
        
        $response['success'] = true;
        $response['data'] = $reportData;
        
    } catch (Exception $e) {
        throw new Exception('Failed to generate user report: ' . $e->getMessage(), 500);
    }
}

function handleGenerateReport() {
    global $response, $report, $user, $currentUser;
    
    if (!$user->hasPermission('generate_reports')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $reportData = [
        'type' => $input['type'] ?? '',
        'name' => $input['name'] ?? '',
        'filters' => $input['filters'] ?? [],
        'format' => $input['format'] ?? 'json',
        'created_by' => $currentUser['id']
    ];
    
    if (empty($reportData['type']) || empty($reportData['name'])) {
        throw new Exception('Report type and name are required', 400);
    }
    
    $allowedTypes = ['sales', 'products', 'financial', 'inventory', 'user'];
    if (!in_array($reportData['type'], $allowedTypes)) {
        throw new Exception('Invalid report type', 400);
    }
    
    $allowedFormats = ['json', 'csv', 'excel', 'pdf'];
    if (!in_array($reportData['format'], $allowedFormats)) {
        throw new Exception('Invalid report format', 400);
    }
    
    try {
        $reportId = $report->generateCustomReport($reportData);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'generate_report', "Generated {$reportData['type']} report: {$reportData['name']}");
        
        $response['success'] = true;
        $response['message'] = 'Report generated successfully';
        $response['data'] = ['report_id' => $reportId];
        
    } catch (Exception $e) {
        throw new Exception('Failed to generate report: ' . $e->getMessage(), 500);
    }
}

function handleScheduleReport() {
    global $response, $report, $user, $currentUser;
    
    if (!$user->hasPermission('schedule_reports')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $scheduleData = [
        'type' => $input['type'] ?? '',
        'name' => $input['name'] ?? '',
        'filters' => $input['filters'] ?? [],
        'format' => $input['format'] ?? 'pdf',
        'frequency' => $input['frequency'] ?? 'weekly',
        'day_of_week' => $input['day_of_week'] ?? 1,
        'day_of_month' => $input['day_of_month'] ?? 1,
        'time' => $input['time'] ?? '09:00',
        'recipients' => $input['recipients'] ?? [],
        'created_by' => $currentUser['id']
    ];
    
    if (empty($scheduleData['type']) || empty($scheduleData['name'])) {
        throw new Exception('Report type and name are required', 400);
    }
    
    $allowedFrequencies = ['daily', 'weekly', 'monthly'];
    if (!in_array($scheduleData['frequency'], $allowedFrequencies)) {
        throw new Exception('Invalid frequency', 400);
    }
    
    if (empty($scheduleData['recipients'])) {
        throw new Exception('At least one recipient is required', 400);
    }
    
    try {
        $scheduleId = $report->scheduleReport($scheduleData);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'schedule_report', "Scheduled {$scheduleData['type']} report: {$scheduleData['name']}");
        
        $response['success'] = true;
        $response['message'] = 'Report scheduled successfully';
        $response['data'] = ['schedule_id' => $scheduleId];
        
    } catch (Exception $e) {
        throw new Exception('Failed to schedule report: ' . $e->getMessage(), 500);
    }
}

function handleExportReport() {
    global $report, $user, $currentUser;
    
    if (!$user->hasPermission('export_reports')) {
        throw new Exception('Permission denied', 403);
    }
    
    $type = $_GET['type'] ?? '';
    $format = $_GET['format'] ?? 'csv';
    
    if (empty($type)) {
        throw new Exception('Report type is required', 400);
    }
    
    $filters = [];
    
    // Extract filters from query parameters
    $allowedFilters = ['date_from', 'date_to', 'user_id', 'category', 'brand', 'payment_method'];
    foreach ($allowedFilters as $filter) {
        if (isset($_GET[$filter]) && !empty($_GET[$filter])) {
            $filters[$filter] = $_GET[$filter];
        }
    }
    
    // Restrict to own data for sellers
    if ($currentUser['role'] === 'seller' && in_array($type, ['sales', 'user'])) {
        $filters['user_id'] = $currentUser['id'];
    }
    
    try {
        switch ($type) {
            case 'sales':
                $data = $report->getSalesReport($filters);
                exportSalesReport($data, $format);
                break;
                
            case 'products':
                $data = $report->getProductReport($filters);
                exportProductReport($data, $format);
                break;
                
            case 'financial':
                if (!$user->hasPermission('view_financial_reports')) {
                    throw new Exception('Permission denied', 403);
                }
                $data = $report->getFinancialReport($filters);
                exportFinancialReport($data, $format);
                break;
                
            case 'inventory':
                $data = $report->getInventoryMovementReport($filters);
                exportInventoryReport($data, $format);
                break;
                
            case 'user':
                if (!$user->hasPermission('view_user_reports')) {
                    throw new Exception('Permission denied', 403);
                }
                $userId = $filters['user_id'] ?? $currentUser['id'];
                $data = $report->getUserPerformanceReport($userId, $filters);
                exportUserReport($data, $format);
                break;
                
            default:
                throw new Exception('Invalid report type', 400);
        }
        
        // Log activity
        $user->logActivity($currentUser['id'], 'export_report', "Exported {$type} report in {$format} format");
        
    } catch (Exception $e) {
        throw new Exception('Failed to export report: ' . $e->getMessage(), 500);
    }
}

function exportSalesReport($data, $format) {
    switch ($format) {
        case 'csv':
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="sales_report_' . date('Y-m-d') . '.csv"');
            
            $output = fopen('php://output', 'w');
            
            // Headers
            fputcsv($output, ['Date', 'Sales Count', 'Revenue', 'Average Sale', 'Top Product']);
            
            // Data
            foreach ($data['daily_breakdown'] as $row) {
                fputcsv($output, [
                    $row['sale_date'],
                    $row['daily_sales'],
                    $row['daily_revenue'],
                    $row['avg_sale_amount'],
                    $row['top_product'] ?? ''
                ]);
            }
            
            fclose($output);
            break;
            
        case 'json':
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="sales_report_' . date('Y-m-d') . '.json"');
            echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            break;
            
        default:
            throw new Exception('Unsupported export format', 400);
    }
    
    exit;
}

function exportProductReport($data, $format) {
    switch ($format) {
        case 'csv':
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="product_report_' . date('Y-m-d') . '.csv"');
            
            $output = fopen('php://output', 'w');
            
            // Headers
            fputcsv($output, ['Product', 'Brand', 'Category', 'Current Stock', 'Min Stock', 'Price', 'Status']);
            
            // Data
            foreach ($data['stock_status'] as $row) {
                fputcsv($output, [
                    $row['name'],
                    $row['brand'],
                    $row['category'],
                    $row['stock_quantity'],
                    $row['min_stock'],
                    $row['price'],
                    $row['stock_status']
                ]);
            }
            
            fclose($output);
            break;
            
        case 'json':
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="product_report_' . date('Y-m-d') . '.json"');
            echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            break;
            
        default:
            throw new Exception('Unsupported export format', 400);
    }
    
    exit;
}

function exportFinancialReport($data, $format) {
    switch ($format) {
        case 'csv':
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="financial_report_' . date('Y-m-d') . '.csv"');
            
            $output = fopen('php://output', 'w');
            
            // Headers
            fputcsv($output, ['Month', 'Revenue', 'Costs', 'Profit', 'Profit Margin %']);
            
            // Data
            foreach ($data['monthly_trend'] as $row) {
                fputcsv($output, [
                    $row['month'],
                    $row['monthly_revenue'],
                    $row['monthly_costs'] ?? 0,
                    $row['monthly_profit'] ?? 0,
                    $row['profit_margin'] ?? 0
                ]);
            }
            
            fclose($output);
            break;
            
        case 'json':
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="financial_report_' . date('Y-m-d') . '.json"');
            echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            break;
            
        default:
            throw new Exception('Unsupported export format', 400);
    }
    
    exit;
}

function exportInventoryReport($data, $format) {
    switch ($format) {
        case 'csv':
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="inventory_report_' . date('Y-m-d') . '.csv"');
            
            $output = fopen('php://output', 'w');
            
            // Headers
            fputcsv($output, ['Product', 'Fast Moving Quantity', 'Slow Moving Stock', 'Inventory Value']);
            
            // Data - combine fast and slow moving products
            $products = array_merge($data['fast_moving'], $data['slow_moving']);
            foreach ($products as $row) {
                fputcsv($output, [
                    $row['product_name'] ?? $row['name'],
                    $row['total_sold'] ?? 0,
                    $row['current_stock'] ?? $row['stock_quantity'],
                    $row['inventory_value'] ?? 0
                ]);
            }
            
            fclose($output);
            break;
            
        case 'json':
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="inventory_report_' . date('Y-m-d') . '.json"');
            echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            break;
            
        default:
            throw new Exception('Unsupported export format', 400);
    }
    
    exit;
}

function exportUserReport($data, $format) {
    switch ($format) {
        case 'csv':
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="user_report_' . date('Y-m-d') . '.csv"');
            
            $output = fopen('php://output', 'w');
            
            // Headers
            fputcsv($output, ['Date', 'Sales', 'Revenue', 'Messages', 'Activity Score']);
            
            // Data
            foreach ($data['daily_performance'] as $row) {
                fputcsv($output, [
                    $row['sale_date'],
                    $row['daily_sales'],
                    $row['daily_revenue'],
                    $row['messages_sent'] ?? 0,
                    $row['activity_score'] ?? 0
                ]);
            }
            
            fclose($output);
            break;
            
        case 'json':
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="user_report_' . date('Y-m-d') . '.json"');
            echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            break;
            
        default:
            throw new Exception('Unsupported export format', 400);
    }
    
    exit;
}
?>