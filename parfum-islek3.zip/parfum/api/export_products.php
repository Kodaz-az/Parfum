<?php
/**
 * Products Export API
 * Kodaz-az - 2025-07-21 14:50:56 (UTC)
 * Login: Kodaz-az
 */

require_once '../config/config.php';
require_once '../includes/Database.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 401 Unauthorized');
    exit('Unauthorized');
}

try {
    $db = Database::getInstance();
    
    // Get products with filters from query string
    $search = $_GET['search'] ?? '';
    $category = $_GET['category'] ?? '';
    $brand = $_GET['brand'] ?? '';
    $status = $_GET['status'] ?? '';
    
    $sql = "SELECT p.*, 
            COALESCE(sales_data.total_sold, 0) as total_sold,
            COALESCE(sales_data.total_revenue, 0) as total_revenue
            FROM products p
            LEFT JOIN (
                SELECT sd.product_id, 
                       SUM(sd.quantity) as total_sold,
                       SUM(sd.total_price) as total_revenue
                FROM sale_details sd
                GROUP BY sd.product_id
            ) sales_data ON p.id = sales_data.product_id
            WHERE p.deleted_at IS NULL";
    
    $params = [];
    
    if (!empty($search)) {
        $sql .= " AND (p.name LIKE ? OR p.brand LIKE ? OR p.barcode LIKE ? OR p.sku LIKE ?)";
        $searchTerm = "%{$search}%";
        $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    }
    
    if (!empty($category)) {
        $sql .= " AND p.category = ?";
        $params[] = $category;
    }
    
    if (!empty($brand)) {
        $sql .= " AND p.brand = ?";
        $params[] = $brand;
    }
    
    if ($status !== '') {
        $sql .= " AND p.is_active = ?";
        $params[] = intval($status);
    }
    
    $sql .= " ORDER BY p.name";
    
    $products = $db->selectAll($sql, $params);
    
    // Set headers for CSV download
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="products_export_' . date('Y-m-d_H-i-s') . '.csv"');
    
    // Create CSV output
    $output = fopen('php://output', 'w');
    
    // Write BOM for UTF-8
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Write headers
    fputcsv($output, [
        'ID',
        'Ad',
        'Brand',
        'Kateqoriya',
        'Barkod',
        'SKU',
        'Qiymət',
        'Maya Dəyəri',
        'Stok',
        'Min Stok',
        'Ölçü',
        'Cins',
        'Çəki',
        'İstehsalçı',
        'Mənşə',
        'Təsvir',
        'Status',
        'Cəmi Satılan',
        'Cəmi Gəlir',
        'Yaradılma Tarixi',
        'Yeniləmə Tarixi'
    ]);
    
    // Write data
    foreach ($products as $product) {
        fputcsv($output, [
            $product['id'],
            $product['name'],
            $product['brand'],
            $product['category'],
            $product['barcode'],
            $product['sku'],
            $product['price'],
            $product['cost_price'],
            $product['stock_quantity'],
            $product['min_stock'],
            $product['size'],
            $product['gender'],
            $product['weight'],
            $product['manufacturer'],
            $product['country_origin'],
            $product['description'],
            $product['is_active'] ? 'Aktiv' : 'Deaktiv',
            $product['total_sold'],
            $product['total_revenue'],
            $product['created_at'],
            $product['updated_at']
        ]);
    }
    
    fclose($output);
    
} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo 'Export xətası: ' . $e->getMessage();
}
?>