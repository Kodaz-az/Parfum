<?php
/**
 * Parfüm POS Sistemi - Authentication API
 * Yaradıldığı tarix: 2025-07-21
 * Müəllif: Kodaz-az
 */

switch ($method) {
    case 'POST':
        switch ($id) {
            case 'login':
                handleLogin();
                break;
                
            case 'logout':
                handleLogout();
                break;
                
            case 'refresh':
                handleRefreshToken();
                break;
                
            case 'forgot-password':
                handleForgotPassword();
                break;
                
            case 'reset-password':
                handleResetPassword();
                break;
                
            default:
                throw new Exception('Invalid auth endpoint', 400);
        }
        break;
        
    case 'GET':
        switch ($id) {
            case 'me':
                handleGetCurrentUser();
                break;
                
            case 'verify':
                handleVerifyToken();
                break;
                
            default:
                throw new Exception('Invalid auth endpoint', 400);
        }
        break;
        
    default:
        throw new Exception('Method not allowed', 405);
}

function handleLogin() {
    global $response, $user;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $username = $input['username'] ?? '';
    $password = $input['password'] ?? '';
    $remember = $input['remember'] ?? false;
    
    if (empty($username) || empty($password)) {
        throw new Exception('Username and password are required', 400);
    }
    
    // Rate limiting
    $ip = getUserIpAddress();
    if ($user->isLoginRateLimited($ip)) {
        throw new Exception('Too many login attempts. Please try again later.', 429);
    }
    
    // Authenticate user
    $userData = $user->login($username, $password, $remember);
    
    if ($userData) {
        // Generate API token
        $token = $user->generateApiToken($userData['id']);
        
        $response['success'] = true;
        $response['message'] = 'Login successful';
        $response['data'] = [
            'user' => [
                'id' => $userData['id'],
                'username' => $userData['username'],
                'full_name' => $userData['full_name'],
                'email' => $userData['email'],
                'role' => $userData['role'],
                'avatar' => $userData['avatar']
            ],
            'token' => $token,
            'expires_in' => 3600 // 1 hour
        ];
        
        // Log successful login
        $user->logActivity($userData['id'], 'login', 'API login successful');
        
    } else {
        // Log failed login attempt
        $user->logFailedLogin($username, $ip);
        throw new Exception('Invalid credentials', 401);
    }
}

function handleLogout() {
    global $response, $user, $currentUser;
    
    if ($currentUser) {
        // Invalidate API token
        $user->invalidateApiToken($currentUser['id']);
        
        // Log logout
        $user->logActivity($currentUser['id'], 'logout', 'API logout');
        
        // Destroy session if exists
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_destroy();
        }
    }
    
    $response['success'] = true;
    $response['message'] = 'Logout successful';
}

function handleRefreshToken() {
    global $response, $user, $currentUser;
    
    if (!$currentUser) {
        throw new Exception('Authentication required', 401);
    }
    
    // Generate new token
    $token = $user->generateApiToken($currentUser['id']);
    
    $response['success'] = true;
    $response['message'] = 'Token refreshed';
    $response['data'] = [
        'token' => $token,
        'expires_in' => 3600
    ];
}

function handleGetCurrentUser() {
    global $response, $currentUser;
    
    if (!$currentUser) {
        throw new Exception('Authentication required', 401);
    }
    
    $response['success'] = true;
    $response['data'] = [
        'id' => $currentUser['id'],
        'username' => $currentUser['username'],
        'full_name' => $currentUser['full_name'],
        'email' => $currentUser['email'],
        'role' => $currentUser['role'],
        'avatar' => $currentUser['avatar'],
        'last_login' => $currentUser['last_login'],
        'is_active' => $currentUser['is_active']
    ];
}

function handleVerifyToken() {
    global $response, $currentUser;
    
    if (!$currentUser) {
        throw new Exception('Invalid token', 401);
    }
    
    $response['success'] = true;
    $response['message'] = 'Token is valid';
    $response['data'] = [
        'user_id' => $currentUser['id'],
        'valid' => true
    ];
}

function handleForgotPassword() {
    global $response, $user;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $email = $input['email'] ?? '';
    
    if (empty($email)) {
        throw new Exception('Email is required', 400);
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format', 400);
    }
    
    // Generate reset token
    $resetToken = $user->generatePasswordResetToken($email);
    
    if ($resetToken) {
        // Send reset email (implementation depends on your email service)
        $resetLink = BASE_URL . "reset-password?token=" . $resetToken;
        
        // Here you would send the email with the reset link
        // For now, we'll just return success
        
        $response['success'] = true;
        $response['message'] = 'Password reset email sent';
    } else {
        throw new Exception('Email not found', 404);
    }
}

function handleResetPassword() {
    global $response, $user;
    
    $input = json_decode(file_get_contents('php://input'), true);
    $token = $input['token'] ?? '';
    $newPassword = $input['password'] ?? '';
    
    if (empty($token) || empty($newPassword)) {
        throw new Exception('Token and new password are required', 400);
    }
    
    if (strlen($newPassword) < 6) {
        throw new Exception('Password must be at least 6 characters', 400);
    }
    
    if ($user->resetPassword($token, $newPassword)) {
        $response['success'] = true;
        $response['message'] = 'Password reset successful';
    } else {
        throw new Exception('Invalid or expired reset token', 400);
    }
}

function getUserIpAddress() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
}
?>