<?php
/**
 * Parfüm POS Sistemi - System API
 * Yaradıldığı tarix: 2025-07-21 11:00:24
 * Müəllif: Kodaz-az
 */

switch ($method) {
    case 'GET':
        if ($id) {
            if ($id === 'status') {
                handleGetSystemStatus();
            } else if ($id === 'info') {
                handleGetSystemInfo();
            } else if ($id === 'logs') {
                handleGetSystemLogs();
            } else if ($id === 'backup-status') {
                handleGetBackupStatus();
            } else {
                throw new Exception('Invalid system endpoint', 400);
            }
        } else {
            handleGetSystemOverview();
        }
        break;
        
    case 'POST':
        if ($action === 'backup') {
            handleCreateBackup();
        } else if ($action === 'restore') {
            handleRestoreBackup();
        } else if ($action === 'clear-cache') {
            handleClearCache();
        } else if ($action === 'optimize-database') {
            handleOptimizeDatabase();
        } else if ($action === 'test-email') {
            handleTestEmail();
        } else if ($action === 'reset-settings') {
            handleResetSettings();
        } else if ($action === 'clear-all-data') {
            handleClearAllData();
        } else if ($action === 'export-logs') {
            handleExportLogs();
        } else {
            throw new Exception('Invalid system action', 400);
        }
        break;
        
    default:
        throw new Exception('Method not allowed', 405);
}

function handleGetSystemStatus() {
    global $response;
    
    $status = [
        'online' => true,
        'timestamp' => date('Y-m-d H:i:s'),
        'server_time' => time(),
        'timezone' => date_default_timezone_get(),
        'php_version' => phpversion(),
        'memory_usage' => memory_get_usage(true),
        'memory_limit' => ini_get('memory_limit'),
        'disk_free_space' => disk_free_space('.'),
        'database_connection' => checkDatabaseConnection(),
        'cache_status' => checkCacheStatus(),
        'services' => [
            'web_server' => true,
            'database' => checkDatabaseConnection(),
            'file_system' => is_writable('uploads/'),
            'sessions' => session_status() !== PHP_SESSION_DISABLED
        ]
    ];
    
    $response['success'] = true;
    $response['data'] = $status;
}

function handleGetSystemInfo() {
    global $response, $user;
    
    if (!$user->hasPermission('view_system_info')) {
        throw new Exception('Permission denied', 403);
    }
    
    $info = [
        'application' => [
            'name' => PWA_NAME ?? 'Parfüm POS',
            'version' => APP_VERSION ?? '1.0.0',
            'environment' => defined('ENVIRONMENT') ? ENVIRONMENT : 'production'
        ],
        'server' => [
            'php_version' => phpversion(),
            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'server_name' => $_SERVER['SERVER_NAME'] ?? 'Unknown',
            'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? 'Unknown',
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size')
        ],
        'database' => getDatabaseInfo(),
        'storage' => getStorageInfo(),
        'extensions' => getRequiredExtensions()
    ];
    
    $response['success'] = true;
    $response['data'] = $info;
}

function handleGetSystemLogs() {
    global $response, $user;
    
    if (!$user->hasPermission('view_system_logs')) {
        throw new Exception('Permission denied', 403);
    }
    
    $logType = $_GET['type'] ?? 'error';
    $limit = intval($_GET['limit'] ?? 100);
    $offset = intval($_GET['offset'] ?? 0);
    
    $logs = getSystemLogs($logType, $limit, $offset);
    
    $response['success'] = true;
    $response['data'] = [
        'logs' => $logs,
        'type' => $logType,
        'limit' => $limit,
        'offset' => $offset
    ];
}

function handleGetBackupStatus() {
    global $response, $user;
    
    if (!$user->hasPermission('manage_backups')) {
        throw new Exception('Permission denied', 403);
    }
    
    $backupDir = ROOT_PATH . '/backups';
    $backups = [];
    
    if (is_dir($backupDir)) {
        $files = scandir($backupDir);
        foreach ($files as $file) {
            if (strpos($file, '.sql') !== false || strpos($file, '.zip') !== false) {
                $backups[] = [
                    'filename' => $file,
                    'size' => filesize($backupDir . '/' . $file),
                    'created_at' => date('Y-m-d H:i:s', filemtime($backupDir . '/' . $file))
                ];
            }
        }
    }
    
    usort($backups, function($a, $b) {
        return strtotime($b['created_at']) - strtotime($a['created_at']);
    });
    
    $response['success'] = true;
    $response['data'] = [
        'backups' => array_slice($backups, 0, 10),
        'total_backups' => count($backups),
        'backup_directory' => $backupDir
    ];
}

function handleGetSystemOverview() {
    global $response, $user;
    
    if (!$user->hasPermission('view_system_overview')) {
        throw new Exception('Permission denied', 403);
    }
    
    $overview = [
        'status' => 'healthy',
        'uptime' => getSystemUptime(),
        'users' => [
            'total' => getUserCount(),
            'online' => getOnlineUserCount(),
            'active_today' => getActiveTodayUserCount()
        ],
        'data' => [
            'total_sales' => getTotalSalesCount(),
            'total_products' => getTotalProductsCount(),
            'total_revenue' => getTotalRevenue(),
            'database_size' => getDatabaseSize()
        ],
        'performance' => [
            'memory_usage' => memory_get_usage(true),
            'memory_peak' => memory_get_peak_usage(true),
            'disk_usage' => getDiskUsage(),
            'response_time' => getAverageResponseTime()
        ]
    ];
    
    $response['success'] = true;
    $response['data'] = $overview;
}

function handleCreateBackup() {
    global $response, $user, $currentUser;
    
    if (!$user->hasPermission('manage_backups')) {
        throw new Exception('Permission denied', 403);
    }
    
    try {
        $backupFile = createDatabaseBackup();
        
        // Log activity
        $user->logActivity($currentUser['id'], 'create_backup', "Created database backup: {$backupFile}");
        
        $response['success'] = true;
        $response['message'] = 'Backup created successfully';
        $response['data'] = [
            'backup_file' => $backupFile,
            'backup_size' => filesize($backupFile),
            'created_at' => date('Y-m-d H:i:s')
        ];
        
    } catch (Exception $e) {
        throw new Exception('Failed to create backup: ' . $e->getMessage(), 500);
    }
}

function handleRestoreBackup() {
    global $response, $user, $currentUser;
    
    if (!$user->hasPermission('manage_backups')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $backupFile = $input['backup_file'] ?? '';
    
    if (empty($backupFile)) {
        throw new Exception('Backup file is required', 400);
    }
    
    try {
        $result = restoreDatabaseBackup($backupFile);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'restore_backup', "Restored database from backup: {$backupFile}");
        
        $response['success'] = true;
        $response['message'] = 'Database restored successfully';
        $response['data'] = $result;
        
    } catch (Exception $e) {
        throw new Exception('Failed to restore backup: ' . $e->getMessage(), 500);
    }
}

function handleClearCache() {
    global $response, $user, $currentUser;
    
    if (!$user->hasPermission('manage_system')) {
        throw new Exception('Permission denied', 403);
    }
    
    try {
        $cleared = clearSystemCache();
        
        // Log activity
        $user->logActivity($currentUser['id'], 'clear_cache', "Cleared system cache");
        
        $response['success'] = true;
        $response['message'] = 'Cache cleared successfully';
        $response['data'] = ['cleared_items' => $cleared];
        
    } catch (Exception $e) {
        throw new Exception('Failed to clear cache: ' . $e->getMessage(), 500);
    }
}

function handleOptimizeDatabase() {
    global $response, $user, $currentUser;
    
    if (!$user->hasPermission('manage_system')) {
        throw new Exception('Permission denied', 403);
    }
    
    try {
        $result = optimizeDatabase();
        
        // Log activity
        $user->logActivity($currentUser['id'], 'optimize_database', "Optimized database tables");
        
        $response['success'] = true;
        $response['message'] = 'Database optimized successfully';
        $response['data'] = $result;
        
    } catch (Exception $e) {
        throw new Exception('Failed to optimize database: ' . $e->getMessage(), 500);
    }
}

function handleTestEmail() {
    global $response, $user, $currentUser;
    
    if (!$user->hasPermission('manage_settings')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $emailSettings = [
        'smtp_host' => $input['smtp_host'] ?? '',
        'smtp_port' => intval($input['smtp_port'] ?? 587),
        'smtp_username' => $input['smtp_username'] ?? '',
        'smtp_password' => $input['smtp_password'] ?? '',
        'smtp_encryption' => $input['smtp_encryption'] ?? 'tls'
    ];
    
    try {
        $result = testEmailConfiguration($emailSettings);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'test_email', "Tested email configuration");
        
        $response['success'] = true;
        $response['message'] = 'Email configuration test successful';
        $response['data'] = $result;
        
    } catch (Exception $e) {
        throw new Exception('Email test failed: ' . $e->getMessage(), 400);
    }
}

function handleResetSettings() {
    global $response, $user, $currentUser;
    
    if (!$user->hasPermission('manage_settings')) {
        throw new Exception('Permission denied', 403);
    }
    
    try {
        $reset = resetSystemSettings();
        
        // Log activity
        $user->logActivity($currentUser['id'], 'reset_settings', "Reset system settings to defaults");
        
        $response['success'] = true;
        $response['message'] = 'System settings reset successfully';
        $response['data'] = ['reset_count' => $reset];
        
    } catch (Exception $e) {
        throw new Exception('Failed to reset settings: ' . $e->getMessage(), 500);
    }
}

function handleClearAllData() {
    global $response, $user, $currentUser;
    
    if (!$user->hasPermission('manage_system')) {
        throw new Exception('Permission denied', 403);
    }
    
    // This is a dangerous operation - require additional confirmation
    $input = json_decode(file_get_contents('php://input'), true);
    $confirmation = $input['confirmation'] ?? '';
    
    if ($confirmation !== 'CLEAR_ALL_DATA') {
        throw new Exception('Confirmation required', 400);
    }
    
    try {
        $result = clearAllSystemData();
        
        // Log activity (this might be the last log entry)
        $user->logActivity($currentUser['id'], 'clear_all_data', "Cleared all system data - SYSTEM RESET");
        
        $response['success'] = true;
        $response['message'] = 'All system data cleared successfully';
        $response['data'] = $result;
        
    } catch (Exception $e) {
        throw new Exception('Failed to clear all data: ' . $e->getMessage(), 500);
    }
}

function handleExportLogs() {
    global $user;
    
    if (!$user->hasPermission('view_system_logs')) {
        throw new Exception('Permission denied', 403);
    }
    
    $logType = $_GET['type'] ?? 'all';
    $format = $_GET['format'] ?? 'txt';
    
    try {
        exportSystemLogs($logType, $format);
        
    } catch (Exception $e) {
        throw new Exception('Failed to export logs: ' . $e->getMessage(), 500);
    }
}

// Helper functions

function checkDatabaseConnection() {
    try {
        $db = Database::getInstance();
        $result = $db->selectOne("SELECT 1 as test");
        return $result['test'] == 1;
    } catch (Exception $e) {
        return false;
    }
}

function checkCacheStatus() {
    return [
        'opcache_enabled' => function_exists('opcache_get_status') && opcache_get_status() !== false,
        'session_cache' => session_status() !== PHP_SESSION_DISABLED,
        'file_cache_writable' => is_writable('cache/')
    ];
}

function getDatabaseInfo() {
    try {
        $db = Database::getInstance();
        
        $version = $db->selectOne("SELECT VERSION() as version");
        $size = $db->selectOne("SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 1) AS 'size_mb' FROM information_schema.tables WHERE table_schema = DATABASE()");
        $tables = $db->selectAll("SELECT table_name, table_rows FROM information_schema.tables WHERE table_schema = DATABASE()");
        
        return [
            'version' => $version['version'] ?? 'Unknown',
            'size_mb' => $size['size_mb'] ?? 0,
            'table_count' => count($tables),
            'tables' => $tables
        ];
    } catch (Exception $e) {
        return [
            'error' => $e->getMessage()
        ];
    }
}

function getStorageInfo() {
    $uploadDir = ROOT_PATH . '/uploads';
    $backupDir = ROOT_PATH . '/backups';
    
    return [
        'disk_total' => disk_total_space('.'),
        'disk_free' => disk_free_space('.'),
        'upload_directory' => [
            'path' => $uploadDir,
            'writable' => is_writable($uploadDir),
            'size' => getDirSize($uploadDir)
        ],
        'backup_directory' => [
            'path' => $backupDir,
            'writable' => is_writable($backupDir),
            'size' => getDirSize($backupDir)
        ]
    ];
}

function getRequiredExtensions() {
    $required = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'fileinfo', 'openssl'];
    $extensions = [];
    
    foreach ($required as $ext) {
        $extensions[$ext] = extension_loaded($ext);
    }
    
    return $extensions;
}

function getSystemLogs($type, $limit, $offset) {
    // This would read from system log files
    // For now, return mock data
    return [
        [
            'timestamp' => date('Y-m-d H:i:s'),
            'level' => 'INFO',
            'message' => 'System status check completed',
            'context' => []
        ]
    ];
}

function createDatabaseBackup() {
    $backupDir = ROOT_PATH . '/backups';
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0755, true);
    }
    
    $filename = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
    $filepath = $backupDir . '/' . $filename;
    
    // Use mysqldump command or PHP implementation
    $command = sprintf(
        'mysqldump --host=%s --user=%s --password=%s %s > %s',
        DB_HOST,
        DB_USER,
        DB_PASS,
        DB_NAME,
        $filepath
    );
    
    exec($command, $output, $returnCode);
    
    if ($returnCode !== 0) {
        throw new Exception('Backup command failed');
    }
    
    return $filepath;
}

function restoreDatabaseBackup($backupFile) {
    $backupPath = ROOT_PATH . '/backups/' . basename($backupFile);
    
    if (!file_exists($backupPath)) {
        throw new Exception('Backup file not found');
    }
    
    $command = sprintf(
        'mysql --host=%s --user=%s --password=%s %s < %s',
        DB_HOST,
        DB_USER,
        DB_PASS,
        DB_NAME,
        $backupPath
    );
    
    exec($command, $output, $returnCode);
    
    if ($returnCode !== 0) {
        throw new Exception('Restore command failed');
    }
    
    return [
        'restored_from' => $backupFile,
        'restored_at' => date('Y-m-d H:i:s')
    ];
}

function clearSystemCache() {
    $cleared = 0;
    
    // Clear opcache if available
    if (function_exists('opcache_reset')) {
        opcache_reset();
        $cleared++;
    }
    
    // Clear custom cache directory
    $cacheDir = ROOT_PATH . '/cache';
    if (is_dir($cacheDir)) {
        $files = glob($cacheDir . '/*');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
                $cleared++;
            }
        }
    }
    
    return $cleared;
}

function optimizeDatabase() {
    try {
        $db = Database::getInstance();
        
        // Get all tables
        $tables = $db->selectAll("SHOW TABLES");
        $optimized = [];
        
        foreach ($tables as $table) {
            $tableName = array_values($table)[0];
            $result = $db->selectOne("OPTIMIZE TABLE `{$tableName}`");
            $optimized[] = [
                'table' => $tableName,
                'status' => $result['Msg_text'] ?? 'OK'
            ];
        }
        
        return [
            'optimized_tables' => count($optimized),
            'tables' => $optimized
        ];
        
    } catch (Exception $e) {
        throw new Exception('Database optimization failed: ' . $e->getMessage());
    }
}

function testEmailConfiguration($settings) {
    // Test email configuration
    // This would use your email library (PHPMailer, SwiftMailer, etc.)
    return [
        'smtp_connection' => true,
        'authentication' => true,
        'send_test' => true,
        'test_message' => 'Test email sent successfully'
    ];
}

function resetSystemSettings() {
    try {
        $db = Database::getInstance();
        
        // Reset system settings to defaults
        $db->delete("DELETE FROM system_settings WHERE setting_key NOT IN ('app_name', 'company_name')");
        
        return 1;
        
    } catch (Exception $e) {
        throw new Exception('Failed to reset settings: ' . $e->getMessage());
    }
}

function clearAllSystemData() {
    try {
        $db = Database::getInstance();
        
        // Clear all data except admin user and essential settings
        $tables = [
            'sales', 'sale_details', 'chat_messages', 'chat_rooms', 'chat_participants',
            'calls', 'call_participants', 'notifications', 'salary_months',
            'salary_requests', 'salary_adjustments', 'user_activity_log'
        ];
        
        $cleared = [];
        foreach ($tables as $table) {
            $count = $db->delete("DELETE FROM {$table}");
            $cleared[$table] = $count;
        }
        
        // Reset product stock to 0
        $db->update("UPDATE products SET stock_quantity = 0");
        
        return [
            'cleared_tables' => $cleared,
            'reset_at' => date('Y-m-d H:i:s')
        ];
        
    } catch (Exception $e) {
        throw new Exception('Failed to clear all data: ' . $e->getMessage());
    }
}

function exportSystemLogs($type, $format) {
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename="system_logs_' . date('Y-m-d') . '.txt"');
    
    echo "System Logs Export\n";
    echo "Generated: " . date('Y-m-d H:i:s') . "\n";
    echo "Type: " . $type . "\n";
    echo str_repeat("-", 50) . "\n\n";
    
    // Export logs
    $logs = getSystemLogs($type, 1000, 0);
    foreach ($logs as $log) {
        echo "[{$log['timestamp']}] {$log['level']}: {$log['message']}\n";
    }
    
    exit;
}

function getDirSize($dir) {
    if (!is_dir($dir)) {
        return 0;
    }
    
    $size = 0;
    $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
    
    foreach ($files as $file) {
        if ($file->isFile()) {
            $size += $file->getSize();
        }
    }
    
    return $size;
}

function getSystemUptime() {
    // System uptime - would need to be tracked in database or system
    return time() - filemtime(__FILE__);
}

function getUserCount() {
    try {
        $db = Database::getInstance();
        $result = $db->selectOne("SELECT COUNT(*) as count FROM users");
        return $result['count'] ?? 0;
    } catch (Exception $e) {
        return 0;
    }
}

function getOnlineUserCount() {
    try {
        $db = Database::getInstance();
        $result = $db->selectOne("SELECT COUNT(*) as count FROM users WHERE last_activity > DATE_SUB(NOW(), INTERVAL 15 MINUTE)");
        return $result['count'] ?? 0;
    } catch (Exception $e) {
        return 0;
    }
}

function getActiveTodayUserCount() {
    try {
        $db = Database::getInstance();
        $result = $db->selectOne("SELECT COUNT(*) as count FROM users WHERE DATE(last_activity) = CURDATE()");
        return $result['count'] ?? 0;
    } catch (Exception $e) {
        return 0;
    }
}

function getTotalSalesCount() {
    try {
        $db = Database::getInstance();
        $result = $db->selectOne("SELECT COUNT(*) as count FROM sales WHERE status = 'completed'");
        return $result['count'] ?? 0;
    } catch (Exception $e) {
        return 0;
    }
}

function getTotalProductsCount() {
    try {
        $db = Database::getInstance();
        $result = $db->selectOne("SELECT COUNT(*) as count FROM products");
        return $result['count'] ?? 0;
    } catch (Exception $e) {
        return 0;
    }
}

function getTotalRevenue() {
    try {
        $db = Database::getInstance();
        $result = $db->selectOne("SELECT SUM(final_amount) as total FROM sales WHERE status = 'completed'");
        return floatval($result['total'] ?? 0);
    } catch (Exception $e) {
        return 0;
    }
}

function getDatabaseSize() {
    try {
        $db = Database::getInstance();
        $result = $db->selectOne("SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 1) AS 'size_mb' FROM information_schema.tables WHERE table_schema = DATABASE()");
        return floatval($result['size_mb'] ?? 0);
    } catch (Exception $e) {
        return 0;
    }
}

function getDiskUsage() {
    $total = disk_total_space('.');
    $free = disk_free_space('.');
    $used = $total - $free;
    
    return [
        'total' => $total,
        'used' => $used,
        'free' => $free,
        'percentage' => round(($used / $total) * 100, 2)
    ];
}

function getAverageResponseTime() {
    // This would be tracked over time
    return 0.15; // seconds
}
?>