<?php
/**
 * Parfüm POS Sistemi - Salary API
 * Yaradıldığı tarix: 2025-07-21 11:00:24
 * Müəllif: Kodaz-az
 */

require_once '../classes/Salary.php';

$salary = new Salary();

switch ($method) {
    case 'GET':
        if ($id) {
            if ($id === 'info') {
                handleGetSalaryInfo();
            } else if ($id === 'history') {
                handleGetSalaryHistory();
            } else if ($id === 'requests') {
                handleGetRequests();
            } else if ($id === 'reports') {
                handleGetSalaryReports();
            } else if ($id === 'calculate') {
                handleCalculateSalary();
            } else {
                handleGetMonthlySalary($id);
            }
        } else {
            handleGetAllSalaries();
        }
        break;
        
    case 'POST':
        if ($action === 'request-advance') {
            handleRequestAdvance();
        } else if ($action === 'approve') {
            handleApproveRequest($id);
        } else if ($action === 'reject') {
            handleRejectRequest($id);
        } else if ($action === 'calculate') {
            handleCalculateMonthlySalary();
        } else if ($action === 'adjustment') {
            handleAddAdjustment();
        } else if ($action === 'mark-paid') {
            handleMarkAsPaid($id);
        } else {
            throw new Exception('Invalid salary action', 400);
        }
        break;
        
    case 'PUT':
        if ($id) {
            handleUpdateSalary($id);
        } else {
            throw new Exception('Salary ID required', 400);
        }
        break;
        
    default:
        throw new Exception('Method not allowed', 405);
}

function handleGetSalaryInfo() {
    global $response, $salary, $currentUser;
    
    $userId = $_GET['user_id'] ?? $currentUser['id'];
    
    // Users can only view their own salary info unless they have admin permissions
    if ($userId != $currentUser['id'] && !$user->hasPermission('view_salary')) {
        $userId = $currentUser['id'];
    }
    
    $salaryInfo = $salary->getUserSalaryInfo($userId);
    
    $response['success'] = true;
    $response['data'] = $salaryInfo;
}

function handleGetSalaryHistory() {
    global $response, $salary, $user, $currentUser;
    
    $userId = $_GET['user_id'] ?? $currentUser['id'];
    $limit = intval($_GET['limit'] ?? 12);
    
    // Users can only view their own salary history unless they have admin permissions
    if ($userId != $currentUser['id'] && !$user->hasPermission('view_salary')) {
        $userId = $currentUser['id'];
    }
    
    $history = $salary->getSalaryHistory($userId, $limit);
    
    $response['success'] = true;
    $response['data'] = ['history' => $history];
}

function handleGetRequests() {
    global $response, $salary, $user, $currentUser;
    
    if ($user->hasPermission('manage_salary')) {
        // Admin can see all requests
        $requests = $salary->getAllRequests();
    } else {
        // Users can only see their own requests
        $requests = $salary->getPendingRequests($currentUser['id']);
    }
    
    $response['success'] = true;
    $response['data'] = ['requests' => $requests];
}

function handleGetSalaryReports() {
    global $response, $salary, $user;
    
    if (!$user->hasPermission('view_salary')) {
        throw new Exception('Permission denied', 403);
    }
    
    $month = intval($_GET['month'] ?? date('n'));
    $year = intval($_GET['year'] ?? date('Y'));
    
    $reports = $salary->getAllSalaryReports($month, $year);
    
    $response['success'] = true;
    $response['data'] = [
        'reports' => $reports,
        'month' => $month,
        'year' => $year
    ];
}

function handleGetMonthlySalary($salaryId) {
    global $response, $salary, $user, $currentUser;
    
    $userId = $_GET['user_id'] ?? $currentUser['id'];
    $month = intval($_GET['month'] ?? date('n'));
    $year = intval($_GET['year'] ?? date('Y'));
    
    // Users can only view their own salary unless they have admin permissions
    if ($userId != $currentUser['id'] && !$user->hasPermission('view_salary')) {
        $userId = $currentUser['id'];
    }
    
    $monthlySalary = $salary->getMonthlySalary($userId, $month, $year);
    
    $response['success'] = true;
    $response['data'] = ['salary' => $monthlySalary];
}

function handleGetAllSalaries() {
    global $response, $salary, $user;
    
    if (!$user->hasPermission('view_salary')) {
        throw new Exception('Permission denied', 403);
    }
    
    $month = intval($_GET['month'] ?? date('n'));
    $year = intval($_GET['year'] ?? date('Y'));
    
    $salaries = $salary->getAllSalaryReports($month, $year);
    
    $response['success'] = true;
    $response['data'] = [
        'salaries' => $salaries,
        'month' => $month,
        'year' => $year
    ];
}

function handleRequestAdvance() {
    global $response, $salary, $user, $currentUser;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $amount = floatval($input['amount'] ?? 0);
    $reason = $input['reason'] ?? '';
    
    if ($amount <= 0) {
        throw new Exception('Invalid advance amount', 400);
    }
    
    if (empty($reason)) {
        throw new Exception('Advance reason is required', 400);
    }
    
    try {
        $requestId = $salary->requestAdvance($currentUser['id'], $amount, $reason);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'request_advance', "Requested advance: {$amount} AZN");
        
        $response['success'] = true;
        $response['message'] = 'Advance request submitted successfully';
        $response['data'] = ['request_id' => $requestId];
        
    } catch (Exception $e) {
        throw new Exception('Failed to submit advance request: ' . $e->getMessage(), 400);
    }
}

function handleApproveRequest($requestId) {
    global $response, $salary, $user, $currentUser;
    
    if (!$user->hasPermission('manage_salary')) {
        throw new Exception('Permission denied', 403);
    }
    
    if (empty($requestId)) {
        throw new Exception('Request ID is required', 400);
    }
    
    if ($salary->approveRequest($requestId)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'approve_salary_request', "Approved salary request: {$requestId}");
        
        $response['success'] = true;
        $response['message'] = 'Request approved successfully';
    } else {
        throw new Exception('Failed to approve request', 500);
    }
}

function handleRejectRequest($requestId) {
    global $response, $salary, $user, $currentUser;
    
    if (!$user->hasPermission('manage_salary')) {
        throw new Exception('Permission denied', 403);
    }
    
    if (empty($requestId)) {
        throw new Exception('Request ID is required', 400);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $rejectionReason = $input['reason'] ?? '';
    
    if ($salary->rejectRequest($requestId, $rejectionReason)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'reject_salary_request', "Rejected salary request: {$requestId}");
        
        $response['success'] = true;
        $response['message'] = 'Request rejected successfully';
    } else {
        throw new Exception('Failed to reject request', 500);
    }
}

function handleCalculateMonthlySalary() {
    global $response, $salary, $user, $currentUser;
    
    if (!$user->hasPermission('manage_salary')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $userId = intval($input['user_id'] ?? 0);
    $month = intval($input['month'] ?? date('n'));
    $year = intval($input['year'] ?? date('Y'));
    
    if (empty($userId)) {
        throw new Exception('User ID is required', 400);
    }
    
    try {
        $salaryId = $salary->calculateMonthlySalary($userId, $month, $year);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'calculate_salary', "Calculated salary for user {$userId} - {$month}/{$year}");
        
        $response['success'] = true;
        $response['message'] = 'Salary calculated successfully';
        $response['data'] = ['salary_id' => $salaryId];
        
    } catch (Exception $e) {
        throw new Exception('Failed to calculate salary: ' . $e->getMessage(), 500);
    }
}

function handleCalculateSalary() {
    global $response, $salary, $user, $currentUser;
    
    if (!$user->hasPermission('manage_salary')) {
        throw new Exception('Permission denied', 403);
    }
    
    $userId = intval($_GET['user_id'] ?? 0);
    $month = intval($_GET['month'] ?? date('n'));
    $year = intval($_GET['year'] ?? date('Y'));
    
    if (empty($userId)) {
        throw new Exception('User ID is required', 400);
    }
    
    try {
        // Calculate but don't save - just return the calculation
        $userInfo = $user->getUserById($userId);
        if (!$userInfo) {
            throw new Exception('User not found', 404);
        }
        
        // Get salary components
        $baseSalary = floatval($userInfo['base_salary']);
        
        // Calculate commission
        $sql = "SELECT SUM(final_amount) as total_sales
                FROM sales
                WHERE user_id = ? AND MONTH(created_at) = ? AND YEAR(created_at) = ?
                AND status = 'completed'";
        
        $salesResult = $salary->db->selectOne($sql, [$userId, $month, $year]);
        $totalSales = floatval($salesResult['total_sales'] ?? 0);
        $commissionRate = floatval($userInfo['commission_rate'] ?? 0);
        $commissionAmount = $totalSales * ($commissionRate / 100);
        
        // Get adjustments
        $sql = "SELECT adjustment_type, SUM(amount) as total_amount
                FROM salary_adjustments
                WHERE user_id = ? AND MONTH(created_at) = ? AND YEAR(created_at) = ?
                GROUP BY adjustment_type";
        
        $adjustments = $salary->db->selectAll($sql, [$userId, $month, $year]);
        $bonusAmount = 0;
        $penaltyAmount = 0;
        
        foreach ($adjustments as $adj) {
            if ($adj['adjustment_type'] === 'bonus') {
                $bonusAmount += $adj['total_amount'];
            } elseif ($adj['adjustment_type'] === 'penalty') {
                $penaltyAmount += $adj['total_amount'];
            }
        }
        
        // Get advance
        $sql = "SELECT SUM(amount) as total_advance
                FROM salary_requests
                WHERE user_id = ? AND request_type = 'advance' AND status = 'approved'
                AND MONTH(created_at) = ? AND YEAR(created_at) = ?";
        
        $advanceResult = $salary->db->selectOne($sql, [$userId, $month, $year]);
        $advanceAmount = floatval($advanceResult['total_advance'] ?? 0);
        
        $totalSalary = $baseSalary + $commissionAmount + $bonusAmount - $penaltyAmount - $advanceAmount;
        
        $calculation = [
            'user_id' => $userId,
            'user_name' => $userInfo['full_name'],
            'month' => $month,
            'year' => $year,
            'base_salary' => $baseSalary,
            'total_sales' => $totalSales,
            'commission_rate' => $commissionRate,
            'commission_amount' => $commissionAmount,
            'bonus_amount' => $bonusAmount,
            'penalty_amount' => $penaltyAmount,
            'advance_amount' => $advanceAmount,
            'total_salary' => $totalSalary
        ];
        
        $response['success'] = true;
        $response['data'] = ['calculation' => $calculation];
        
    } catch (Exception $e) {
        throw new Exception('Failed to calculate salary: ' . $e->getMessage(), 500);
    }
}

function handleAddAdjustment() {
    global $response, $salary, $user, $currentUser;
    
    if (!$user->hasPermission('manage_salary')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $userId = intval($input['user_id'] ?? 0);
    $type = $input['type'] ?? '';
    $amount = floatval($input['amount'] ?? 0);
    $reason = $input['reason'] ?? '';
    
    if (empty($userId) || empty($type) || $amount <= 0 || empty($reason)) {
        throw new Exception('All fields are required', 400);
    }
    
    $allowedTypes = ['bonus', 'penalty', 'deduction'];
    if (!in_array($type, $allowedTypes)) {
        throw new Exception('Invalid adjustment type', 400);
    }
    
    try {
        $adjustmentId = $salary->addSalaryAdjustment($userId, $type, $amount, $reason, $currentUser['id']);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'add_salary_adjustment', "Added {$type} adjustment: {$amount} AZN for user {$userId}");
        
        $response['success'] = true;
        $response['message'] = 'Salary adjustment added successfully';
        $response['data'] = ['adjustment_id' => $adjustmentId];
        
    } catch (Exception $e) {
        throw new Exception('Failed to add salary adjustment: ' . $e->getMessage(), 500);
    }
}

function handleMarkAsPaid($salaryMonthId) {
    global $response, $salary, $user, $currentUser;
    
    if (!$user->hasPermission('manage_salary')) {
        throw new Exception('Permission denied', 403);
    }
    
    if (empty($salaryMonthId)) {
        throw new Exception('Salary month ID is required', 400);
    }
    
    if ($salary->markAsPaid($salaryMonthId)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'mark_salary_paid', "Marked salary as paid: {$salaryMonthId}");
        
        $response['success'] = true;
        $response['message'] = 'Salary marked as paid successfully';
    } else {
        throw new Exception('Failed to mark salary as paid', 500);
    }
}

function handleUpdateSalary($salaryId) {
    global $response, $salary, $user, $currentUser;
    
    if (!$user->hasPermission('manage_salary')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // This function would allow manual adjustments to calculated salaries
    // Implementation depends on specific business requirements
    
    $response['success'] = true;
    $response['message'] = 'Salary updated successfully';
}
?>