<?php
/**
 * Parfüm POS Sistemi - API Router
 * Yaradıldığı tarix: 2025-07-21
 */

require_once __DIR__ . '/../config/config.php';

// CORS headers
if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');
}

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
        header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
    }
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    }
    exit(0);
}

// Set JSON content type
header('Content-Type: application/json; charset=utf-8');

// Parse the request URI
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);
$path = str_replace('/parfum/api', '', $path);
$path = trim($path, '/');

// Split path into segments
$segments = explode('/', $path);
$endpoint = $segments[0] ?? '';
$action = $segments[1] ?? '';
$id = $segments[2] ?? '';

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

// Get request data
$input = json_decode(file_get_contents('php://input'), true) ?? [];

// Merge with POST data
if (!empty($_POST)) {
    $input = array_merge($input, $_POST);
}

// CSRF validation for state-changing operations
if (in_array($method, ['POST', 'PUT', 'DELETE'])) {
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? $input['csrf_token'] ?? '';
    if (!validateCSRF($token)) {
        jsonResponse(['success' => false, 'message' => 'CSRF token mismatch'], 403);
    }
}

// Initialize classes
$user = new User();
$db = Database::getInstance();

// Check authentication for protected endpoints
$protectedEndpoints = [
    'chat', 'calls', 'sales', 'products', 'reports', 
    'salary', 'users', 'dashboard', 'profile'
];

if (in_array($endpoint, $protectedEndpoints) && !$user->isLoggedIn()) {
    jsonResponse(['success' => false, 'message' => 'Authentication required'], 401);
}

// Route the request
try {
    switch ($endpoint) {
        case 'auth':
            handleAuthEndpoint($action, $method, $input);
            break;
            
        case 'chat':
            handleChatEndpoint($action, $method, $input);
            break;
            
        case 'calls':
            handleCallsEndpoint($action, $method, $input);
            break;
            
        case 'sales':
            handleSalesEndpoint($action, $method, $input);
            break;
            
        case 'products':
            handleProductsEndpoint($action, $method, $input);
            break;
            
        case 'salary':
            handleSalaryEndpoint($action, $method, $input);
            break;
            
        case 'users':
            handleUsersEndpoint($action, $method, $input);
            break;
            
        case 'dashboard':
            handleDashboardEndpoint($action, $method, $input);
            break;
            
        case 'profile':
            handleProfileEndpoint($action, $method, $input);
            break;
            
        case 'reports':
            handleReportsEndpoint($action, $method, $input);
            break;
            
        case 'upload':
            handleUploadEndpoint($action, $method, $input);
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => 'Endpoint not found'], 404);
    }
} catch (Exception $e) {
    if (DEBUG_MODE) {
        jsonResponse([
            'success' => false, 
            'message' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ], 500);
    } else {
        jsonResponse(['success' => false, 'message' => 'Internal server error'], 500);
    }
}

// Auth endpoints
function handleAuthEndpoint($action, $method, $input) {
    global $user;
    
    switch ($action) {
        case 'login':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            try {
                $loggedUser = $user->login(
                    $input['username'], 
                    $input['password'], 
                    $input['remember'] ?? false
                );
                
                jsonResponse([
                    'success' => true,
                    'message' => 'Uğurla daxil oldunuz',
                    'user' => [
                        'id' => $loggedUser['id'],
                        'username' => $loggedUser['username'],
                        'full_name' => $loggedUser['full_name'],
                        'role' => $loggedUser['role'],
                        'avatar' => $loggedUser['avatar']
                    ]
                ]);
            } catch (Exception $e) {
                jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
            }
            break;
            
        case 'logout':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            $user->logout();
            jsonResponse(['success' => true, 'message' => 'Uğurla çıxış etdiniz']);
            break;
            
        case 'register':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            try {
                $userId = $user->register($input);
                jsonResponse([
                    'success' => true,
                    'message' => 'Hesab uğurla yaradıldı',
                    'user_id' => $userId
                ]);
            } catch (Exception $e) {
                jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
            }
            break;
            
        case 'forgot-password':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            // Simulate forgot password (implement actual email sending)
            jsonResponse([
                'success' => true,
                'message' => 'Şifrə bərpası linki email ünvanınıza göndərildi'
            ]);
            break;
            
        case 'me':
            if ($method !== 'GET') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            $currentUser = $user->getCurrentUser();
            if ($currentUser) {
                jsonResponse([
                    'success' => true,
                    'user' => [
                        'id' => $currentUser['id'],
                        'username' => $currentUser['username'],
                        'email' => $currentUser['email'],
                        'full_name' => $currentUser['full_name'],
                        'role' => $currentUser['role'],
                        'avatar' => $currentUser['avatar'],
                        'phone' => $currentUser['phone']
                    ]
                ]);
            } else {
                jsonResponse(['success' => false, 'message' => 'Not authenticated'], 401);
            }
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => 'Action not found'], 404);
    }
}

// Chat endpoints
function handleChatEndpoint($action, $method, $input) {
    $chat = new Chat();
    
    switch ($action) {
        case 'rooms':
            if ($method !== 'GET') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            $rooms = $chat->getRooms();
            jsonResponse(['success' => true, 'rooms' => $rooms]);
            break;
            
        case 'messages':
            if ($method !== 'GET') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            $roomId = $_GET['room_id'] ?? null;
            $before = $_GET['before'] ?? null;
            $limit = min(50, $_GET['limit'] ?? 20);
            
            if (!$roomId) {
                jsonResponse(['success' => false, 'message' => 'Room ID required'], 400);
            }
            
            $messages = $chat->getMessages($roomId, 1, $limit);
            jsonResponse(['success' => true, 'messages' => $messages]);
            break;
            
        case 'send-message':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            try {
                $messageId = $chat->sendMessage(
                    $input['room_id'],
                    $input['content'],
                    $input['type'] ?? 'text',
                    $input['metadata'] ?? []
                );
                
                jsonResponse([
                    'success' => true,
                    'message' => 'Mesaj göndərildi',
                    'message_id' => $messageId
                ]);
            } catch (Exception $e) {
                jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
            }
            break;
            
        case 'upload-file':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            if (!isset($_FILES['file'])) {
                jsonResponse(['success' => false, 'message' => 'File required'], 400);
            }
            
            try {
                $messageId = $chat->uploadFile(
                    $input['room_id'],
                    $_FILES['file'],
                    $input['type'] ?? 'document'
                );
                
                jsonResponse([
                    'success' => true,
                    'message' => 'Fayl yükləndi',
                    'message_id' => $messageId
                ]);
            } catch (Exception $e) {
                jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
            }
            break;
            
        case 'get-or-create-private-room':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            try {
                $user = new User();
                $currentUser = $user->getCurrentUser();
                
                $roomId = $chat->getOrCreatePrivateRoom(
                    $currentUser['id'],
                    $input['user_id']
                );
                
                jsonResponse([
                    'success' => true,
                    'room_id' => $roomId
                ]);
            } catch (Exception $e) {
                jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
            }
            break;
            
        case 'mark-room-as-read':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            try {
                $user = new User();
                $currentUser = $user->getCurrentUser();
                
                $chat->markRoomAsRead($input['room_id'], $currentUser['id']);
                
                jsonResponse(['success' => true, 'message' => 'Oxunmuş kimi qeyd edildi']);
            } catch (Exception $e) {
                jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
            }
            break;
            
        case 'unread-count':
            if ($method !== 'GET') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            $count = $chat->getUnreadCount();
            jsonResponse(['success' => true, 'count' => $count]);
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => 'Action not found'], 404);
    }
}

// Calls endpoints
function handleCallsEndpoint($action, $method, $input) {
    $call = new Call();
    
    switch ($action) {
        case 'initiate':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            try {
                $callId = $call->initiateCall(
                    $input['room_id'],
                    $input['call_type'] ?? 'audio'
                );
                
                jsonResponse([
                    'success' => true,
                    'message' => 'Zəng başladıldı',
                    'call_id' => $callId
                ]);
            } catch (Exception $e) {
                jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
            }
            break;
            
        case 'answer':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            try {
                $call->answerCall($input['call_id']);
                jsonResponse(['success' => true, 'message' => 'Zəng cavablandırıldı']);
            } catch (Exception $e) {
                jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
            }
            break;
            
        case 'end':
            if ($method !== 'POST') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            try {
                $call->endCall($input['call_id']);
                jsonResponse(['success' => true, 'message' => 'Zəng bitirildi']);
            } catch (Exception $e) {
                jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
            }
            break;
            
        case 'history':
            if ($method !== 'GET') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            $roomId = $_GET['room_id'] ?? null;
            $limit = min(100, $_GET['limit'] ?? 20);
            
            $history = $call->getCallHistory($roomId, $limit);
            jsonResponse(['success' => true, 'calls' => $history]);
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => 'Action not found'], 404);
    }
}

// Dashboard endpoints
function handleDashboardEndpoint($action, $method, $input) {
    global $db, $user;
    
    switch ($action) {
        case 'stats':
            if ($method !== 'GET') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            $currentUser = $user->getCurrentUser();
            $userCondition = $currentUser['role'] === 'seller' ? 'AND user_id = ' . $currentUser['id'] : '';
            
            // Today's stats
            $todayStats = $db->selectOne(
                "SELECT 
                    COUNT(*) as sales_count,
                    COALESCE(SUM(final_amount), 0) as total_revenue
                 FROM sales 
                 WHERE DATE(created_at) = CURDATE() {$userCondition}"
            );
            
            // This week's stats
            $weekStats = $db->selectOne(
                "SELECT 
                    COUNT(*) as sales_count,
                    COALESCE(SUM(final_amount), 0) as total_revenue
                 FROM sales 
                 WHERE WEEK(created_at) = WEEK(NOW()) 
                 AND YEAR(created_at) = YEAR(NOW()) {$userCondition}"
            );
            
            // This month's stats
            $monthStats = $db->selectOne(
                "SELECT 
                    COUNT(*) as sales_count,
                    COALESCE(SUM(final_amount), 0) as total_revenue
                 FROM sales 
                 WHERE MONTH(created_at) = MONTH(NOW()) 
                 AND YEAR(created_at) = YEAR(NOW()) {$userCondition}"
            );
            
            jsonResponse([
                'success' => true,
                'stats' => [
                    'today' => $todayStats,
                    'week' => $weekStats,
                    'month' => $monthStats
                ]
            ]);
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => 'Action not found'], 404);
    }
}

// Users endpoints
function handleUsersEndpoint($action, $method, $input) {
    global $user;
    
    switch ($action) {
        case 'online':
            if ($method !== 'GET') {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            
            $onlineUsers = $user->getOnlineUsers();
            jsonResponse(['success' => true, 'users' => $onlineUsers]);
            break;
            
        case 'profile':
            if ($method === 'GET') {
                $userId = $_GET['user_id'] ?? null;
                $currentUser = $user->getCurrentUser();
                
                if (!$userId) {
                    $userId = $currentUser['id'];
                }
                
                $profile = $user->getUserById($userId);
                if ($profile) {
                    jsonResponse(['success' => true, 'profile' => $profile]);
                } else {
                    jsonResponse(['success' => false, 'message' => 'İstifadəçi tapılmadı'], 404);
                }
            } elseif ($method === 'PUT') {
                try {
                    $currentUser = $user->getCurrentUser();
                    $user->updateProfile($currentUser['id'], $input);
                    jsonResponse(['success' => true, 'message' => 'Profil yeniləndi']);
                } catch (Exception $e) {
                    jsonResponse(['success' => false, 'message' => $e->getMessage()], 400);
                }
            } else {
                jsonResponse(['success' => false, 'message' => 'Method not allowed'], 405);
            }
            break;
            
        default:
            jsonResponse(['success' => false, 'message' => 'Action not found'], 404);
    }
}

// Generic error handler
function handleApiError($message, $code = 400) {
    jsonResponse(['success' => false, 'message' => $message], $code);
}

?>