<?php
/**
 * Parfüm POS Sistemi - Users API
 * Yaradıldığı tarix: 2025-07-21
 * Müəllif: Kodaz-az
 */

switch ($method) {
    case 'GET':
        if ($id) {
            if ($id === 'online') {
                handleGetOnlineUsers();
            } else {
                handleGetUser($id);
            }
        } else {
            handleGetUsers();
        }
        break;
        
    case 'POST':
        if ($id === 'activity') {
            handleUpdateActivity();
        } else {
            handleCreateUser();
        }
        break;
        
    case 'PUT':
        if ($id) {
            handleUpdateUser($id);
        } else {
            throw new Exception('User ID required', 400);
        }
        break;
        
    case 'DELETE':
        if ($id) {
            handleDeleteUser($id);
        } else {
            throw new Exception('User ID required', 400);
        }
        break;
        
    default:
        throw new Exception('Method not allowed', 405);
}

function handleGetUsers() {
    global $response, $user, $currentUser;
    
    // Check permission
    if (!$user->hasPermission('view_users')) {
        throw new Exception('Permission denied', 403);
    }
    
    $filters = [
        'search' => $_GET['search'] ?? '',
        'role' => $_GET['role'] ?? '',
        'status' => $_GET['status'] ?? '',
        'order_by' => $_GET['order_by'] ?? 'created_at',
        'order_dir' => $_GET['order_dir'] ?? 'DESC',
        'limit' => intval($_GET['limit'] ?? 50),
        'offset' => intval($_GET['offset'] ?? 0)
    ];
    
    $users = $user->getAllUsers($filters);
    $total = $user->getUsersCount($filters);
    
    $response['success'] = true;
    $response['data'] = [
        'users' => $users,
        'total' => $total,
        'filters' => $filters
    ];
}

function handleGetUser($userId) {
    global $response, $user, $currentUser;
    
    // Users can view their own profile, others need permission
    if ($userId != $currentUser['id'] && !$user->hasPermission('view_users')) {
        throw new Exception('Permission denied', 403);
    }
    
    $userData = $user->getUserById($userId);
    
    if (!$userData) {
        throw new Exception('User not found', 404);
    }
    
    // Remove sensitive data for other users
    if ($userId != $currentUser['id']) {
        unset($userData['password']);
        unset($userData['api_token']);
    }
    
    $response['success'] = true;
    $response['data'] = ['user' => $userData];
}

function handleGetOnlineUsers() {
    global $response, $user;
    
    $onlineUsers = $user->getOnlineUsers();
    
    $response['success'] = true;
    $response['data'] = ['users' => $onlineUsers];
}

function handleCreateUser() {
    global $response, $user, $currentUser;
    
    // Check permission
    if (!$user->hasPermission('manage_users')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $userData = [
        'username' => $input['username'] ?? '',
        'email' => $input['email'] ?? '',
        'password' => $input['password'] ?? '',
        'full_name' => $input['full_name'] ?? '',
        'phone' => $input['phone'] ?? '',
        'role' => $input['role'] ?? 'seller',
        'base_salary' => floatval($input['base_salary'] ?? 0),
        'commission_rate' => floatval($input['commission_rate'] ?? 0),
        'is_active' => isset($input['is_active']) ? 1 : 0
    ];
    
    // Validate required fields
    $required = ['username', 'email', 'password', 'full_name'];
    foreach ($required as $field) {
        if (empty($userData[$field])) {
            throw new Exception("Field {$field} is required", 400);
        }
    }
    
    // Validate email
    if (!filter_var($userData['email'], FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format', 400);
    }
    
    // Validate password
    if (strlen($userData['password']) < 6) {
        throw new Exception('Password must be at least 6 characters', 400);
    }
    
    // Check if username/email already exists
    if ($user->userExists($userData['username'], $userData['email'])) {
        throw new Exception('Username or email already exists', 409);
    }
    
    $userId = $user->register($userData);
    
    if ($userId) {
        // Log activity
        $user->logActivity($currentUser['id'], 'create_user', "Created user: {$userData['username']}");
        
        $response['success'] = true;
        $response['message'] = 'User created successfully';
        $response['data'] = ['user_id' => $userId];
    } else {
        throw new Exception('Failed to create user', 500);
    }
}

function handleUpdateUser($userId) {
    global $response, $user, $currentUser;
    
    // Users can update their own profile, others need permission
    if ($userId != $currentUser['id'] && !$user->hasPermission('manage_users')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $updateData = [];
    
    // Fields that can be updated
    $allowedFields = ['full_name', 'email', 'phone', 'address', 'birth_date', 'bio'];
    
    // Admin-only fields
    if ($user->hasPermission('manage_users')) {
        $allowedFields = array_merge($allowedFields, [
            'role', 'base_salary', 'commission_rate', 'is_active'
        ]);
    }
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updateData[$field] = $input[$field];
        }
    }
    
    // Handle password change
    if (!empty($input['password'])) {
        if (strlen($input['password']) < 6) {
            throw new Exception('Password must be at least 6 characters', 400);
        }
        $updateData['password'] = $input['password'];
    }
    
    // Validate email if provided
    if (isset($updateData['email']) && !filter_var($updateData['email'], FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format', 400);
    }
    
    if (empty($updateData)) {
        throw new Exception('No valid fields to update', 400);
    }
    
    if ($user->updateUser($userId, $updateData)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'update_user', "Updated user ID: {$userId}");
        
        $response['success'] = true;
        $response['message'] = 'User updated successfully';
    } else {
        throw new Exception('Failed to update user', 500);
    }
}

function handleDeleteUser($userId) {
    global $response, $user, $currentUser;
    
    // Check permission
    if (!$user->hasPermission('manage_users')) {
        throw new Exception('Permission denied', 403);
    }
    
    // Prevent self-deletion
    if ($userId == $currentUser['id']) {
        throw new Exception('Cannot delete your own account', 400);
    }
    
    $userData = $user->getUserById($userId);
    if (!$userData) {
        throw new Exception('User not found', 404);
    }
    
    if ($user->deleteUser($userId)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'delete_user', "Deleted user: {$userData['username']}");
        
        $response['success'] = true;
        $response['message'] = 'User deleted successfully';
    } else {
        throw new Exception('Failed to delete user', 500);
    }
}

function handleUpdateActivity() {
    global $response, $user, $currentUser;
    
    if (!$currentUser) {
        throw new Exception('Authentication required', 401);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $timestamp = $input['timestamp'] ?? time() * 1000; // JavaScript timestamp
    
    $user->updateLastActivity($currentUser['id'], date('Y-m-d H:i:s', $timestamp / 1000));
    
    $response['success'] = true;
    $response['message'] = 'Activity updated';
}
?>