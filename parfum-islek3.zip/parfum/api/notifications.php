<?php
/**
 * Notifications API
 * Kodaz-az - 2025-07-21 14:10:38 (UTC)
 * Login: Kodaz-az
 */

header('Content-Type: application/json');
require_once '../config/config.php';
require_once '../includes/database.php';

session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$currentUserId = $_SESSION['user_id'];

try {
    $db = Database::getInstance();
    
    // Get notifications for current user
    $notifications = $db->selectAll("
        SELECT 
            id,
            title,
            message,
            type,
            is_read,
            created_at,
            CASE 
                WHEN created_at >= NOW() - INTERVAL 1 MINUTE THEN 'İndi'
                WHEN created_at >= NOW() - INTERVAL 1 HOUR THEN CONCAT(TIMESTAMPDIFF(MINUTE, created_at, NOW()), ' dəq əvvəl')
                WHEN created_at >= NOW() - INTERVAL 1 DAY THEN CONCAT(TIMESTAMPDIFF(HOUR, created_at, NOW()), ' saat əvvəl')
                ELSE DATE_FORMAT(created_at, '%d.%m.%Y')
            END as time_ago
        FROM notifications 
        WHERE user_id = ? OR user_id IS NULL
        ORDER BY created_at DESC 
        LIMIT 20
    ", [$currentUserId]);
    
    // Add icons for different notification types
    foreach ($notifications as &$notification) {
        switch ($notification['type']) {
            case 'sale':
                $notification['icon'] = 'shopping-cart';
                break;
            case 'stock':
                $notification['icon'] = 'exclamation-triangle';
                break;
            case 'user':
                $notification['icon'] = 'user-plus';
                break;
            case 'system':
                $notification['icon'] = 'cog';
                break;
            default:
                $notification['icon'] = 'bell';
        }
    }
    
    // Get unread count
    $unreadCount = $db->selectOne("
        SELECT COUNT(*) as count 
        FROM notifications 
        WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0
    ", [$currentUserId])['count'];
    
    echo json_encode([
        'success' => true,
        'notifications' => $notifications,
        'unread_count' => (int)$unreadCount
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>