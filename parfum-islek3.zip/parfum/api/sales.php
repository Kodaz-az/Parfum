<?php
/**
 * Parfüm POS Sistemi - Sales API
 * Yaradıldığı tarix: 2025-07-21 10:43:37
 * Müəllif: Kodaz-az
 */

require_once '../classes/Sale.php';

$sale = new Sale();

switch ($method) {
    case 'GET':
        if ($id) {
            if ($id === 'stats') {
                handleGetSalesStats();
            } else if ($id === 'recent') {
                handleGetRecentSales();
            } else if ($id === 'export') {
                handleExportSales();
            } else {
                handleGetSale($id);
            }
        } else {
            handleGetSales();
        }
        break;
        
    case 'POST':
        if ($action === 'cancel') {
            handleCancelSale($id);
        } else if ($action === 'refund') {
            handleRefundSale($id);
        } else {
            handleCreateSale();
        }
        break;
        
    case 'PUT':
        if ($id) {
            handleUpdateSale($id);
        } else {
            throw new Exception('Sale ID required', 400);
        }
        break;
        
    case 'DELETE':
        if ($id) {
            handleDeleteSale($id);
        } else {
            throw new Exception('Sale ID required', 400);
        }
        break;
        
    default:
        throw new Exception('Method not allowed', 405);
}

function handleGetSales() {
    global $response, $sale, $user, $currentUser;
    
    $filters = [
        'search' => $_GET['search'] ?? '',
        'status' => $_GET['status'] ?? '',
        'payment_method' => $_GET['payment_method'] ?? '',
        'date_from' => $_GET['date_from'] ?? '',
        'date_to' => $_GET['date_to'] ?? '',
        'user_id' => $_GET['user_id'] ?? null,
        'order_by' => $_GET['order_by'] ?? 'created_at',
        'order_dir' => $_GET['order_dir'] ?? 'DESC',
        'limit' => intval($_GET['limit'] ?? 50),
        'offset' => intval($_GET['offset'] ?? 0)
    ];
    
    // Restrict to own sales for sellers
    if ($currentUser['role'] === 'seller') {
        $filters['user_id'] = $currentUser['id'];
    }
    
    $sales = $sale->getAllSales($filters);
    $total = $sale->getSalesCount($filters);
    
    $response['success'] = true;
    $response['data'] = [
        'sales' => $sales,
        'total' => $total,
        'filters' => $filters
    ];
}

function handleGetSale($saleId) {
    global $response, $sale, $user, $currentUser;
    
    $saleData = $sale->getSaleById($saleId);
    
    if (!$saleData) {
        throw new Exception('Sale not found', 404);
    }
    
    // Check permission - sellers can only view their own sales
    if ($currentUser['role'] === 'seller' && $saleData['user_id'] != $currentUser['id']) {
        throw new Exception('Permission denied', 403);
    }
    
    // Get sale details (products)
    $saleDetails = $sale->getSaleDetails($saleId);
    $saleData['items'] = $saleDetails;
    
    $response['success'] = true;
    $response['data'] = ['sale' => $saleData];
}

function handleGetRecentSales() {
    global $response, $sale, $currentUser;
    
    $limit = intval($_GET['limit'] ?? 10);
    $userId = ($currentUser['role'] === 'seller') ? $currentUser['id'] : null;
    
    $recentSales = $sale->getRecentSales($limit, $userId);
    
    $response['success'] = true;
    $response['data'] = ['sales' => $recentSales];
}

function handleGetSalesStats() {
    global $response, $sale, $currentUser;
    
    $filters = [
        'date_from' => $_GET['date_from'] ?? date('Y-m-01'),
        'date_to' => $_GET['date_to'] ?? date('Y-m-t'),
        'user_id' => $_GET['user_id'] ?? null
    ];
    
    // Restrict to own stats for sellers
    if ($currentUser['role'] === 'seller') {
        $filters['user_id'] = $currentUser['id'];
    }
    
    $stats = $sale->getSalesStatistics($filters);
    
    $response['success'] = true;
    $response['data'] = $stats;
}

function handleCreateSale() {
    global $response, $sale, $user, $currentUser;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $saleData = [
        'customer_name' => $input['customer_name'] ?? '',
        'customer_phone' => $input['customer_phone'] ?? '',
        'customer_email' => $input['customer_email'] ?? '',
        'payment_method' => $input['payment_method'] ?? 'cash',
        'payment_status' => $input['payment_status'] ?? 'completed',
        'discount_amount' => floatval($input['discount_amount'] ?? 0),
        'notes' => $input['notes'] ?? '',
        'user_id' => $currentUser['id']
    ];
    
    $saleDetails = $input['products'] ?? [];
    
    if (empty($saleDetails)) {
        throw new Exception('At least one product is required', 400);
    }
    
    // Validate products
    foreach ($saleDetails as &$item) {
        if (empty($item['product_id']) || empty($item['quantity'])) {
            throw new Exception('Product ID and quantity are required for all items', 400);
        }
        
        $item['product_id'] = intval($item['product_id']);
        $item['quantity'] = intval($item['quantity']);
        $item['unit_price'] = floatval($item['unit_price'] ?? 0);
        $item['discount_rate'] = floatval($item['discount_rate'] ?? 0);
        
        if ($item['quantity'] <= 0) {
            throw new Exception('Quantity must be greater than 0', 400);
        }
        
        if ($item['unit_price'] <= 0) {
            throw new Exception('Unit price must be greater than 0', 400);
        }
    }
    
    try {
        $saleId = $sale->createSale($saleData, $saleDetails);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'create_sale', "Created sale #$saleId");
        
        // Send real-time notification
        $this->sendSaleNotification($saleId, 'new_sale');
        
        $response['success'] = true;
        $response['message'] = 'Sale created successfully';
        $response['data'] = [
            'sale_id' => $saleId,
            'sale_number' => $sale->generateSaleNumber($saleId)
        ];
        
    } catch (Exception $e) {
        throw new Exception('Failed to create sale: ' . $e->getMessage(), 500);
    }
}

function handleUpdateSale($saleId) {
    global $response, $sale, $user, $currentUser;
    
    // Check if sale exists
    $saleData = $sale->getSaleById($saleId);
    if (!$saleData) {
        throw new Exception('Sale not found', 404);
    }
    
    // Check permission
    if ($currentUser['role'] === 'seller' && $saleData['user_id'] != $currentUser['id']) {
        throw new Exception('Permission denied', 403);
    }
    
    // Only allow updates for pending/draft sales
    if ($saleData['status'] !== 'pending' && $saleData['status'] !== 'draft') {
        throw new Exception('Cannot update completed or cancelled sales', 400);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $updateData = [];
    $allowedFields = [
        'customer_name', 'customer_phone', 'customer_email',
        'payment_method', 'payment_status', 'discount_amount', 'notes'
    ];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updateData[$field] = $input[$field];
        }
    }
    
    if (empty($updateData)) {
        throw new Exception('No valid fields to update', 400);
    }
    
    if ($sale->updateSale($saleId, $updateData)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'update_sale', "Updated sale #$saleId");
        
        $response['success'] = true;
        $response['message'] = 'Sale updated successfully';
    } else {
        throw new Exception('Failed to update sale', 500);
    }
}

function handleCancelSale($saleId) {
    global $response, $sale, $user, $currentUser;
    
    if (!$user->hasPermission('manage_sales')) {
        throw new Exception('Permission denied', 403);
    }
    
    $saleData = $sale->getSaleById($saleId);
    if (!$saleData) {
        throw new Exception('Sale not found', 404);
    }
    
    if ($saleData['status'] === 'cancelled') {
        throw new Exception('Sale is already cancelled', 400);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $reason = $input['reason'] ?? '';
    
    if ($sale->cancelSale($saleId, $reason)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'cancel_sale', "Cancelled sale #$saleId - Reason: $reason");
        
        $response['success'] = true;
        $response['message'] = 'Sale cancelled successfully';
    } else {
        throw new Exception('Failed to cancel sale', 500);
    }
}

function handleRefundSale($saleId) {
    global $response, $sale, $user, $currentUser;
    
    if (!$user->hasPermission('manage_sales')) {
        throw new Exception('Permission denied', 403);
    }
    
    $saleData = $sale->getSaleById($saleId);
    if (!$saleData) {
        throw new Exception('Sale not found', 404);
    }
    
    if ($saleData['status'] !== 'completed') {
        throw new Exception('Only completed sales can be refunded', 400);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $refundAmount = floatval($input['amount'] ?? $saleData['final_amount']);
    $reason = $input['reason'] ?? '';
    
    if ($refundAmount <= 0 || $refundAmount > $saleData['final_amount']) {
        throw new Exception('Invalid refund amount', 400);
    }
    
    if ($sale->refundSale($saleId, $refundAmount, $reason)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'refund_sale', "Refunded sale #$saleId - Amount: $refundAmount - Reason: $reason");
        
        $response['success'] = true;
        $response['message'] = 'Sale refunded successfully';
        $response['data'] = ['refund_amount' => $refundAmount];
    } else {
        throw new Exception('Failed to refund sale', 500);
    }
}

function handleDeleteSale($saleId) {
    global $response, $sale, $user, $currentUser;
    
    if (!$user->hasPermission('manage_sales')) {
        throw new Exception('Permission denied', 403);
    }
    
    $saleData = $sale->getSaleById($saleId);
    if (!$saleData) {
        throw new Exception('Sale not found', 404);
    }
    
    // Only allow deletion of draft sales
    if ($saleData['status'] !== 'draft') {
        throw new Exception('Only draft sales can be deleted', 400);
    }
    
    if ($sale->deleteSale($saleId)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'delete_sale', "Deleted sale #$saleId");
        
        $response['success'] = true;
        $response['message'] = 'Sale deleted successfully';
    } else {
        throw new Exception('Failed to delete sale', 500);
    }
}

function handleExportSales() {
    global $sale, $currentUser;
    
    $format = $_GET['format'] ?? 'csv';
    $filters = [
        'date_from' => $_GET['date_from'] ?? '',
        'date_to' => $_GET['date_to'] ?? '',
        'status' => $_GET['status'] ?? '',
        'user_id' => $_GET['user_id'] ?? null
    ];
    
    // Restrict to own sales for sellers
    if ($currentUser['role'] === 'seller') {
        $filters['user_id'] = $currentUser['id'];
    }
    
    $sales = $sale->getAllSales($filters);
    
    switch ($format) {
        case 'csv':
            exportSalesAsCSV($sales);
            break;
        case 'excel':
            exportSalesAsExcel($sales);
            break;
        case 'pdf':
            exportSalesAsPDF($sales);
            break;
        default:
            throw new Exception('Unsupported export format', 400);
    }
}

function exportSalesAsCSV($sales) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="sales_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // CSV header
    fputcsv($output, [
        'Sale Number', 'Date', 'Customer', 'Items', 'Subtotal', 
        'Discount', 'Tax', 'Total', 'Payment Method', 'Status', 'Seller'
    ]);
    
    // CSV data
    foreach ($sales as $sale) {
        fputcsv($output, [
            $sale['sale_number'],
            $sale['created_at'],
            $sale['customer_name'] ?: 'Walk-in Customer',
            $sale['total_items'],
            number_format($sale['subtotal'], 2),
            number_format($sale['discount_amount'], 2),
            number_format($sale['tax_amount'], 2),
            number_format($sale['final_amount'], 2),
            ucfirst($sale['payment_method']),
            ucfirst($sale['status']),
            $sale['seller_name']
        ]);
    }
    
    fclose($output);
    exit;
}

function exportSalesAsExcel($sales) {
    // For now, fall back to CSV
    // In production, you would use PhpSpreadsheet
    exportSalesAsCSV($sales);
}

function exportSalesAsPDF($sales) {
    // For now, fall back to CSV
    // In production, you would use a PDF library like TCPDF or FPDF
    exportSalesAsCSV($sales);
}

function sendSaleNotification($saleId, $type) {
    // Implementation for WebSocket notification
    // This would send real-time updates to connected clients
}
?>