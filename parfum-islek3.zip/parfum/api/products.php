<?php
/**
 * Parfüm POS Sistemi - Products API
 * Yaradıldığı tarix: 2025-07-21
 * Müəllif: Kodaz-az
 */

require_once '../classes/Product.php';

$product = new Product();

switch ($method) {
    case 'GET':
        if ($id) {
            if ($id === 'search') {
                handleSearchProducts();
            } else if ($id === 'export') {
                handleExportProducts();
            } else if ($id === 'generate-barcode') {
                handleGenerateBarcode();
            } else {
                handleGetProduct($id);
            }
        } else {
            handleGetProducts();
        }
        break;
        
    case 'POST':
        if ($action === 'import') {
            handleImportProducts();
        } else {
            handleCreateProduct();
        }
        break;
        
    case 'PUT':
        if ($id) {
            handleUpdateProduct($id);
        } else {
            throw new Exception('Product ID required', 400);
        }
        break;
        
    case 'DELETE':
        if ($id) {
            handleDeleteProduct($id);
        } else {
            throw new Exception('Product ID required', 400);
        }
        break;
        
    default:
        throw new Exception('Method not allowed', 405);
}

function handleGetProducts() {
    global $response, $product;
    
    $filters = [
        'search' => $_GET['search'] ?? '',
        'category' => $_GET['category'] ?? '',
        'brand' => $_GET['brand'] ?? '',
        'low_stock' => isset($_GET['low_stock']),
        'order_by' => $_GET['order_by'] ?? 'name',
        'order_dir' => $_GET['order_dir'] ?? 'ASC',
        'limit' => intval($_GET['limit'] ?? 50),
        'offset' => intval($_GET['offset'] ?? 0)
    ];
    
    $products = $product->getAllProducts($filters);
    $total = $product->getProductsCount($filters);
    
    $response['success'] = true;
    $response['data'] = [
        'products' => $products,
        'total' => $total,
        'filters' => $filters
    ];
}

function handleGetProduct($productId) {
    global $response, $product;
    
    $productData = $product->getProductById($productId);
    
    if (!$productData) {
        throw new Exception('Product not found', 404);
    }
    
    $response['success'] = true;
    $response['data'] = ['product' => $productData];
}

function handleSearchProducts() {
    global $response, $product;
    
    $query = $_GET['q'] ?? '';
    $limit = intval($_GET['limit'] ?? 20);
    
    if (strlen($query) < 2) {
        throw new Exception('Search query must be at least 2 characters', 400);
    }
    
    $products = $product->searchProducts($query, $limit);
    
    $response['success'] = true;
    $response['data'] = ['products' => $products];
}

function handleCreateProduct() {
    global $response, $product, $user, $currentUser;
    
    // Check permission
    if (!$user->hasPermission('manage_products')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $productData = [
        'name' => $input['name'] ?? '',
        'brand' => $input['brand'] ?? '',
        'category' => $input['category'] ?? '',
        'barcode' => $input['barcode'] ?? '',
        'price' => floatval($input['price'] ?? 0),
        'cost_price' => floatval($input['cost_price'] ?? 0),
        'stock_quantity' => intval($input['stock_quantity'] ?? 0),
        'min_stock' => intval($input['min_stock'] ?? 5),
        'description' => $input['description'] ?? '',
        'size' => $input['size'] ?? '',
        'gender' => $input['gender'] ?? 'unisex',
        'fragrance_family' => $input['fragrance_family'] ?? '',
        'top_notes' => $input['top_notes'] ?? '',
        'middle_notes' => $input['middle_notes'] ?? '',
        'base_notes' => $input['base_notes'] ?? ''
    ];
    
    // Validate required fields
    if (empty($productData['name'])) {
        throw new Exception('Product name is required', 400);
    }
    
    if ($productData['price'] <= 0) {
        throw new Exception('Product price must be greater than 0', 400);
    }
    
    // Generate barcode if not provided
    if (empty($productData['barcode'])) {
        $productData['barcode'] = $product->generateBarcode();
    }
    
    // Check if barcode already exists
    if ($product->barcodeExists($productData['barcode'])) {
        throw new Exception('Barcode already exists', 409);
    }
    
    $productId = $product->createProduct($productData);
    
    if ($productId) {
        // Log activity
        $user->logActivity($currentUser['id'], 'create_product', "Created product: {$productData['name']}");
        
        $response['success'] = true;
        $response['message'] = 'Product created successfully';
        $response['data'] = ['product_id' => $productId];
    } else {
        throw new Exception('Failed to create product', 500);
    }
}

function handleUpdateProduct($productId) {
    global $response, $product, $user, $currentUser;
    
    // Check permission
    if (!$user->hasPermission('manage_products')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Check if product exists
    $existingProduct = $product->getProductById($productId);
    if (!$existingProduct) {
        throw new Exception('Product not found', 404);
    }
    
    $updateData = [];
    
    // Fields that can be updated
    $allowedFields = [
        'name', 'brand', 'category', 'barcode', 'price', 'cost_price', 
        'stock_quantity', 'min_stock', 'description', 'size', 'gender',
        'fragrance_family', 'top_notes', 'middle_notes', 'base_notes'
    ];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updateData[$field] = $input[$field];
        }
    }
    
    // Validate price if provided
    if (isset($updateData['price']) && $updateData['price'] <= 0) {
        throw new Exception('Product price must be greater than 0', 400);
    }
    
    // Check barcode uniqueness if changed
    if (isset($updateData['barcode']) && $updateData['barcode'] !== $existingProduct['barcode']) {
        if ($product->barcodeExists($updateData['barcode'])) {
            throw new Exception('Barcode already exists', 409);
        }
    }
    
    if (empty($updateData)) {
        throw new Exception('No valid fields to update', 400);
    }
    
    if ($product->updateProduct($productId, $updateData)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'update_product', "Updated product: {$existingProduct['name']}");
        
        $response['success'] = true;
        $response['message'] = 'Product updated successfully';
    } else {
        throw new Exception('Failed to update product', 500);
    }
}

function handleDeleteProduct($productId) {
    global $response, $product, $user, $currentUser;
    
    // Check permission
    if (!$user->hasPermission('manage_products')) {
        throw new Exception('Permission denied', 403);
    }
    
    $productData = $product->getProductById($productId);
    if (!$productData) {
        throw new Exception('Product not found', 404);
    }
    
    if ($product->deleteProduct($productId)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'delete_product', "Deleted product: {$productData['name']}");
        
        $response['success'] = true;
        $response['message'] = 'Product deleted successfully';
    } else {
        throw new Exception('Failed to delete product', 500);
    }
}

function handleGenerateBarcode() {
    global $response, $product;
    
    $barcode = $product->generateBarcode();
    
    $response['success'] = true;
    $response['data'] = ['barcode' => $barcode];
}

function handleExportProducts() {
    global $product;
    
    $format = $_GET['format'] ?? 'csv';
    $filters = [
        'search' => $_GET['search'] ?? '',
        'category' => $_GET['category'] ?? '',
        'brand' => $_GET['brand'] ?? ''
    ];
    
    $products = $product->getAllProducts($filters);
    
    switch ($format) {
        case 'csv':
            exportAsCSV($products);
            break;
        case 'excel':
            exportAsExcel($products);
            break;
        case 'json':
            exportAsJSON($products);
            break;
        default:
            throw new Exception('Unsupported export format', 400);
    }
}

function handleImportProducts() {
    global $response, $product, $user, $currentUser;
    
    // Check permission
    if (!$user->hasPermission('manage_products')) {
        throw new Exception('Permission denied', 403);
    }
    
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('File upload error', 400);
    }
    
    $file = $_FILES['file'];
    $fileType = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($fileType, ['csv', 'xlsx'])) {
        throw new Exception('Only CSV and Excel files are supported', 400);
    }
    
    $imported = 0;
    $errors = [];
    
    try {
        if ($fileType === 'csv') {
            $result = $product->importFromCSV($file['tmp_name']);
        } else {
            $result = $product->importFromExcel($file['tmp_name']);
        }
        
        $imported = $result['imported'];
        $errors = $result['errors'];
        
        // Log activity
        $user->logActivity($currentUser['id'], 'import_products', "Imported {$imported} products");
        
        $response['success'] = true;
        $response['message'] = "Successfully imported {$imported} products";
        $response['data'] = [
            'imported' => $imported,
            'errors' => $errors
        ];
        
    } catch (Exception $e) {
        throw new Exception('Import failed: ' . $e->getMessage(), 500);
    }
}

function exportAsCSV($products) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="products_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // CSV header
    fputcsv($output, [
        'ID', 'Name', 'Brand', 'Category', 'Barcode', 'Price', 'Cost Price',
        'Stock Quantity', 'Min Stock', 'Size', 'Gender', 'Description'
    ]);
    
    // CSV data
    foreach ($products as $product) {
        fputcsv($output, [
            $product['id'],
            $product['name'],
            $product['brand'],
            $product['category'],
            $product['barcode'],
            $product['price'],
            $product['cost_price'],
            $product['stock_quantity'],
            $product['min_stock'],
            $product['size'],
            $product['gender'],
            $product['description']
        ]);
    }
    
    fclose($output);
    exit;
}

function exportAsJSON($products) {
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="products_' . date('Y-m-d') . '.json"');
    
    echo json_encode($products, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function exportAsExcel($products) {
    // This would require a library like PhpSpreadsheet
    // For now, we'll fall back to CSV
    exportAsCSV($products);
}
?>