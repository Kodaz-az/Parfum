<?php
/**
 * Parfüm POS Sistemi - Chat API
 * Yaradıldığı tarix: 2025-07-21 10:43:37
 * Müəllif: Kodaz-az
 */

require_once '../classes/Chat.php';

$chat = new Chat();

switch ($method) {
    case 'GET':
        if ($id) {
            if ($id === 'rooms') {
                handleGetChatRooms();
            } else if ($id === 'messages') {
                handleGetMessages();
            } else if ($id === 'online') {
                handleGetOnlineUsers();
            } else {
                handleGetChatRoom($id);
            }
        } else {
            handleGetChats();
        }
        break;
        
    case 'POST':
        if ($action === 'send') {
            handleSendMessage();
        } else if ($action === 'create-room') {
            handleCreateChatRoom();
        } else if ($action === 'join') {
            handleJoinRoom($id);
        } else if ($action === 'leave') {
            handleLeaveRoom($id);
        } else if ($action === 'mark-read') {
            handleMarkAsRead($id);
        } else {
            throw new Exception('Invalid chat action', 400);
        }
        break;
        
    case 'PUT':
        if ($id && $action === 'edit') {
            handleEditMessage($id);
        } else {
            throw new Exception('Invalid chat endpoint', 400);
        }
        break;
        
    case 'DELETE':
        if ($id) {
            handleDeleteMessage($id);
        } else {
            throw new Exception('Message ID required', 400);
        }
        break;
        
    default:
        throw new Exception('Method not allowed', 405);
}

function handleGetChats() {
    global $response, $chat, $currentUser;
    
    $chats = $chat->getUserChats($currentUser['id']);
    
    $response['success'] = true;
    $response['data'] = ['chats' => $chats];
}

function handleGetChatRooms() {
    global $response, $chat, $currentUser;
    
    $rooms = $chat->getChatRooms($currentUser['id']);
    
    $response['success'] = true;
    $response['data'] = ['rooms' => $rooms];
}

function handleGetChatRoom($roomId) {
    global $response, $chat, $currentUser;
    
    $room = $chat->getChatRoom($roomId);
    
    if (!$room) {
        throw new Exception('Chat room not found', 404);
    }
    
    // Check if user is member of the room
    if (!$chat->isRoomMember($roomId, $currentUser['id'])) {
        throw new Exception('Access denied to this chat room', 403);
    }
    
    $response['success'] = true;
    $response['data'] = ['room' => $room];
}

function handleGetMessages() {
    global $response, $chat, $currentUser;
    
    $roomId = $_GET['room_id'] ?? null;
    $userId = $_GET['user_id'] ?? null;
    $limit = intval($_GET['limit'] ?? 50);
    $offset = intval($_GET['offset'] ?? 0);
    $before = $_GET['before'] ?? null;
    
    if (!$roomId && !$userId) {
        throw new Exception('Either room_id or user_id is required', 400);
    }
    
    if ($roomId) {
        // Check room access
        if (!$chat->isRoomMember($roomId, $currentUser['id'])) {
            throw new Exception('Access denied to this chat room', 403);
        }
        
        $messages = $chat->getRoomMessages($roomId, $limit, $offset, $before);
    } else {
        // Direct messages between users
        $messages = $chat->getDirectMessages($currentUser['id'], $userId, $limit, $offset, $before);
    }
    
    $response['success'] = true;
    $response['data'] = [
        'messages' => $messages,
        'has_more' => count($messages) === $limit
    ];
}

function handleGetOnlineUsers() {
    global $response, $user;
    
    $onlineUsers = $user->getOnlineUsers();
    
    $response['success'] = true;
    $response['data'] = ['users' => $onlineUsers];
}

function handleSendMessage() {
    global $response, $chat, $user, $currentUser;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $messageData = [
        'room_id' => $input['room_id'] ?? null,
        'recipient_id' => $input['recipient_id'] ?? null,
        'message_type' => $input['message_type'] ?? 'text',
        'content' => $input['content'] ?? '',
        'reply_to' => $input['reply_to'] ?? null,
        'sender_id' => $currentUser['id']
    ];
    
    // Validate message
    if (empty($messageData['content']) && $messageData['message_type'] === 'text') {
        throw new Exception('Message content cannot be empty', 400);
    }
    
    if (!$messageData['room_id'] && !$messageData['recipient_id']) {
        throw new Exception('Either room_id or recipient_id is required', 400);
    }
    
    // Check room access if sending to room
    if ($messageData['room_id']) {
        if (!$chat->isRoomMember($messageData['room_id'], $currentUser['id'])) {
            throw new Exception('Access denied to this chat room', 403);
        }
    }
    
    // Handle file uploads
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $uploadResult = $chat->uploadFile($_FILES['file'], $currentUser['id']);
        if ($uploadResult) {
            $messageData['message_type'] = $uploadResult['type'];
            $messageData['content'] = $uploadResult['path'];
            $messageData['metadata'] = json_encode([
                'original_name' => $uploadResult['original_name'],
                'file_size' => $uploadResult['file_size'],
                'mime_type' => $uploadResult['mime_type']
            ]);
        }
    }
    
    try {
        $messageId = $chat->sendMessage($messageData);
        
        // Get the complete message data
        $message = $chat->getMessage($messageId);
        
        // Send real-time notification
        $this->sendChatNotification($message);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'send_message', "Sent message");
        
        $response['success'] = true;
        $response['message'] = 'Message sent successfully';
        $response['data'] = ['message' => $message];
        
    } catch (Exception $e) {
        throw new Exception('Failed to send message: ' . $e->getMessage(), 500);
    }
}

function handleCreateChatRoom() {
    global $response, $chat, $user, $currentUser;
    
    if (!$user->hasPermission('create_chat_rooms')) {
        throw new Exception('Permission denied', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $roomData = [
        'name' => $input['name'] ?? '',
        'description' => $input['description'] ?? '',
        'type' => $input['type'] ?? 'group',
        'is_private' => isset($input['is_private']) ? 1 : 0,
        'created_by' => $currentUser['id']
    ];
    
    $members = $input['members'] ?? [];
    
    if (empty($roomData['name'])) {
        throw new Exception('Room name is required', 400);
    }
    
    if (!in_array($roomData['type'], ['group', 'channel', 'direct'])) {
        throw new Exception('Invalid room type', 400);
    }
    
    try {
        $roomId = $chat->createChatRoom($roomData, $members);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'create_chat_room', "Created chat room: {$roomData['name']}");
        
        $response['success'] = true;
        $response['message'] = 'Chat room created successfully';
        $response['data'] = ['room_id' => $roomId];
        
    } catch (Exception $e) {
        throw new Exception('Failed to create chat room: ' . $e->getMessage(), 500);
    }
}

function handleJoinRoom($roomId) {
    global $response, $chat, $user, $currentUser;
    
    $room = $chat->getChatRoom($roomId);
    if (!$room) {
        throw new Exception('Chat room not found', 404);
    }
    
    // Check if room is private and user has permission
    if ($room['is_private'] && !$user->hasPermission('join_private_rooms')) {
        throw new Exception('Permission denied to join private room', 403);
    }
    
    if ($chat->joinRoom($roomId, $currentUser['id'])) {
        // Log activity
        $user->logActivity($currentUser['id'], 'join_chat_room', "Joined chat room: {$room['name']}");
        
        $response['success'] = true;
        $response['message'] = 'Successfully joined the chat room';
    } else {
        throw new Exception('Failed to join chat room', 500);
    }
}

function handleLeaveRoom($roomId) {
    global $response, $chat, $user, $currentUser;
    
    $room = $chat->getChatRoom($roomId);
    if (!$room) {
        throw new Exception('Chat room not found', 404);
    }
    
    if (!$chat->isRoomMember($roomId, $currentUser['id'])) {
        throw new Exception('You are not a member of this room', 400);
    }
    
    if ($chat->leaveRoom($roomId, $currentUser['id'])) {
        // Log activity
        $user->logActivity($currentUser['id'], 'leave_chat_room', "Left chat room: {$room['name']}");
        
        $response['success'] = true;
        $response['message'] = 'Successfully left the chat room';
    } else {
        throw new Exception('Failed to leave chat room', 500);
    }
}

function handleMarkAsRead($messageId) {
    global $response, $chat, $currentUser;
    
    if ($chat->markMessageAsRead($messageId, $currentUser['id'])) {
        $response['success'] = true;
        $response['message'] = 'Message marked as read';
    } else {
        throw new Exception('Failed to mark message as read', 500);
    }
}

function handleEditMessage($messageId) {
    global $response, $chat, $user, $currentUser;
    
    $message = $chat->getMessage($messageId);
    if (!$message) {
        throw new Exception('Message not found', 404);
    }
    
    // Only allow editing own messages
    if ($message['sender_id'] != $currentUser['id']) {
        throw new Exception('You can only edit your own messages', 403);
    }
    
    // Only allow editing within 5 minutes
    $messageTime = strtotime($message['created_at']);
    if (time() - $messageTime > 300) { // 5 minutes
        throw new Exception('Messages can only be edited within 5 minutes', 400);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $newContent = $input['content'] ?? '';
    
    if (empty($newContent)) {
        throw new Exception('Message content cannot be empty', 400);
    }
    
    if ($chat->editMessage($messageId, $newContent)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'edit_message', "Edited message");
        
        $response['success'] = true;
        $response['message'] = 'Message edited successfully';
    } else {
        throw new Exception('Failed to edit message', 500);
    }
}

function handleDeleteMessage($messageId) {
    global $response, $chat, $user, $currentUser;
    
    $message = $chat->getMessage($messageId);
    if (!$message) {
        throw new Exception('Message not found', 404);
    }
    
    // Allow deletion of own messages or if user has admin permissions
    $canDelete = ($message['sender_id'] == $currentUser['id']) || 
                 $user->hasPermission('delete_any_message');
    
    if (!$canDelete) {
        throw new Exception('Permission denied', 403);
    }
    
    if ($chat->deleteMessage($messageId)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'delete_message', "Deleted message");
        
        $response['success'] = true;
        $response['message'] = 'Message deleted successfully';
    } else {
        throw new Exception('Failed to delete message', 500);
    }
}

function sendChatNotification($message) {
    // Implementation for WebSocket notification
    // This would send real-time chat updates to connected clients
}
?>