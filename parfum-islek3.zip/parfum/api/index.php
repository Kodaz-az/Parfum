<?php
/**
 * Parfüm POS Sistemi - API Base
 * Yaradıldığı tarix: 2025-07-21
 * Müəllif: Kodaz-az
 */

require_once '../config/config.php';
require_once '../includes/database.php';
require_once '../classes/User.php';

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-TOKEN, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Get request method and endpoint
$method = $_SERVER['REQUEST_METHOD'];
$request = $_SERVER['REQUEST_URI'];
$path = parse_url($request, PHP_URL_PATH);

// Remove base path
$basePath = '/parfum-pos/api';
$endpoint = str_replace($basePath, '', $path);
$endpoint = trim($endpoint, '/');

// Parse endpoint parts
$parts = explode('/', $endpoint);
$resource = $parts[0] ?? '';
$id = $parts[1] ?? null;
$action = $parts[2] ?? null;

// Initialize response
$response = [
    'success' => false,
    'message' => 'Invalid request',
    'data' => null,
    'timestamp' => date('Y-m-d H:i:s')
];

try {
    // Authentication check for protected endpoints
    $user = new User();
    $currentUser = null;
    
    // Public endpoints that don't require authentication
    $publicEndpoints = ['auth/login', 'auth/register', 'system/status'];
    $isPublic = in_array($endpoint, $publicEndpoints);
    
    if (!$isPublic) {
        // Check for valid session or API key
        if (!$user->isLoggedIn()) {
            // Check for API key in headers
            $apiKey = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
            if (strpos($apiKey, 'Bearer ') === 0) {
                $apiKey = substr($apiKey, 7);
                $currentUser = $user->validateApiKey($apiKey);
                if (!$currentUser) {
                    throw new Exception('Invalid API key', 401);
                }
            } else {
                throw new Exception('Authentication required', 401);
            }
        } else {
            $currentUser = $user->getCurrentUser();
        }
    }
    
    // Route requests to appropriate handlers
    switch ($resource) {
        case 'auth':
            require_once 'auth.php';
            break;
            
        case 'users':
            require_once 'users.php';
            break;
            
        case 'products':
            require_once 'products.php';
            break;
            
        case 'sales':
            require_once 'sales.php';
            break;
            
        case 'chat':
            require_once 'chat.php';
            break;
            
        case 'calls':
            require_once 'calls.php';
            break;
            
        case 'notifications':
            require_once 'notifications.php';
            break;
            
        case 'reports':
            require_once 'reports.php';
            break;
            
        case 'salary':
            require_once 'salary.php';
            break;
            
        case 'system':
            require_once 'system.php';
            break;
            
        default:
            throw new Exception('Endpoint not found', 404);
    }
    
} catch (Exception $e) {
    $statusCode = $e->getCode() ?: 500;
    $response['message'] = $e->getMessage();
    
    // Log error
    error_log("API Error [{$endpoint}]: " . $e->getMessage());
    
    http_response_code($statusCode);
}

// Send JSON response
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>