<?php
/**
 * Parfüm POS Sistemi - Calls API
 * Yaradıldığı tarix: 2025-07-21 10:43:37
 * Müəllif: Kodaz-az
 */

require_once '../classes/Call.php';

$call = new Call();

switch ($method) {
    case 'GET':
        if ($id) {
            if ($id === 'history') {
                handleGetCallHistory();
            } else if ($id === 'stats') {
                handleGetCallStats();
            } else if ($id === 'missed') {
                handleGetMissedCalls();
            } else {
                handleGetCall($id);
            }
        } else {
            handleGetCalls();
        }
        break;
        
    case 'POST':
        if ($action === 'initiate') {
            handleInitiateCall();
        } else if ($action === 'answer') {
            handleAnswerCall($id);
        } else if ($action === 'reject') {
            handleRejectCall($id);
        } else if ($action === 'end') {
            handleEndCall($id);
        } else if ($action === 'signaling') {
            handleSignaling();
        } else {
            throw new Exception('Invalid call action', 400);
        }
        break;
        
    case 'PUT':
        if ($id) {
            handleUpdateCall($id);
        } else {
            throw new Exception('Call ID required', 400);
        }
        break;
        
    default:
        throw new Exception('Method not allowed', 405);
}

function handleGetCalls() {
    global $response, $call, $currentUser;
    
    $filters = [
        'user_id' => $_GET['user_id'] ?? $currentUser['id'],
        'status' => $_GET['status'] ?? '',
        'call_type' => $_GET['call_type'] ?? '',
        'date_from' => $_GET['date_from'] ?? '',
        'date_to' => $_GET['date_to'] ?? '',
        'limit' => intval($_GET['limit'] ?? 20),
        'offset' => intval($_GET['offset'] ?? 0)
    ];
    
    $calls = $call->getCalls($filters);
    $total = $call->getCallsCount($filters);
    
    $response['success'] = true;
    $response['data'] = [
        'calls' => $calls,
        'total' => $total,
        'filters' => $filters
    ];
}

function handleGetCall($callId) {
    global $response, $call, $currentUser;
    
    $callData = $call->getCallById($callId);
    
    if (!$callData) {
        throw new Exception('Call not found', 404);
    }
    
    // Check if user is participant in the call
    if ($callData['caller_id'] != $currentUser['id'] && 
        !in_array($currentUser['id'], $callData['participants'])) {
        throw new Exception('Access denied to this call', 403);
    }
    
    $response['success'] = true;
    $response['data'] = ['call' => $callData];
}

function handleGetCallHistory() {
    global $response, $call, $currentUser;
    
    $userId = $_GET['user_id'] ?? $currentUser['id'];
    $limit = intval($_GET['limit'] ?? 20);
    
    // Users can only view their own call history unless they have admin permissions
    if ($userId != $currentUser['id'] && !$user->hasPermission('view_all_calls')) {
        $userId = $currentUser['id'];
    }
    
    $history = $call->getCallHistory($userId, $limit);
    
    $response['success'] = true;
    $response['data'] = ['history' => $history];
}

function handleGetCallStats() {
    global $response, $call, $currentUser;
    
    $userId = $_GET['user_id'] ?? $currentUser['id'];
    
    // Users can only view their own stats unless they have admin permissions
    if ($userId != $currentUser['id'] && !$user->hasPermission('view_all_calls')) {
        $userId = $currentUser['id'];
    }
    
    $stats = $call->getCallStatistics($userId);
    
    $response['success'] = true;
    $response['data'] = $stats;
}

function handleGetMissedCalls() {
    global $response, $call, $currentUser;
    
    $missedCalls = $call->getMissedCalls($currentUser['id']);
    
    $response['success'] = true;
    $response['data'] = ['missed_calls' => $missedCalls];
}

function handleInitiateCall() {
    global $response, $call, $user, $currentUser;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $callData = [
        'caller_id' => $currentUser['id'],
        'recipient_id' => intval($input['user_id'] ?? 0),
        'call_type' => $input['call_type'] ?? 'audio'
    ];
    
    if (empty($callData['recipient_id'])) {
        throw new Exception('Recipient user ID is required', 400);
    }
    
    if (!in_array($callData['call_type'], ['audio', 'video'])) {
        throw new Exception('Invalid call type', 400);
    }
    
    // Check if recipient exists and is online
    $recipient = $user->getUserById($callData['recipient_id']);
    if (!$recipient) {
        throw new Exception('Recipient not found', 404);
    }
    
    if (!$user->isUserOnline($callData['recipient_id'])) {
        throw new Exception('Recipient is not online', 400);
    }
    
    // Check if there's already an active call between these users
    if ($call->hasActiveCall($currentUser['id'], $callData['recipient_id'])) {
        throw new Exception('There is already an active call between these users', 409);
    }
    
    try {
        $callId = $call->initiateCall($callData);
        
        // Send real-time notification to recipient
        $this->sendCallNotification($callId, 'incoming', $callData['recipient_id']);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'initiate_call', "Initiated {$callData['call_type']} call to user {$callData['recipient_id']}");
        
        $response['success'] = true;
        $response['message'] = 'Call initiated successfully';
        $response['data'] = ['call_id' => $callId];
        
    } catch (Exception $e) {
        throw new Exception('Failed to initiate call: ' . $e->getMessage(), 500);
    }
}

function handleAnswerCall($callId) {
    global $response, $call, $user, $currentUser;
    
    $callData = $call->getCallById($callId);
    if (!$callData) {
        throw new Exception('Call not found', 404);
    }
    
    // Only the recipient can answer the call
    if ($callData['recipient_id'] != $currentUser['id']) {
        throw new Exception('You can only answer calls made to you', 403);
    }
    
    if ($callData['status'] !== 'calling') {
        throw new Exception('Call cannot be answered in current state', 400);
    }
    
    if ($call->answerCall($callId)) {
        // Send real-time notification to caller
        $this->sendCallNotification($callId, 'answered', $callData['caller_id']);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'answer_call', "Answered call #$callId");
        
        $response['success'] = true;
        $response['message'] = 'Call answered successfully';
    } else {
        throw new Exception('Failed to answer call', 500);
    }
}

function handleRejectCall($callId) {
    global $response, $call, $user, $currentUser;
    
    $callData = $call->getCallById($callId);
    if (!$callData) {
        throw new Exception('Call not found', 404);
    }
    
    // Only the recipient can reject the call
    if ($callData['recipient_id'] != $currentUser['id']) {
        throw new Exception('You can only reject calls made to you', 403);
    }
    
    if ($callData['status'] !== 'calling') {
        throw new Exception('Call cannot be rejected in current state', 400);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    $reason = $input['reason'] ?? '';
    
    if ($call->rejectCall($callId, $reason)) {
        // Send real-time notification to caller
        $this->sendCallNotification($callId, 'rejected', $callData['caller_id']);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'reject_call', "Rejected call #$callId");
        
        $response['success'] = true;
        $response['message'] = 'Call rejected successfully';
    } else {
        throw new Exception('Failed to reject call', 500);
    }
}

function handleEndCall($callId) {
    global $response, $call, $user, $currentUser;
    
    $callData = $call->getCallById($callId);
    if (!$callData) {
        throw new Exception('Call not found', 404);
    }
    
    // Only participants can end the call
    $isParticipant = ($callData['caller_id'] == $currentUser['id']) || 
                     ($callData['recipient_id'] == $currentUser['id']);
    
    if (!$isParticipant) {
        throw new Exception('You can only end calls you are participating in', 403);
    }
    
    if (!in_array($callData['status'], ['calling', 'active'])) {
        throw new Exception('Call cannot be ended in current state', 400);
    }
    
    if ($call->endCall($callId)) {
        // Send real-time notification to other participant
        $otherParticipantId = ($callData['caller_id'] == $currentUser['id']) ? 
                              $callData['recipient_id'] : $callData['caller_id'];
        
        $this->sendCallNotification($callId, 'ended', $otherParticipantId);
        
        // Log activity
        $user->logActivity($currentUser['id'], 'end_call', "Ended call #$callId");
        
        $response['success'] = true;
        $response['message'] = 'Call ended successfully';
    } else {
        throw new Exception('Failed to end call', 500);
    }
}

function handleSignaling() {
    global $response, $call, $currentUser;
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $signalingData = [
        'call_id' => intval($input['call_id'] ?? 0),
        'type' => $input['type'] ?? '',
        'data' => $input['data'] ?? null,
        'sender_id' => $currentUser['id']
    ];
    
    if (empty($signalingData['call_id']) || empty($signalingData['type'])) {
        throw new Exception('Call ID and signaling type are required', 400);
    }
    
    $callData = $call->getCallById($signalingData['call_id']);
    if (!$callData) {
        throw new Exception('Call not found', 404);
    }
    
    // Check if user is participant in the call
    $isParticipant = ($callData['caller_id'] == $currentUser['id']) || 
                     ($callData['recipient_id'] == $currentUser['id']);
    
    if (!$isParticipant) {
        throw new Exception('Access denied to this call', 403);
    }
    
    // Store signaling data and forward to other participant
    if ($call->storeSignalingData($signalingData)) {
        // Send to other participant via WebSocket
        $otherParticipantId = ($callData['caller_id'] == $currentUser['id']) ? 
                              $callData['recipient_id'] : $callData['caller_id'];
        
        $this->sendSignalingMessage($signalingData, $otherParticipantId);
        
        $response['success'] = true;
        $response['message'] = 'Signaling data sent successfully';
    } else {
        throw new Exception('Failed to process signaling data', 500);
    }
}

function handleUpdateCall($callId) {
    global $response, $call, $user, $currentUser;
    
    $callData = $call->getCallById($callId);
    if (!$callData) {
        throw new Exception('Call not found', 404);
    }
    
    // Only participants can update the call
    $isParticipant = ($callData['caller_id'] == $currentUser['id']) || 
                     ($callData['recipient_id'] == $currentUser['id']);
    
    if (!$isParticipant) {
        throw new Exception('Access denied to this call', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $updateData = [];
    $allowedFields = ['quality_rating', 'feedback'];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $updateData[$field] = $input[$field];
        }
    }
    
    if (empty($updateData)) {
        throw new Exception('No valid fields to update', 400);
    }
    
    if ($call->updateCall($callId, $updateData)) {
        // Log activity
        $user->logActivity($currentUser['id'], 'update_call', "Updated call #$callId");
        
        $response['success'] = true;
        $response['message'] = 'Call updated successfully';
    } else {
        throw new Exception('Failed to update call', 500);
    }
}

function sendCallNotification($callId, $type, $recipientId) {
    // Implementation for WebSocket notification
    // This would send real-time call updates to connected clients
}

function sendSignalingMessage($signalingData, $recipientId) {
    // Implementation for WebSocket signaling
    // This would forward WebRTC signaling data between call participants
}
?>